# Changelog

## 0.3.0 (2026-09-29)
* **Graphical interface** (`lcsem gui`, `lcsem-gui`; napari): tabs for data (JEOL series, SE/BSE/STEM movies, finished
  runs), processing (detector combination, Monte Carlo detector model, calibration and references, denoising,
  particles, segmentation, objects, volume), run (worker thread with progress and abort, project save/load), display and
  export; time-resolved 3-D volumes that rotate with the mouse, a time slider at the bottom, charts that follow it (liquid
  and gas volume, thickness histogram, particle depth / classes / objects / SE contact). Automatic z exaggeration and
  content-centred oblique, top and side views. Projects (JSON) run without the interface: `lcsem project`. `docs/GUI.md`.
* **Movies** (`lcsem.io_movie`): multi-frame TIFF, AVI/MP4/MOV/MKV, image folders; one detector per file or several per
  frame (side by side, top/bottom, interleaved); frame time from the file or set; temporal windows; crop. Drift by chained,
  band-passed, windowed phase correlation (optional multi-baseline least squares). Movies as references.
  `lcsem movie-info`, `lcsem simulate-movie` (synthetic SE/BSE/STEM movies with ground truth, Poisson-Gaussian noise,
  changing or static scenes).
* **Denoising** (`lcsem.denoise`): Poisson-Gaussian noise model fitted per series, generalized Anscombe transform and its
  exact unbiased inverse; per frame NLM (default), BM3D, TV, Gaussian; per series MP-PCA, Gavish-Donoho SVD threshold,
  temporal mean/median. Benchmark with ground truth: `docs/VALIDATION_DENOISING.md`.
* **SE-only mode** (`lcsem.se_only`): contact maps, multi-Otsu levels, objects, nominal 3-D model.
* **Objects** (`lcsem.objects`, `lcsem objects`): bubbles/objects per frame (SE contact, gas, thin liquid or a class),
  watershed separation, measurements, IoU tracking with split/merge events, growth rates.
* **4-D model** (`lcsem.volume4d`): one voxel model for the GUI and every export (liquid/gas partial-volume fractions, walls
  and particles = 1, SE contact); lazy per frame, cached, next frame prefetched; time series over the field imaged in every
  frame; thickness clipped to [0, cap] before binning (as the 0.2.1 Amira export did).
* **Exports** (`lcsem.export_formats`, `lcsem export`): Amira, ImageJ/Fiji hyperstack, OME-TIFF, OME-Zarr, Imaris, VTK/ParaView,
  NRRD and NIfTI (3D Slicer, ITK-SNAP), MRC (ChimeraX, IMOD), meshes (STL, glTF), MATLAB, HDF5, CSV/Excel, TrackMate; each
  read back with an independent reader; missing libraries skip a format instead of stopping the export.
  `docs/EXPORT_FORMATS.md`.
* Amira export rebuilt on the 4-D model (identical voxels to the GUI and the other exports) and zlib-compressed (HxZip):
  20 MB instead of 463 MB for the 12k series. `lcsem.export_amira.read_am` reads it back.
* Configuration: mode "SE only" no longer requires a thickness channel. Movie run tags are `<name>_<k>_f<frame>`.
* Tests: `tests/test_v030.py` (movies, registration, noise model and GAT, denoisers, objects, 4-D model, all exports read
  back, Amira = model, projects, GUI headless).

Changes after the internal peer review (four reviewers; `docs/REVIEW_RESPONSE.md`):
* Detector modes: "BSE only" and "BSE + STEM" no longer pick up the SE channel (the mode was parsed by substrings);
  "SE only" works for JEOL series too.
* Calibration: no default flat-field thickness (an assumed flat field must be entered and is then shown as ASSUMED in the
  view and every export); a pre-flight check shows the calibration the references allow and refuses a run that would rest
  on a hidden assumption or lacks the pixel size; the analytical detector models were removed from the interface (they do
  not follow the Monte Carlo curves and fail with dark + empty references); dark + empty needs S(0) > 0; manual g != 0.
* SE contact map: shading-corrected, significance-based detection with half-contrast edges (no contact in frames without
  gas; areas within a few per cent); minimum region in um2 (0.01 by default); particle masks no longer cut the map.
* Particles: Hessian and isolation tests reject detections on bubble rims (98 % fewer false detections).
* Gas without a gap map: gap interpolated from the wet surroundings (robust quadratic surface), unbiased (unclipped) sums
  over the contact region and a margin; frames without SE have no gas value (NaN), SE-only volumes are NaN (nominal).
* Electron dose (`lcsem.dose`): per frame and cumulative fluence, dose rate, first-order absorbed dose; probe current in the
  Data tab; summary.csv, run_info, charts, view and export README.
* Movies: bit depth from the file (and a stop when data exceed it), frame time for interleaved files, OME TimeIncrement,
  natural file order, crop before splitting, near-duplicate frames flagged, *Preview first frame*; averaged time points keep
  the per-row clock (mean acquisition time per row); series denoising on whole-pixel-aligned frames in their own geometry,
  raw frames kept for photometry; registration region of interest; movie frame numbers in the run names.
* Runs: every run in its own folder (a non-empty output folder gets a new sub-folder); frames listed in run_info.json;
  clear errors for empty or mixed folders; project paths relative to the project file; lcsem version in the project.
* GUI: one job at a time; SystemExit and every other exception reported; closing the window aborts and waits; 2-D maps
  dock (thickness with a colour bar, SE contact outline, input frames with particles); record an MP4/GIF of the 3-D view;
  save the charts; particles without a measured depth drawn as vertical lines; calibration, dose and layer-model
  convention stated in the view; charts: gas NaN without SE, depth only from >= 5 particles, class caveat, dose chart.
* Objects: h-maxima markers (elongated objects are not over-split), row-time of each object, splits/merges by overlap with
  the smaller object, growth fit without border-touching frames, net speed instead of path length.
* Exports: every layer of the first, middle and last frame compared voxel by voxel, voxel size and origin checked; one
  voxel-centre origin in every format; NRRD (LPS) and NIfTI in the same units; MATLAB v7.3 fixed; provenance README.
* Packaging: curves shipped inside the package (`lcsem/data`), extras completed, conda environment without a second Qt;
  `lcsem export --list` without a run folder.
* Registration: the template refinement is off by default (it made the error larger on scenes without static features).
* Denoising benchmark corrected (registration sign, common field, three seeds, SSIM, task-level errors):
  `docs/VALIDATION_DENOISING.md`.

Changes after the second review round (all four reviewers: minor revision; `docs/REVIEW_RESPONSE.md`, round 2):
* SE contact map with contact over most of the field: a two-state background (one smooth shading for the wet and the contact
  state, fitted to the whole field) when the SE distribution is bimodal, else a robust fit from the brighter half that also
  ignores bright structure; discs up to 80 % and drying fronts up to 90 % of the field found at 0.97-0.99 of their area.
  New summary.csv columns: `se_detection_floor`, `se_contrast`, `se_background`, `se_contact_flag` (contact over half of the
  field), `se_signal` (the SE detector of each frame). The view states the 5 % detection limit and flags such frames.
* SE-only JEOL series use one SE detector (the chosen one) instead of alternating between in-lens and E-T images.
* Particles: fine scales first and a sector test on the ring (a ridge crosses it on opposite sides, a neighbour on one):
  close pairs (6-14 px) and particles next to a thickness step are kept; rims still give no false detections.
* Drift of movies measured on every frame, also when only every n-th frame is analysed (then subsampled).
* Series denoising in blocks of 32 time points, each on its own common field (flag map `denoised`); the segmentation no
  longer denoises already denoised frames; MP-PCA patches with p^2 >= 4T.
* Gas volume with its standard deviation (`gas_top_volume_um3`, `gas_top_volume_sd_um3`; spatially correlated residual of
  the wet surroundings); chart (b) with a +-2 sd band and points consistent with no gas; volume charts include zero. No gas
  value (NaN, maps key `gas_measured`) when the contact covers more than half of the field without a full-cell reference.
* Dose: a time point averaging W frames carries W frame fluences; the cumulative dose runs to its last frame.
* Calibration: no default flat field in the library either (`lcsem run`); a failed particle gain standard is explained
  (record an empty cell); reference movies are read with the movie's layout and crop; `simulate.make_movie` writes dark,
  empty and full-cell reference movies and a run in 'auto' was validated with them (`docs/VALIDATION.md`).
* Checks before a run: acquisition values shown, memory needed against free memory (the run is refused if it cannot fit);
  a thickness map stuck at one value or at the curve limits is reported (detector order, layout, calibration).
* GUI: a running job is listed in napari's close dialog and aborted only when the close is accepted (never terminated);
  movie recording streams frames; per-frame thickness access for the histogram; the view text wraps; SE-only maps say that
  no thickness channel was recorded; *Probe files* reads on until the repeat period of screen recordings is known.
* Viewing a run writes nothing into its folder (4-D model cache per user, `LCSEM_CACHE_DIR`).
* Objects: `drift_reference` says whether speeds include the registration error. Segmentation: `k_at_limit` column.
* Thickness errors labelled lower bounds (about 2.3x too small on synthetic movies) in the maps, the hover and METHODS.
* Exports: NIfTI written on the same physical grid as NRRD in ITK-based tools (origin and directions checked on read-back).
* Every run and project records `lcsem.build_id()` (version + revision date + source hash). Python >= 3.11 (napari 0.9
  needs it); SPDX license field. CLI and close-during-a-job tests.

## 0.2.1 (2026-09-27)
* Segmentation inside `lcsem run` (option `segmentation`, on by default when an SE channel is recorded) and on a finished run
  (`lcsem segment run_dir`): the recipe of the K-kit 1 PCA + GMM figure (thickness of the primary channel denoised with
  non-local means and smoothed at the fine scale only; NLM-denoised SE; two scales; |grad T|; ICL and BIC). New: the number
  of classes is the most frequent choice over independent random subsamples of the same size as the final fit
  (`stability_runs`, default 5; ICL/BIC depend on the number of points) and is reported with that frequency; `skip_rows`, `seed`, `figure_frame_list`. Outputs: `*_classes_<crit>.tif`, `*_class_prob_<crit>.tif`
  (continuous probabilities, one plane per class), `segmentation_classes.csv`, `segmentation_overview.png`.
* Amira export (`amira` option or `lcsem amira run_dir`): per frame AmiraMesh volumes with liquid and gas as partial-volume
  fractions (0-255, smooth isosurfaces, not binary); binary only for the cell edges (SiN membranes, window frame = 1) and the
  Au particles (= 1), plus exact-size particle spheres (`.surf`), landmarks, thickness/time maps and class probabilities;
  areas not imaged in a frame are empty. README_AMIRA.txt explains the time-series loading.
* Particle depth curve for the K-kit 1 data shipped: `data/curve_15kV_SiN30_H2O_BEDC_Au38.json` (38 nm Au, 15 kV, BED-C,
  100-800 nm water, five depths); the example configurations use it (`depth.curve`).
* Particle gain: with 8-bit saturated particle cores the depth-corrected gain falls back to the aperture photometry of all
  particles (logged); a particle calibration mode without usable particles now stops with a clear message.
* Relative file names in configurations resolve next to the configuration file or in the package folder.
* Monte Carlo: horizontal rods (`rod`), transverse profiles of rod-like objects (`transverse_profiles`), capsule rendering;
  E. coli model (`scenes.ECOLI`, compartments from Neidhardt 1990 / BioNumbers, envelope from Matias et al. 2003) and the
  example `examples/ecoli` (2 um K-kit, 15-30 kV, all detectors, depth cues, doses vs the lethal dose).
* Fix: `smooth_profile` used inverse-variance weights, which let the nearly noise-free bins outside an object dominate the
  kernel at its edge (profiles pulled towards zero there). Now a width-weighted Gaussian kernel. Effect on the rotavirus
  images of 0.2.0: below 0.2 percentage points of contrast.
* `maps.npz` also stores the outside-window mask and the fine-scale thickness used by the segmentation.

## 0.2.0 (2026-09-27)
* Channels: BSE, STEM-in-SEM (any semi-angle range) and SE (in-lens and/or E-T) from the same scans; thickness per channel,
  inverse-variance fusion and a chi2 disagreement map.
* References: dark (blanked), empty cell, full cell (gap map -> gas not touching the top membrane, label 4), flat field,
  particle standard, probe-current log; calibration 'auto' picks the best model and reports the redundant references as
  consistency checks (clipping-corrected reference levels).
* Particles in 3-D: core-fraction (one detector, one kV), BSE/STEM ratio, energy ratio; depth-corrected particle gain
  (top quarter of the liquid, local thickness); saturated/crowded particles flagged; trajectories, MSD.
* Monte Carlo v2: optical-depth-conserving transport for low-variance correlated sampling (weak-contrast objects), spheres,
  nested shells and cylinders, P S Na Cl added, 0.5-32 keV, detector library (BSE annular/axial/grazing, SE2, SE3, STEM
  BF/ADF/HAADF), radial-profile imaging of axisymmetric objects, rotavirus model.
* Synthetic data with ground truth (`lcsem simulate`) and validation of every option set (`lcsem validate`), incl. a
  detector-model-error test. 16-bit data supported (`bits`).
* Dynamics maps and 4-D stacks moved into the package; `lcsem list` shows channels and kV.
* v0.1 configurations still run and give identical thickness maps on the K-kit 1 data.

## 0.1.0
* BSE thickness with particle gain + flat field, SE contact map, gas gap, time maps, label volumes; PCA + GMM segmentation.
