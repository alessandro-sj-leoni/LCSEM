"""Tests for 0.3.0: movies, denoising, objects, the 4-D model, the exports (read back) and the GUI (headless, when a display
is available: run with xvfb-run on a server)."""
import os, sys, json, tempfile, numpy as np, pandas as pd
import pytest
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))


# ------------------------------------------------------------------------------------------------------------ movies
def _write_stack(fn, a, finterval=0.25):
    import tifffile
    tifffile.imwrite(fn, a, imagej=True, metadata={'axes': 'TYX', 'finterval': finterval})


def test_movie_source_layouts_and_times():
    from lcsem.io_movie import MovieSource, movie_scans, probe
    rng = np.random.default_rng(1); T, H, W = 6, 20, 30
    se = rng.integers(0, 100, (T, H, W)).astype(np.uint8); bse = (se + 100).astype(np.uint8)
    with tempfile.TemporaryDirectory() as d:
        _write_stack(os.path.join(d, 'se.tif'), se); _write_stack(os.path.join(d, 'sbs.tif'), np.concatenate([se, bse], axis=2))
        info = probe(os.path.join(d, 'se.tif')); assert info['n_frames'] == T and abs(info['fps'] - 4.0) < 1e-6
        a = MovieSource(os.path.join(d, 'sbs.tif'), layout='side_by_side', part=0, parts=2)
        b = MovieSource(os.path.join(d, 'sbs.tif'), layout='side_by_side', part=1, parts=2)
        assert np.array_equal(a.get(3), se[3]) and np.array_equal(b.get(3), bse[3])
        scans = movie_scans({'SE': a, 'BSE': b}, t0_s=100.0, window=2, step=2)
        assert len(scans) == 3 and scans[0].primary == 'BSE'
        # frame time from the file (0.25 s); a time point averages 2 frames: every row was recorded twice, so its clock is that of
        # one frame ending half a frame before the last one (mean acquisition time of each row), with the single-frame duration
        fr = scans[1].channels['BSE']
        assert abs(fr.time_s - (100.0 + (2 + 2) * 0.25 - 0.5 * 0.25)) < 1e-9 and fr.frame_s == 0.25 and fr.support_s == 0.5
        assert np.allclose(scans[0].channels['SE'].load(), se[:2].astype(np.float32).mean(0))


def test_register_stack_subpixel():
    from lcsem.io_movie import register_stack
    from scipy.ndimage import shift as nd_shift, gaussian_filter
    rng = np.random.default_rng(2); base = gaussian_filter(rng.normal(size=(160, 200)), 3) * 50 + 100
    true = np.cumsum(rng.normal(0, 1.5, (12, 2)), axis=0); true -= true[0]
    frames = np.stack([nd_shift(base, t, order=3, mode='reflect') + rng.normal(0, 2, base.shape) for t in true])
    sh = register_stack(frames, particles=False)
    err = (sh + true)[:, :]                               # shifts map each frame back onto frame 0: sh = -true
    assert np.max(np.abs(err[:, :] - err[0])) < 0.3


# ------------------------------------------------------------------------------------------------------------ denoising
def test_noise_model_and_gat():
    from lcsem import denoise as DN
    rng = np.random.default_rng(3); a, b = 2.0, 9.0
    x = np.tile(np.linspace(5, 120, 256), (256, 1))
    y = a * rng.poisson(x / a) + rng.normal(0, np.sqrt(b), x.shape)
    ae, be = DN.estimate_noise_model(y)
    assert abs(ae - a) / a < 0.2 and abs(be - b) < 6
    # exact unbiased inverse (Makitalo & Foi 2013): the mean of the inverse of the (noise-free) expected GAT is the signal
    lam = 3.0; z = a * rng.poisson(lam, 400000) + rng.normal(0, np.sqrt(b), 400000)
    back = DN.igat(np.array([DN.gat(z, a, b).mean()]), a, b)[0]
    assert abs(back - a * lam) / (a * lam) < 0.05


@pytest.mark.parametrize('method', ['gaussian', 'nlm', 'tv'])
def test_frame_denoisers_reduce_error(method):
    from lcsem import denoise as DN
    from scipy.ndimage import gaussian_filter
    rng = np.random.default_rng(4); Y, X = np.mgrid[:128, :128]
    clean = 60 + 80 * gaussian_filter(((X - 64) ** 2 + (Y - 64) ** 2 < 40 ** 2).astype(float), 3)      # a bubble with a soft edge
    noisy = rng.poisson(clean).astype(np.float32)
    out = DN.denoise_image(noisy, method, vst=True)
    assert np.sqrt(np.mean((out - clean) ** 2)) < 0.6 * np.sqrt(np.mean((noisy - clean) ** 2))


@pytest.mark.parametrize('method', ['mppca', 'svd_gd'])
def test_stack_denoisers_low_rank(method):
    from lcsem import denoise as DN
    rng = np.random.default_rng(5); T, H, W = 24, 64, 64
    Y, X = np.mgrid[:H, :W]; comp = [np.sin(X / 7.0), np.cos(Y / 5.0), ((X - 32) ** 2 + (Y - 32) ** 2 < 300).astype(float)]
    w = rng.normal(size=(T, 3)); clean = 100 + 20 * np.einsum('tk,kyx->tyx', w, np.stack(comp))
    noisy = clean + rng.normal(0, 8, clean.shape)
    out = DN.denoise_stack(noisy.astype(np.float32), method, vst=False)
    assert np.sqrt(np.mean((out - clean) ** 2)) < 0.5 * 8


# ------------------------------------------------------------------------------------------------------------ objects
def test_objects_split_measure_and_track():
    from lcsem.objects import split_objects, measure, link
    Y, X = np.mgrid[:120, :160]
    def discs(dx):
        return (((X - 55 - dx) ** 2 + (Y - 60) ** 2) < 25 ** 2) | (((X - 100 - dx) ** 2 + (Y - 60) ** 2) < 25 ** 2)
    L0 = split_objects(discs(0), min_area_px=50, min_distance_px=10); L1 = split_objects(discs(3), min_area_px=50, min_distance_px=10)
    assert L0.max() == 2 and L1.max() == 2                                  # two touching discs are split by the watershed
    maps = dict(gas_top=np.where(L0 > 0, 50.0, 0.0), gas_other=np.zeros(L0.shape), T=np.full(L0.shape, 200.0))
    m0 = pd.DataFrame(measure(L0, maps, (10.0, 10.0), (0.0, 0.0), (0, 0), 0.0)); assert len(m0) == 2
    area = np.pi * 25 ** 2 * 1e-4                                            # um^2 at 10 nm pixels
    assert np.all(np.abs(m0['area_um2'] - area) / area < 0.25)
    assert np.allclose(m0['gas_volume_um3'], m0['area_um2'] * 0.05, rtol=1e-6)   # 50 nm of gas over the object
    match, splits, merges = link(L0, L1, min_iou=0.1)
    assert len(match) == 2 and not splits and not merges
    for c, p in match.items():                                              # each disc keeps its identity
        assert abs(np.argwhere(L1 == c)[:, 1].mean() - 3 - np.argwhere(L0 == p)[:, 1].mean()) < 1.0


# ------------------------------------------------------------------------------------------------------------ 4-D model and exports
def fake_run(d, n=3, H=40, W=52, T0=200.0):
    """a minimal run folder (the files lcsem.volume4d reads), with a gas pocket at the top membrane and one particle"""
    cfg = dict(name='fake', pixel_nm=[10.0, 10.0], cell=dict(membranes_nm=[30.0, 30.0]), references=dict(particles=dict(diameter_nm=40.0)))
    info = dict(config=cfg, canvas=[H, W, 0, 0], drift=[[0.0, 0.0]] * n, mode='SE + BSE')
    json.dump(info, open(os.path.join(d, 'run_info.json'), 'w'))
    Y, X = np.mgrid[:H, :W]; rows = []
    for i in range(n):
        T = np.full((H, W), T0, np.float32) + 5 * X; gas = np.where((X - 20) ** 2 + (Y - 20) ** 2 < (6 + 2 * i) ** 2, 80.0, 0.0).astype(np.float32)
        np.savez(os.path.join(d, f'fake_{i}_f{i:05d}_maps.npz'), T=T, valid=np.ones((H, W), bool), au=np.zeros((H, W), bool), gas_top=gas,
                 gas_other=np.zeros((H, W), np.float32), outwin=np.zeros((H, W), bool), dark=(gas > 0).astype(np.float32), sT=np.full((H, W), 5, np.float32),
                 row_t=np.linspace(0, 1, H) + 10 * i)
        rows.append(dict(frame=i, time_end=f'10:00:{10 * i:02d}', liquid_nm_median=float(np.median(T))))
    pd.DataFrame(rows).to_csv(os.path.join(d, 'summary.csv'), index=False)
    pd.DataFrame(dict(frame=list(range(n)), x_nm=[300.0] * n, y_nm=[250.0] * n, z_nm=[60.0] * n, track=[0] * n)).to_csv(os.path.join(d, 'particles.csv'), index=False)
    return d


def test_volume4d_conserves_the_columns():
    from lcsem.volume4d import Volume4D
    with tempfile.TemporaryDirectory() as d:
        fake_run(d); V = Volume4D(d, bin=2, dz=10.0)
        fr = V.frame(1); liq = fr['liquid'].sum(axis=0) / 255.0 * V.dz; gas = fr['gas'].sum(axis=0) / 255.0 * V.dz
        T = V.m2['T'][1]; G = V.m2['gt'][1] + V.m2['go'][1]
        assert np.max(np.abs(liq - T)) < 0.5 * 255 ** -1 * V.nz * V.dz + 1e-6 or np.max(np.abs(liq - T)) < 2.0   # rounding to 1/255 per voxel
        assert np.max(np.abs(gas - G)) < 2.0
        assert fr['walls'][-3:].all() and fr['au'].sum() > 0                    # top membrane (flat) and the particle
        V2 = Volume4D(d, bin=2, dz=10.0); assert np.array_equal(V2.frame(1)['liquid'], fr['liquid'])     # from the cache file


def test_exports_read_back():
    from lcsem.export_formats import export_all, FORMATS
    with tempfile.TemporaryDirectory() as d:
        fake_run(d); out = os.path.join(d, 'export')
        M = export_all(d, out, list(FORMATS), bin=2, dz=10.0, check=True, log=lambda *a: None)
        assert set(M['format']) == set(FORMATS)
        bad = M[M['read_back'] == False]                                          # None = library missing, skipped
        assert len(bad) == 0, bad[['format', 'reader']].to_string()


def test_amira_equals_model():
    from lcsem.volume4d import Volume4D
    from lcsem.export_amira import export_run, read_am
    with tempfile.TemporaryDirectory() as d:
        fake_run(d); V = Volume4D(d, bin=2, dz=10.0); out = export_run(d, os.path.join(d, 'am'), volume=V, log=lambda *a: None)
        for i, tag in enumerate(V.tags):
            for kind, fn in (('liquid', 'liquid_fraction'), ('gas', 'gas_fraction'), ('walls', 'cell_walls'), ('au', 'au_nps')):
                a, _ = read_am(os.path.join(out, f'{tag}_{fn}.am')); assert np.array_equal(a, V.frame(i)[kind])


# ------------------------------------------------------------------------------------------------------------ project and GUI
def test_project_roundtrip_and_configs():
    from lcsem.gui.project import new_project, save_project, load_project, to_config, MODES, MODELS
    with tempfile.TemporaryDirectory() as d:
        for mode in MODES:
            for model in MODELS[::2]:
                p = new_project(mode=mode, model=dict(kind=model), out_dir=d, source='movie', movie=dict(files=dict(SE='a.tif', BSE='b.tif', STEM='c.tif')))
                cfg = to_config(p, d); assert cfg['mode'] == mode and cfg['registration']['method'] == 'phase'
        fn = os.path.join(d, 'p.json'); save_project(p, fn); q = load_project(fn); assert q['mode'] == p['mode'] and q['volume'] == p['volume']


def _display_ok():
    if not os.environ.get('DISPLAY'): return False
    try:
        import napari  # noqa: F401
        return True
    except Exception: return False


@pytest.mark.skipif(not _display_ok(), reason='needs a display (e.g. xvfb-run) and napari')
def test_gui_opens_a_run():
    from qtpy.QtWidgets import QApplication
    from lcsem.gui.app import LcsemApp, _volume_job
    with tempfile.TemporaryDirectory() as d:
        fake_run(d); app = LcsemApp(show=False)
        V = _volume_job(d, 2, 10.0); app._show(d, V)
        names = [l.name for l in app.viewer.layers]
        for n in ('liquid', 'gas', 'cell walls', 'SE contact', 'Au particles (depth measured)'): assert n in names
        app.viewer.dims.set_current_step(0, 2); QApplication.processEvents(); assert app.rv.frame_index() == 2 and app.charts.i == 2
        app.set_z(3); assert abs(app.rv.layers['liquid'].scale[1] - 3 * V.dz) < 1e-9
        for key in ('top', 'side', 'oblique'): app.set_view(key)
        assert app.maps.i == 2                                                   # the 2-D maps dock follows the time slider
        fn = os.path.join(d, 'm.gif'); app.record_movie(fn, fps=2); assert os.path.getsize(fn) > 1000
        app.viewer.close()


# ------------------------------------------------------------------------------------------------------------ review round 1
def test_modes_map_to_detectors():
    from lcsem.gui.project import channels_of
    assert channels_of('BSE only') == dict(SE=False, BSE=True, STEM=False)          # 'BSE' contains the letters 'SE'
    assert channels_of('BSE + STEM') == dict(SE=False, BSE=True, STEM=True)
    assert channels_of('SE + BSE + STEM') == dict(SE=True, BSE=True, STEM=True) and channels_of('SE only') == dict(SE=True, BSE=False, STEM=False)


def _se_frame(rng, bubbles, shading=0.0, H=300, W=400, wet=150.0, dry=70.0, noise=40.0):
    Y, X = np.mgrid[:H, :W]; img = np.full((H, W), wet) * (1 + shading * (X / W - 0.5))
    for cy, cx, r in bubbles: img[(X - cx) ** 2 + (Y - cy) ** 2 < r * r] = dry * (1 + shading * (cx / W - 0.5))
    return img + rng.normal(0, noise, (H, W))


def test_se_contact_map_no_false_contact_and_true_areas():
    from lcsem.analysis import se_contact_map
    rng = np.random.default_rng(0); valid = np.ones((300, 400), bool)
    for img in (_se_frame(rng, []), _se_frame(rng, [], shading=0.2)):                 # no gas: no contact (Otsu gave 34-50 %)
        assert se_contact_map(img, valid, 6, 100, 3)[0].mean() == 0
    for bubbles, sh in (([(150, 200, 60)], 0.0), ([(150, 200, 60)], 0.2), ([(100, 120, 80), (180, 300, 80)], 0.0)):
        true = sum(np.pi * r * r for _, _, r in bubbles) / (300 * 400)
        assert abs(se_contact_map(_se_frame(rng, bubbles, sh), valid, 6, 100, 3)[0].mean() / true - 1) < 0.03


def test_particles_not_detected_on_bubble_rims():
    from lcsem.imageproc import detect_particles
    rng = np.random.default_rng(1); H, W = 240, 320; Y, X = np.mgrid[:H, :W]
    img = 120.0 - 40.0 * (((X - 160) ** 2 + (Y - 120) ** 2) < 70 ** 2)                  # a thickness step (bubble rim)
    parts = [(40, 40), (200, 60), (40, 280), (210, 290), (120, 160)]
    for y, x in parts: img = img + 60 * np.exp(-((X - x) ** 2 + (Y - y) ** 2) / (2 * 2.5 ** 2))
    b = detect_particles(img + rng.normal(0, 6, img.shape), None, 1.5, 5.0, 5.0, sat_level=1e9)
    d_part = np.min(np.hypot(b[:, None, 0] - np.array(parts)[None, :, 0], b[:, None, 1] - np.array(parts)[None, :, 1]), axis=1)
    assert (d_part < 3).sum() >= 4 and (d_part >= 3).sum() <= 1                          # the particles, not the rim


def test_dose_bookkeeping():
    from lcsem import dose as DS
    fl = DS.frame_fluence(100.0, 0.5, 300, 400, (8.0, 8.0)); assert abs(fl - 100e-12 * 0.5 / 1.602176634e-19 / (300 * 400 * 64)) < 1e-9
    assert abs(DS.absorbed_Gy(1.0, 15.0) / 1e6 - 0.258) < 0.01                             # ~0.26 MGy per e/nm2 at 15 keV
    tb = DS.table([0.5] * 3, [0, 4, 8], 100.0, 300, 400, (8.0, 8.0), 15.0); assert np.allclose(tb['dose_cum_e_nm2'], [fl, 5 * fl, 9 * fl])
    assert np.isnan(DS.frame_fluence(None, 0.5, 10, 10, (1, 1)))


def test_calibration_plan_refuses_hidden_assumptions():
    from lcsem.gui.project import new_project, calibration_plan
    px = dict(pixel_nm=[8.0, 8.0])
    assert calibration_plan(new_project())[2]                                                              # no pixel size: refuse
    mode, ass, prob = calibration_plan(new_project(**px)); assert mode is None and prob                     # no references: refuse
    mode, ass, prob = calibration_plan(new_project(references=dict(dark=dict(BSE='d.tif')), **px)); assert mode == 'dark+particles' and not prob
    mode, ass, prob = calibration_plan(new_project(calibration=dict(flat_T_nm=300.0), **px)); assert 'flat' in mode and any('ASSUMED' in a for a in ass)


def test_row_clock_and_objects_split():
    from lcsem.objects import split_objects
    Y, X = np.mgrid[:200, :300]
    assert split_objects(((X - 150) / 75.0) ** 2 + ((Y - 100) / 20.0) ** 2 < 1, 50, 10).max() == 1        # elongated: one object
    assert split_objects((((X - 110) ** 2 + (Y - 100) ** 2) < 40 ** 2) | (((X - 180) ** 2 + (Y - 100) ** 2) < 40 ** 2), 50, 10).max() == 2


def test_export_check_detects_corruption():
    from lcsem.export_formats import export_all, verify
    from lcsem.volume4d import Volume4D
    import tifffile
    with tempfile.TemporaryDirectory() as d:
        fake_run(d, n=4); V = Volume4D(d, bin=2, dz=10.0); out = os.path.join(d, 'export')
        M = export_all(d, out, ['tiff'], volume=V, log=lambda *a: None); assert bool(M['read_back'].iloc[0])
        fn = os.path.join(out, 'tiff', 'fake_TZCYX.tif'); a = tifffile.imread(fn); a[-1] = 0
        tifffile.imwrite(fn, a, imagej=True, metadata={'axes': 'TZCYX', 'spacing': V.spacing[0], 'unit': 'nm'}, resolution=(1 / V.spacing[2], 1 / V.spacing[1]))
        assert verify('tiff', [fn], V)['ok'] is False                                           # the last frame is compared too


def test_matlab_v73_branch():
    import importlib.util
    if importlib.util.find_spec('hdf5storage') is None: pytest.skip('hdf5storage not installed')
    from lcsem import export_formats as E
    from lcsem.volume4d import Volume4D
    with tempfile.TemporaryDirectory() as d:
        fake_run(d, n=3); V = Volume4D(d, bin=2, dz=10.0); out = os.path.join(d, 'm'); os.makedirs(out)
        files = E.export_matlab(V, out, log=lambda *a: None, v73_above_bytes=0)             # the path used for runs over 1.8 GB
        r = E.verify('matlab', files, V); assert r['ok'] and 'v7.3' in r['reader'], r


def test_rerun_goes_to_a_new_folder_and_opens(tmp_path):
    from lcsem.gui.project import new_project, run_project
    from lcsem.simulate import make_movie
    from lcsem.calib import ChannelCurve
    from lcsem.volume4d import Volume4D
    cf = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'curve_15kV_SiN30_H2O_BEDC_STEM100_Au60.json')
    D = str(tmp_path / 'mv'); make_movie(D, {'BSE': ChannelCurve(cf, 'BEDC')}, n_frames=4, shape=(96, 128), channels=('SE', 'BSE'), mp4=False, n_particles=3)
    out = str(tmp_path / 'out'); runs = []
    for mode in ('BSE only', 'SE only'):
        p = new_project(name='t', source='movie', mode=mode, pixel_nm=[8.0, 8.0], particle_nm=60.0, out_dir=out, beam_current_pA=50.0,
                        movie=dict(files=dict(SE=f'{D}/movie_SE.tif', BSE=f'{D}/movie_BSE.tif'), frame_time_s=0.5),
                        model=dict(kind='Monte Carlo curve file', curve_file=cf), calibration=dict(mode='manual', B0=dict(BSE=30.0), g=dict(BSE=600.0)),
                        segmentation=dict(enabled=False), objects=dict(enabled=True))
        runs.append(run_project(p, log=lambda *a: None))
    assert runs[0] != runs[1] and all(os.path.exists(os.path.join(r, 'run_info.json')) for r in runs)      # never two runs in one folder
    for r in runs:
        V = Volume4D(r, bin=2, dz=10.0); S = V.series(); assert V.n == 4 and np.isfinite(S['dose_cum_e_nm2']).all()
    assert np.isnan(Volume4D(runs[1], bin=2, dz=10.0).series()['liquid_um3']).all()                    # SE only: nominal volumes are NaN


@pytest.mark.skipif(not _display_ok(), reason='needs a display (e.g. xvfb-run) and napari')
def test_worker_reports_systemexit_and_serialises_jobs():
    import time
    from qtpy.QtWidgets import QApplication
    from lcsem.gui.app import LcsemApp
    app = LcsemApp(show=False); msgs = []
    app.runp.message = lambda m: msgs.append(m)
    def bad(log=None, progress=None, should_abort=None): raise SystemExit('no scans selected')
    def slow(log=None, progress=None, should_abort=None):
        for _ in range(50):
            if should_abort(): raise RuntimeError('stopped')
            time.sleep(0.02)
    app._start(bad); t0 = time.time()
    while app.busy() and time.time() - t0 < 10: QApplication.processEvents(); time.sleep(0.01)
    assert not app.busy() and app.runp.run.isEnabled() and any('SystemExit' in m for m in msgs)
    app._start(slow); assert app._start(slow) is None                                    # one job at a time
    app.shutdown_jobs(timeout_s=5); assert not app.busy()
    app.viewer.close()


# ------------------------------------------------------------------------------------------------------------ review round 2
def test_se_contact_map_high_coverage_and_drying_front():
    """N1 (round 2): contact over most of the field (disc or drying front, with shading) is found and flagged; a bright bump of
    thicker liquid in a gas-free frame is not taken for the background"""
    from lcsem.analysis import se_contact_map
    rng = np.random.default_rng(3); H, W = 300, 400; Y, X = np.mgrid[:H, :W]; valid = np.ones((H, W), bool); sh = 1 + 0.05 * (X / W - 0.5)
    cases = [((X - 200) ** 2 + (Y - 150) ** 2 < r * r) for r in (150, 185)] + [X < f * W for f in (0.6, 0.8, 0.9)]
    for true in cases:
        d, _, _, info = se_contact_map((150 - 25 * true) * sh + rng.normal(0, 40, (H, W)), valid, 6, 100, 3, return_info=True)
        assert abs(d.sum() / true.sum() - 1) < 0.05 and (d & ~true).mean() < 0.005
        assert info['high_coverage'] == (true.mean() > 0.5) and info['start'] == 'two surface states'
    bump = 150 * (1 + 0.6 * np.exp(-(((X - 320) / 50.) ** 2 + ((Y - 80) / 40.) ** 2)))
    assert se_contact_map(bump + rng.normal(0, 10, (H, W)), valid, 6, 100, 3)[0].mean() == 0


def test_dose_of_averaged_time_points():
    """N3 (round 2): a time point averaging W raw frames carries W frame fluences, and the cumulative dose runs to its last frame"""
    from lcsem import dose as DS
    fl = DS.frame_fluence(100.0, 0.5, 300, 400, (8.0, 8.0))
    tb = DS.table([0.5] * 3, [0, 4, 8], 100.0, 300, 400, (8.0, 8.0), 15.0, n_raw=[3, 3, 3])
    assert np.allclose(tb['dose_frame_e_nm2'], 3 * fl) and np.allclose(tb['dose_cum_e_nm2'], [3 * fl, 7 * fl, 11 * fl])
    assert np.allclose(tb['dose_rate_e_nm2_s'], fl / 0.5)


def test_se_only_jeol_uses_one_detector():
    """Reviewer 3 A (round 2): an SE-only JEOL series with in-lens (UED) and E-T (LED) images uses the chosen detector only"""
    from lcsem.io_jeol import Frame, group_scans
    fr = [Frame(path=f'/x/{i}.tif', time_s=100.0 + 3 * i, signal=('UED', 'LED')[i % 2], mag=12000.0, stage=(0.0, 0.0, 0.0), kv=15.0, name=str(i)) for i in range(10)]
    for pref in (['UED', 'LED'], ['LED', 'UED']):
        sc = next(iter(group_scans(fr, dict(SE=dict(signal=pref, role='contact'))).values()))
        assert len(sc) == 5 and {s.channels['SE'].signal for s in sc} == {pref[0]}
    only_led = [f for f in fr if f.signal == 'LED']                                        # chosen detector absent: the other one
    assert {s.channels['SE'].signal for s in next(iter(group_scans(only_led, dict(SE=dict(signal=['UED', 'LED'], role='contact'))).values()))} == {'LED'}


def test_particle_pairs_and_particles_at_steps_are_kept():
    """Reviewer 2 new-1 (round 2): the rim tests keep close pairs (dimers) and particles next to a thickness step, and still
    reject the rims themselves"""
    from lcsem.imageproc import detect_particles
    rng = np.random.default_rng(4); H, W = 200, 600; Y, X = np.mgrid[:H, :W]
    spot = lambda y, x, A=60.0: A * np.exp(-((Y - y) ** 2 + (X - x) ** 2) / (2 * 1.8 ** 2))
    det = lambda im: detect_particles(im + rng.normal(0, 8.0, im.shape), None, 1.5, 6.0, 6.0, sat_level=1e9)
    hit = lambda b, y, x: bool(len(b)) and np.min(np.hypot(b[:, 0] - y, b[:, 1] - x)) < 2.5
    for sep in (8, 10):
        img = np.full((H, W), 100.0); truth = []
        for x in (100, 220, 340, 460): img += spot(100, x) + spot(100, x + sep); truth += [(100, x), (100, x + sep)]
        b = det(img); assert np.mean([hit(b, y, x) for y, x in truth]) >= 0.9
    for d in (3, 6, 15):
        assert hit(det(100.0 + 25.0 * (X > 300) + spot(100, 300 + d)), 100, 300 + d)
    img = np.full((H, W), 120.0)
    for cx, r in ((100, 60), (300, 40), (480, 80)): img -= 40.0 * (((X - cx) ** 2 + (Y - 100) ** 2) < r * r)
    assert len(detect_particles(img + rng.normal(0, 6.0, img.shape), None, 1.5, 6.0, 6.0, sat_level=1e9)) <= 1


def test_cli_commands(tmp_path, capsys):
    """Reviewer 3 (round 2): the command line (export --list, options, movie-info, export of a run, objects)"""
    from lcsem.cli import main
    main(['export', '--list']); out = capsys.readouterr().out; assert 'amira' in out and 'trackmate' in out
    main(['options']); assert 'dark reference' in capsys.readouterr().out
    rng = np.random.default_rng(0); a = np.repeat(rng.normal(100, 20, (6, 32, 40)), 5, axis=0).astype(np.float32) + rng.normal(0, 0.2, (30, 32, 40)).astype(np.float32)
    fn = str(tmp_path / 'm.tif'); _write_stack(fn, a); main(['movie-info', fn]); out = capsys.readouterr().out
    assert '30 frames' in out and 'use step 5' in out
    d = str(tmp_path / 'run'); os.makedirs(d); fake_run(d)
    main(['export', d, '--formats', 'csv,trackmate', '--out', str(tmp_path / 'ex')]); out = capsys.readouterr().out
    assert 'csv' in out and 'True' in out and os.path.exists(tmp_path / 'ex' / 'export_manifest.csv')


@pytest.mark.skipif(not _display_ok(), reason='needs a display (e.g. xvfb-run) and napari')
def test_close_asks_napari_and_aborts_only_when_accepted():
    """Reviewer 3 B (round 2): a running job is listed in napari's task manager (its close dialog); cancelling it (what napari
    does once the close is accepted) aborts the job and waits for the thread - nothing is aborted before"""
    import time
    from qtpy.QtWidgets import QApplication
    from lcsem.gui.app import LcsemApp
    app = LcsemApp(show=False); stopped = []
    def slow(log=None, progress=None, should_abort=None):
        for _ in range(500):
            if should_abort(): stopped.append(True); raise RuntimeError('stopped')
            time.sleep(0.01)
    app._start(slow)
    try:
        tm = app.viewer.window._task_status_manager
        assert tm.is_busy() and any('lcsem' in m for m in tm.get_status()) and not stopped
        tm.cancel_all(); assert stopped and not app.busy() and not any(t.isRunning() for t, _ in app.jobs)
    finally:
        app.shutdown_jobs(timeout_s=10); app.viewer.close()


def test_auto_calibration_from_reference_movies(tmp_path):
    """Reviewers 1 M2 / 4 (round 2): a movie run in 'auto' with dark and empty-cell reference movies (read like the movie)
    calibrates without assumptions and recovers the detector's black level and gain; gas volumes carry a standard deviation"""
    from lcsem.gui.project import new_project, run_project
    from lcsem.simulate import make_movie
    from lcsem.calib import ChannelCurve
    cf = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'curve_15kV_SiN30_H2O_BEDC_STEM100_Au60.json')
    D = str(tmp_path / 'mv'); make_movie(D, {'BSE': ChannelCurve(cf, 'BEDC')}, n_frames=4, shape=(120, 160), channels=('SE', 'BSE'), mp4=False, n_particles=3)
    assert all(os.path.exists(os.path.join(D, f'ref_{k}_BSE.tif')) for k in ('dark', 'empty', 'full'))
    refs = dict(dark=dict(BSE=f'{D}/ref_dark_BSE.tif', SE='', STEM=''), empty=dict(BSE=f'{D}/ref_empty_BSE.tif', SE='', STEM=''), full=dict(BSE='', SE='', STEM=''))
    p = new_project(name='auto', source='movie', mode='SE + BSE', pixel_nm=[8.0, 8.0], particle_nm=60.0, out_dir=str(tmp_path / 'out'), references=refs,
                    movie=dict(files=dict(SE=f'{D}/movie_SE.tif', BSE=f'{D}/movie_BSE.tif'), frame_time_s=0.5),
                    model=dict(kind='Monte Carlo curve file', curve_file=cf), calibration=dict(mode='auto'), segmentation=dict(enabled=False), objects=dict(enabled=False))
    r = run_project(p, log=lambda *a: None)
    info = json.load(open(os.path.join(r, 'run_info.json'))); cal = info['calibration']['BSE']
    assert info['calibration_modes']['BSE'].startswith('dark+empty') and abs(cal['B0'] - 30.0) < 0.5 and abs(cal['g'] / 600.0 - 1) < 0.02
    assert info.get('build', '').startswith('0.3.0+')
    S = pd.read_csv(os.path.join(r, 'summary.csv')); assert {'gas_top_volume_um3', 'gas_top_volume_sd_um3', 'se_detection_floor', 'se_signal'} <= set(S.columns)
