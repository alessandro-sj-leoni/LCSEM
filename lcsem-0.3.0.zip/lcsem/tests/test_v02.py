"""v0.2 tests: Monte Carlo engine, calibration models, reference levels, particle depth model, end-to-end synthetic run.
Run: python -m pytest tests/  (about 3 minutes)"""
import os, sys, json, tempfile, numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from lcsem.mc.engine import Sim, stack, sphere
from lcsem.mc.detectors import signals
from lcsem.calib import ChannelCurve, solve
from lcsem import depth as D
CURVE = os.path.join(os.path.dirname(__file__), '..', 'data', 'curve_15kV_SiN30_H2O_BEDC_STEM100_Au60.json')

def test_engine_values_and_correlation():
    S = Sim(['vac', 'SiN', 'H2O', 'Au', 'protein']); zb, lm = stack(S, [(200, 'H2O')]); n = 100000
    o = S.go(np.zeros(n), np.zeros(n), np.arange(n), 15.0, zb, lm); b = signals(o, ['BEDC'])['BEDC']
    assert abs(b.mean() - 0.078) < 0.006, b.mean()                       # v0.1 value 0.0778
    # correlated sampling: identical trajectories for primaries that never reach the object
    o1 = S.go(np.full(n, 300.0), np.zeros(n), np.arange(n), 15.0, zb, lm, objects=[sphere(0, 0, 60, 20, S.m('Au'))])
    o0 = S.go(np.full(n, 300.0), np.zeros(n), np.arange(n), 15.0, zb, lm)
    miss = o1[:, 7] == 0; assert np.all(o1[miss, :7] == o0[miss, :7])
    # weak object: the correlated difference has a much smaller variance than an independent one
    zb5, lm5 = stack(S, [(500, 'H2O')]); n = 60000
    a = S.go(np.zeros(n), np.zeros(n), np.arange(n), 15.0, zb5, lm5, objects=[sphere(0, 0, 280, 35, S.m('protein'))])
    c = S.go(np.zeros(n), np.zeros(n), np.arange(n), 15.0, zb5, lm5); u = S.go(np.zeros(n), np.zeros(n), np.arange(n) + 10 ** 7, 15.0, zb5, lm5)
    sa, sc, su = (signals(x, ['BEDC'])['BEDC'] for x in (a, c, u))
    assert np.var(sa - sc) * 10 < np.var(sa - su)

def test_calibration_models():
    cv = ChannelCurve(CURVE, 'BEDC'); B0, g = 30.0, 600.0; S0 = float(cv.S_of_T(0)); S5 = float(cv.S_of_T(500))
    cal, rep = solve(cv, dict(dark=(B0, 0.05), empty=(B0 + g * S0, 0.05)))
    assert rep['mode'] == 'dark+empty' and abs(cal.B0 - B0) < 1e-6 and abs(cal.g / g - 1) < 1e-6
    assert abs(float(cal.thickness(B0 + g * S5)) - 500) < 1.0
    cal2, rep2 = solve(cv, dict(dark=(B0, 0.05), flat=(B0 + g * S5, 0.05, 500.0)))
    assert rep2['mode'] == 'dark+flat' and abs(cal2.g / g - 1) < 1e-6
    cal3, rep3 = solve(cv, dict(dark=(B0, 0.05), empty=(B0 + g * S0, 0.05), flat=(B0 + g * S5, 0.05, 400.0)))
    chk = [c for c in rep3['checks'] if 'flat' in c['check']][0]; assert abs(chk['value'] - 500) < 2      # the check reveals the wrong flat assumption

def test_reference_level_clipping():
    from lcsem.references import level
    import tifffile
    d = tempfile.mkdtemp(); rng = np.random.default_rng(0); fr = []
    class F:
        def __init__(self, p): self.path = p
        def load(self): return tifffile.imread(self.path).astype(np.float32)
    for i in range(2):
        p = os.path.join(d, f'd{i}.tif'); tifffile.imwrite(p, np.clip(np.rint(rng.normal(12.0, 20.0, (200, 200))), 0, 255).astype(np.uint8)); fr.append(F(p))
    m, e, c = level(fr); assert c > 0.2 and abs(m - 12.0) < 1.0, (m, c)

def test_depth_model():
    cv = ChannelCurve(CURVE, 'BEDC'); m = D.ParticleModel(cv.particle, 'BEDC', (8.0, 8.0))
    z, cf = m.cf(600.0); assert np.all(np.diff(cf) < 0.02) and cf[0] > 0.9 and cf[-1] < 0.5
    zz, s = m.z_from_cf(float(np.interp(250.0, z, cf)), 0.02, 600.0); assert abs(zz - 250) < 10

def test_end_to_end_synthetic():
    from lcsem import simulate as SIM
    from lcsem.config import load_config
    from lcsem.pipeline import run
    from lcsem.validate import evaluate
    d = tempfile.mkdtemp(); data = os.path.join(d, 'data'); out = os.path.join(d, 'out')
    cb, cs = ChannelCurve(CURVE, 'BEDC'), ChannelCurve(CURVE, 'stem_0_100')
    SIM.make_dataset(data, {'BSE': cb, 'STEM': cs}, n_frames=3, shape=(300, 400), bits=16)
    cfg = SIM.config_for(data, (8.0, 8.0), ('BSE', 'STEM', 'SE'), ('dark', 'empty', 'full'), curves={'BSE': dict(file=CURVE, detector='BEDC'), 'STEM': dict(file=CURVE, detector='stem_0_100')}, bits=16)
    run(load_config(cfg), out, verbose=False); r = evaluate(out, data, (8.0, 8.0))
    assert abs(r['T_bias_nm']) < 10 and r['T_spread_nm'] < 25 and r['gas_class_accuracy'] > 0.9, r
    assert abs(r['BSE_B0'] - 30) < 1 and abs(r['BSE_g'] / 600 - 1) < 0.02, r

if __name__ == '__main__':
    for k, f in list(globals().items()):
        if k.startswith('test_'): f(); print(k, 'ok', flush=True)
