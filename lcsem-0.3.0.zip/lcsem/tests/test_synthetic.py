"""Synthetic end-to-end test of the calibration and inversion: a known thickness field, a known detector (B0, g), Gaussian noise,
8-bit clipping and Au particles of known excess -> the pipeline pieces must recover the thickness field within the noise.
Run:  python -m pytest tests/   (or simply python tests/test_synthetic.py)"""
import os, sys, numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from lcsem.calib import ThicknessCurve, Calibration, single_particle_excess
from lcsem.imageproc import smooth_masked, unclip_mean, noise_sigma_censored, detect_particles, particle_mask, aperture_excess, register_by_particles
from lcsem.analysis import se_contact_map, gas_gap, block_bootstrap_median
CURVE = os.path.join(os.path.dirname(__file__), '..', 'data', 'bse_vs_water_15kV_BEDC.json')

def make_frame(T_field, B0, g, sigma, curve, particles, px_area=64.5, seed=0, clip=True):
    rng = np.random.default_rng(seed)
    grey = B0 + g * curve.S_of_T(T_field)
    for (y, x) in particles:   # Gaussian spots whose integrated excess equals the MC particle excess * g / px_area
        yy, xx = np.mgrid[:T_field.shape[0], :T_field.shape[1]]; s = 2.5
        amp = curve.particle_dB(200.0) * g / px_area / (2 * np.pi * s * s)
        grey = grey + amp * np.exp(-((yy - y) ** 2 + (xx - x) ** 2) / (2 * s * s))
    img = grey + rng.normal(0, sigma, grey.shape)
    return (np.clip(np.rint(img), 0, 255) if clip else img).astype(np.float32)

def test_thickness_recovery():
    curve = ThicknessCurve(CURVE); ny, nx = 400, 500; B0, g, sigma = 75.0, 280.0, 60.0
    yy, xx = np.mgrid[:ny, :nx]; T = 200 + 120 * np.exp(-((yy - 200) ** 2 + (xx - 250) ** 2) / (2 * 60 ** 2)) - 80 * (xx > 400)
    rng = np.random.default_rng(1); parts = [(int(y), int(x)) for y, x in zip(rng.integers(30, ny - 30, 25), rng.integers(30, nx - 30, 25))]
    img = make_frame(T, B0, g, sigma, curve, parts)
    # noise and clipping
    s_est = noise_sigma_censored(img); assert abs(s_est - sigma) / sigma < 0.15, s_est
    # particles: detection and photometry -> gain
    blobs = detect_particles(img, None, 1.5, 5.0, 6.0); assert 20 <= len(blobs) <= 30, len(blobs)
    au = particle_mask(img.shape, blobs, 3.0, 6)
    ex = [aperture_excess(img, y, x, 12, 16, 28)[0] for y, x, s in blobs if 30 < x < nx - 30 and 30 < y < ny - 30]
    ex1 = single_particle_excess(ex); g_est = ex1 * 64.5 / curve.particle_dB(200.0)
    assert abs(g_est / g - 1) < 0.15, (g_est, g)
    # black level from a flat reference region (the T=200 plateau), then thickness
    sm = smooth_masked(img, au, 12); sm = unclip_mean(sm, s_est)
    ref = np.zeros(img.shape, bool); ref[20:120, 20:120] = True
    cal = Calibration.from_particles(curve, ex1, 64.5, float(np.median(sm[ref])), 200.0)
    T_est = cal.thickness(sm)
    err = (T_est - T)[40:-40, 40:-40]; ok = ~au[40:-40, 40:-40]
    assert abs(np.median(err[ok])) < 15, np.median(err[ok])
    assert np.percentile(np.abs(err[ok]), 90) < 45, np.percentile(np.abs(err[ok]), 90)
    # the bump (+120 nm) and the step (-80 nm) are recovered
    assert abs(np.median(T_est[180:220, 230:270]) - 320) < 30
    assert abs(np.median(T_est[100:300, 420:480]) - 120) < 30

def test_registration_vote():
    rng = np.random.default_rng(3); pts = np.c_[rng.uniform(50, 900, 20), rng.uniform(50, 1200, 20)]
    mov = pts - np.array([37.0, -112.0]) + rng.normal(0, 1.0, pts.shape)
    mov = np.r_[mov, np.c_[rng.uniform(0, 900, 6), rng.uniform(0, 1200, 6)]]     # spurious detections
    dy, dx, n = register_by_particles(np.c_[pts, np.ones(20)], np.c_[mov, np.ones(26)])
    assert abs(dy - 37) < 2 and abs(dx + 112) < 2 and n >= 15

def test_contact_and_gap():
    ny, nx = 300, 400; yy, xx = np.mgrid[:ny, :nx]; dark_true = (xx - 150) ** 2 + (yy - 150) ** 2 < 80 ** 2
    rng = np.random.default_rng(5); se = np.where(dark_true, 90, 140) + rng.normal(0, 15, (ny, nx))
    dark, thr, _ = se_contact_map(se, np.ones((ny, nx), bool), sigma=4, min_area=500)
    iou = (dark & dark_true).sum() / (dark | dark_true).sum(); assert iou > 0.9, iou
    T = np.where(dark_true, 150.0, 200.0) + rng.normal(0, 5, (ny, nx))
    gap, Tref = gas_gap(T, dark, np.ones((ny, nx), bool)); assert abs(Tref - 200) < 3 and abs(np.median(gap[dark]) - 50) < 5
    med, lo, hi = block_bootstrap_median(np.where(dark, T, np.nan), block=16, n_boot=100); assert lo < 150 < hi

if __name__ == '__main__':
    test_thickness_recovery(); test_registration_vote(); test_contact_and_gap(); print('all tests passed')
