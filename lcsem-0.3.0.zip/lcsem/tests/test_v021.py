"""Tests for 0.2.1: Amira export pieces, segmentation (with subsampling stability), profile smoothing at object edges."""
import os, sys, re, tempfile, numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

def test_voxel_fractions():
    from lcsem.export_amira import _fraction
    z0 = np.arange(6) * 10.0
    f = _fraction(np.array([[10.0]]), np.array([[35.0]]), z0, 10.0)[:, 0, 0]
    assert np.allclose(f, [0, 1, 1, 0.5, 0, 0])

def test_amiramesh_roundtrip():
    from lcsem.export_amira import write_am, read_am
    a = (np.arange(4 * 5 * 6) % 256).astype(np.uint8).reshape(4, 5, 6)
    with tempfile.TemporaryDirectory() as d:
        fn = os.path.join(d, 't.am'); write_am(fn, a, (0, 5, 0, 4, 0, 3), 'test', compress=False)       # raw data section
        raw = open(fn, 'rb').read(); i = raw.index(b'# Data section follows\n@1\n') + len(b'# Data section follows\n@1\n'); hdr = raw[:i].decode()
        nx, ny, nz = map(int, re.search(r'define Lattice (\d+) (\d+) (\d+)', hdr).groups())
        assert (nx, ny, nz) == (6, 5, 4) and 'byte Data' in hdr
        b = np.frombuffer(raw[i:i + a.size], np.uint8).reshape(nz, ny, nx); assert np.array_equal(a, b)
        for comp in (False, True):                                                                     # HxZip (zlib) too
            write_am(fn, a, (0, 5, 0, 4, 0, 3), 'test', compress=comp); b, hdr = read_am(fn)
            assert np.array_equal(a, b) and (('HxZip' in hdr) == comp)
        f = np.linspace(0, 1, 30, dtype=np.float32).reshape(1, 5, 6); write_am(fn, f, (0, 5, 0, 4, 0, 0)); b, _ = read_am(fn); assert np.array_equal(f, b)

def test_sphere_surface():
    from lcsem.export_amira import icosphere, write_spheres_surf
    V, F = icosphere(2); assert len(V) == 162 and len(F) == 320 and np.allclose(np.linalg.norm(V, axis=1), 1)
    with tempfile.TemporaryDirectory() as d:
        fn = os.path.join(d, 's.surf'); write_spheres_surf(fn, [(0, 0, 0), (100, 0, 0)], 19.0)
        t = open(fn).read(); assert t.startswith('# HyperSurface 0.1 ASCII') and 'Vertices 324' in t and 'Triangles 640' in t

def test_smooth_profile_keeps_edges():
    from lcsem.mc.radial import smooth_profile
    rc = np.arange(0.5, 200, 1.0); prof = np.where(rc < 100, 1.0, 0.0); err = np.where(rc < 100, 0.1, 1e-6)   # tiny MC errors outside
    sm = smooth_profile(rc, prof, err, 5.0)
    assert abs(sm[80] - 1.0) < 0.01 and 0.3 < sm[99] < 0.7          # inverse-variance weights would pull sm[80..99] to zero

def test_segmentation_two_phases():
    from lcsem.segment import segment_frame
    rng = np.random.default_rng(0); ny, nx = 240, 240; Y, X = np.mgrid[:ny, :nx]
    wet = (X - 120) ** 2 + (Y - 120) ** 2 < 70 ** 2
    T = np.where(wet, 250.0, 180.0) + rng.normal(0, 8, (ny, nx)); se = np.where(wet, 170.0, 130.0) + rng.normal(0, 10, (ny, nx))
    valid = np.ones((ny, nx), bool)
    cfg = dict(criteria=['icl'], nlm=False, k_range=[2, 4], n_fit=20000, stability_runs=3, stability_n_fit=10000, seed=0)
    res = segment_frame(T, se, valid, ~wet, 8.0, cfg)['icl']
    assert 2 <= res['k'] <= 4 and sum(res['stability']['freq'].values()) == 3
    # the boundary (high |grad T|) may form its own 'rim' class, as the ring rims do in the K-kit data: the thick classes
    # together must reproduce the wet disk
    thick = [r['cls'] for r in res['rows'] if r['T_median'] > 215]; lab = res['labels']
    agree = (np.isin(lab, thick) == wet).mean(); assert agree > 0.95, agree
    assert np.allclose(np.nansum(res['prob'], axis=0)[valid], 1.0, atol=1e-3)     # probabilities, not binary

if __name__ == '__main__':
    for k, v in list(globals().items()):
        if k.startswith('test_'): v(); print(k, 'ok')
