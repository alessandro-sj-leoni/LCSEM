# The lcsem graphical interface

`lcsem gui` opens a napari viewer [napari, doi:10.5281/zenodo.3555620] with the lcsem panels docked on the right. It runs
the whole analysis (JEOL image series or SE/BSE/STEM movies -> thickness, gas, particles, segmentation, objects, dose),
shows the result as time-resolved 3-D volumes that rotate with the mouse, with a **time slider at the bottom**, charts and
2-D maps that follow it, and exports to Amira and 13 other formats.

![GUI, K-kit 1, 12k series](img/gui_12k.png)

*12k series of K-kit 1 (21 Aug 2026), frame 7 of 9: liquid (blue, isosurface of the liquid fraction at half filling), gas at
the top membrane (orange), Au particles (light yellow spheres: depth measured; grey vertical lines: depth not measured),
z exaggerated 10x. The text in the view states the calibration - here an ASSUMED 200 nm flat field, the v0.2 configuration
of these data - the dose (no probe current was recorded), the SE detection limit and the layer-model convention. Charts:
(a) liquid and (b) gas volume over the field imaged in every frame - gas with +-2 sd, no value in frames 4, 5 and 8, where
the SE contact covers most of the field (a CHECK line in the view), and significantly below zero in frame 7, which marks
the limit of the gap interpolation without a full-cell reference; (c) thickness histogram of the current frame; (d) SE contact area
(the SE of frames 1-3 is the E-T image, of frames 4-9 the in-lens image: compare within each group).*

## Install (Windows, macOS, Linux)

1. Install Miniforge (https://github.com/conda-forge/miniforge) and open the *Miniforge Prompt* (Windows) or a terminal. If
   Anaconda or Miniconda is already installed, its *Anaconda Prompt* works the same way (the environment uses conda-forge).
2. Unzip lcsem and go into its folder: `cd C:\path\to\lcsem`.
3. Create the environment (once, 5-15 minutes) and start:

```
conda env create -f environment.yml
conda activate lcsem
lcsem gui
```

Next time only `conda activate lcsem` and `lcsem gui`. With pip into an existing Python 3.11 environment:
`pip install -e ".[all]"`. napari needs OpenGL 2.1: on a remote desktop without a GPU use a local session. Tested with
napari 0.9.1, PyQt6 6.11, vispy 0.16, Python 3.11 (Linux); the conda environment is written for Windows and macOS too but was
not tested there. First use of the Monte Carlo model for a new beam energy or cell takes a few minutes (cached afterwards).

```
lcsem gui RUN_DIR               # open a finished run (a folder with run_info.json)
lcsem gui my_project.json       # load a saved project
lcsem project my_project.json   # run a saved project without the interface (same result)
```

## Before you record (checklist)

* **A dark frame** (beam blanked, same detector brightness and contrast): with the Au particles it calibrates the thickness
  without assumptions. If possible also **an empty cell** (dry, T = 0) and **a full cell** (before gas forms: the gap map).
  A few frames of each are enough; record them like the movie (same layout, e.g. the dual display side by side, and the
  same crop): they are read with the movie's layout. Dark + empty cell calibrate without any sample assumption (validated
  on a synthetic movie: black level and gain within 0.1 %).
* Keep brightness, contrast and automatic contrast/brightness **fixed** during the movie and the references.
* Record the native scan as **16-bit TIFF** if the SEM allows (screen recordings are lossy and repeat frames).
* Note: magnification and **pixel size**, **frame time**, beam energy, **probe current** (for the dose), working
  distance, which detector is on which side of a dual display.
* Keep a static feature in the field if you can (window edge, a stuck particle): drift correction needs it.

## Workflow

The tabs on the right follow the order of the work.

**1 Data.** Source: a folder of JEOL images (NAME.tif + NAME.txt; *List series in folder* groups them by stage position,
magnification and time), **movies / image stacks**, or a finished run. Movies: one file per detector (multi-frame TIFF, AVI,
MP4, MOV, MKV or a folder of images), or one file with the detectors side by side, top/bottom or in interleaved frames
(*layout*, *parts per frame*, *part index*; a Fiji composite TCYX = interleaved with parts = channels). *Probe files* reads
frames, size, frame rate and the bit depth (and sets it), fills the frame time from the file (1/fps x parts for interleaved
files - check it: screen recordings store the recording rate, not the SEM frame time) and flags near-duplicate frames of
screen recordings with the step to use (it reads on until it has seen complete runs of repeated frames). *Preview first frame* shows each detector as it will be read (layout, part, crop) -
check that SE and BSE are the right way round. Start time (00:00:00 = relative times), frames (start, stop, step),
temporal window, crop (y0 y1 x0 x1 of the whole frame, applied before splitting), drift correction (*phase* = chained
cross-correlation, or *none*; optional region of interest that does not change). Acquisition: **pixel size (required)**,
beam energy, bit depth, **probe current** (dose; 0 = unknown), SiN membranes, channel height, Au particle diameter.

**2 Processing.**
* *Detectors*: SE + BSE, SE + BSE + STEM, BSE only, SE only, BSE + STEM, STEM only, SE + STEM. "SE only" gives contact maps
  and objects; its 3-D model is nominal and its volumes are reported as not measured.
* *Detector model*: Monte Carlo (computed once for your beam energy and cell and cached) or a Monte Carlo curve file.
* *Calibration and references*: automatic (uses whatever references exist) or a named combination of dark, empty cell,
  particle standard and flat field, or manual B0 and gain. **Assumed flat field**: "not used" by default; entering a value
  makes every thickness relative to that assumption (shown in the view and the exports).
* *Denoising*: non-local means (default), BM3D, total variation, Gaussian; for movies also MP-PCA, SVD threshold, temporal
  mean/median; variance stabilisation on by default. Which to use: `docs/VALIDATION_DENOISING.md` (per frame for changing
  scenes, MP-PCA for slowly changing ones).
* *Particles, segmentation, objects*: detection threshold; SE contact map (smallest region in um2, smoothing); SE-only gas
  height (nominal); PCA + Gaussian-mixture segmentation; bubbles/objects (source: SE contact or gas thickness).
* *3-D volume*: lateral binning, voxel height, maximum liquid drawn. *Output*: a folder; every run goes into a new
  sub-folder when the folder is not empty.

**3 Run.** *Run analysis* first shows the calibration the references allow and its assumptions, the acquisition values
it will use (kV, pixel size, membranes, particle size, bit depth, frame time, frames, probe current - several are prefilled
defaults: check them) and, for movies, the memory the analysis needs against the free memory. It refuses to start if the
thickness could only rest on a hidden assumption, the pixel size is missing or the run would not fit in memory (the log
says what to record, enter or reduce). Reference movies (dark, empty, full) are read with the movie's layout and crop.
The viewer stays usable; one job at a time; *Abort* stops at the next step. Closing the window while a job runs: napari's
"Close window?" dialog lists the job; *Cancel* leaves it running, accepting aborts it and waits for it to stop.
*Save project...*, *Load project...* (paths relative to the project file are allowed).

**4 Display.** z exaggeration (automatic from the field of view; the slider overrides it), rendering and isosurface level
of the liquid, Au sphere size, views (*oblique*, *top* = as the SEM image, *side* = x-z), 2-D/3-D, reset view, *play*
(frames per second), *record movie...* (MP4 or GIF of the 3-D view over time, as seen), *screenshot...* (the view only).
Layers (left): liquid, gas, SE contact, cell walls, Au particles (depth measured), Au particles without a measured depth
(vertical lines: the particle is somewhere in that column), particle tracks, thickness map, classes and objects.

**5 Export.** Tick the formats, choose a folder, *Export*; the table lists the files, their size, whether each was read
back correctly (every layer of the first, middle and last frame and the voxel size) and which programs open it
(`docs/EXPORT_FORMATS.md`).

**Charts and 2-D maps** (docks below the tabs, switch with their tabs; both follow the time slider). Charts: (a) liquid and
(b) gas volume over the field imaged in every frame, both on axes that include zero (gas: with a +-2 sd band - the scatter
of the same sum where there is no gas - hollow points consistent with no gas; not measured in frames without SE; SE only:
not measured), (c)
thickness distribution of the frame shown (dry columns at 0 nm included), (d) particle depth (median and IQR of frames with
at least 5 measured particles), classes (fitted frame by frame - their number and tags can change between frames), largest
objects, SE contact area, or cumulative electron dose; *save...* writes PNG/PDF/SVG. 2-D maps: (a) thickness (nm) with a
colour bar - hover for thickness +- its statistical error (a lower bound, about 2.3x too small on synthetic data), (b) the
SE contact outline on the SE frame, (c) the thickness-channel frame with the particles (yellow: depth measured, grey rings:
not measured), (d) the SE frame. The text in the 3-D view also gives the SE detection limit (contact is found where the SE
is at least 5 % darker than the wet background) and a CHECK line in frames where the contact covers more than half of the
field (its background then rests on the remaining wet part).

Mouse and keys in the viewer: drag = rotate, wheel = zoom, Shift + drag = pan, Ctrl + Y = 2-D/3-D; the time slider at the
bottom steps through the frames (numbered from 0 there, from 1 in the text of the view).

![Synthetic SE + BSE + STEM movie](img/gui_synmovie.png)

*Synthetic SE + BSE movie with ground truth (`lcsem simulate-movie`: noise level 150 Poisson quanta per unit signal, 100 pA
for the dose), calibrated in 'auto' from its dark and empty-cell reference movies: a growing and a shrinking bubble at the
top membrane, diffusing Au particles (grey lines: saturated in the 8-bit movie, no depth); the 2-D maps dock shows the
thickness map with its colour bar, the SE contact outline and the input frames with the detected particles.*

![SE-only movie](img/gui_se_only.png)

*The same movie analysed from the SE channel only, read from a side-by-side SE | BSE MP4: contact regions and objects; the
thickness is nominal. Contact area 0.988 x the truth (IoU 0.987); growth rates of the two bubbles 0.0758 and -0.0273 um2/s
(truth 0.0758 and -0.0273).*

## What the 3-D view shows and does not show

The model is a 2.5-D layer model: per column, the measured liquid thickness (BSE/STEM), whether gas touches the top
membrane (SE), the gas thickness under it, and the particles. By convention the top membrane is drawn flat and every change
of the column shows at the bottom membrane; gas that does not touch the top membrane is drawn on the bottom membrane (its
height in the column is not measured); particles without a measured depth are drawn as vertical lines. z is exaggerated as
stated in the view: at 10x, 20 nm of thickness noise looks like 200 nm of relief. The lateral resolution of the thickness is
set by the calibration smoothing (15 px, about 120 nm at 8 nm pixels).

## Movies: practical notes

* Prefer lossless files (TIFF stacks). MP4/AVI work, but compression alters grey levels and noise; references must be
  recorded and read the same way as the movie.
* Set the frame time and the start time: every pixel gets its acquisition time from them (row by row within a frame).
* Drift: measured on every frame of the movie (also with a frame step); needs a static feature: give a region of interest
  that does not change, or choose *none* if the stage is stable. On synthetic movies in which everything moves the chain
  drifted 2-3 px (BSE) and 3-6 px (SE) over 40 frames; positions, trajectories and object speeds include that error
  (`object_tracks.csv`, column `drift_reference`).
* For a changing scene use a per-frame denoiser (NLM or BM3D with variance stabilisation); MP-PCA and the SVD threshold pool
  frames (in blocks of 32) and suit slowly changing scenes; a temporal window > 1 averages frames (the dose of such a time
  point counts all its frames).
* Gas volumes need a full-cell reference to be quantitative; without it the gap under a bubble is interpolated from its
  surroundings (0.93-0.98 of the truth for small bubbles, 0.63-0.70 for a bubble covering the thickest part of the bulge),
  and frames in which the contact covers more than half of the field have no gas value at all.
* Long movies: memory is about 80 bytes per pixel and time point (the log gives the estimate): analyse every n-th frame
  first (*step*), crop, use lateral binning 8 in the 3-D volume, and switch the segmentation stability off for a quick look.
  A 1000-frame run writes about 10 files per frame into its folder.

## Performance

Switching the time point recomputes the 3-D volumes of that frame (about 0.3 s for a 12k frame at bin 4) and uploads them to
the graphics card; the next frame is prepared in the background and recent frames are kept in memory (`LCSEM_CACHE_MB`,
default 1500). The binned 2-D model of a run is cached per user (`LCSEM_CACHE_DIR`, default `~/.cache/lcsem` or
`%LOCALAPPDATA%\lcsem\cache`): viewing a run writes nothing into its folder. Analysis time per frame: 3-10 s for 300 x 400-pixel movie frames with NLM denoising and segmentation, more for
full 1280 x 960 frames; BM3D alone takes about 4 s per 240 x 320 frame (about a minute at 1280 x 960).

## Headless use and scripting

The interface has no analysis code of its own: a project (all settings) is a JSON file, and `lcsem project` or
`lcsem.gui.project.run_project(load_project(...))` runs it identically. The 4-D model, the charts' time series and the
exports are available from Python: `lcsem.volume4d.Volume4D(run_dir)`, `.frame(i)`, `.series()`,
`lcsem.export_formats.export_all(run_dir, out_dir, formats)`.
