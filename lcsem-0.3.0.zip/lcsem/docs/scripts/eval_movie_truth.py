"""errors of a movie run against the synthetic ground truth: liquid thickness per pixel (frame grid: the scene shifted by
the frame's drift, image_k(y) = scene(y + d_k)), SE contact area, particle detections"""
import sys, glob, os, json, numpy as np, pandas as pd
from scipy.ndimage import shift as nd_shift
D = os.environ.get('SYNMOVIE', '/home/claude/gui_dev/synmovie3'); d = np.load(f'{D}/truth_movie.npz'); tr = json.load(open(f'{D}/truth_movie.json'))
Tt = d['T'].astype(np.float32); G = d['gas_top'].astype(np.float32); dr = d['drift']
def evaluate(run):
    info = json.load(open(os.path.join(run, 'run_info.json'))); files = [os.path.join(run, t + '_maps.npz') for t in info['tags']]
    idx = [int(t.split('_f')[-1]) for t in info['tags']]; out = []
    for fn, j in zip(files, idx):
        m = np.load(fn); T = m['T']; v = m['valid'] & np.isfinite(T)
        tt = nd_shift(Tt[j], -dr[j], order=1, mode='nearest'); gg = nd_shift(G[j], -dr[j], order=0, mode='nearest')
        from scipy.ndimage import distance_transform_edt
        e = (T - tt)[v]; dist = distance_transform_edt(gg == 0); far = v & (gg == 0) & (dist > 12)
        e2 = (T - tt)[far]
        dk = m['dark']; true_dark = gg > 0; area_ratio = dk.sum() / max(true_dark.sum(), 1)
        iou = (dk & true_dark).sum() / max((dk | true_dark).sum(), 1)
        out.append((np.median(e), np.median(np.abs(e)), np.median(e2), np.median(np.abs(e2)), area_ratio, iou))
    o = np.array(out)
    # gas on the top membrane: volume per frame (truth: sum of the true gas layer over the frame; run: summary.csv) and whether
    # the truth lies within 2 sd of the estimate
    S = pd.read_csv(os.path.join(run, 'summary.csv')); pxa = float(tr['px'][0]) * float(tr['px'][1]); gv = []
    if 'gas_top_volume_um3' in S:
        for k, j in enumerate(idx):
            gt = float(nd_shift(G[j], -dr[j], order=0, mode='constant', cval=0.0).sum()) * pxa / 1e9
            est, sd = float(S['gas_top_volume_um3'].iloc[k]), float(S.get('gas_top_volume_sd_um3', pd.Series([np.nan] * len(S))).iloc[k])
            gv.append((gt, est, sd))
    gv = np.array(gv) if gv else np.zeros((0, 3))
    P = pd.read_csv(os.path.join(run, 'particles.csv')); fp = tp = 0; n_true = 0; found = 0
    for k, j in enumerate(idx):
        q = P[P['frame'] == k]; truth = np.array([(p['y_px'] - dr[j][0], p['x_px'] - dr[j][1]) for p in tr['frames'][j]['particles']]); n_true += len(truth)
        if len(q):
            Dm = np.hypot(q['y_px'].values[:, None] - truth[None, :, 0], q['x_px'].values[:, None] - truth[None, :, 1]); fp += int((Dm.min(1) >= 4).sum()); found += int((Dm.min(0) < 4).sum())
    return dict(frames=len(o), bias_nm=round(float(np.median(o[:, 0])), 1), mae_nm=round(float(np.median(o[:, 1])), 1), mae_away_from_rims_nm=round(float(np.median(o[:, 3])), 1),
                contact_area_ratio=round(float(np.median(o[:, 4])), 3), contact_iou=round(float(np.median(o[:, 5])), 3),
                particle_recall=round(found / max(n_true, 1), 2), false_particles=fp, detections=len(P),
                gas_volume_ratio=round(float(np.median(gv[:, 1] / np.maximum(gv[:, 0], 1e-9))), 3) if len(gv) and np.isfinite(gv[:, 1]).any() else None,
                gas_truth_within_2sd=round(float(np.mean(np.abs(gv[:, 1] - gv[:, 0]) <= 2 * gv[:, 2])), 2) if len(gv) and np.isfinite(gv[:, 2]).any() else None,
                gas_sd_um3_median=round(float(np.nanmedian(gv[:, 2])), 4) if len(gv) and np.isfinite(gv[:, 2]).any() else None)
if __name__ == '__main__':
    for run in sys.argv[1:]: print(os.path.basename(run), json.dumps(evaluate(run)))
