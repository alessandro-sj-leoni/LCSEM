"""Denoising benchmark on synthetic SE + BSE movies with ground truth (lcsem.simulate.make_movie, Poisson-Gaussian noise).
Per method: RMSE, mean error (bias) and SSIM of the denoised frames against the noise-free frames, over the field imaged in
every frame, for three noise levels, a changing scene (bubbles grow/shrink, particles move) and a static scene (drift only),
three noise realisations each (seeds). Frames drift by whole pixels and are registered with the true drift (+(d - d0), the
convention of lcsem.io_movie.register_stack), so registration adds no interpolation; per-frame methods are scored on the
middle 6 frames, series methods see all 24 frames and are scored on the same 6."""
import sys, os, time, json, numpy as np, tifffile
sys.path.insert(0, '/home/claude/pkg/lcsem')
from skimage.metrics import structural_similarity as ssim
from lcsem import denoise as DN
from lcsem.calib import ChannelCurve
from lcsem.simulate import make_movie
from lcsem.io_movie import apply_shifts
cf = '/home/claude/pkg/lcsem/data/curve_15kV_SiN30_H2O_BEDC_STEM100_Au60.json'
curves = {'BSE': ChannelCurve(cf, 'BEDC')}
OUT = '/home/claude/gui_dev/dnbench'; res = {}
METHODS = [('none', False), ('gaussian', True), ('tv', True), ('nlm', False), ('nlm', True), ('bm3d', True), ('temporal_mean', False),
           ('svd_gd', True), ('mppca', False), ('mppca', True)]
NF = 24; MID = slice(9, 15)
for scene_kind in ('changing', 'static'):
    for dose in (50.0, 150.0, 1000.0):
        for seed in (0, 1, 2):
            D = os.path.join(OUT, f'{scene_kind}_{int(dose)}_s{seed}')
            kw = dict(step_px=1.0, step_u=0.02, growth=1.0) if scene_kind == 'changing' else dict(step_px=0.0, step_u=0.0, growth=0.0)
            make_movie(D, curves, n_frames=NF, shape=(240, 320), dose_e_px=dose, channels=('SE', 'BSE'), mp4=False, seed=seed,
                       drift_per_frame=(1.0, -1.0), jitter_px=0.0, **kw)
            t = np.load(os.path.join(D, 'truth_movie.npz')); sh = t['drift'] - t['drift'][0]          # register onto frame 0
            valid = apply_shifts(np.ones((NF, 240, 320), np.float32), sh, order=0) if False else None
            m = np.ones((240, 320), bool)
            for dy, dx in np.rint(sh).astype(int):                                                  # field imaged in every frame
                m &= np.roll(np.roll(np.pad(np.ones((240, 320), bool), 40)[40 - dy:280 - dy, 40 - dx:360 - dx], 0, 0), 0, 1)
            m[:4] = m[-4:] = False; m[:, :4] = m[:, -4:] = False
            for ch in ('BSE', 'SE'):
                raw = tifffile.imread(os.path.join(D, f'movie_{ch}.tif')).astype(np.float32); clean = t[f'clean_{ch}']
                reg = apply_shifts(raw, sh); creg = apply_shifts(clean, sh)
                ok = m & (creg[MID].min(0) > 2) & (creg[MID].max(0) < 250)                             # away from 8-bit clipping
                a, b = DN.estimate_noise_model(reg[0])
                key = f'{scene_kind}/{int(dose)}/{ch}'; r = res.setdefault(key, {'noise_model': [], 'psnr_raw': []})
                r['noise_model'].append([round(a, 3), round(b, 2)])
                for meth, vst in METHODS:
                    t0 = time.time()
                    if meth in DN.STACK_METHODS: out = DN.denoise_stack(reg, meth, vst=vst, noise=(a, b) if vst else None)[MID]
                    elif meth == 'none': out = reg[MID]
                    else: out = np.stack([DN.denoise_image(f, meth, vst=vst, noise=(a, b) if vst else None) for f in reg[MID]])
                    dt = (time.time() - t0) / (NF if meth in DN.STACK_METHODS else 6)
                    e = (out - creg[MID])[:, ok]; ss = float(np.mean([ssim(o, c, data_range=255.0, full=True)[1][ok].mean() for o, c in zip(out, creg[MID])]))
                    q = r.setdefault(meth + ('+vst' if vst else ''), {'rmse': [], 'bias': [], 'ssim': [], 's_per_frame': []})
                    q['rmse'].append(round(float(np.sqrt(np.mean(e ** 2))), 3)); q['bias'].append(round(float(np.mean(e)), 3))
                    q['ssim'].append(round(ss, 4)); q['s_per_frame'].append(round(dt, 3))
                rr = r['none']['rmse'][-1]; r['psnr_raw'].append(round(float(20 * np.log10(255.0 / rr)), 2))
                print(key, seed, {k: v['rmse'][-1] for k, v in r.items() if isinstance(v, dict)}, flush=True)
                json.dump(res, open(os.path.join(OUT, 'denoise_benchmark.json'), 'w'), indent=1)
