# Validation on synthetic ground truth (lcsem 0.2.0 and 0.3.0)

Regenerate: `lcsem validate out_dir` (about 20 min; the Monte Carlo curves are cached in `out_dir/mc_cache`).

**Data.** Two synthetic K-kit series (8 frames, 480 x 640 px, 8 nm pixels, 15 kV, 16-bit): membranes bulging from a 500 nm
channel to ~800 nm, a growing gas pocket on the top membrane, a gas pocket on the bottom membrane, a shrinking top pocket,
20 diffusing 60 nm Au particles at known depths, stage drift, BSE (B0 30, g 600, noise 35 grey), STEM bright field
(<100 mrad; B0 15, g 220, noise 12), in-lens SE (contact), and dark / empty-cell / full-cell reference frames. In the
second series ("model_error") the BSE images were formed with a detector accepting 20-55 deg while the analysis assumes the
BED-C model (15-65 deg): a 10-15 % error of the detector model, of the size expected in practice.

**Reading the table.** T = liquid thickness error (median bias, robust spread, 95th percentile of |error|) over all frames
excluding 8-pixel bands at gas edges; gas class = fraction of pixels correctly classified as liquid / gas on the top membrane /
gas elsewhere; z = particle depth error for particles with a reported error below 100 nm (BSE core fraction; with STEM also the
BSE/STEM ratio); check = the particle standard measured / predicted when it is not used for the calibration.

**Findings.**
1. With a correct detector model every reference-based calibration is unbiased to within a few nm (dark + empty: -2.6 nm on
   ~650 nm); the v0.1 calibration (particle gain + a flat field *assumed* to be 500 nm) inherits the error of the assumption
   (-188 nm). Record a dark frame and an empty cell instead of assuming a thickness.
2. Adding STEM to BSE reduces the thickness spread (13.7 -> 11.9 nm here, 8 nm pixels, 6 px smoothing) and the particle-depth
   spread (34 -> 26 nm); STEM alone gives unbiased thickness but no usable particle depth at this pixel size.
3. The full-cell reference (gap map) is what makes gas that does not touch the top membrane visible: gas classification
   0.977 -> 0.999. Without SE the top gas cannot be placed (0.941) and particles under it get wrong depths.
4. With a wrong detector model, dark + empty calibrations are biased (+191 nm) - but the particle-standard check reports
   1.13 +- 0.01 instead of 1, i.e. the error is detected on the data set itself. The particle-gain calibration (dark +
   particles) absorbs most of the scale error (+35 nm). Recording all references and reading the checks is therefore the
   safeguard; the next step (planned) is to fit the detector acceptance to the references automatically.
5. Particle depth: ~25-35 nm robust spread per particle per frame at 8 nm pixels (60 nm Au in 500-800 nm liquid), small bias
   (-15 to -25 nm). The reported errors are 2.5-4x too small (z_pull_std in validation.csv): use the validated spread for
   planning until the error model includes centring and rendering errors.


| data          | option_set                              |   T_bias_nm |   T_spread_nm |   T_p95_abs_nm |   gas_class_accuracy |   z_bias_nm |   z_mad_nm |   n_z |   BSE_B0 |   BSE_g | BSE_check: particle excess measured / predicted   |   STEM_B0 |   STEM_g |
|:--------------|:----------------------------------------|------------:|--------------:|---------------:|---------------------:|------------:|-----------:|------:|---------:|--------:|:--------------------------------------------------|----------:|---------:|
| correct_model | BSE | particles + flat (v0.1)           |    -188     |          14.6 |          212   |                0.977 |       -29   |       38.2 |   138 |     58   |     587 | nan                                               |       nan |      nan |
| correct_model | BSE | dark + particles                  |      11.1   |          14.5 |           40.4 |                0.977 |       -22.3 |       32.5 |   144 |     29.9 |     594 | nan                                               |       nan |      nan |
| correct_model | BSE | dark + empty                      |      -2.64  |          13.7 |           29.9 |                0.977 |       -23.2 |       34.2 |   142 |     29.9 |     604 | nan                                               |       nan |      nan |
| correct_model | BSE | dark + empty + particles (check)  |      -2.64  |          13.7 |           29.9 |                0.977 |       -23.2 |       34.2 |   142 |     29.9 |     604 | 0.983 +- 0.0081                                   |       nan |      nan |
| correct_model | BSE | dark + empty + full cell          |      -2.64  |          13.7 |           29.9 |                0.999 |       -17.7 |       27.3 |   142 |     29.9 |     604 | nan                                               |       nan |      nan |
| correct_model | STEM | dark + empty                     |       0.492 |          29.2 |           69.8 |                0.975 |       nan   |      nan   |     0 |    nan   |     nan | nan                                               |        15 |      220 |
| correct_model | BSE + STEM | dark + empty + full cell   |      -2.39  |          11.9 |           27.2 |                0.999 |       -14.6 |       26.1 |   143 |     29.9 |     604 | 0.983 +- 0.0081                                   |        15 |      220 |
| correct_model | BSE + STEM, no SE | dark + empty + full |      -2.39  |          11.9 |           27.2 |                0.941 |       -21   |       31.2 |   143 |     29.9 |     604 | nan                                               |        15 |      220 |
| model_error   | BSE | particles + flat (v0.1)           |    -186     |          23.9 |          226   |                0.976 |       -27.9 |       42.3 |   136 |     51.1 |     391 | nan                                               |       nan |      nan |
| model_error   | BSE | dark + particles                  |      35     |          35.3 |          103   |                0.976 |       -18.7 |       29.7 |   138 |     29.9 |     398 | nan                                               |       nan |      nan |
| model_error   | BSE | dark + empty                      |     191     |         102   |          347   |                0.976 |       -17.5 |       34.8 |   139 |     29.9 |     351 | nan                                               |       nan |      nan |
| model_error   | BSE | dark + empty + particles (check)  |     191     |         102   |          347   |                0.976 |       -17.5 |       34.8 |   139 |     29.9 |     351 | 1.13 +- 0.011                                     |       nan |      nan |
| model_error   | BSE | dark + empty + full cell          |     191     |         102   |          347   |                0.999 |       -15.5 |       34.5 |   139 |     29.9 |     351 | nan                                               |       nan |      nan |

# Additions for 0.3.0 (movies and the GUI)

Synthetic SE + BSE (+ STEM) movies with ground truth (`lcsem simulate-movie`, `lcsem.simulate.make_movie`; 40 frames of
300 x 400 px, 8 nm pixels, 0.5 s frames, drift 0.3 / -0.45 px per frame plus 0.5 px jitter, one growing and one shrinking
gas pocket on the top membrane, one on the bottom membrane, 12 diffusing 60 nm Au particles, Poisson-Gaussian noise).
Scripts: `docs/scripts/eval_movie_truth.py`. Denoisers: `docs/VALIDATION_DENOISING.md`.

| quantity | result | notes |
|---|---|---|
| SE contact map (SE + BSE run) | area 0.987 x truth, IoU 0.983 | 0.2.1-0.3.0-rc: 0.80 x truth (particle masks cut every rim) |
| SE contact map (SE only, from a side-by-side MP4) | area 1.000 x truth (0.997-1.005), IoU 0.967 | |
| SE contact map, frames without gas | 0 % of the field | a per-frame Otsu split gave 34-50 % (review round 1) |
| SE contact map, 20 % shading across the field | 0 % without gas; 9.30 % for a 9.42 % bubble | shading removed by a robust quadratic background |
| SE contact map, bubble radius 10 / 20 / 60 px | 0.32 / 1.01 / 9.28 % for 0.26 / 1.05 / 9.42 % | edges at half contrast; smallest region: 0.01 um2 |
| Au particle detection (BSE) | recall 0.85-0.90, false detections 0-4 per 10 frames | before: 245-284 false detections on bubble rims |
| bubble growth rate (SE only) | 0.0752 um2/s (truth 0.0758) | objects table, h-maxima watershed, IoU tracking |
| liquid thickness (NLM + VST) | bias 1.7 nm, MAE 16.8 nm (9.5 nm > 12 px from gas rims) | liquid 560-700 nm, manual calibration |
| gas volume at the top, no gap map | 0.93-0.98 x truth while the contact covers < 17 % of the field; 0.63-0.70 x at 19-23 % | the gap under the gas is interpolated from the wet surroundings; a large bubble on the thickest part of the bulge hides the gap - record a full-cell reference |
| drift (chained cross-correlation) | 2-6 px accumulated over 40 frames of this movie | everything in it moves or changes; give a static region (registration ROI) or choose "none" for a stable stage |
| electron dose bookkeeping | 40.6 e/nm2 per frame at 100 pA (300 x 400 px of 8 nm, 0.5 s) | analytical; 0.258 MGy per e/nm2 in water at 15 keV (first order) |

(The table above is from the first review round, on the first synthetic movie; the second round below supersedes it.)

## Second review round: regenerated movie, reference movies and the final code

The synthetic movie was regenerated with true Poisson noise and with reference movies (`lcsem.simulate.make_movie(...,
references=True)`: dark, empty-cell and full-cell movies of 5 frames per detector): 40 frames of 360 x 480 px, 8 nm
pixels, 0.5 s frames, the same scene as above (seed 0), noise level 150 Poisson quanta per unit of detector signal, 8-bit.
Runs through the GUI project runner on every 2nd frame (20 time points), 100 pA for the dose (28.2 e/nm2 per frame).
Scripts: `docs/scripts/eval_movie_truth.py` (SYNMOVIE = the movie folder).

| run | thickness bias / MAE / MAE > 12 px from rims (nm) | SE contact area / truth, IoU | particles: recall, false (of detections) | gas at the top / truth |
|---|---|---|---|---|
| SE + BSE, no denoiser, true detector parameters | -0.3 / 8.2 / 6.1 | 0.987, 0.985 | 0.89, 2 (of 215) | 0.926 |
| SE + BSE, NLM + VST, true detector parameters | 0.5 / 8.9 / 6.4 | 0.987, 0.985 | 0.89, 2 (of 215) | 0.929 |
| SE + BSE, NLM + VST, **'auto' with dark + empty-cell movies** | 0.8 / 9.0 / 6.3 | 0.987, 0.985 | 0.89, 2 (of 215) | 0.929 |
| as above + full-cell movie (gap map) | 0.8 / 9.0 / 6.3 | 0.987, 0.985 | 0.89, 2 (of 215) | 0.950 |
| MP-PCA + VST (series, blocks of 32; 93 % of the pixels inside the blocks' common field) | 0.3 / 8.6 / 6.2 | 0.987, 0.985 | 0.89, 2 (of 215) | 0.926 |
| SE only, side-by-side MP4 | - (nominal) | 0.988, 0.987 | - | - |

* **Calibration in 'auto' from reference movies**: dark + empty cell, B0 = 30.01 (true 30), g = 599.8 (true 600); the
  thickness is as good as with the true parameters. The full-cell movie gives the gap map (median 724 nm): gas at the top
  0.95 of the truth, and gas not touching the top membrane is found (13-24 % of the field: the pocket on the bottom
  membrane).
* **Gas volume uncertainty**: the statistical sd (0.008-0.10 um3, growing with the contact area) does not cover the bias of
  the gap interpolation without a gap map (0.93 of the truth: the truth is outside +-2 sd in every frame); with the gap map
  the truth is within +-2 sd in half of the frames.
* **Objects** (SE + BSE and SE only): growth rates 0.0758 and -0.0273 um2/s for the growing and the shrinking pocket (truth
  0.0758 and -0.0273). Net speeds 1.2-1.4 nm/s for pockets that do not move: the registration error (about 3 px over 19 s),
  flagged in `object_tracks.csv` (`drift_reference`).
* **Particles**: 204 of 215 detections are saturated in the 8-bit movie, so only 11 depths are measured - particle depth
  from movies needs 16-bit data or a lower gain (the depth method was validated on the 16-bit JEOL series above).
* **Drift**: measured on every frame (also with a frame step): maximum error over the 40 frames of this movie BSE 2.3 px, SE
  2.8 px, at step 1 and at step 4 alike (chaining only every 4th frame gave 4.2 and 11.9 px; on the first movie 5.2 and
  21 px against 3.0 and 5.7 px).
* **Dose**: 28.2 e/nm2 per frame; a time point averaging W frames carries W frame fluences.

Tests of the SE contact map with contact over much of the field (`test_se_contact_map_high_coverage_and_drying_front`;
360 x 480 px, SE contrast 25 grey levels on 150, noise 40, 5 % shading):

| case | found / true area | false contact (% of field) | flag |
|---|---|---|---|
| no gas: noise, 5 % shading, bulging SE2 +-3 %, noise 40 | 0 % contact | 0 | - |
| no gas: bright bump of +60 % (thicker liquid) | 0 % contact (12.7 % before round 2) | 0 | - |
| discs covering 0.4 / 1.1 / 6.5 % | 0.84 / 0.97 / 0.96 | 0 | - |
| discs covering 36 / 47 / 59 / 70 / 80 % | 0.98 / 0.98 / 0.99 / 0.98 / 0.99 | <= 0.1 | from 59 % |
| drying fronts covering 30 / 50 / 60 / 70 / 80 / 90 % (shading across or along the front) | 0.95-0.97 | <= 0.1 | from 60 % |
| disc covering 96 % (4 % wet) | 0 (not found: the wet state is below 5 % of the field) | 0 | - |
| smooth SE texture of 6 % in a gas-free frame | 17.6 % false contact (texture beyond the 5 % floor) | | - |

Particle detection (`docs`-independent tests in `tests/test_v030.py`; 1.8-px particles of amplitude 40-80 on noise 8):
pairs 5 / 6 / 8 / 10 / 14 px apart: recall 0.6 / 0.98-1.00 / 1.00 / 1.00 / 1.00 (0.00-0.03 at 8-10 px before round 2);
a particle 3-20 px inside a 25-grey thickness step: 1.00 (0-0.2 before); circular rims without particles: 0 false
detections per image (141 without the rim tests).

**Known limitations.** The statistical thickness errors in the maps (`sT`) propagate the raw pixel noise through the
smoothing but ignore the denoiser and all systematic errors: 51-53 % of the errors fall within 1.96 sT (review round 2):
treat sT as a lower bound, about 2.3x too small. The PCA + GMM segmentation is fitted frame by frame, so the number of
classes and their tags can change between frames of a movie, and the criterion often picks the largest k searched
(`k_at_limit`); a series-wide model is planned.
