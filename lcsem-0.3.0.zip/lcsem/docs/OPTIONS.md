# Acquisition and analysis options

`lcsem` runs with whatever you recorded. Every optional acquisition adds a measured quantity or replaces an assumption;
the calibration report (`calibration_report.json`) says which model was used and turns every redundant reference into a
consistency check. `lcsem options` prints this table.

| option | what to record | what it gives | without it |
|---|---|---|---|
| **BSE channel** | annular BSE detector (e.g. JEOL BED-C) images | liquid thickness in the column; particle photometry and depth (core fraction) | required unless STEM is used |
| **STEM channel** | transmission detector below the cell, same scan | 10-60x more thickness information per electron for T < ~500 nm; BSE/STEM ratio -> particle depth from one scan; independent check of the BSE thickness (chi2 map) | BSE only |
| **SE channel(s)** | in-lens (UED) and/or E-T (LED) SE, same scan | where gas touches the top membrane (charging-mediated contact map) -> gas placed at the top | gas cannot be placed vertically |
| **dark reference** | frames with the beam blanked, same detector settings | black level measured, not assumed | black level from a flat field of assumed thickness or from a second reference |
| **empty reference** | an empty (dry) K-kit, same kV, current, detector settings | signal at T = 0 -> gain without particles; with dark: instrument-calibrated thickness | gain from particles |
| **full reference** | this cell completely filled (before gas forms) | local gap h(x, y) incl. membrane bulging -> total gas = h - T, incl. gas that does not touch the top membrane (label 4) | gap = median of the wet region of each frame |
| **particle standard** | isolated Au spheres of known size (60 nm recommended at 12k, 30-40 nm at 60k) | gain (internal standard; particles in the top quarter of the liquid, depth-corrected) and a test of the Monte Carlo detector model | gain from dark + empty |
| **probe current** | Faraday-cup reading or a current log per frame | frames at different currents on one scale; dose per frame | constant current assumed |
| **second kV** | frames at e.g. 8-10 kV between main frames | particle depth from the energy ratio | core fraction / channel ratio only |
| **16-bit images** | 16-bit TIFF export | no clipping of bright particles (the core fraction needs unsaturated particle cores) | clipped cores are flagged and get no depth |

## Analysis options (no extra acquisition)

| option | what it does | default |
|---|---|---|
| `segmentation` | per frame PCA of (thickness at two scales, NLM-denoised SE at two scales, thickness gradient) and a Gaussian mixture with the number of classes by ICL (separated phases) and BIC (finer levels); the number of classes is the most frequent choice over `stability_runs` random subsamples (same size as the fit) and is reported with that frequency; `skip_rows` leaves out the first scan lines | on (needs an SE channel), 5 stability runs |
| `amira` | AmiraMesh export: liquid and gas as voxel fractions (not binary), cell walls and Au particles = 1, particle spheres, landmarks, 2-D maps, class probabilities | off (`lcsem amira run_dir` any time) |
| `depth.curve` | a separate Monte Carlo file for the particle depth models (e.g. `data/curve_15kV_SiN30_H2O_BEDC_Au38.json`) | the thickness curve, if it has particle profiles |

## Configuration examples

Minimal (what K-kit 1 had: BSE + SE, Au particles, no references):
```json
{"name": "kkit1_12k", "folder": "/data/K-Kit_Au_NPs", "prefix": "20260821", "pixel_nm": [8.016, 8.041],
 "select": {"mag": 12000, "time_from": "10:19:00", "time_to": "10:28:00"},
 "channels": {"BSE": {"signal": "BED_C", "role": "thickness", "detector": "BEDC"}, "SE": {"signal": ["UED", "LED"], "role": "contact"}},
 "references": {"flat": {"frames": "all", "T_nm": 200}, "particles": {"diameter_nm": 38}},
 "curves": {"BSE": "data/bse_vs_water_15kV_BEDC.json"}, "frame_edge": true}
```

Full (recommended next experiment: 0.5 um K-kit, BSE + STEM + in-lens SE, all references):
```json
{"name": "kkit2", "folder": "/data/K-Kit2", "prefix": "2026", "pixel_nm": [1.603, 1.608], "bits": 16,
 "cell": {"membranes_nm": [30, 30], "channel_nm": 500},
 "channels": {"BSE":  {"signal": "BED_C", "role": "thickness", "detector": "BEDC"},
              "STEM": {"signal": "STEM", "role": "thickness", "detector": {"kind": "stem", "mrad": [0, 100]}},
              "SE":   {"signal": ["UED"], "role": "contact"}},
 "references": {"dark":  {"files": ["dark_001", "dark_002"]},
                "empty": {"files": ["empty_001", "empty_002"]},
                "full":  {"files": ["full_001"]},
                "particles": {"diameter_nm": 60},
                "current": {"csv": "faraday_log.csv"}},
 "depth": {"methods": ["core_fraction", "channel_ratio"]}}
```
The Monte Carlo curves for the STEM detector (and for any kV, membrane or detector geometry) are computed on first use and
cached in `~/.lcsem/curves` (a few minutes). Set the STEM detector's semi-angles from its geometry
(half-angle = atan(radius / distance)); the curve depends on them.

Other keys (defaults in `lcsem/config.py`): `select` (mag, time window, kV), `frame_edge` (Si frame in view), `particles`
(detection scales, threshold, aperture), `smooth_sigma_px`, `nlm`, `deinterfere` (mains pickup in slow scans), `frame_time`,
`se` (contact-map smoothing and cleaning), `gas.other_threshold_nm`, `tracking` (max displacement, gaps), `volume`
(z step, 4-D stacks), `mc` (electrons per point, cache folder), `calibration.mode` (`auto` or a forced model),
`calibration.use_particles`.

## What the validation says about each option set

See `docs/VALIDATION.md` (regenerate with `lcsem validate out_dir`): synthetic K-kit data with ground truth, analysed with
each subset of channels and references, and a second data set whose images were formed with a different BSE detector
acceptance than the analysis assumes (a detector-model error).
