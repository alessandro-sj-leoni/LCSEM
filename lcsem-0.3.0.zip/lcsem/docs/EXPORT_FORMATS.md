# Export formats

Every export is written from one 4-D model of the run (`lcsem.volume4d.Volume4D`), so all programs show the same voxels as
the GUI. From the GUI: tab **5 Export**, tick the formats, choose a folder, **Export**. From the command line:

```
lcsem export RUN_DIR --formats amira,tiff,ome-tiff,imaris,vtk,csv --out RUN_DIR/export     # "all" for every format
lcsem export --list                                                                        # formats and the programs that open them
```

Each format goes into its own sub-folder. Unless `--no-check` is given, every export is read back with an independent
reader where one exists (tifffile, zarr + ome-zarr, imaris-ims-file-reader, VTK, SimpleITK, a raw MRC header parser,
meshio + trimesh, scipy.io / h5py, h5py, openpyxl, pandas, an AmiraMesh parser) and compared with the model **voxel by voxel
for every layer of the first, middle and last frame**, with the frame count and the voxel size and origin where the format
stores them; meshes and tables are checked for readability and rows. The result is in `export_manifest.csv` (column
`checked` says what was compared). `README_EXPORT.txt` also states the mode, the calibration used and any assumption, the
layer-model conventions, the particles without a measured depth and the dose. A format whose library is missing is reported
and skipped; the others are still written. The files were verified by these readers, not yet opened in every target program:
please report any program that does not read them.

## What is in the volumes

| layer | meaning | values |
|---|---|---|
| liquid | fraction of the voxel filled with liquid | 0-255 (= 0-1); **not binary**: an isosurface at 128 is a smooth liquid surface |
| gas | fraction of the voxel filled with gas (at the top membrane and elsewhere) | 0-255 |
| contact | SE contact (gas touching the top membrane, also films too thin to change the thickness), in the voxel layer under the top membrane | 0-255 |
| walls | SiN membranes and the window frame (the edges of the liquid cell) | 1 (255 in 8-bit multi-channel files) |
| au | Au particles, spheres of their true diameter at their measured depth (just under the top membrane if the depth was not measured) | 1 (255 in 8-bit multi-channel files) |

Axes: z = height above the bottom of the volume (the beam comes from +z). Conventions, not measurements: the top membrane
is drawn flat and every change of the column shows at the bottom membrane; gas not touching the top membrane is drawn on
the bottom membrane; particles without a measured depth sit under the top membrane in the `au` volumes (flagged
`z_measured = 0` in the tables, `Z_MEASURED = 0` in the TrackMate table). x, y on the drift-corrected canvas, binned
(default 4 x 4). Voxel (0, 0, 0) is centred at (dz/2, (b - 1) p_y/2, (b - 1) p_x/2) (z, y, x) in every format that stores an
origin, as in the viewer and the particle tables. Areas not imaged in a frame (drift) are 0. Liquid thicker than the cap
(default 1500 nm) is drawn at the cap.

The liquid layer is thin compared with the field: exaggerate z (x 5-10 at 12k, x 1-2 at 60k) - Amira: Transform Editor
(scale z); Fiji: Image > Properties (voxel depth); Imaris: Edit > Image Properties (voxel size z); ParaView: Transform filter
(scale z); 3D Slicer: Volumes module, spacing; ChimeraX: `volume #1 voxelSize 25.6,25.6,100`; Blender: scale Z of the
imported objects.

## Formats and how to open them

| format | files | open with | how |
|---|---|---|---|
| `amira` | per frame `*_liquid_fraction.am`, `*_gas_fraction.am`, `*_cell_walls.am`, `*_au_nps.am`, `*_top_contact.am` (zlib-compressed AmiraMesh), `*_au_nps.surf` (exact spheres), `*_particles.landmarkAscii`, 2-D `*_thickness_nm.am`, `*_time_s.am`, `*_class_prob_*.am` | Amira, Avizo | File > Open Time Series Data, select all `*_liquid_fraction.am`; repeat for the other layers; Isosurface at 128 (liquid, gas), 0.5 (walls, particles); see `README_AMIRA.txt` |
| `tiff` | `NAME_TZCYX.tif`, ImageJ hyperstack, 5 channels (liquid, gas, contact, walls, au), calibrated in nm, frame interval in s | Fiji / ImageJ, Icy, napari | File > Open; Image > Hyperstacks; for the 3D Viewer (threshold 128) split the channels first (Image > Color > Split Channels) |
| `ome-tiff` | `NAME.ome.tif` (TCZYX, physical sizes in the OME-XML) | Fiji (Bio-Formats), QuPath, Imaris, arivis, Dragonfly, napari | File > Import > Bio-Formats (Fiji); drag and drop elsewhere |
| `ome-zarr` | `NAME.ome.zarr` (OME-NGFF 0.4, TCZYX, scale and translation metadata) | napari with the napari-ome-zarr plugin, Fiji (MoBIE, N5 viewer), Neuroglancer, vizarr | `pip install napari-ome-zarr`, then `napari NAME.ome.zarr` (without the plugin napari opens it as a plain 5-D array in pixel units); for web viewers serve the folder over http |
| `imaris` | `NAME.ims` (Imaris 5.5 HDF5, all frames and channels) | Imaris, Imaris Viewer (free), Fiji (Bio-Formats), arivis | open the file; Surpass > Surfaces on liquid / gas at 128 |
| `vtk` | per frame `*.vti` (image data, one array per layer), `NAME.pvd` (time collection), `NAME_particles.vtp`, `NAME_tracks.vtp` | ParaView, VisIt, PyVista | open `NAME.pvd` (the time controls step through the frames); Contour at 127.5 on liquid / gas; particles: Glyph (sphere) |
| `nrrd` | `NAME_liquid_fraction.seq.nrrd` (4-D sequence), per frame `*_labels.nrrd` (0 empty, 1 liquid, 2 gas, 3 SE contact, 4 wall, 5 Au) | 3D Slicer (Sequences), ITK-SNAP, MITK | drag the `.seq.nrrd` into Slicer (loaded as a sequence; play in the Sequences module); label maps as segmentations. Spacing and origin in micrometres labelled mm (1 "mm" = 1 um), space LPS with identity directions (ITK tools show the image as the SEM does) |
| `nifti` | `NAME_liquid_fraction.nii.gz`, `NAME_gas_fraction.nii.gz` (4-D: x, y, z, t; micrometres labelled mm as in NRRD, seconds) | 3D Slicer, ITK-SNAP, FSLeyes, MRIcroGL | open the file; time is the 4th dimension. The affine flips x and y (RAS), so in ITK-based tools (Slicer, ITK-SNAP) NIfTI and NRRD lie on the same grid; RAS viewers (FSLeyes, MRIcroGL) show it turned by 180 degrees in the image plane relative to the SEM image |
| `mrc` | per frame `*_liquid.mrc`, `*_gas.mrc` (8-bit, percent of the voxel filled), `*_au.mrc` (1 = particle); voxel size and origin in angstrom (MRC2014) | UCSF ChimeraX / Chimera, IMOD, Dragonfly | ChimeraX: `open *_liquid.mrc vseries true` (a slider steps through the frames); `volume #1 style surface level 50` |
| `mesh` | per frame `*_liquid.stl`, `*_gas.stl`, `*_au.stl` (binary STL) and `*_scene.glb` (glTF with colours), surfaces by marching cubes at half filling (every 2nd voxel); z not exaggerated; coordinates in nm | Blender, MeshLab, ParaView, CAD programs, 3-D printing, web viewers | Blender: File > Import > glTF 2.0 (.glb; one file per frame; nm come in as metres - scale by 1e-3 or set the scene unit); `lcsem.export_formats.export_mesh(..., z_exaggeration=5)` for exaggerated relief |
| `matlab` | `NAME.mat` (v5; v7.3/HDF5 when over 2 GB): `liquid`, `gas`, `contact`, `walls`, `au` (t, z, y, x), `thickness_nm`, `contact_map`, `time_s`, `spacing_nm_zyx`, `particles`, `volumes_vs_time` | MATLAB, Octave, Python (`scipy.io.loadmat`) | `S = load('NAME.mat')`; v7.3: `matfile` or `h5read` |
| `hdf5` | `NAME.h5`: `/volumes/<layer>` (t, z, y, x, gzip, chunked per frame), `/maps/*` (thickness, sigma, gas, contact, time), `/tables/*` (CSV text), metadata and the full configuration as attributes | HDFView, Python (h5py), MATLAB (`h5read`), R (rhdf5), Dragonfly | |
| `csv` | `NAME_volumes_vs_time.csv`, `_summary`, `_particles`, `_tracks`, `_objects`, `_object_tracks`, `_segmentation_classes` (whatever the run has) and one workbook `NAME_tables.xlsx` with all of them | Excel, Origin, Prism, R, pandas | |
| `trackmate` | `NAME_trackmate_spots.csv` with TrackMate column names (ID, TRACK_ID, POSITION_X/Y/Z in nm, POSITION_T in s, FRAME, RADIUS, Z_MEASURED; POSITION_Z of particles without a measured depth is the top-membrane convention, see Z_MEASURED) | Fiji TrackMate (CSV importer, from the Fiji update sites), napari | import as spots with tracks |

## Sizes

Volumes are mostly empty and compress well. The 12k series of K-kit 1 (9 frames, lattice 418 x 307 x 70 voxels of
25.6 x 25.6 x 10 nm at bin 4), all 14 formats in 69 s, all read back correctly:

| format | MB | format | MB | format | MB |
|---|---|---|---|---|---|
| amira (zlib) | 20.3 | tiff | 3.4 | ome-tiff | 3.6 |
| ome-zarr | 6.3 | imaris | 6.3 | vtk | 3.5 |
| nrrd | 2.2 | nifti | 2.5 | mrc (uncompressed) | 243 |
| mesh | 72 | matlab | 6.1 | hdf5 | 9.6 |
| csv + xlsx | 0.15 | trackmate | 0.01 | | |

MRC has no compression (about 9 MB per layer and frame here); increase the binning (`--bin 8`) or `--dz` for long movies.
