# Review of lcsem 0.3.0 (GUI release): Reviewer 4, usability

Reviewer profile: liquid-cell SEM user (JEOL, K-kit SiN cells, SE/BSE/STEM-in-SEM, movies of bubbles and nanoparticles).
I worked through the GUI as tomorrow's user would. I read `lcsem/gui/*.py`, `io_movie.py`, `project.py`, the calibration,
SE-contact, object and particle code, README.md, docs/GUI.md and docs/EXPORT_FORMATS.md. I looked at all 7 screenshots, made
new headless screenshots, and ran the GUI's project runner and the GUI itself on the synthetic movie (with ground truth)
under the **default** settings and in the failure cases a user will hit. Scripts, run folders and images are in
`/home/claude/reviews/reviewer4_usability_work/`. I changed nothing outside `/home/claude/reviews/`, except that importing
the GUI made Python regenerate three stale bytecode files in `lcsem/gui/__pycache__`.

## Summary

The GUI is well built. The tabs follow the work, projects are JSON files that also run headless, long jobs run in a
worker thread with abort, the charts follow the time slider, every export is read back, and README_AMIRA.txt is
exemplary. But its default path for tomorrow's data (SE + BSE movies without references) is not safe: with the GUI
defaults the run either stops after preprocessing ("not enough references"), or it silently anchors the thickness to a
hidden 200 nm flat field (synthetic movie: 217 +- 1.4 nm reported, 690 nm true), and the GUI never shows which calibration
it used (every movie demonstration in the docs used the simulation's true B0 and g as a "manual" calibration). Silent
defaults and hidden parameters change results without warning: 8-bit depth on 16-bit data gives 0 nm everywhere; pixel
size (8 nm), frame time (container frame rate) and start time (10:00:00) are prefilled; swapped SE/BSE halves in a
side-by-side file go unnoticed; and a 2000-px floor overrides the GUI's minimum bubble area. Two detectors produce
convincing false structures exactly in bubble movies. The particle detector puts rings of "Au particles" on bubble edges:
68-73 % of detections on the synthetic movie, 46 of the 49 amber "depth measured" particles are false, and bubble areas
come out 20 % low. The per-frame Otsu contact map calls about 45 % of a gas-free frame "gas". The display cannot be
checked against the data (no raw frames, no reachable 2-D thickness map with a colour bar) and does not say how reliable
each number is. I recommend **major revision**: fix M1-M3 and M8 (mostly quick) before tomorrow, and treat tomorrow as a
supervised demonstration until M4-M5 are fixed too.

## Major issues

Priority for tomorrow: M1, M2, M3 and M8 (hours of work each), then M4 and M5 (correctness), then M6 and M7 (display and
trust).

### M1. Default calibration for movies: fails, or silently uses an assumed 200 nm flat field; the GUI never says which

* **Where.**
  * `gui/project.py:74` always passes `references.flat = {frames: 'all', T_nm: flat_T_nm}` with the Processing-tab default
    of 200 nm (`panels.py:157`, `project.py:25`).
  * `calib.solve` in 'auto' mode (`calib.py:129-134`) takes the first model the references allow. Without an empty cell,
    that is 'particles+flat' or 'dark+flat'. Without particles near the top membrane and without a dark reference, no model
    fits and the run stops.
  * The mode used is written only to `calibration_report.json` and to one log line. Nothing in the viewer, the overlay, the
    charts or the exports shows it.
  * The tooltip says the flat thickness is used in "modes ...+flat", so a user who leaves 'auto' selected does not know it
    applies.
* **Evidence (synthetic SE + BSE movie, 60 nm Au, GUI project runner, defaults except step 4).**
  1. `run_A_auto`, no references, the GUI default. It stops after preprocessing (17 s in the GUI) with
     `ValueError: calibration: not enough references (['flat']); record a dark frame and an empty cell, or use Au standards
     + a flat field`. The traceback is shown in the Run log. The user never entered a "flat" reference. The particle
     standard failed because "only 0 particles near the top membrane".
  2. `run_B_auto_dark`, a diligent user who recorded a dark reference (beam blanked). 'auto' picks **dark+flat**:
     B0 = 30.00 (true 30), g = 1374 (true 600). Every frame reads about 30 % of the truth: frame 0 gives **217 +- 1.4 nm**
     against a true 690 nm, and frame 9 gives 176 nm against 585 nm. The median bias is -441 nm. Gas thickness, volumes and
     depths inherit the factor of 3. The stated +-1.4 nm is only the statistical error.
  3. The real runs behind the README/GUI screenshots (`run12_v4`, `run60_v4`) used **particles+flat** with "flat field ...
     assumed 200 nm -> B0". The medians shown in the screenshots (187 nm, 171 nm) therefore sit near 200 nm by construction.
     In run12_v4, scan 0 was re-anchored again ("own gain and black level").
  4. All GUI movie runs used for the docs (`gui_dev/run_proj_SE_BSE*`, `run_synmovie_SE_BSE_STEM`) used
     `calibration.mode = 'manual'` with B0 = 30, g = 600 (BSE) and 15/220 (STEM). These are the simulation's own constants
     from `simulate.make_movie`. The default path was never exercised, and no test covers it (`tests/test_v030.py` only
     round-trips projects and opens a finished run).
* **Why it matters.** Tomorrow's movies will most likely have no empty-cell reference. The user will either get an error they
  cannot act on, or absolute numbers (nm, µm³, depths) that are an assumption shown as a measurement. METHODS §7 admits
  "+-25-30 % without references" and "absolute level: set by the dark (or flat) reference". The GUI shows none of this.
* **What to do.**
  * Add a **pre-flight check** on *Run*. It should list the references found, the calibration model that will be used and
    every assumption it makes, and refuse or confirm before the long preprocessing.
  * Never default the flat-field thickness. If a "+flat" model is chosen, make the user type the thickness and a reason
    (e.g. "window centre measured by EELS / known spacer").
  * Offer an explicit **"relative thickness (no absolute scale)"** mode for movies without references.
  * Print the calibration model, its assumptions and a systematic-error line in the viewer overlay, on the charts (e.g.
    "thickness scaled to an assumed 200 nm flat field; systematic +-30 %") and in every export README.
  * Add a test of the default GUI path on the synthetic movie, and report the result of that path in the docs, not the
    manual one.
  * For tomorrow: tell the user to record a dark reference (beam blanked, same brightness/contrast) and, if at all
    possible, an empty (dry) cell at the same settings.

### M2. Unsafe silent defaults in the Data tab for movies (bit depth, pixel size, frame time, start time, cell, beam)

* **Bit depth** (`panels.py:84`, default '8'). `pipeline.py:84` sets the saturation level `HI = 2**bits - 1`, which is used
  for clipping, noise and particle rejection (lines 124 and 136-146).
  * **Evidence** (`run_C_16bit_bits8` against `run_C_16bit_bits16`): the same movie as 16-bit TIFF analysed with the default
    8 gives "BSE clip 100.0 %, particles 0, liquid 0 nm (+- 0.3)" in every frame, and the run ends "OK" with no warning.
    With 16 it gives 665 nm (truth 690 nm) and 24-40 particles per frame.
  * *Probe files* shows the grey range (e.g. "range 514-65535") but does not set or check the bit depth. For videos,
    `probe()` reports `dtype float32` because it reports after grey conversion (`io_movie.py:144`).
  * **Fix:** set the bit depth from the file dtype or maximum, and refuse to run when the data exceed `2**bits - 1`.
* **Pixel size** (`panels.py:81`, 8.0 x 8.0 nm prefilled). Neither JEOL series nor movies fill it in.
  * It is silently used for everything. The particle gain is in grey x nm² (`pipeline.py:223-237`, `pxa`). Particle depth
    models are rendered at the pixel size. It also sets volumes and areas (scale with px²), the object minimum area,
    smoothing in pixels, and the automatic z exaggeration.
  * For a screen recording the pixel size is not the scan pixel size.
  * **Fix:** no default (red field until set), plus a "set scale" tool: draw a line along the burnt-in scale bar on the
    first frame and type its length. Optionally compute it from magnification and the JEOL field-width reference.
* **Frame time.**
  * *Probe files* silently sets frame time = 1/fps of the container when the field is 0 (`panels.py:116`).
    * **Evidence** (`screenrec_SE_BSE.mp4`, a JEOL-like screen recording with 2 s SEM frames recorded at 10 fps): the
      frame time was set to 0.1000 s, with no message beyond "fps 10.0".
    * For screen recordings the container rate is the recorder's rate, not the SEM frame time. The per-row clock (METHODS
      §5), dT/dt, velocities and growth rates are then wrong by the ratio (x20 here).
  * If there is no rate (image folders, TIFF stacks without `finterval`), `movie_scans` silently uses 1 s
    (`io_movie.py:155`).
  * **Fix:** show both "SEM frame time (scan)" and "video frame interval", make the user confirm the SEM frame time, and say
    in the info line what will be used.
* **Start time** (`panels.py:69`, `project.py:19`, default "10:00:00").
  * It is a made-up clock time. It appears in the overlay ("t = 10:00:10.5"), in `*_time_s.tif` ("s since midnight") and in
    the CSV exports (`volumes_vs_time.csv: time_s = 36000.25`) as if it were measured.
  * Parse errors such as "10:00" become 0 silently (`project.py:54-57`).
  * **Fix:** leave it empty, show relative time (+s) unless a real start time is given, and validate the entry.
* **Cell, beam and detector.**
  * The defaults are 15 kV, SiN 30/30 nm (one value for both membranes), 38 nm Au (the author's sample), 500 nm channel and
    "detect Au particles" on. The BSE detector is always BED-C (15-65°, `project.py:69`).
  * The Monte Carlo curve is computed for these values without showing them. On first use it took **226 s** on this machine
    for the default cell, with no progress in the GUI (the MC prints to stdout, invisible with `lcsem-gui` on Windows).
  * Changing the channel height changes the cache key (`particle_T` depends on it, `pipeline.py:185-199`), so every trial
    value costs another 4 minutes.
  * The MC library has other BSE detectors (in-lens axial, E-T grazing, `mc/detectors.py:52-63`), but the GUI cannot select
    them.
  * **Fix:** a "cell and model" summary box with no hidden defaults for kV and particle size in movie mode, a BSE detector
    choice, separate top and bottom membrane thicknesses, particle detection off unless a particle diameter is entered, and
    MC progress in the Run tab.

### M3. Tomorrow's likely file layouts (side by side / top-bottom with a data bar, screen recordings) cannot be set up safely

* **Crop is applied after splitting** (`io_movie.py:86` and `104`) and the split is an equal division (`io_movie.py:100-103`).
  The GUI placeholder does not say this.
  * **Side by side.** A dual-display recording has separators, a title bar and a data bar under both images. Neither the
    split nor the post-split crop can isolate the two images.
    * **Evidence** (`screenrec_SE_BSE.mp4`, 2 x 400 px images with a 4-px separator): each part is 402 px wide. The SE part
      ends with 2 separator columns (grey 255), the BSE part starts with 2, and one common crop cannot remove both.
  * **Top/bottom.** With a data bar under the lower image, `h = H // 2` cuts the upper image 20 rows into the lower one
    (300 + 300 + 40 rows gives parts of 320 rows each). The SE and BSE parts are then offset by 20 rows. That is beyond the
    10-px SE-to-BSE alignment limit (`pipeline.py:172`), so the SE contact map is silently misplaced by 160 nm.
* **No preview of the parts.** Nothing in the GUI shows the input frames or the split and cropped parts, so the part indices
  cannot be checked.
  * **Evidence** (`run_D_swapped`, the side-by-side MP4 with SE and BSE part indices swapped): the run completes "OK" with
    liquid **711 nm in every frame** (truth 690 -> 585 nm), "SE-dark 11-21 %" and 15 "particles" found in the SE image. There
    is no warning. With the correct indices (`run_E_sbs_correct`) the result is 662 -> 570 nm.
* **Screen recordings.** Duplicate and partially refreshed frames are not detected.
  * **Evidence:** in the simulated recording (20 video frames per SEM frame, rolling scan line), consecutive frames differ by
    0.6-0.7 grey on average. Nothing flags this. Every video frame becomes an independent time point with a full per-row
    clock. The noise model and the series denoisers (MP-PCA, SVD, temporal mean) then see duplicated frames as signal.
* **Fix.**
  * Crop before splitting, ideally by drawing one rectangle per detector on the first frame.
  * Show a preview of the parts labelled "SE" and "BSE" with the crop applied.
  * Add a sanity check (Au particles are bright in BSE and absent in SE; a warning when the "BSE" part looks like SE).
  * Detect duplicate and rolling-update frames and propose `step` and the SEM frame time.
  * Accept a time offset between separate SE and BSE files. Today different lengths are silently truncated to the shorter
    one (`project.py:141`).

### M4. False Au particles along bubble edges, drawn in 3-D with "measured" depths; they also cut about 20 % off every bubble

* **Where.** `imageproc.detect_particles` (`imageproc.py:126-145`) takes local maxima of a difference-of-Gaussians response
  above 6 robust sigmas, with no test for elongated (edge) responses. At the bright side of a dark disc (a bubble in BSE)
  the response forms a ridge. Non-maximum suppression over 13 px turns it into a ring of evenly spaced "particles".
* **Evidence.** I matched detections to the true positions (`truth_movie.json`, drift-corrected, 4 px tolerance).
  * **GUI project run** (`gui_dev/run_proj_SE_BSE`, NLM, the documented default):
    * 657 detections in 20 frames for 12 true particles per frame.
    * 209 of them are true particles (recall 87 %). **448 (68 %) are not at any particle**, and 446 of those lie within
      12 px of a bubble edge.
    * **46 of the 49 particles with a "measured depth" (amber) are false.**
  * **Run shown in `docs/img/gui_synmovie.png`:** 1165 of 1591 detections (73 %) are false (1107 at bubble edges), and 181 of
    the 507 "measured positions" in its chart footer are false.
  * The ring of grey spheres around the bubbles in that screenshot, and in my top view `synBSE_top.png`, is this artefact.
    `false_particles_frame0.png` overlays detections and truth on the BSE and SE frames.
  * The false detections also mask the bubble rim. `f.valid = valid & ~f.au`, and the SE contact map is computed on
    `f.valid` (`pipeline.py:125` and `310`).
    * In the SE + BSE run, particle masks cover 23-26 % of the true contact area.
    * Bubble (object) areas are **0.75-0.82 of the truth**. In SE-only mode, which has no particle detection, they are
      0.94-1.03 (median 1.02), which confirms the "about 2 %" claim of GUI.md for SE-only only.
* **Why it matters.** A ring of nanoparticles "decorating" a gas-liquid interface is exactly what a user would interpret
  physically. It feeds the particle-depth chart, tracks, the particle gain, the particle masks and the object areas.
  Tomorrow's bubble movies are the worst case. I could not test whether the real 12k/60k data are affected; see the
  questions.
* **Fix.**
  * Reject edge responses (Hessian eigenvalue ratio as in SIFT, or a minimum contrast in every direction of an annulus).
  * Do not remove particle masks from the SE contact map. Fill them from the surroundings instead.
  * Turn particle detection off by default unless the user enters a particle diameter.
  * Report detection precision and recall on the synthetic movies in VALIDATION.

### M5. SE contact map and objects: false gas in gas-free frames, a hidden 2000-px floor, and a "thin" source that is constant by construction

* **Otsu per frame without a bimodality test** (`analysis.py:15-25`, METHODS §3).
  * **Evidence:** a gas-free SE frame with the synthetic movie's noise model (sd 7.3 grey) gives a contact map covering
    **41-44 % of the field and 46-58 "bubbles"**. After NLM + VST denoising it is 43 % and 18 objects; after BM3D + VST,
    47 % and 21 objects.
  * Movies that start before nucleation, or in a fully wet cell, will show gas where there is none. In SE-only mode this is
    multiplied by 50 nm into a "gas volume".
  * **Fix:** a contrast or bimodality test (e.g. Otsu effectiveness, or 1- against 2-component GMM by BIC), or one threshold
    for the whole movie set on a reference frame.
* **Hidden minimum area.**
  * The contact map uses `config.se.min_area_px = 2000` (`config.py:48`), with 6-px smoothing and 3 opening iterations. None
    of these are in the GUI, and they override the GUI's "min object area (px) 100".
  * **Evidence:** discs of 201, 452, 1017 and 1963 px area (130-400 nm diameter at 8 nm/px) are **not** found. Discs of 3848
    and 7853 px are found.
  * For nucleation studies this delays every bubble's "first appearance" and truncates size distributions.
  * **Fix:** expose it in nm², and state it next to the object settings.
* **Object source "thin".**
  * It uses the 20th percentile of each frame (`objects.py:31`, `thin_nm=None`), so the thin area is **exactly 20.0 % of the
    field in every frame**. On the synthetic movie the true fraction below 300 nm grows from 10.5 % to 24.1 %.
  * The option cannot follow thinning or dewetting.
  * **Fix:** an absolute threshold in nm.

### M6. The display cannot be checked against the data, and the 2-D thickness map is not reachable as documented

* **No raw data.** No SE or BSE frame (raw or denoised) is shown, and there is no overlay of the contact outline or particle
  detections on the images. A microscopist's first check, and the only way to catch M3 and M4, is impossible in the GUI.
* **2-D maps.**
  * GUI.md (line 71) says "switch to 2-D to see them as images". The *2-D / 3-D* button shows a slice through the **middle**
    of the volume (z step 552 of 1000; `synBSE_2d_button.png`). The thickness map is a slab at z = -3 dz below the volume
    (`display.py:90-93`), so the user must find and drag the unlabelled z slider to 0 to see it (`synBSE_2d_zbottom.png`).
  * The map has **no colour bar**, no numbers, and fixed contrast limits at the 2-98 % percentiles of all frames.
  * Areas not imaged and masked areas are converted NaN -> 0 and drawn as the darkest viridis colour, i.e. as "thinnest
    liquid".
  * The status bar shows `liquid [10.00, 3450.00, 0.00, 0.00]: 0`. These are world coordinates with z multiplied by the
    exaggeration, and the value of the selected layer, not "T = ... +- ... nm at x, y".
* **What I would want.**
  * A linked 2-D panel (or napari grid mode) with raw SE, raw BSE, the thickness map in nm with a colour bar, the contact
    outline and particle markers, all following the time slider.
  * NaN shown as transparent.
  * A cursor readout of T +- sigma, gas and pixel time.
  * A line-profile tool and an ROI time series (mean thickness in a drawn region against time).
  * Clicking a particle to show its z(t) with error bars.

### M7. Trust: the GUI does not say how reliable each number is, and invites over-interpretation

1. **Calibration and references** used are not shown anywhere in the viewer (see M1). Opening a finished run does not load
   its settings: the tabs keep showing whatever defaults are in them.
2. **Errors.**
   * Charts have no error bands. The only uncertainty anywhere is the statistical +-1-3 nm in the log.
   * The systematic model and calibration error (METHODS §7: +-25-30 %) and the flat-field assumption are absent.
   * Chart y-axes do not start at zero. In `gui_12k.png`, chart (a) spans 6.0-7.0 µm³, so frame-to-frame gain re-anchoring
     looks like dynamics.
3. **SE-only mode.**
   * Charts (a) "liquid volume (µm³)" and (b) "gas volume (µm³)" are nominal: the channel height times area, and a
     hard-coded 50 nm gas layer times contact area (`project.py:80`, `se_only.py:39`).
   * They are not labelled "nominal"; only chart (c) is. The 50 nm is not settable. In `gui_se_only.png` a reader sees gas
     "growing" from 0.05 to 0.09 µm³.
4. **Particles.**
   * Particles without a measured depth are drawn "just under the top membrane" (`volume4d.py:113`). In 3-D that is a
     statement of position.
   * In the flagship 12k run, **1 of 192** particle positions has a measured depth. The note that says so is set only when
     chart (d) shows particle depth (`charts.py:97`). For the 12k run chart (d) defaults to classes, so the user never sees
     it.
   * In the exported `au` volumes, measured and assumed depths look identical.
   * Draw unmeasured particles as open markers or vertical lines spanning the liquid, not as spheres at the top.
5. **Geometry.**
   * The top membrane is drawn flat and all relief goes to the bottom membrane. This is stated in METHODS and README_AMIRA but
     not in the GUI, so the side view reads as "the bottom membrane is wavy".
   * Gas thickness uses a uniform "wet reference" gap (`pipeline.py:333-336`) unless a full-cell reference exists, and the
     GUI does not say which.
   * Thickness is smoothed by 15 px before calibration (`config.py:45`). That is a sigma of 120 nm at 12k and 24 nm at 60k,
     so the effective lateral resolution changes 5x with magnification without being shown.
   * With 10x z exaggeration a per-pixel sigma of about 20 nm (12k run) becomes 200 nm of jagged relief on screen
     (`gui_12k.png`).
6. **Segmentation chart.** Classes are fitted per frame, and their identities and number change between frames. The stacked
   area chart (d) then shows class areas jumping by tens of percent (`synBSE_top.png`), which reads as physics.
* **What to do.**
  * A "Run summary / reliability" box in the Display tab, one line in the canvas overlay (mode, calibration, references,
    assumptions), and per-frame QC flags (re-anchored gain, registration fallback, clipping, false-contact risk).
  * Label nominal quantities in the chart titles, and add error bands.

### M8. Robustness in the main path (hangs, crashes, ignored controls)

1. **Empty frame selection hangs the GUI.** If start >= stop, or start lies beyond the movie, the pipeline raises
   `SystemExit('no scans selected')` (`pipeline.py:96`). `worker.Job.run` catches only `Exception` (`worker.py:24`), so
   neither `finished` nor `failed` is emitted.
   * **Evidence** (`test_noscan.py`): after 60 s the Run button is still disabled, Abort is enabled, the status reads
     "ready" and the log's last line is "0 scans given". The process aborted when the viewer closed.
   * **Fix:** raise `ValueError`, catch `BaseException` in the worker, and validate the frame range in the Data tab.
2. **Re-running into the same output folder breaks the run.** `run_project` reuses a non-empty folder
   (`project.py:172`). `Volume4D` globs `{name}_*_maps.npz` (`volume4d.py:54`) instead of reading the frame list in
   `run_info.json`.
   * **Evidence** (`run_F_rerun`, the same project re-run with step 3 instead of 4): the folder then holds 23 map files for a
     14-frame run, and opening it fails with `IndexError: index 14 is out of bounds`.
   * Tomorrow the user will certainly re-run with another step or crop into the same folder.
   * **Fix:** write a new timestamped subfolder per run (or clear it after confirmation), and read frames from
     `run_info.json`.
3. **"max liquid shown" does nothing.** The Processing field (`panels.py:185`) is not passed to `Volume4D` (`app.py:11-13`
   uses the default `T_cap=1500`).
   * The display, the charts and all exports use 1500 nm. The volume charts sum the **capped** thickness
     (`volume4d.py:96`), so liquid volumes are silently underestimated where the column exceeds 1.5 µm, and the control meant
     to change this is ignored.
   * "SE detector" has no effect for movies either: signals are fixed to UED in `io_movie.SIGNAL`, and any choice still
     matches.

## Minor issues

1. **Layout on laptops.**
   * The settings dock gets 40 % of the height, and the empty charts dock 60 % before any run.
   * At 1366 x 740 (or 1920 x 1080 with 150 % Windows scaling) the Data tab shows only 7 rows, name to "parts per frame"
     (`window_data_1366.png`). Pixel size, bit depth and kV are below the fold.
   * The mandatory output folder sits at the bottom of a 1500-px Processing tab. A user who presses Run without it only gets
     a log line.
   * Collapse the charts until a run is open, and put the output folder on the Run tab with a default next to the input.
2. **Irrelevant fields and missing help.**
   * "parts per frame" and "part index" are shown for separate files, with STEM part 2 of 2 parts.
   * STEM length, STEM mrad and manual/dark/empty/full STEM rows are shown in SE + BSE mode.
   * Manual B0 and g are shown even when the mode is not manual. The default g = 0 is accepted in manual mode and gives
     T = inf everywhere (checked with `calib.solve`).
   * Tooltips cover 4 of 58 widgets (fields and buttons) in the Data tab, 8 of 72 in Processing and 3 of 14 in Display.
   * Jargon is unexplained: ICL/BIC, "full" reference (a full-cell gap map), raw keys `se_contact/gas/thin`, "strength",
     "pixels per fit", "translucent/attenuated_mip".
3. **Input formats.**
   * The crop order "y0 y1 x0 x1" differs from Fiji (x, y, w, h), and there is no validation.
   * "STEM mrad" is free text that falls back to "0 100" silently.
   * Image folders are sorted lexicographically: image1, image10, image2. Use a natural sort.
4. **Frame numbering and time.**
   * The overlay counts frames from 1 ("frame 7/9"), the napari slider from 0 (6 of 8), and the movie frame number
     (`_f00020`) is a third numbering.
   * The overlay shows the clock time of the frame end; the charts show seconds from the first frame's mean row time.
   * Show "frame 11/20 (movie frame 20), t = +10.0 s (10:00:10.5)".
   * *play time series* is fixed at 2 fps, with no speed control and no loop option.
5. **Charts.**
   * In (c), "pixels" are binned 4 x 4 pixels and T = 0 is excluded without saying so. Use area (µm²).
   * In (d), the stacked-class legend uses 6-pt text on top of the data (`gui_12k.png`, `gui_60k.png`).
   * `ChartsWidget.save_png` exists but no button calls it. Add "save chart (PNG/SVG/PDF) and data (CSV)".
6. **3-D view.**
   * There is no in-canvas legend, so screenshots lose the colour key that only the Display tab help text gives.
   * The napari scale bar is valid only in the top view. There is no z scale or axes, although the beam direction (+z)
     matters.
   * The automatic Au sphere size is up to 2.2x the true size at 12k (at least 0.8 % of the field), and this is not
     indicated.
   * Particles are drawn with `translucent_no_depth`, always on top.
   * Every particle mask punches a hole of 100-200 nm into the liquid/gas model.
   * Gas orange (#d95926) and Au amber (#c98500) differ by ΔE76 = 11 under simulated deuteranopia (34 normally), so
     particles on gas patches are hard to tell apart.
   * The overlay says "(thickness from BSE/STEM)" for every JEOL-series run, whatever channels were used.
   * *screenshot...* saves the whole window including docks. Offer canvas-only at a chosen resolution.
7. **Exports and their instructions (EXPORT_FORMATS.md).** Mostly correct and far better than usual. README_AMIRA.txt is
   exemplary: it covers z scaling in Amira, particle-depth counts and the flat-top convention. Missing or wrong:
   * (i) Z exaggeration is explained only for Amira, and only in Python for meshes. Add one line per program:
     * Fiji: Image > Properties, voxel depth x10.
     * Imaris: Edit > Image Properties.
     * ParaView: Transform filter.
     * ChimeraX: `volume #1 voxelSize 32,32,100`.
     * Slicer: volume spacing.
     * Blender: scale Z.
   * (ii) `napari NAME.ome.zarr` needs `napari-ome-zarr`, which is not in environment.yml. Without it napari 0.9.1 opens
     the file as one 5-D layer (20, 5, 95, 79, 105) with scale 1 and units "pixel": the physical scale is lost and the
     channels end up on a slider.
   * (iii) The Fiji 3D Viewer needs one channel. Duplicate the channel first.
   * (iv) Blender: the units are nm, so 1 nm becomes 1 m and the field is kilometres wide. Say "scale 0.001 on import". Each
     frame is a separate .glb, so a stop-motion import add-on is needed for animation.
   * (v) The TrackMate CSV importer comes from an update site. Say so.
   * (vi) Read-back uses Python readers. Say which versions of Amira, Imaris, Slicer, ChimeraX, ParaView and Blender were
     actually used to open the files.
   * (vii) `time_s` in the CSV exports is seconds since midnight of the start time (fabricated by default).
   * Wanted by any lab and missing:
     * An **MP4/GIF/PNG sequence of the 3-D rendering over time** (imageio-ffmpeg is already a dependency; one button that
       steps the time slider and writes frames).
     * Chart export.
     * The 2-D thickness, sigma, gas and time map stacks (they exist in the run folder as `*_4D_*.tif`, but the Export tab
       does not offer or mention them).
     * A one-page human-readable run report: settings, calibration, assumptions, versions, references.
8. **Installation and docs for a Windows non-programmer.**
   * README's `conda env create ... && conda activate lcsem` fails in Windows PowerShell 5.1 (the Anaconda PowerShell
     Prompt), because `&&` needs PowerShell 7. Use two lines.
   * `python -m pytest tests` fails: pytest is not in environment.yml.
   * GUI.md says pip works in "Python 3.9-3.12", but napari 0.9.1 and zarr 3 require >= 3.11. pyproject says `napari>=0.5`
     and `requires-python >=3.9`.
   * `dipy` is in the denoise extra but not used.
   * `docs/VALIDATION_DENOISING.md` is referenced (README, GUI.md, CHANGELOG, METHODS) but missing, so "which denoiser to
     use" has no answer.
   * GUI.md should say how to get the lcsem folder, which prompt to open, that results go to the output folder you choose
     (plus `lcsem_project.json`), that exports go to RUN/export, and that *Probe files* changes the frame time.
   * The z-exaggeration text is inconsistent: the tooltip says 5x at 12k, GUI.md says 5-10x, the screenshot shows 10x.
   * `gui_12k_data_tab.png` shows the synthetic movie, not the 12k data.
9. **Feedback and performance.**
   * Abort is not checked during the Monte Carlo or the stack denoising (MP-PCA/SVD).
   * Object-analysis errors are only logged (`project.py:189-190`).
   * About 10-15 files per frame land in one folder, so a 1000-frame movie gives more than 10,000 files. Use per-frame
     subfolders or containers.
10. **Smoothing units.** Give the calibration smoothing in nm, not pixels, and show the resulting lateral resolution (see M7).
11. **Acquisition checklist for tomorrow** (add to GUI.md, "Movies: practical notes").
    * Record a dark reference (beam blanked, same brightness/contrast/gain), and an empty-cell reference if possible.
    * Keep brightness, contrast and auto contrast/brightness (ACB) fixed during the movie. Per-frame gain correction only
      works with Au particles.
    * Record the native scan (not the screen) as 16-bit TIFF if the software allows.
    * Note magnification, pixel size or scale bar, scan speed/frame time, kV, WD and probe current.
    * With dual display, note which detector is on which side.

## Questions to the authors

1. What exactly should the user do tomorrow with SE + BSE movies and no empty-cell reference: which calibration mode, and
   how will the absolute scale be reported? Will a "relative thickness" mode exist?
2. On the real 12k and 60k data, how many of the detected Au particles are real? Please inspect detections near the gas
   patches as in `false_particles_frame0.png`. Is the 1 of 192 measured depths in the 12k run expected?
3. Why a per-frame Otsu threshold for the SE contact map rather than a movie-wide threshold, or a bimodality test? What
   happens in frames with no gas?
4. Which JEOL recording mode do you expect tomorrow (native frame export, SEM Center movie capture, or a screen recorder)?
   Has any real JEOL movie been through `io_movie`?
5. Were the exported files opened in the target programs (Amira/Avizo, Imaris, 3D Slicer, ChimeraX, ParaView, Blender), and
   in which versions?
6. Why is the top membrane drawn flat, rather than splitting the column symmetrically between the two membranes (the usual
   bulging model), or at least offering both? Will the GUI state the convention?
7. How are segmentation classes linked across frames? Should chart (d) show classes as time series at all?
8. Why is the SE-only gas layer fixed at 50 nm, and why are the SE contact parameters (2000 px, 6 px, 3 iterations) not in
   the GUI?
9. For the paper: is there a user test (someone other than the authors analysing a new movie with the GUI) and a table of
   default-path results on the synthetic ground truth?

## Verdict

**Major revision.** The architecture is sound. Projects, the worker, one 4-D model for display and all exports, and the
read-back checks are good foundations. As released, however, the GUI's default path for the user's own SE + BSE movies
either fails or produces unflagged absolute numbers from an assumed 200 nm flat field. Several silent defaults (bit depth,
pixel size, frame time, start time, cell) and hidden parameters (the 2000-px SE contact floor, the 20 % "thin" threshold,
an ignored "max liquid" control) change results without any warning. The particle detector and the SE contact threshold
produce convincing but false structures, rings of particles and gas in gas-free frames, exactly in bubble movies. And the
display shows neither the raw data nor how reliable each number is.

For tomorrow, fix at least these (each small):
* Pre-flight check with the calibration model shown (M1).
* Bit depth from the file (M2).
* Crop before split, a part preview and duplicate-frame detection (M3).
* A fresh output subfolder per run, and the worker catching `SystemExit` (M8).
* Particle detection off unless a diameter is entered, and a bimodality check for the SE contact map (M4, M5).

Run the session as a supervised demonstration, and report relative rather than absolute thickness.
