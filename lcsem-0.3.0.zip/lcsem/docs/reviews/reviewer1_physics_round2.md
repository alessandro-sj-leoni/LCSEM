# Round 2, Reviewer 1 (physics and modelling): lcsem 0.3.0 revision

Checks were re-run on the revised package and the new runs. The scripts are in `reviewer1_physics_work/`: `cal_test.py`, `r2_gas.py`, `r2_otsu.py`, plus inline checks. `run60_v5` was not yet written and `run12_v5` had 3 of 9 frames.

## Status of the major points

| # | status | reason / check |
|---|---|---|
| M1 analytical models | **resolved** | Removed from the GUI and METHODS. `solve()` now refuses dark + empty when S(0) = 0 with a clear ValueError (re-ran `cal_test.py`). Leftovers (minor): the `analytical_curve` docstring still says "Beer-Lambert… offset and scale absorbed", and CHANGELOG 0.3.0 still lists the models as a feature (l. 5, 21) while l. 41 says they were removed. |
| M2 silent 200 nm flat field | **mostly resolved** | The GUI no longer sets a flat field by default. `calibration_plan` refuses a run with no references, gives dark + particles with a dark frame, and labels a typed-in flat field ASSUMED; the view and exports show the calibration. Still open: the movie calibration in 'auto' is untested (all v2 synthetic runs use the true B0/g again, and `make_movie` could write dark/empty/full reference movies without any recorded data). `config.py` l. 38 still defaults the flat field to 200 nm for `lcsem run` and the library. |
| M3 gas volumes | **partly resolved** | The unclipped sum and the local quadratic gap remove the noise bias. Per-pixel top gas, estimate/true: 0.98, 0.93, 0.84, 0.63 at contact 12, 14, 17, 23 % (`run_v2_SE_BSE`; matches VALIDATION.md). Gas is NaN without SE and in SE-only mode (code checked; not verifiable on real 60k data yet). Documented but not fixed: the large-bubble bias, bottom-membrane gas that is invisible without a gap map (12-21 % of the synthetic gas), no uncertainty bands, and the static-gap assumption. |
| M4 SE contact map | **resolved in the tested range; new failure (N1)** | Gas-free, shaded or noisy frames now give 0 % contact (was 34-50 %). Bubbles covering 0.4-6.5 % at 12k-like CNR with 5 % shading are found at 0.89-0.96 of their true area, with no false contact. Real 12k v5 frames 0-2: 10.2 / 2.8 / 1.3 % contact (was 52 / 48 / 47 %); in frame 0 the contact region is 58 nm thinner than its surroundings, as gas should be. The mechanism and references (Cazaux, Reimer) are in METHODS. |
| M5 conventions shown as measurements | **mostly resolved** | "2.5-D layer model" and "top membrane drawn flat" appear in the view; unmeasured particles are drawn as vertical lines; SE-only volumes are NaN / nominal; every export has a provenance README. Rim rejection works: `run_v2_SE_BSE` gives 102 detections, all true (recall 0.85), 0 false (was 448 false out of 657). Still open (documented): unmeasured particles remain spheres at the top in the voxel `au` volume, and the noise relief at the bottom surface remains. |
| M6 synthetic movie | **partly resolved** | The noise is now true Poisson, the "dose" is relabelled a noise level everywhere, and the limitations are listed. Not addressed: BSE and STEM noise from one common dose (MC moments), row-by-row acquisition, and the v2 runs reuse the old movie. 99 of 102 detected particles are 8-bit saturated in that movie, so the depth path is effectively untested (3 depths). |
| M7 dose | **resolved (first order)** | `run_v2`: 40.6 e/nm² per frame (300×400 px of 8 nm, 0.5 s, 100 pA), cumulative 203 e/nm² at raw frame 4 (skipped frames counted), 0.258 MGy per e/nm² at 15 keV. All correct. Radiolysis references added. Deferred: a per-pixel cumulative map (drift edges), the MC depth-dose, and dose at first detection in `objects.csv`. |
| M8 row clock, W > 1 | **resolved** | Each averaged frame now ends at the window end minus (W-1)t_f/2, with `frame_s` = t_f and `support_s` = W·t_f. This is the correct mean row time. |

## New problems introduced by the revision

**N1 (major): the new SE contact map collapses when gas covers more than about half the field.**
* **Cause:** `analysis._background` (l. 20) starts from the brighter half of the pixels. When the contact covers most of the field, it fits the dark majority instead of the wet background.
* **Found/true area (synthetic):** 0.99 at 53 % coverage; 0.23-0.47 at 59 %; 0.17-0.35 at 70-80 %. For a drying front covering 60 / 70 / 90 % of the field: 0.18 / 0.12 / 0.10.
* **Real data:** applied to the stored SE of 12k frame 3 (smoothed-SE bimodality coefficient 0.77; Otsu 84 % dark), the new map returns 18 %.
* **Consequence:** in a drying or coalescence movie, the contact area and gas volume would fall exactly as the gas takes over the field.
* **Not tested:** the test's largest coverage is about 34 %.
* **Fix:** start the fit from an upper quantile or a gas-free reference frame, use a plane when coverage is large, and flag frames with coverage above 50 % or a bimodal residual.

**N2 (minor): SE contrast below 5 % is not detected at all.** The floor `min_contrast` is not shown in the GUI. The 60k series' SE contrast (about 3 %) falls below it, so no contact is detected there. Report it as a detection limit in the view and the README.

**N3 (minor): dose is undercounted for averaged frames.** With W > 1, `dose_frame` counts one raw frame, and `dose_cum` = (i+1)·D_f is taken at the first frame of the window. Both undercount by (W-1) frames.

## Round-2 verdict

**Minor revision, conditional on N1.** M1, M7 and M8 are resolved; M2, M4 and M5 essentially so; M3 and M6 are honestly documented where not fixed. N1 is a new failure in the main SE path, but its fix is local. Before tomorrow's movies:
* fix N1, or at least flag coverage above 50 %;
* record a dark frame, an empty cell and the probe current;
* do not read gas volumes as measurements without a full-cell reference.
