# Referee report, Reviewer 1 (physics and modelling): lcsem 0.3.0

Scope: the physics and modelling behind the 0.3.0 features, and how they are presented. This covers METHODS section 8 (plus sections 1-7 where the GUI and the 4-D model rely on them), `calib.analytical_curve`, `volume4d`, `se_only`, `simulate.make_movie`, and radiation dose.
Everything below was checked against the code and, where possible, recomputed. The scripts are in `/home/claude/reviews/reviewer1_physics_work/`:

| script | what it checks |
|---|---|
| `mc_quick.py`, `fit_analytic2.py` | MC curves at 10-30 keV; fits of the analytical forms |
| `cal_test.py` | calibration of the analytical models against MC truth |
| `v4d_check.py`, `gas_truth2.py` | 4-D model and gas volumes against synthetic truth and real runs |
| `otsu_nogas.py` | SE contact map on frames with no gas |
| `fp_particles2.py` | false particle detections |
| `eta_check.py` | bulk backscatter coefficients |

Nothing outside `/home/claude/reviews/` was modified. Volume4D was used with `cache=False`, so no cache files were written into the run folders.

## Summary

The core of lcsem is physically well founded, and a spot check of the engine supports it. The engine combines ELSEPA Mott cross sections, Joy-Luo slowing down and correlated sampling. My check of bulk backscatter coefficients (C 0.05-0.06, Al 0.15-0.17, Si 0.16-0.18, Cu 0.30-0.31, Au 0.46-0.50 at 5-30 keV) agrees with published values.

The physics-facing parts that are new in 0.3.0 are not yet at that standard:

* **Analytical detector models.** Both functional forms contradict the package's own Monte Carlo. With the dark + empty references that the documentation recommends, the BSE model cannot be calibrated at all: the run crashes with ZeroDivisionError, or returns T = 0 everywhere.
* **Gas thickness for movies.** Without a gap map (the movie case), the gas-at-top estimator underestimates the gas by up to 22-29 % even with a perfect calibration, and the bias grows with bubble size. On the real K-kit data it is largely noise.
* **SE contact map.** The per-frame Otsu map labels 34-50 % of the field as "gas contact" when there is no gas, and 33-42 % when a bubble has just nucleated.
* **4-D renderings and exports.** They present drawing conventions as if they were measurements: a flat top membrane, gas and unmeasured particles placed by convention, a ring of false particles on bubble rims, and nominal SE-only volumes.
* **Synthetic movie.** Its noise is not tied to a physical dose, it was analysed with the true calibration plugged in, and it omits the effects that dominate real SEM movies.
* **Dose.** There is no dose bookkeeping at all. Plausible movie settings (e.g. 100 pA, 0.5 s frames at 8 nm pixels) deposit ~28 e-/nm² per frame, about 7 MGy per frame in the liquid. At this level radiolysis can itself create the bubbles the software is meant to measure.

## Major issues

### M1. The analytical detector models (`calib.py` l. 181-200, `ANALYTICAL_DEFAULTS` l. 184-185; `gui/project.py` l. 103-111; METHODS l. 151-154) are not physically defensible as implemented, and fail in the recommended calibration path

**(a) The BSE model has no membrane offset, so dark + empty calibration is impossible.**
S = 1 - exp(-T/L) gives S(0) = 0. The Monte Carlo gives S(0) = 0.038 (15 keV), which is 14 % of S(1500 nm) and 49 % of S(200 nm): this is backscatter from the two 30 nm SiN membranes.
In `solve()`, dark + empty computes g = (empty - dark)/S(0).
* `references.level()` returns Python floats, and with those the calibration raises `ZeroDivisionError: float division by zero`. Reproduced with `solve(analytical_curve('bse', 15), {dark, empty, flat}, 'auto')`.
* With numpy floats, g = inf and every pixel is read as T = 0 (only a RuntimeWarning).

'auto' chooses dark + empty whenever both references exist, and both the documentation and VALIDATION.md tell users to record exactly that. With dark + flat instead, the membrane backscatter is read as water.

**(b) Thickness errors against the MC at 15 keV.** These come from `lcsem.calib.solve`, with images formed from the shipped MC curve (`cal_test.py`):

| true T (nm) | 0 | 100 | 200 | 500 | 1000 | 1200 |
|---|---|---|---|---|---|---|
| BSE, dark + empty | crash / 0 | crash / 0 | crash / 0 | crash / 0 | crash / 0 | crash / 0 |
| BSE, dark + flat (200 nm, GUI default) | 92 | 143 | 200 | 431 | 874 | 1008 |
| BSE, two references (100, 700 nm) | 41 | 100 | 169 | 457 | 1074 | 1289 |
| STEM BF<100, dark + empty | 0 | 166 | 306 | 612 | 908 | 990 |
| STEM BF<100, dark + flat (200 nm) | 0 | 58 | 200 | 505 | 801 | 885 |

**(c) The functional forms are wrong for these detectors.** I recomputed MC curves at 10, 12, 15, 20, 25 and 30 keV (150k primaries per thickness, 0-3000 nm).

*BED-C (15-65°, E - 2 keV weighting).*
* The curve is convex at small T for E0 ≥ 15 keV.
* It saturates abruptly: at about 0.5 µm (10 keV) and about 1.2-1.5 µm (15 keV). The 2 keV threshold removes deep BSE.
* A concave 1 - exp(-T/L) cannot follow this shape. At 15 keV the fitted L ranges from 614 to 5363 nm, depending on the fit range and on how the offset is handled. At 20-30 keV, fits over 0-1.5 µm run to the upper bound. The shipped L = 1e5 nm is therefore a bound, not a parameter.
* Log interpolation of the table between 15 keV (944 nm) and 20 keV (1e5 nm) gives L ≈ 6 µm at 17 keV.

*STEM BF (0-100 mrad).*
* "Beer-Lambert attenuation of the unscattered beam" (METHODS l. 152) is not what the detector measures.
* The ELSEPA tables give an elastic mean free path of 58 nm in water and 12 nm in SiN at 15 keV. Only 0.6 % of the beam is unscattered after the two membranes alone. The BF signal (S(0) = 0.33) is almost entirely scattered electrons inside the cone.
* The local attenuation length of the MC curve rises continuously: 232 nm (0-25 nm), 426 nm (300-500), 770 nm (700-1000), 1000-1800 nm beyond 1 µm. At 30 keV it rises from 600 to 1900 nm.
* The exponential is the TEM "contrast-thickness" law (Reimer & Kohl, *Transmission Electron Microscopy*), which holds only for thin specimens. It needs that reference and a stated range of validity (≲ 150-200 nm at 15 keV).
* The GUI accepts any STEM mrad range with the analytical model, but ADF (100-400 mrad) is non-monotonic. Its maximum is at T = 200, 300, 700 and 1000 nm for 15, 20, 25 and 30 keV (contrast inversion), so an exponential decay has the wrong sign there.
* λ also depends on the acceptance angle (358 vs 426 nm for BF<50 vs BF<100 at 15 keV). The defaults exist only for BF<100 mrad, 30/30 nm SiN and pure water, yet they are applied to any membrane, liquid and detector entered in the GUI.

**(d) Not reproducible.** No script, curves or fit settings for `ANALYTICAL_DEFAULTS` exist in the package, and no MC curve other than 15 keV exists anywhere on disk. None of the fits I tried reproduces (180, 358, 944, 1e5) nm. The λ values are within ~10 % of log-linear fits over 0-1000 nm (394, 401, 426, 487, 574, 684 nm).

**(e) No self-check is left.** With analytical models the particle modes are disabled (`project.py` l. 110-111). This removes the only internal test of the detector model. VALIDATION.md finding 4 shows why that test matters: a 10-15 % detector error gives +191 nm, and only the particle check reveals it. The GUI's `CAL_MODES` (l. 12) also lacks `two_references`, the one mode in which the BSE offset is a free parameter.

**Why it matters.** Users who follow the documentation get a crash or zero thickness. The other paths carry errors of 10-60 % that no check will reveal. There are no tests of the analytical path (`tests/test_v030.py`).

**What to do.**
* Remove the analytical models from the GUI, or replace them with Monte Carlo tables. The MC is cheap: a BED-C + BF + ADF curve at 150k primaries per thickness took 17-38 s per energy on 2 cores here. Precomputed tables over (E0, membrane, detector) would cost nothing at run time.
* If an analytical option is kept:
  * BSE: use S = S0 + A[1 - exp(-(T/L)^p)], with S0/A from the MC.
  * STEM: refuse any range other than BF, and state the validity range.
  * Ship the fitting script and curves.
  * Add `two_references` to the GUI.
  * Add tests: the analytical model with dark + empty must calibrate, and the thickness error against the MC must stay within a stated tolerance.
  * State in METHODS and the GUI that no self-consistency check is available with analytical models.

### M2. GUI calibration defaults silently set the absolute thickness from an assumption, and the movie calibration path is unvalidated (`gui/project.py` l. 25 and 74; `pipeline.py` l. 150 and 246-250)

The GUI always passes a "flat field" of `flat_T_nm` = 200 nm. In `pipeline.py` this is the median grey of all frames, assumed to be 200 nm thick. 'auto' therefore falls back to particles + flat (MC model, no dark/empty) or dark + flat (analytical model), and the median thickness is then 200 nm by construction. This is the v0.1 path that VALIDATION.md finding 1 shows to be biased by the assumption (-188 nm).

The default also contradicts the GUI's own default channel height (500 nm). In every GUI run on the synthetic movie, the calibration report's flat-field check reads 620-624 nm for the assumed 200 nm.

Further points:
* The real K-kit 1 runs (`run12_v4`, `run60_v4`) also used particles + flat at 200 nm. Their median thickness of ~200 nm is an input, not a measurement. That must be stated wherever these numbers are shown.
* All synthetic movie runs (`run_proj_SE_BSE`, `..._mppca`, `run_synmovie_SE_BSE_STEM`) used manual calibration with the true B0 and g. The calibration of movies has never been tested: references supplied as movies, 'auto', or the analytical model.
* Black-level stability is critical for time series. The thickness change per grey level is 1/(g dS/dT): about 15 nm per grey in the 12k series (g = 295) and about 60 nm per grey in the 60k series (g = 69). Any drift of detector brightness or probe current is therefore read as a change of liquid thickness (see Q3).

**What to do.**
* Default `flat_T_nm` to off. Never use an assumed flat field in 'auto' without explicit confirmation.
* Show the calibration mode and its assumption in the viewer overlay, the charts and every export README, for example "thickness scale ASSUMED: field median = 200 nm".
* Validate the movie path on synthetic movies with dark, empty and full reference movies in 'auto'.
* For long movies, track the black level: periodic blanked frames, or an in-frame region of known state.

### M3. Gas volumes (GUI chart (b), `objects.csv`, the 4-D gas layer) are biased or noise-dominated whenever there is no gap map, which is the normal case for movies (`pipeline.py` l. 328-345; `volume4d.series`)

Without a full-cell reference, `gap = median(T over SE-bright pixels)` is a single number per frame. Gas at the top is then clip(gap - T, 0) in SE-dark pixels, and gas not at the top is always 0.

* **Synthetic movie, perfect calibration (true B0, g and curve).**
  * The top gas is underestimated by 2 % → 16 % → 22 % (frames 0/20/36, `run_synmovie_SE_BSE_STEM`) and by 17 % → 26 % → 29 % (GUI run `run_proj_SE_BSE`).
  * The bias grows as the bubble grows. The bubble covers the thick centre of the bulged window, so the "wet reference" falls from 700 to 619 nm while the true gap under the bubble is ~775 nm. The growth curve, and hence the growth rate, is distorted.
  * Gas on the bottom membrane (12-21 % of the total gas) is not detected at all. It is drawn as a thinner liquid column: the bottom membrane moves up.
* **Real 12k data.**
  * 21-85 % of the reported gas volume comes from columns where gas < 2σ_T. Here clip(g0 - T, 0) is essentially the positive half of the thickness noise (bias ≈ 0.4σ_T ≈ 8 nm over the whole SE-dark area).
  * In the 60k frames 4-6, SE was not recorded. There `gas_top` is stored as 0, not NaN, so chart (b) shows the gas "disappearing" (visible in `docs/img/gui_60k.png`).
* **Real data and the SE-dark = gas interpretation.** The median liquid thickness under SE-dark regions is barely different from that under SE-bright regions, and the sign of the difference flips. Bright minus dark, with 10 px erosion:
  * 12k: +37, +27, +27, +25, +7, -11, -16, +7, +37 nm
  * 60k: -31, +50, +6, -32 nm

  In 4 of 13 frames the "gas contact" region is thicker. Whatever SE-dark means in these data, it is mostly not a gas layer that BSE can measure (see M4).
* **Static gap.** Even with a gap map, h(x, y) is assumed not to change over time. In a sealed cell, gas formation or loss changes the internal pressure and hence the membrane deflection. A 5 % change of a 700 nm gap becomes 35 nm of spurious "gas" over the whole field.

**What to do.**
* Without a gap map, report gas as contact area only, or as a lower bound with its uncertainty. Do not draw or chart a gas volume.
* Otherwise estimate the local gap from the SE-bright surroundings (a smooth surface; bulging is smooth), not a global median.
* Require the gas to be significant (> kσ) and spatially coherent.
* Show uncertainty bands, combining statistical and calibration errors (METHODS §7: ±25-30 % detector scale without references).
* Mark frames without SE as "not measured".
* State the static-gap assumption, and add a per-frame diagnostic of bulging drift: median(h - T) in wet regions far from bubbles.

### M4. The SE contact map is not robust in the regimes a movie will contain, and its physical meaning is not established (`analysis.se_contact_map` l. 15-25; METHODS l. 57 and 72; `se_only.py`; GUI.md l. 96)

Otsu is applied per frame, with no test of bimodality or contrast. Using the package function with its default parameters (σ = 6 px, min_area 2000 px, opening 3):

* **Frames with no gas.** Noise only, a 5 % shading gradient or bulging-correlated SE2 of ±3 % → 34-50 % of the field is labelled "gas touches the top membrane".
* **Just after nucleation.** A bubble covering 0.4 % of the field, at the SE contrast-to-noise of the real 12k data (contrast 25, noise 40 grey), gives "contact" over 35-42 % of the field. At 1.1 % with 5 % shading, it is 33 %.
* **Minimum size.** Bubbles below min_area (0.13 µm², ~400 nm diameter at 8 nm pixels) are removed. Nucleation is therefore both missed and preceded by false objects.
* **Real SE is far from the synthetic regime.** In the 12k series the SE level drifts about fourfold within 4 min (dark mean 33 → 58 → 91 → 133 grey), and the per-pixel contrast-to-noise is 0.3-3. The synthetic movie has CNR ≈ 11, binary static contrast, no drift, and bubbles always ≥ 12 % of the field.

  The claim "object areas agree with the ground truth to about 2 %" (GUI.md l. 96) is correct for that idealised case; I reproduced ratios of 0.94-1.03. For large bubbles the map also holds up at realistic CNR, because smoothing rescues it. It does not transfer to empty frames, small gas fractions, shading or drift.
* **Physics.** A 30 nm SiN membrane is thicker than the SE escape depth. The contrast must therefore come from SE2 and from charging (voltage contrast, "charging-mediated" in OPTIONS.md), which depends on dose rate and scan speed, can invert, and has a charging length of its own. METHODS gives no reference or experiment for "SE-dark = gas touching the top membrane", and the real-data comparison in M3 does not support a simple reading.

**What to do.**
* Test separability before thresholding: a 1- vs 2-component GMM by BIC, or Otsu's effectiveness σ_B²/σ_T² calibrated on noise-only frames, plus a contrast-to-noise criterion.
* Correct SE shading and drift, and use one threshold per series rather than a per-frame Otsu.
* Report a detection limit in µm² and flag frames where the map is undefined.
* Validate on empty frames, small gas fractions, shading and drift, at the real CNR.
* Cite a mechanism (e.g. Cazaux, Scanning 26, 181 (2004); Reimer, *Scanning Electron Microscopy*, 2nd ed.). More importantly, validate the interpretation experimentally, for example a partially filled cell with a gap map, or a known bubble measured by BSE and SE.

### M5. The 4-D model is a 2.5-D layered height field whose drawing conventions are rendered and exported as if measured (`volume4d.py`; `gui/display.py`; `gui/charts.py` l. 70-80; `export_formats.py` l. 422-425; `export_amira.py` l. 174-199)

Each column is a prescribed stack of layers: top membrane, gas at the top, liquid, gas elsewhere, bottom membrane. Only the column thickness, the SE footprint and the particle depths are measured. A reader of the renderings or of an Amira/Imaris export can be misled in six ways:

**(a) Flat top, everything at the bottom.** All bulging and all thickness noise appear on the bottom membrane. The fine relief (std 7-12 nm on the 128 nm grid) is below the per-pixel σ_T (20-22 nm), yet the automatic 10× z exaggeration renders it as 70-120 nm "stalactites" (`docs/img/gui_12k.png`). GUI.md never mentions the convention. When there is no gap map, the bottom is flat at the median wet thickness under SE-dark regions and follows T elsewhere, which creates steps at bubble rims that do not exist.

**(b) Gas not touching the top.** Its vertical position is not measured (METHODS §2), but it is drawn directly on the bottom membrane, in the same layer and style as the measured top gas. Neither README mentions this.

**(c) Particles without a measured depth.** They are drawn as spheres just under the top membrane, and the voxel `au` volume and the TrackMate/VTK z values make them indistinguishable from measured ones. In the 12k series this applies to 191 of 192 positions: an Amira rendering "shows" every particle adsorbed on the top membrane.

**(d) False particles on bubble rims.** The matched filter responds to thickness steps.
* Synthetic SE + BSE + STEM run: 1591 detections for 480 true positions; 1165 false, of which 1111 lie within ±6 px of a bubble rim. 181 of the false detections (171 of them on rims) received a "measured" depth.
* GUI NLM run: 448 of 657 detections are false (419 on rims).
* MP-PCA run: 616 of 737 are false, and only 121 of 240 true positions are matched. Most of these false detections are not on rims; they look like ghosts from temporal pooling.

In `docs/img/gui_synmovie.png` this appears as a ring of particles around the bubble, a very suggestive artefact because particles really do accumulate at contact lines.

**(e) SE-only runs.** Charts (a) and (b) say "liquid volume (µm³)" and "gas volume (µm³)". Only histogram (c) says "nominal". These numbers are channel height × area and 50 nm × contact area; `objects.csv` gas_volume and the exports carry them too, unflagged.

**(f) Exports.** `README_EXPORT.txt` has three lines. It gives no mode, no calibration mode or assumption, no gap source, no statement of what is conventional (flat top, gas elsewhere, unmeasured depths), no cap, no nominal flag and no uncertainty. The volumes are also raster composites spanning [t_end - t_f, t_end] (30 s at 60k), while the GUI shows a single time.

**What to do.**
* Call it a "2.5-D layer model" in METHODS, the GUI and the README.
* Render only measured quantities by default:
  * gas elsewhere as an undetermined column, in a distinct style;
  * unmeasured particles as vertical lines, or omitted; if kept in the voxel volume, give them a separate label value; NaN z in TrackMate;
  * the bottom surface smoothed to the scale where σ_T < dz, or with an uncertainty surface;
  * optionally a symmetric or plate-theory bulging split.
* Reject edge-like detections: a Hessian eigenvalue-ratio test, or the χ² of the MC particle-profile fit.
* In SE-only mode, set volumes to NaN or label them "nominal" everywhere: charts, CSV, objects, exports.
* Generate a provenance and caveats block from `run_info` into every export README.

### M6. The synthetic movie (`simulate.make_movie` l. 150-195) is not a physically consistent test of the movie pipeline or of the denoisers, and its limitations are undocumented

* **"Dose" is not a dose.** The noise is var = (g/dose)(x - B0) + σ_r² per channel, so "dose" means something different for each detector:
  * BSE: S is in keV per primary. With the curve's own second moment (m2/S = 8.5-12.4 keV), `dose_e_px = 150` equals 1280-1860 primaries per pixel.
  * STEM: the same setting equals 100-146 primaries per pixel.
  * The two channels "recorded in the same scan" thus differ by ~12× in equivalent electrons, which favours BSE by ~3.5× in SNR.
  * SE uses an arbitrary gain (40).
  * The CLI help ("electrons per pixel per frame", `cli.py` l. 27) and the GUI.md caption ("150 electrons per pixel", l. 90) are therefore wrong. So are the "three doses" of the denoising benchmark. Note also that `docs/VALIDATION_DENOISING.md`, cited in README, METHODS (twice) and GUI.md, does not exist.
* **What the synthetic movie does not capture:**
  * charging (SE drift and inversion, charging halos) and SE2 correlated with T and with Au particles;
  * dose-dependent effects: radiolytic bubble nucleation, beam-induced particle motion or pinning, contamination (bubbles grow on a prescribed schedule);
  * raster timing: each frame is an instantaneous snapshot, so the per-row clock, which is claim 1 of the paper, is untested;
  * detector response time and noise correlated along the fast-scan axis (see m3);
  * drift of B0, g and probe current;
  * finite-size BSE blur at bubble edges (information volume, top-bottom effect);
  * scan distortions and frame-start transients (the pipeline has `skip_rows` = 200 for them, the GUI uses 0);
  * membrane deflection changing with pressure;
  * frames with no gas, or very small gas fractions.

  None of this is stated in the docstring, METHODS §8 or GUI.md.

**What to do.**
* Define the dose as incident primaries per pixel.
* Draw each detector's noise from the MC per-primary moments (compound Poisson with S and m2, already in the curve files) at a common dose.
* Model the SE from the MC SE2 model plus an explicit, documented contact term, with drift.
* Render row r at scene time t_end - t_f + r·t_f/N, and include detector temporal blur, B0/g drift and gas-free frames.
* Add a limitations paragraph.
* Rerun the benchmark with physical doses before ranking denoisers. Piecewise-constant, white-noise scenes favour NLM, BM3D and TV.

### M7. There is no radiation-dose bookkeeping, and no mention of radiolysis or beam effects, although the new movie mode is intended for continuous SE + BSE movies of bubbles

* **No dose is computed.** The probe current is used only to rescale the gain (`pipeline.py` l. 270-276). `beam.current_pA` in `config.py` (l. 30) is never read. OPTIONS.md and `OPTION_MATRIX` (l. 117) promise "dose per frame", which does not exist.
* **The doses are large.** The package's own Joy-Luo stopping power for water at 15 keV (16.1 MeV cm²/g) gives **1 e-/nm² ≈ 0.26 MGy** at the top of the liquid (0.14 MGy at 30 keV). Illustrative settings:
  * 100 pA, 0.5 s frames, 480 × 360 px of 8 nm: ≈ 28 e-/nm² per frame, i.e. ~7 MGy per frame and ~15 MGy/s frame-averaged. A 60-frame movie reaches ≈ 1700 e-/nm² (~0.4 GGy).
  * A 60k frame (1.6 nm pixels, 30 s) at 20 pA: ≈ 1200 e-/nm².

  This is the dose-rate range in which radiolysis models predict H₂ supersaturation within seconds and in which beam-induced bubble nucleation is routinely seen in liquid-cell TEM (Schneider et al., J. Phys. Chem. C 118, 22373 (2014); Grogan et al., Nano Lett. 14, 359 (2014)). Irradiation history also matters (Moser et al., Sci. Adv. 4, eaaq1202 (2018); Woehl & Abellan, J. Microsc. 265, 135 (2017)).
* **The measured quantities depend on dose.** Without the dose, bubble nucleation and growth, particle adsorption and the SE charging contrast cannot be separated from beam effects.

**Minimal, correct bookkeeping I suggest:**

1. **Inputs**
   * Probe current per frame, from the existing `references.current`, a pA value or a log.
   * Frame time and scanned area (N_x·N_y·p_x·p_y) from metadata, not guessed from the noise level.
   * Frame-integration count and flyback/overscan fraction.
   * A manual log of exposure outside the recorded frames: focusing, surveys, references.
2. **Per frame**
   * D_f = I_p·t_f/(e·A_scan) in e-/nm².
   * The frame-averaged dose rate, plus the dwell, line and frame periods: for a scanned probe the local instantaneous dose rate is orders of magnitude above the average.
   * The absorbed dose D_f × 10¹⁸ × (S/ρ) in Gy, at first order with S at E0. Better, use the MC depth-dose profile averaged over the liquid column; the engine already computes the energy lost on each step, so a depth histogram is a small addition.
3. **Maps**
   * The cumulative dose D_cum(x, y) on the drift-corrected canvas. Frame edges receive less dose, and references and surveys add to it.
   * Saved per frame like `time_s`, and in `maps.npz`, the 4-D model and the exports.
4. **Outputs**
   * Columns `dose_frame_e_nm2`, `dose_cum_e_nm2`, `dose_rate` and `dose_Gy` in `summary.csv`.
   * The cumulative dose at first detection for each object and particle.
   * Dose as an alternative x-axis in the GUI charts.
   * Dose in `run_info` and the export READMEs.
5. **Cross-check when no Faraday cup was used.** From the Poisson-Gaussian slope a, the calibrated g and the MC moments, N_primaries ≈ g·(m2/S)/a. This needs a well-conditioned series fit; see m1.
6. **Documentation.** A short section on radiolysis, and recommended controls: vary the dose rate, blank the beam at intervals, and inspect unexposed areas after the movie.

### M8. The per-row clock is wrong for averaged movie frames (window > 1), contradicting METHODS l. 127 (`io_movie.movie_scans` l. 161-163; `volume.row_times`)

With `window` = W, each time point has `frame_s` = W·t_f. `row_times` then spreads the rows over the whole window. In reality every row is acquired W times, so its mean time is t_end - t_f + r·t_f/N - (W-1)·t_f/2.

The error is (W-1)·t_f·(r/N - 1/2): ±0.75 s for W = 4 and t_f = 0.5 s. Time differences at the same pixel cancel. Those between different rows do not: particle steps, object times, and comparisons with other data are off by (W-1)·t_f·Δr/N. The same applies in `se_only`.

**What to do.** Use t_f per scan with a shifted t_end, store the temporal support (W·t_f) separately, add a test, and also report the temporal support of stack-denoised time points.

## Minor issues

1. **Noise model (METHODS l. 134-139; `denoise.py` docstring).**
   * a is not "the gain per detected electron". It is gain × ⟨s²⟩/⟨s⟩, the excess-noise or Swank factor of the single-electron response; for BED-C the MC gives m2/S = 8.5-12.4 keV at 15 kV.
   * In the pipeline and in `se_only`, (a, b) is fitted per frame (`denoise_image(..., noise=None)`), not per series as METHODS states.
   * On real 8-bit BED-C frames the fit is ill-conditioned: a = 9.6, b = 2182 (12k frame 1); a = 0.16, b = 395 (60k frame 1); a = 0, b = 10138 (12k frame 0).
   * Prefer series fits from frame differences in static regions.
2. **GAT inverse.** The closed form in `igat` is the pure-Poisson inverse (Mäkitalo & Foi 2011) applied to (a·x + b)/a². With substantial read noise, the σ-dependent exact unbiased inverse of Mäkitalo & Foi 2013 applies. METHODS [36, 37] should not present them as equivalent.
3. **Correlated noise and detector bandwidth.** Residual lag-1 correlation along the fast-scan axis is +0.10 (12k BED-C) and -0.26 (60k BED-C), against ≈ 0 along the slow axis.
   * At movie dwell times (~3 µs for 0.5 s at 480 × 360, shorter at TV rate), the response time of solid-state BSE detectors blurs images along x.
   * This affects NLM, BM3D and MP-PCA, which assume white noise. BM3D accepts a PSD (the already cited Mäkinen et al. 2020).
   * It also affects the core-fraction depth, whose model includes only a 2 nm probe blur.
4. **Clipping and capping in `volume4d._build_2d` (l. 96).**
   * Clipping T at 0 before binning adds +σ_T/√(2π) in dry areas.
   * The capped T feeds `liquid_um3` and `T_median_nm` without a note.
   * Gas columns are not capped and can exceed Zmax.
5. **Lossy video.** Limited luma range (16-235), colour conversion and inter-frame compression break the linear grey = B0 + g·S model and the noise model. References must go through the same codec as the movie, or quantitative thickness and depth from MP4 should be refused. The MP4 frame rate is the container's display rate, not the acquisition rate.
6. **Engine energy range.** The engine docstring says 0.5-21 keV; the tables and METHODS say 0.5-32 keV. Please also add the pending benchmark from `PUBLICATION_PLAN.md`: my bulk η values (above) could seed a table against Joy's database and CASINO. Everything, including the analytical defaults, depends on the MC.
7. **STEM detector model.** MC STEM detectors count electrons (1 per electron). Real STEM-in-SEM detectors often weight by energy. The "10-60× more information per electron" statement (`panels.py` mode note, OPTIONS) needs this qualification.
8. **STEM DF sign.** `pipeline.py` l. 122 treats any STEM spec without "HAADF" as bright field (Au dark). A custom DF range (e.g. `stem:100:400`) gets the wrong particle sign.
9. **SE-only nominal model.**
   * The gas height (50 nm) is hard-coded in `project.to_config` and not settable in the GUI.
   * The nominal column ignores bulging (500 → 800 nm in the package's own synthetic scene).
   * Call SE objects "contact regions" rather than bubbles.
10. **Object times.** `objects.py` gives every object the frame-mean time. With 30 s frames an object's real scan time differs by up to ±15 s. Use the mean row time of the object's pixels, which is the raster clock the paper advertises.
11. **Time labels.** The viewer overlay shows `time_end`; the charts use the frame-mean time (`t_mean`). Pick one and say which.
12. **METHODS §8 SE-only wording.** It says the contact map is "multi-Otsu [20]". It is binary Otsu [19]; the multi-Otsu levels are stored but not used.
13. **Aggregates.** Every detection is drawn with the nominal diameter (38 nm), including aggregates. Flag detections whose excess is > 1.5× the single-particle level.
14. **`top_membrane_dry` bug (`pipeline.py` l. 351).** The flag is read at the particle's own pixel, which is excluded from the contact map, so it is always False: 0 of 1591 in the synthetic run, although 80 of 480 true positions lie under top gas; 0/192 and 0/18 in the real runs.
15. **Misleading error message.** With analytical models and no dark reference, `calib.solve` suggests "Au standards + a flat field", which are disabled.
16. **Lateral resolution.** State the lateral resolution of each layer. The thickness is smoothed with σ = 15 px (≈ 120 nm) plus BSE lateral spread in the liquid; the SE footprint is sharper. The mismatch creates ramps of gas height at rims in 3-D.
17. **Clamped defaults.** Outside 10-30 keV `ANALYTICAL_DEFAULTS` are clamped silently (`np.interp`); please warn.

## Questions to the authors

1. How exactly were `ANALYTICAL_DEFAULTS` obtained (curves, T range, weights, offset handling)? Can you ship the script and the MC curves at 10-30 keV?
2. What evidence supports "SE-dark = gas touching the top membrane" in K-kit 1? The BSE thickness under SE-dark and SE-bright regions differs by only -32 to +50 nm, with a changing sign. Has this been tested with a cell of known gas distribution?
3. In the 60k series, the liquid volume doubles (0.62 → 1.31 µm³) exactly when SE stops being recorded (frames 4-6), while the BED-C mean grey rises by ~4 levels (≈ 240 nm at g = 69). Were brightness, contrast, current or scan settings changed at that point?
4. What were the probe current, dwell time and frame time for K-kit 1, and what will they be for the new movies? Did bubbles nucleate only in scanned areas, and does their appearance scale with dose or with time?
5. Will dark, empty and full references be recorded with the same detector settings and file path (TIFF vs MP4) as tomorrow's movies?
6. How do you expect the membrane deflection to change when gas forms in the sealed K-kit? Can a full-cell reference be re-recorded, or the bulging drift monitored during a movie?
7. For particles inside SE-dark regions, BSE and STEM cannot distinguish a particle on the top membrane (in gas) from one at the gas-liquid interface, because vacuum layers only translate trajectories. How is z defined there? The pipeline adds the gas thickness.
8. What is the temporal response of the BED-C detector and preamplifier at the dwell times you will use for movies? Has the core-fraction depth been checked at those scan speeds?
9. Do you see false particle detections on bubble rims in real data, and do MP-PCA-denoised movies produce ghost particles in the real series as they do on the synthetic ones?

## Verdict

**Major revision.** The Monte Carlo foundation is sound. But in its current form the 0.3.0 layer can crash or give zero thickness in the recommended calibration path (analytical BSE). It reports gas volumes that are biased (synthetic) or noise-dominated (real), and it invents "contact" regions in gas-free or nucleation frames. Its 3-D renderings and exports present conventions and false particles as measurements. None of its outputs can yet be related to dose.

Two things are needed before the GUI is used on tomorrow's SE + BSE movies:
* the fixes in M1 (at least disabling the analytical BSE model), M2 (no silent 200 nm flat field) and M4 (a separability test);
* dose logging as in M7 (at minimum the probe current and frame time), so that the movies can later be interpreted.
