# Reviewer 4 (usability), round 2: lcsem 0.3.0 revised

**How I checked.** I re-ran my round-1 cases against the revised package: the project runner, the GUI headless, and the
synthetic movie with ground truth. Scripts and outputs are in `reviewer4_usability_work/r2_*` and `run_R2_*`. The test suite
passes: 37 tests in 215 s.

One side effect: opening `gui_dev/run_v2_SEonly` in the GUI made `Volume4D` rewrite that folder's cache file,
`volume2d_bin4.npz`. This was not an edit by me, but viewing a run should not write into the run folder.

## Status of my major points

| | Status | Quick check |
|---|---|---|
| **M1** Calibration default | **Resolved** (one misleading message) | Default project (auto, no references): *Run* stops before any processing and says what to record. Pixel size 0 is refused. An assumed flat field must be typed in, then shows as "ASSUMED flat field 200 nm" in the view (12k run) and in the export README. With only a dark frame, see new problem 2. |
| **M2** Silent defaults | **Partly** | Bit depth now comes from the file (16-bit stack sets 16). 16-bit data with bits = 8 stop after 1 s with a clear message. Pixel size is required. The frame time from the file rate comes with a "check it: screen recordings..." note, and no silent 1 s. Start time is 00:00:00. Not addressed: kV, membranes and particle size are still prefilled and not echoed before *Run*; the first Monte Carlo run (about 4 min) shows no progress; the BSE detector is fixed (both documented). |
| **M3** File layouts | **Mostly resolved** | Crop is now applied before splitting. *Preview first frame* shows SE and BSE as they will be read, so a swap is visible. Screen recording: 100 % near-duplicates flagged, and different movie lengths are warned. If the preview is skipped, swapped halves still run silently (710 nm constant, no warning in the log). A separator in the middle of a side-by-side frame cannot be cropped out. The time offset between separate files is left for later. |
| **M4** False particles on bubble rims | **Resolved** (synthetic) | `run_v2_SE_BSE` against the truth: 0 false detections out of 102 (was 68 %), recall 0.85; object areas are 0.983-0.991 of the true contact area (were 0.75-0.82). Real 12k data not verifiable: 186 positions, 1 with a depth. |
| **M5** SE contact map, objects | **Resolved** | Gas-free frame, raw or NLM-denoised, with or without shading: 0.0 % contact and 0 objects (was 41-47 %). Discs of radius 8-50 px are all found (was ≥ 35 px only). The minimum area is set in µm² in the GUI. "thin" is gone from the GUI list and raises an error without a limit. |
| **M6** Display cannot be checked against the data | **Resolved** | The 2-D maps dock shows: (a) thickness with a colour bar, NaN hatched, and a hover readout "179 nm +- 21 (statistical)"; (b) the SE contact outline on the SE frame; (c) the BSE frame with particles; (d) the SE frame. All follow the slider. The panels are small in the default dock but can be undocked. |
| **M7** Trust | **Mostly resolved** | The view states the calibration and its assumption, the dose and the flat-top convention. Particles without a depth are drawn as grey vertical lines. SE-only volume charts read "not measured: SE only". Missing: error bands on the charts, and zero-based y-axes (12k liquid chart spans 5.84-7.19 µm³). New problems 1 and 4. |
| **M8** Robustness | **Resolved** | An empty frame range gives a clear ValueError after 1 s and *Run* is enabled again. A re-run into the same folder goes to a new timestamped subfolder and opens (n = 8). "max liquid shown" (T_cap) is passed to the 4-D model. |

## New problems introduced by the revision

1. **Negative gas volumes in chart (b)** (the unclipped estimator). In the 12k run, frame 7 shows **−0.125 µm³** while the SE
   contact covers 9.4 µm²; frames 1-7 range from −0.13 to +0.13 µm³. These values are shown without an uncertainty. Add a band,
   or mark "consistent with 0", or the user will read noise as gas dynamics.
2. **The pre-flight plan assumes the Au particles will work.** It counts particles as available whenever detection is on. With
   a dark reference but no usable particle near the top (synthetic movie), the plan says "dark+particles". The run then
   preprocesses and fails with "not enough references (['dark']); record a dark frame...", which asks for the dark frame the
   user already gave. Say instead "no particle near the top membrane could set the gain".
3. **Suggested step is wrong for rolling-scan screen recordings.** *Probe files* suggested "use step 40" for a recording whose
   SEM period is 20 video frames. The suggestion is capped at the 40 frames checked, because a rolling scan never produces a
   clean frame change.
4. **The key warning in the overlay is clipped.** At 1800 px window width the calibration line ends at "...absolute thickness
   scales with th". Wrap it or shorten it.
5. **Wrong message in SE-only 2-D maps.** Panel (c) says "input frame not stored (run made with lcsem < 0.3)" for an SE-only
   run made with 0.3. It should say that no thickness channel was recorded.

Still open from round 1 (documented by the authors): the movie path with 'auto' and real references has not been validated
end-to-end; the GUI demonstration runs (`run_v2_*`) still use the simulation's own B0 and g entered as a manual calibration.

## Round-2 verdict

**Minor revision.** The points that made round 1 unsafe for tomorrow are fixed and I verified each one:
* hidden calibration assumptions,
* bit depth,
* the pixel size default,
* crop and preview,
* false rim particles,
* false SE contact,
* the hang,
* the re-run crash.

The GUI now fails safe and says what it assumes. Before tomorrow, fix new problems 1, 2 and 4, which are small. The user can
then analyse SE + BSE movies unsupervised, provided they record a dark frame (and ideally an empty cell) and use *Preview*
before running.
