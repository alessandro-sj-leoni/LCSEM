# Reviewer 3 (software engineering), round 2: revised lcsem 0.3.0

**What I checked.** I checked a snapshot of `/home/claude/pkg/lcsem` taken on 2026-09-28 at about 20:05, copied to `reviewer3_software_work/round2/src` because the package was still being edited.
- **Tests:** 37 passed. `test_v030`, `test_v021` and `test_synthetic` gave 32 in 78 s; `test_v02` gave 5 in 318 s.
- **Scripts:** my quick checks are in `reviewer3_software_work/round2/exp/`.

## Major points 1-8

1. **GUI-to-pipeline mapping: resolved.**
   - All 7 modes map to the right detectors, and "BSE only" / "BSE + STEM" movies now run without SE.
   - SE-only runs on the real JEOL folder.
   - A dark reference given as `...101000.TIF` is excluded from the series.
   - kV = 10 on 15 kV data now gives a warning and falls back to the metadata kV.
   - New problem A (below) sits in the SE-only JEOL path.
2. **Worker lifecycle: resolved.**
   - SystemExit is reported and the controls are restored.
   - A second job is refused while one is running.
   - Closing the viewer during a job, or while an analysis finishes and opens its run, no longer kills the process (exit 0).
   - Abort does not reach the first Monte Carlo run or the registration; this is documented.
   - New problem B below.
3. **Movie inputs: resolved.**
   - 16-bit data with bits = 8 now stop with a clear message, and Probe sets 16.
   - A manual gain of 0 and a pixel size of 0 are refused.
   - For interleaved files, Probe now gives a 1.00 s period (it gave 0.50 s).
   - OME `TimeIncrement` is read, and file order is natural.
   - With a 3-frame window, the row clock equals the true mean times.
   - Remaining, documented: in interleaved files `frame_s` is the period (1.0 s), not the raster time (0.5 s), and there is no SE/BSE time offset.
4. **Memory: partly resolved.**
   - Done: the log gives an estimate (80 B per pixel per time point) and GUI.md states it; videos are decoded on demand; prefetch is bounded.
   - The pipeline still holds every frame in RAM. The estimate is only logged inside the running job, and nothing stops the run beforehand.
   - Stack denoising, which peaks at about 13x the stack, is not included in the estimate.
   - The class and object layers are still built in the GUI thread.
   - `_hist` still copies the whole thickness stack on every slider step.
   - The QC figure still has 3 x n panels.
   - The new "record movie" keeps every screenshot in RAM.
   - This is acceptable as a stated limit. For the movies tomorrow, use a frame step or a crop.
5. **Re-runs: resolved.**
   - A second run into the same folder (step 2, then every frame) goes to a new sub-folder, and both runs open.
   - Old mixed folders and empty runs give clear errors.
6. **Export check: resolved.**
   - Damaged files are now caught: the last frame's gas zeroed, the middle frame's walls zeroed, and a layer flipped all give read_back = False.
   - The docs now say "first, middle and last frame". A corrupted frame 1 of 5 still passes, which matches that description.
   - The MATLAB v7.3 branch works.
   - One voxel-centre origin is used in VTK, Amira, NRRD, NIfTI, MRC, OME and Imaris.
   - Former false failures are now reported as "not checked".
   - New problem C below.
7. **Packaging: mostly resolved.**
   - Fixed: the curves are in the wheel and the sdist; the extras are complete (pynrrd, vtk and qtpy added, dipy removed); MANIFEST.in exists; napari >= 0.9 is required.
   - The license is still the `{text = ...}` table, so setuptools still warns at build time; the response says this was fixed.
   - `requires-python >= 3.10`, but napari 0.9.1 needs Python 3.11 or later, so `.[gui]` and `.[all]` cannot be installed on 3.10.
   - There is no CI; this is documented.
   - I could not verify here that "vtk-base without Qt" holds on Windows and macOS. Pin a non-Qt build or test it.
   - CITATION.cff still has no authors, repository or DOI.
8. **Tests: largely resolved.** Ten tests were added. Coverage over `test_v030` and `test_v021`:

   | module | round 1 | round 2 |
   |---|---|---|
   | `gui/worker.py` | 0 % | 79 % |
   | `gui/project.py` | 41 % | 77 % |
   | `se_only.py` | 0 % | 96 % |
   | `objects.py` | 44 % | 93 % |
   | `pipeline.py` | 0 % | 63 % |

   Still untested: the CLI (0 %), SE-only on JEOL series (where problem A sits), and closing during a job.

## New problems introduced by the revision

- **A. SE-only on a JEOL series mixes the two SE detectors, giving a wrong time series.**
  - When SE is primary, `io_jeol.group_scans` turns every SE image into a scan.
  - On the K-kit 12k series this gives 15 "frames" alternating E-T (LED) and in-lens (UED) images, e.g. LED at 10:23:03 and UED at 10:23:06.
  - The contact fraction jumps from 0.76 to 0.23 within 3 s.
  - The chosen "SE detector" (UED) is ignored, and `summary.csv` records only "SE".
  - Fix: make the selected SE signal primary, pair the other detector as a secondary channel, record the detector per frame, and add a test.
- **B. The close filter aborts the job before napari asks for confirmation.**
  - lcsem's filter runs before napari's own "Close window?" dialog, which is on by default in napari 0.9.1 (`confirm_close_window`). Clicking close aborts the analysis and blocks for up to 60 s before the dialog appears.
  - Choosing Cancel leaves the window open with the analysis already aborted.
  - After 60 s, `QThread.terminate()` is called on a thread running Python code, which is unsafe.
  - Better: register the job with napari's task-status manager, whose close dialog lists running tasks, or abort only after the close is accepted.
- **C. NRRD and NIfTI exports are mirrored against each other in ITK and 3D Slicer.** NRRD is now LPS but NIfTI keeps a RAS affine. In ITK, NRRD voxels run from 0.005 to 0.505 "mm" and NIfTI voxels from -0.005 to -0.505. Write the NIfTI affine with the RAS flip, or keep both in RAS.
- **D. Runs from before and after the revision are indistinguishable.** Behaviour changed substantially (SE contact map, gas volumes, crop now applied before splitting), but the version is still 0.3.0. Runs and projects from before and after the revision therefore record the same version, and old projects that use a crop now crop differently. Bump to 0.3.1, or record a build id or date in `run_info.json` and in the project.

## Round-2 verdict

**Minor revision.** Six of the eight points are resolved with tests, and the other two are documented or mostly fixed. Fix A before any SE-only JEOL series is analysed: it is a wrong result in a newly enabled path. Also fix B and C and bump the version. For tomorrow's movies the software is usable, provided the logged memory estimate is respected: use a frame step or a crop for long movies.
