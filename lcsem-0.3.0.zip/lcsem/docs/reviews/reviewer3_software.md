# Reviewer 3 (software engineering, GUI, packaging, tests, file formats): lcsem 0.3.0

## Summary

lcsem 0.3.0 has a sound structure. The napari GUI does no analysis of its own. Every setting goes into a JSON project that `lcsem project` runs headless. One 4-D model (`Volume4D`) feeds both the display and all 14 exporters. Repeated project runs are bit-identical (checked), and with napari 0.9.1 the GUI code raises no deprecation warnings.

The test suite passes (27/27), but the new code paths the user will rely on have almost no tests, and these untested paths contain real defects:
- Two detector modes are broken by a substring bug: "BSE only" and "BSE + STEM".
- "SE only" crashes on JEOL series.
- Closing the window during a job aborts the process.
- An empty selection leaves the GUI stuck.
- Wrong bit depth, frame time or file order silently produce wrong thickness or wrong time axes.
- A re-run into the same folder makes the run unreadable.
- Memory grows by about 96 MB per 1280 x 960 time point, and nothing warns about it.
- The export "read-back check" passes files whose frames 2..n are empty.

The pip extras and the Python-version claims are wrong, and nothing has been tested on Windows or macOS.

None of this is hard to fix. It must be fixed, with tests, before the software is used on the movies or submitted.

## Major issues

**1. The GUI-to-pipeline mapping is wrong for several source x detector combinations (`lcsem/gui/project.py`).** These are the combinations the user explicitly asked for ("SE and BSE independently").

- **a. `channels_of()` (project.py:50-52) matches substrings.** It tests `'SE' in mode.replace(' ', '')`, which is true for "BSE only" and "BSE + STEM" because "BSE" contains "SE". Checked: `load_config(to_config(p))` gives `{BSE: thickness, SE: contact}` for "BSE only".
  - Movies: `run_project` on a BSE-only (or BSE + STEM) movie fails with `ValueError: no movie file for SE`.
  - JEOL series: the SE frames are silently used (contact map, gas at the top, segmentation), although the user picked a mode without SE.
  - Fix: split the mode into tokens (`set(mode.replace(' ', '').split('+'))`) and have the project test assert the channels for every mode.
- **b. "SE only" with a JEOL source crashes.** `run_project` (project.py:181) calls `io_jeol.group_scans` with only an SE channel. `group_scans` requires a thickness channel (io_jeol.py:134), so on the real K-kit folder the run dies with a bare `StopIteration` and an empty message. SE-only therefore works for movies only.
- **c. JEOL references chosen in the GUI are not excluded from the time series.**
  - `to_config` (project.py:93) stores absolute paths with the extension stripped.
  - `pipeline.run` (pipeline.py:87-88) appends `.tif` only to relative names.
  - `group_scans` compares `abspath` against the `.tif` path.
  - Checked: the exclusion list contains `/data/K-Kit/20260821101000`, but the frame is `/data/K-Kit/20260821101000.tif`.
  - Result: a dark (beam-blanked) frame recorded at the same stage position and magnification stays in the series and is processed as a data frame, while also serving as the dark reference.
  - `.tiff` and `.TIF` references break outright.
- **d. The GUI beam energy (default 15 kV) overrides the JEOL metadata** (`beam.kV`, project.py:67). If it differs from the recorded kV, no scan is selected and the run fails with `IndexError: list index out of range` (pipeline.py:102). Checked with kV = 10 on the real series. For JEOL sources, default to "from metadata" and report an empty selection clearly.

**2. The worker thread lifecycle is unsafe (`gui/worker.py`, `gui/app.py`).** I checked each point headless with the real `LcsemApp`.

- **a. Closing the viewer while a job runs kills the application.** The QThreads are children of the main window (worker.py:30). Closing destroys a running thread, Qt prints "QThread: Destroyed while thread is still running", and the process gets SIGABRT (exit code 134). There is no close handler that aborts and waits. A user who closes the window during a long analysis loses the process, and files being written may be truncated.
- **b. `SystemExit` escapes the worker.** `Job.run` catches only `Exception` (worker.py:24), but `pipeline.run` raises `SystemExit('no scans selected')` (pipeline.py:96). That happens for an empty movie frame range, or a JEOL time window or magnification that matches nothing. Checked:
  - no failure message appears;
  - Run stays disabled and Abort enabled for good;
  - the thread never quits, and the application aborts on exit.
  - Fix: raise `ValueError` in the pipeline, catch `BaseException` in the worker, and always emit a final signal.
- **c. Jobs are not serialised.** Only the Run button is disabled; Export, Open run and Load project stay active. When any job finishes, `_idle()` re-enables Run and disables Abort even if another job is still running. Checked: after job B finished while A was still running, Run was enabled and Abort disabled. `app.jobs` is never pruned and threads are never deleted.
- **d. Abort does not reach most long stages.** `_volume_job` and `_export_job` ignore `should_abort` (app.py:11-17). Several stages outside the per-frame loops never check it:
  - the first-use Monte Carlo curve;
  - registration;
  - stack denoising in `build_scans`;
  - object analysis.

  METHODS section 8 ("Long computations run in a worker thread with progress and abort") is therefore only partly true.

**3. Unvalidated inputs silently produce wrong numbers in the movie path — the path the user will take tomorrow.** All items were checked unless marked otherwise.

- **a. Bit depth.** Two frames of the synthetic movie saved as 16-bit and run with the GUI default bit depth of 8 give `BSE_clip = 1.0` and a liquid median of 0 nm, with no warning. With 16 they give 665 nm. `probe()` converts frames to float32 before it reports the dtype (io_movie.py:144), so the GUI cannot detect the depth. Report the raw dtype, set `bits` from it, and warn when the data exceed 2^bits - 1.
- **b. Frame time for interleaved files.**
  - "Probe files" fills in 1/fps of the raw file (panels.py:116). Each detector's period is actually parts/fps, so the time axis is compressed by the number of parts. Checked with SE/BSE interleaved at 0.5 s: time points 0.50 s apart instead of 1.00 s. This distorts every rate (bubble growth, MSD, speeds).
  - With frame time 0 the spacing is right, but `frame_s` (the raster time used for the per-row clock) becomes 1.0 s instead of 0.5 s.
  - SE and BSE frames of an interleaved file are acquired one after the other, yet they get the same time stamp.
  - Frame period and frame duration need to be separate settings, with a time offset per detector.
- **c. Missing frame rate falls back to 1 s without a warning** (io_movie.py:155). OME-TIFF `TimeIncrement` is not read; only the ImageJ `finterval` is (io_movie.py:52). Checked: an OME-TIFF with a 0.25 s increment gives fps None. METHODS section 8 claims "(ImageJ, OME; frame interval from the metadata)".
- **d. Image folders are sorted lexicographically** (io_movie.py:36). `img_0`..`img_11` is read as 0, 1, 10, 11, 2, 3, ..., which scrambles the time order silently. Use a natural sort and warn when names are not zero-padded.
- **e. The temporal window distorts per-row times** (code analysis, not run). With window w > 1, a time point gets `frame_s = w * ft` (io_movie.py:161-163), so `row_times` spreads the rows over the whole window. The mean acquisition time of each row is then off by up to +-(w-1)/2 frame times. METHODS section 8 says the per-row clock "applies unchanged"; it does not for w > 1.
- **f. Manual calibration left at its defaults** (B0 = g = 0) runs to the end and reports a liquid thickness of `inf`. Validate g != 0.

**4. Nothing warns about movie size, and memory grows with every time point.** This is the new main use case, and it is undocumented.

- **The pipeline keeps every frame in RAM until the end** (the `F` list, pipeline.py:112-176; `canv`, pipeline.py:393).
  - Measured peak RSS on the synthetic SE + BSE movie (300 x 400 px, no denoising or segmentation): 350 MB for 10 time points and 631 MB for 40, i.e. 9.4 MB per time point (about 78 B per pixel).
  - Scaled to 1280 x 960 frames that is about 96 MB per time point: about 10 GB for 100 time points and 100 GB for 1000.
  - A TV-rate recording has thousands of frames.
- **Stack denoising (`build_scans`, project.py:143-160) loads all frames of all channels at once** (`np.stack`) and makes float64 copies.
  - Peak extra memory measured with tracemalloc: about 13x the float32 stack for MP-PCA and SVD, 4.3x for `register_stack`, 2x for `apply_shifts`. That is roughly 60 GB per channel for 1000 frames of 1280 x 960.
  - There is no progress or abort inside, and `movie_sources()` opens every file twice (line 154).
- **Video input.**
  - Frames are decoded to float32 and kept in memory whenever n x H x W x 3 < 2 GiB (io_movie.py:64-66), i.e. up to about 2.7 GB per file.
  - "Probe files" and `lcsem movie-info` decode the entire video, and in the GUI this runs in the GUI thread: 1.4 s and +43 MB for the 40-frame demo MP4, growing linearly with length.
- **GUI after loading.**
  - `RunView` builds the class and object layers in the GUI thread (display.py:94-99). `V.classes('icl')` took 0.21 s per frame on the 12k run, which means minutes of frozen UI for a long movie.
  - The 2-D model takes 3.5 MB per frame in RAM (12k run, bin 4), plus full-length thickness, class and object layers.
  - `ChartsWidget._hist` copies the whole thickness stack on every slider step (charts.py:78): 151 ms at 500 frames.
- **QC figure and registration.** `qc_overview.png` draws 3 x n panels (pipeline.py:517): 46 s and a 67,200-px-wide image for 300 tiny frames. `register_stack` finishes with a dense (T+1) x T least-squares solve, run three times (1.8 s at T = 2000, growing as T^3).

Recommendations:
- a pre-flight estimate in the GUI (time points x pixels leads to RAM and run time), with a warning or refusal;
- streaming per-frame outputs (memmap or zarr), with the calibration computed from a subset of frames;
- chunked stack denoising with progress and abort;
- lazy video decoding;
- building the 2-D layers lazily in the worker;
- a subsampled QC figure;
- RAM requirements stated in docs/GUI.md.

**5. Re-running into an existing output folder makes the run unreadable.**

- The pipeline never cleans `out_dir`, and frame tags depend on the selection (`<name>_<k>_f<frame>`, zero-padded according to the frame count).
- A second run with a different selection leaves the old `*_maps.npz` files in place. GUI.md itself recommends exactly this workflow ("analyse every n-th frame first").
- `Volume4D` collects `{name}_*_maps.npz` with a glob (volume4d.py:54), finds more files than drift rows, and fails with `IndexError: index 2 is out of bounds` (checked). `objects.analyse_run` fails the same way.
- `display._objects` silently drops the objects layer when the file counts differ.
- An aborted run leaves new maps next to the old `run_info.json`.

Fix: write each run to a fresh sub-folder, or clear previous outputs after confirmation. Take the frame list from `run_info.json` (store the tags) instead of a glob, and check `n_frames`.

**6. The export "read-back" check is overstated, and several exporters fail on large runs (`export_formats.py`).**

- **a. `verify()` (lines 323-387) checks shape and frame 0 only.**
  - For TIFF, OME-TIFF, OME-Zarr, Imaris, VTK, MATLAB, HDF5, NIfTI and Amira it compares the shape plus frame 0 of the liquid layer. For NRRD it checks one label map of frame 0.
  - For mesh, CSV and TrackMate it checks only that points, rows or column names exist.
  - No physical metadata are compared: spacing, units, time step, channel names.
  - Checked: exports whose frames 2..n are all zero, whose gas layer is flipped and whose walls are empty are all reported as `read_back = True`.
  - METHODS section 8, the CHANGELOG and EXPORT_FORMATS.md ("compared with the model", "all read back correctly") overstate the check.
  - Compare every frame and every layer (per-frame checksums are enough), compare spacing, units and time with `V.spacing` and `V.times`, and state in the manifest what was checked.
- **b. The MATLAB v7.3 branch fails.**
  - It is used above 1.8 GB (i.e. for long movies) and no test reaches it. Forced on a small run, it fails with `NotImplementedError: Can't write data type <class 'pandas.arrays.StringArray'>`.
  - The cause: pandas-3 string columns pass the `dtype != object` filter (lines 260-261).
  - The MATLAB writer (line 256), the NRRD sequence (line 181) and NIfTI (line 202) all stack every frame in memory. The latter two call `V.frame` and bypass the cache, so each frame is computed twice.
- **c. Units are inconsistent between the two 3D Slicer / ITK formats.**
  - NRRD writes micrometre values labelled "mm" (line 184); ITK reads 0.02 mm for a 20 nm voxel.
  - NIfTI writes micrometres with the micron unit code; ITK converts that to 2e-5 mm.
  - In the same program the two volumes therefore differ 1000x in size (checked with SimpleITK).
- **d. False failures.**
  - A mesh export of a run with no voxel >= 128 is reported FAILED: `verify` raises `IndexError` (checked).
  - The libraries that `verify` needs (imaris-ims-file-reader, SimpleITK, meshio) are not listed in `NEEDS`. When one is missing, a correct file is reported FAILED.

**7. The packaging and installation claims do not hold.**

- **a. The pip extras are incomplete.**
  - `export` lacks `pynrrd` and `vtk`, so the NRRD and VTK exports are unavailable after `pip install -e ".[all]"`. Yet the README says pip gives "the same" as conda.
  - `dipy` (in the `denoise` extra) is never imported.
  - `qtpy` is imported directly but not declared.
- **b. The Python version claim is wrong.**
  - `requires-python >= 3.9` and GUI.md ("Python 3.9-3.12") do not match the tested stack. napari 0.9.1, zarr 3.1, ome-zarr 0.18, pandas 3 and numpy 2.4 all require Python 3.11 or later.
  - `lcsem[export]` (`zarr>=3`) cannot be resolved on 3.9 or 3.10.
  - `napari>=0.5` would install napari versions nobody has tested, and the code relies on private napari APIs.
  - Pin the tested ranges.
- **c. The curve files are not packaged.** The `data/*.json` curves are outside the package, and I confirmed by building a wheel and an sdist that neither contains them. This includes the K-kit depth curve that the 0.2.1 changelog calls "shipped".
  - In a normal install, `_find` looks in site-packages and finds nothing.
  - The sdist ships the tests but not `data/`, so `test_v02` and `test_synthetic` fail when run from it.
  - Move the curves to `lcsem/data` as package data and add a MANIFEST.in.
- **d. "Windows, macOS, Linux" is untested.**
  - There is no CI at all.
  - environment.yml takes `vtk` from conda-forge (its Qt builds pull in qt6-main) but PyQt6 and napari from pip. When the GUI runs the VTK export, two Qt6 builds may load into one process.
  - Install napari and pyqt from conda-forge, and add a CI matrix that runs `conda env create` and the tests on Windows, macOS and Ubuntu.
- **e. Code availability is not in place.**
  - There is no repository URL and no archived DOI.
  - CITATION.cff lists only "The lcsem authors".
  - setuptools warns that the `[project.license]` table is deprecated and will be refused after 2027-02-18.

**8. The tests do not cover the new main paths.**

- **Test run.** Under the brief's command, 27 passed and 0 failed, with 18 warnings, in 495.9 s. The machine was shared with a benchmark; 439 s of that is the `test_v02` end-to-end test. The 0.3.0 tests alone take about 35 s.
- **Coverage.** I measured coverage.py on `test_v030` and `test_v021`, with coverage installed only in my work folder:

  | module | coverage | what is untested |
  |---|---|---|
  | `gui/worker.py` | 0 % | everything |
  | `se_only.py` | 0 % | everything |
  | `cli.py` | 0 % | everything |
  | `gui/project.py` | 41 % | `movie_sources`, `build_scans`, `run_project` |
  | `objects.py` | 44 % | `analyse_run` |
  | `gui/app.py` | 56 % | all job paths |
  | `gui/panels.py` | 70 % | `to_project`, `from_project` |
  | `io_movie.py` | 76 % | video, folders, interleaved/top-bottom layouts, crop |
  | `volume4d.py` | 98 % | |
  | `export_formats.py` | 96 % | |

  Every major issue above sits in an untested path.
- **Weak or misleading tests.**
  - `test_project_roundtrip_and_configs` asserts only `cfg['mode']`; checking the channels would have caught 1a.
  - `test_exports_read_back` fails, rather than skips, when an optional library is missing, although its comment says "skipped".
  - `test_voxel_fractions` tests `export_amira._fraction`, which is dead code since 0.3.0.
- **Tests to add.**
  - `run_project` on 3-5 synthetic frames for every mode and every layout (synthetic movies, plus synthetic JEOL folders from `lcsem simulate`).
  - Worker tests: success, failure, SystemExit, abort, and closing during a job.
  - A panel-to-project round trip.
  - CLI smoke tests: `project`, `export --list`, `movie-info`.
  - Export tests that check all frames, all layers and the metadata.
  - Empty, stale and aborted run folders.
  - A determinism test.

## Minor issues

1. **Charts crash for runs segmented with BIC only.** The GUI offers "BIC" as a criterion, but `charts._panel_d` fails with an `IndexError` in `stackplot` (charts.py:99-101; checked). The layers still appear; the charts, export folder and status line are not set.
2. **An empty run folder gives a cryptic error.** `Volume4D` fails with "need at least one array to stack" (volume4d.py:104), or `max()` of an empty sequence when a cache file exists (line 58). Check n = 0 up front and say what is wrong.
3. **`OPEN_WITH` is parsed from the module docstring** (export_formats.py:29). Under `python -OO` or a frozen build the import fails with `AttributeError` (checked), which also breaks the GUI's Export tab. The parsed text also includes the "files" column.
4. **CLI argument problems.** `lcsem export --list`, documented in EXPORT_FORMATS.md and in the `--formats` help, fails because `run_dir` is required (cli.py:20). Unknown format names are not validated: they end up as "NOT written (KeyError)".
5. **Blocking I/O in the GUI thread.** "Probe files" runs in the GUI thread (panels.py:108-118). A compressed TIFF stack is decompressed into a temporary memmap file when it is opened (io_movie.py:44; checked, `/tmp/tmp*.memmap`). That means silent multi-GB temp files, which on Windows stay locked while mapped.
6. **Multi-channel TIFFs are misread under "separate files".** A TCYX hyperstack (e.g. a Fiji composite of SE and BSE) is read as 2T frames with alternating channels (checked). Map the C axis to detectors, or document the limitation.
7. **Denoising options that silently do nothing.**
   - Stack methods with a JEOL source apply no denoising, because the pipeline only runs frame methods.
   - "Also denoise SE" and the temporal window are ignored with stack methods (project.py:146-153).
   - `bm3d` is offered even when it is not installed, and the run then fails after it has started.
8. **The analytical model has hidden consequences.**
   - It silently sets `use_particles = False` for "auto" and the particle calibration modes (project.py:110-111). Without dark or empty references every analytical run then fails with "not enough references (['flat'])" (checked for STEM only, SE + STEM and SE + BSE + STEM). Say so in the GUI.
   - `to_config` writes the analytical curve files and fails when the output folder is empty (checked). Keep the translation free of side effects.
9. **Project-file reproducibility gaps.**
   - Relative paths are resolved against the current directory, not the project file (`load_project`; `load_config` has `_config_dir` for this).
   - `lcsem project --out` stores the old `out_dir` in the new run's `lcsem_project.json`.
   - Asymmetric membranes are lost when a project goes through the GUI: there is one spin box (panels.py:127), and [50, 20] becomes [50, 50] (checked).
   - The project file records neither the lcsem version nor a date.
   - The Monte Carlo curve used is not copied into the run folder.
   - The curve cache key has no engine or table version (mc/curves.py:85-92), and cache writes are not atomic: a killed run leaves a truncated JSON that breaks later runs.
10. **File-name and path robustness.**
    - The free-text `name` goes unsanitised into every file name. On Windows a `:`, `/`, `\` or `*` fails late in the run.
    - Glob patterns built from folder and run names are not escaped (`glob.escape`), so folders containing `[` or `]` yield no files.
    - `.tif` checks are case-sensitive (references.py:32, pipeline.py:88).
    - `cli simulate` strips `/` only (`rstrip('/')`), which is wrong on Windows.
    - Deep Windows paths plus the export sub-folders can exceed MAX_PATH.
11. **Voxel placement differs between the viewer and the exports.**
    - napari places voxel centres at (j*b + (b-1)/2)*px laterally and (k + 1/2)*dz vertically (display.py:61-62).
    - Amira uses (j + 1/2)*b*px (export_amira.py:137).
    - VTK, mesh, NIfTI, NRRD, MRC and OME use j*b*px with origin 0.
    - As a result the Au spheres and tracks in VTK and the meshes sit (b-1)/2*px laterally and dz/2 vertically off the voxels: 12 nm and 5 nm at 12k with bin 4. Write the origins explicitly.
12. **Export metadata and housekeeping.**
    - Imaris time points use a hard-coded date, 2026-08-21 (export_formats.py:112-114).
    - NRRD is written in RAS, so ITK tools show the image mirrored in x and y (direction diag(-1, -1, 1); checked).
    - Export sub-folders are never cleaned, and `export_amira` lists every file in its folder (line 316), so stale files are counted and checked.
    - MRC output is uncompressed.
13. **Volume4D threading and side effects.**
    - `prefetch` adds a task for every slider step to an unbounded single-thread queue, so scrubbing queues every intermediate frame.
    - Each `Volume4D` creates a `ThreadPoolExecutor` that is never shut down.
    - Viewing a run writes `volume2d_bin*.npz` into the run folder; this is not documented.
    - `json.load(open(...))` leaves files open (ResourceWarning observed). Close files explicitly, which matters on Windows.
14. **`register_stack` docstring vs default.** The docstring describes baselines 1, 2, 4, 8, 16 by default; the default is `(1,)`, the neighbour chain only. The dense least-squares solve is unnecessary for a chain; use the chain directly, or a sparse solver.
15. **napari private APIs.** The code uses `window._qt_window`, `window._qt_viewer.dims.play`, `viewer._calculate_bounding_box` and `canvas.viewbox_size`, each wrapped in `try/except`. A future napari will therefore lose layout, zoom or play without any message. With 0.9.1 there are no deprecation warnings (checked). Pin a tested napari range.
16. **Errors that get lost.** Object-analysis failures are only written to the log (project.py:189-190). The `QThread` objects and the `jobs` list grow with every job (app.py:94).
17. **Documentation gaps.**
    - `docs/VALIDATION_DENOISING.md` is referenced five times (README, GUI.md, METHODS twice, CHANGELOG) but does not exist.
    - The README output list lacks the new files: `lcsem_project.json`, `objects*.csv`, `*_objects.tif`, `volume2d_bin*.npz`, the SE-only outputs and `analytical_curve_*.json`.
    - `lcsem simulate-movie` is missing from the README.
    - GUI.md says nothing about RAM needs.
    - "Movies are accepted as references" is true only for movie sources: JEOL sources append `.tif` to the file stem.
    - The lossy-video caveat should add that FFmpeg's YUV-to-RGB conversion rescales limited-range video, so grey levels from MP4 are not quantitative.

## Questions to the authors

1. Which configurations were actually installed and run? Specifically: `conda env create` on Windows and macOS, and the GPU/OpenGL setup. Will you add CI?
2. What movies are expected tomorrow: number of frames, frame size, bit depth, layout (side by side, interleaved, separate files), container? What RAM does the analysis PC have?
3. Were the exports opened in the target programs (Amira, Imaris, 3D Slicer, ChimeraX, Fiji, ParaView), with the physical scale checked there? Screenshots would support the claim.
4. For interleaved recordings, how should per-pixel time represent the SE-BSE offset?
5. Will the code, the K-kit data and the synthetic movies be deposited with a DOI? Will the paper's figures be produced by `lcsem project` from the JSON files in the run folders?
6. Why is `dipy` an extra? Which napari and Python versions do you intend to support?

## Verdict

**Major revision.** The architecture and scope are appropriate for Nature Methods, and the headless runner is reproducible. But five of the fourteen source x detector combinations fail or silently change the analysis (movie BSE only, movie BSE + STEM, JEOL SE only, and JEOL BSE only / BSE + STEM silently using SE), there are crash paths in the GUI's main workflows, inputs that silently corrupt thickness and time, no memory guard for movies, and an export-validation claim the code does not support. All of these are in untested paths. Each needs a fix plus a regression test. The pip and Python-version claims need correcting, and Windows/macOS installation needs verifying in CI.

## Evidence

All scripts and their outputs are in `/home/claude/reviews/reviewer3_software_work/`.

| file | what it checks |
|---|---|
| `pytest_run1.txt` | test run |
| `cov_run.txt`, `.coverage` | coverage |
| `dist/` | wheel and sdist built from a copy of the source |
| `exp/e3_worker.py` | worker cases a, b, c |
| `exp/e4_volume_edge.py` | stale, empty, no-particle and no-liquid runs |
| `exp/e5_project.py` | mode mapping, SE-only JEOL, references, kV, manual calibration, 16-bit, interleaved time |
| `exp/e6_io.py` | readers |
| `exp/e7_verify.py` | corrupted exports pass the check |
| `exp/e8_metadata.py` | physical metadata per format |
| `exp/e9_matlab73.py` | MATLAB v7.3 branch |
| `exp/e10_mem.py` | memory vs frame count |
| `exp/e11_napari_api.py` | napari deprecations and private APIs |
| `exp/e12_roundtrip.py` | GUI round trip |
| `exp/e13_gui_runs.py` | BIC-only charts |
| `exp/e15_determinism.py` | bit-identical re-runs |

Nothing outside `/home/claude/reviews/` was modified. Python was run with `PYTHONDONTWRITEBYTECODE=1` except for the prescribed test command.
