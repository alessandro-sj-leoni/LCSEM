# Reviewer 2 (image processing and statistics), round 2: lcsem 0.3.0 revised

**Scope.** I re-checked each round-1 point against the revised code and the v2 synthetic runs. All scripts and logs are in
`reviews/reviewer2_imaging_work/r2/`: `r2_bench_check.py`, `eval_v2.py`, `dbg_align.py`, `reg_r2.py`, `iso_test*.py`
and `missed.py`.

## 1. Round-1 major points

| # | Status | Reason and independent check |
|---|---|---|
| 1 Benchmark sign / eval alignment | **Resolved** | I recomputed the dose-150 cases (seed 0) with my own common-field mask. The ranking is identical and the values are within 10 %. Static BSE, MP-PCA+VST: 2.97 (published 2.79). Changing BSE, BM3D+VST: 3.49 (published 3.28). The −d_j truth offset is correct: the best contact IoU (0.98–0.99) is at 0–1 px from it. The authors' eval script reproduces 15.5 / 16.8 / 16.3 nm. |
| 2 Chained registration drifts | **Not resolved** (documented; ROI and "none" added) | `register_stack` on synmovie, maximum error: BSE 3.0 px at step 1 and 5.2 px at step 4; SE 5.7 px at step 1 and **21 px at step 4**. Template refinement is worse (up to 35 px), as the authors say. The v2 SE+BSE runs are off by 4.4 px. The SE-only validation run is off by **22 px (180 nm)**. METHODS §8 says "2–6 px over 40 frames". See new problem 2. |
| 3 Contact/objects biased, over-splitting, speed | **Resolved except speed** | Object areas: largest −0.9 % (range −1.5 to −0.4 %), second −2.6 % (−7.6 to −1.7 %). No false rim particles. Growth rate 0.0741 µm²/s (−2 %). Ellipses of 150×40 and 200×60 px now stay one object and touching discs split (`ws_test.py`). **Speed:** both pockets grow or shrink in place, yet their net speeds are 2.3–2.7 nm/s (SE+BSE) and 10.0 nm/s (SE-only). These values equal the registration error ÷ 18 s: the noise bias is gone, and the drift artefact is now the whole signal. |
| 4 sT coverage | **Not resolved** (documented as lower bound) | Coverage of \|err\| < 1.96 sT in liquid ≥ 40 px from gas is **0.51–0.53** (robust SD of err/sT 2.2–2.35), about the same in the none, NLM and MP-PCA runs. METHODS §7 still quotes 39 %. |
| 5 Per-frame classes | **Partly** (hidden, labelled, caveat) | Selection still sits at the k = 7 boundary: ICL gives 7 in 10/10 frames of both synthetic runs. On run12_v5, BIC gives 7 in 8/9 frames and ICL gives 2–3, varying by frame. |
| 6 Series-denoising path | **Resolved** | Whole-pixel alignment uses the same sign as the benchmark. σ and particles now come from the raw frames: median sT 3.7 nm in the MP-PCA run (1.9 nm before). Particles and contact match the undenoised run (recall 0.85, no false particles, IoU 0.985). New caveat: new problem 3. |
| 7 Benchmark scope | **Partly** | Added: 3 seeds, SSIM, bias, task metrics. Still missing: a change-rate sweep (the per-frame vs series advice rests on 0 vs ~1 px/frame only), coloured noise, a check on real data (even/odd frames need no truth) and video/self-supervised comparators. The end-to-end table shows **no benefit of the default denoiser**. "none" is best for thickness (bias 0.3 vs 1.7 nm, MAE 15.5 vs 16.8 nm) and for contact IoU (0.985 vs 0.983). The claim that denoising "matters for segmentation, contact edges" has no number behind it. |
| 8 Noise model | **Partly** (wording fixed, documented) | On the benchmark's own true-Poisson data the fit is still biased. Fitted/true a is 0.87–0.89 (BSE, dose 50) and 0.86–0.89 (SE, dose 150); b is −242 vs −344. The downstream bias is < 0.4 grey, so this is harmless on synthetic data. The real-data mean–variance check is still missing. |

## 2. New problems

1. **The particle isolation test removes pairs and particles on steps** (`imageproc.detect_particles`, l. 155–161; `iso_test.py`, `iso_test2.py`).
   * Two particles 8–10 px apart: recall 0.00–0.03, against 0.35–1.00 without the new tests. At 14 px apart, recall is 0.95–1.
   * A particle ≤ 6 px inside a 25-grey thickness step: detected in 0–0.2 of trials, against 1.0 without the tests.
   * At 8 nm/px this means 38-nm Au pairs with gaps of 26–42 nm are lost, i.e. dimers and aggregates, and particles pinned at gas–liquid interfaces.
   * The validation cannot show this: no truth pair is closer than 25 px, and the synthetic rims are smooth (11 of 12 particles near rims are found).
   * *Fix:* use a sector test (a rim gives a high response along a long arc or on two opposite sides; a neighbour gives it in one narrow sector), or deblend first. Apply the test only near SE/thickness edges. Report recall vs pair separation and vs distance to the rim.
2. **Frame step inflates the registration error, and the METHODS numbers are too low.**
   * `pipeline._register`, `se_only.run_se_only` and `project.build_scans` register only the analysed (stepped) frames. At step 4 the error is 1.7× (BSE) to 3.7× (SE) larger than at step 1.
   * *Fix:* register every frame (40 frames take 1–2 s) and subsample the drift afterwards.
   * Correct METHODS §8 and the docstring to 5–22 px at step 4.
   * Without a static ROI, flag trajectories, MSDs and `net_speed_nm_per_s` as containing the drift error, or withhold them.
3. **Series denoising uses the common field of the whole movie** (`project.build_scans`, l. 216–222).
   * Over a long movie the denoised area shrinks by the total drift. The rest stays raw, which leaves a seam where the noise level steps in the thickness maps and the segmentation.
   * The run stops with "drift larger than the frame" once the drift exceeds the frame width minus 16 px: after about 840 frames at synmovie's 0.46 px/frame in x. MP-PCA itself only needs 32-frame blocks.
   * *Fix:* align, crop and denoise per block, and store a per-pixel "denoised" flag.
4. **The segmentation is denoised twice** (`pipeline.py:336`). NLM with h = raw σ runs on `q['work']`, which is already NLM+VST- or series-denoised. The effective h is about 5× the residual noise, which over-smooths the features. *Fix:* skip this step when a denoiser has run, or set h from the residual noise.
5. **Stale validation material.**
   * The objects of `run_v2_SE_BSE` (the default run) were computed with the old objects.py (path-length speed).
   * The SE-only row and the headline growth rate of 0.0752 µm²/s come from the old MP4, which rescaled 300 rows to 304 (+1.3 % area). The SE+BSE runs give 0.0741.
   * `synmovie` predates the true-Poisson simulator.
   * METHODS quotes 39 % coverage.
   * `mppca` gives a 9×9 patch for T = 24 (81 < 4T), against its comment.
   * *Fix:* regenerate the movie and re-run.

## 3. Verdict

**Minor revision.** Points 1, 3 (areas, rims, splitting) and 6 are fixed, and I reproduced the fixes. Points 4, 5 and 8 are honestly documented. Registration (2) remains the main limitation for movies.

Conditions:
* Fix new problems 1 and 2: they bias particle counts and positions/speeds in exactly the movies the GUI targets.
* Correct the numbers in METHODS and the validation docs.
* Either add an empirical random error from even/odd frames, or state next to every ± that sT is about 2.3× too small.

Speeds or trajectories from SE-only movies without a static reference would need a registration uncertainty. That is a major item if the paper claims them.
