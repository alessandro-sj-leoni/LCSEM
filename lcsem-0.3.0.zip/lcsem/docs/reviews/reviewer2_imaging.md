# Review of lcsem 0.3.0: image processing and statistics (Reviewer 2, reviewer2_imaging)

Scope: `lcsem/denoise.py`, the denoising benchmark (`gui_dev/dnbench/bench.py`, `denoise_benchmark*.json`, `gui_dev/eval_truth.py`),
`lcsem/io_movie.py` (registration), `lcsem/objects.py`, `lcsem/volume4d.py` + `gui/charts.py`, PCA+GMM segmentation in movies,
and the matching claims in METHODS.md section 8, docs/GUI.md, CHANGELOG.md and the GUI tooltips. All my experiments are
in `/home/claude/reviews/reviewer2_imaging_work/`. The script is named after each result below. My re-run of the benchmark
reproduces the published JSON values exactly when I use the published code path, so the corrected numbers are for the
same data and noise realisations.

## Summary

Most of the formulas are right. The generalized Anscombe transform and its closed-form inverse follow Mäkitalo & Foi for
var = a x + b (a = α, b = σ² − αμ). The inverse agrees with a numerically computed exact unbiased inverse to within 0.15
grey. At stride 1, MP-PCA gives the same numbers as DIPY 1.12 (identical RMSE in six cases). The Gavish–Donoho
threshold is implemented as published. On static scenes the chained registration is accurate (≤ 0.2 px after 39 pairs).

The validation around these methods does not yet support the claims:
* **The benchmark registers the stacks with the wrong sign.** The series methods are scored on frames that drift at twice
  the true rate. The conclusion "per-frame methods beat MP-PCA/SVD even on static scenes" is an artefact of this.
* **`eval_truth.py` misaligns the ground truth** by each frame's drift. It overstates the thickness error about 1.7×.
* **Neither script measures what the pipeline delivers:** thickness after a 15-px smoothing, contact areas, objects,
  particle depths.

On the synthetic movie with ground truth I find systematic errors in paths the user will use tomorrow:
* **Registration error grows with scene change:** 2–6 px over 40 frames, and 4–18 px with the multi-baseline option.
* **SE-contact and object areas are 20 % too small in SE + BSE mode.** False Au detections at bubble rims are masked out
  of the contact map.
* **The reported thickness uncertainties cover 39 % of errors instead of 95 %.**
* **The "classes" chart jumps by 30–40 points between frames.** The jumps come from per-frame model selection and
  frame-relative tags, not from the sample.

Each of these is fixable. The benchmark must be re-run and task-level validation added before the denoising and
segmentation claims can go into a Nature Methods paper.

## Major issues

### 1. The denoising benchmark scores the series methods on mis-registered stacks, and `eval_truth.py` misaligns the truth

**Wrong registration sign.** `gui_dev/dnbench/bench.py:21` uses `sh = -(t['drift'] - t['drift'][0])`.
* In `simulate.make_movie` the frames are `image_k(y) = scene(y + d_k)`. Undoing that needs `apply_shifts(frames, +(d_k - d_0))`.
  That is the convention `register_stack` itself returns: on a static movie it gives exactly `+(d - d0)`
  (`regcheck.py`).
* With the benchmark's sign, a **static** movie with integer drift keeps moving 2 px/frame after "registration".
  Mean |f7 − f0| of the clean BSE frames is 59 grey instead of 0 (`signcheck2.py`).
* The published table already shows the symptom: a 5-frame temporal mean is *worse than no denoising on a static scene*
  (static/1000/SE: 6.24 vs 4.60).
* The per-frame methods are unaffected, because noisy and clean frames are shifted alike. Every series-method number in
  `denoise_benchmark.json` and `denoise_benchmark_subpixel_drift.json` is invalid.

**Scoring mask.** The mask (`bench.py:25-26`, 16-px border) also includes border strips that `apply_shifts(mode='nearest')`
filled with replicated pixels. The drift reaches 31 px, and these strips penalise the series methods further.

**Corrected numbers.** `stack_bench.py`: same generator, seed, frames 12–19 and noise model. With the benchmark's sign the
script reproduces the published values (e.g. static/150/BSE: 11.389 / 8.95 / 6.042). Corrected = sign `+(d − d0)` and
scoring only the field imaged in all frames (32-px border). RMSE in grey levels:

| scene / dose / channel | temporal mean (published → corrected) | SVD-GD + VST | MP-PCA + VST, 7×7 | MP-PCA + VST, 11×11 | NLM + VST (per frame) |
|---|---|---|---|---|---|
| static / 50 / BSE   | 17.3 → 15.9 | 12.4 → 6.6 | 9.5 → 5.5 | 4.6 | 6.5 |
| static / 150 / BSE  | 11.4 → 9.4  | 8.9 → 3.8  | 6.0 → 3.1 | 2.7 | 4.1 |
| static / 1000 / BSE | 7.6 → 4.0   | 5.9 → 1.6  | 3.0 → 1.5 | 1.4 | 2.1 |
| static / 150 / SE   | 6.7 → 3.1   | 4.8 → 1.2  | 2.0 → 0.83 | 0.62 | 0.78 |
| static / 1000 / SE  | 6.2 → 2.0   | 4.3 → 0.83 | 1.4 → 0.55 | 0.41 | 0.52 |
| changing / 150 / BSE | 11.3 → 11.6 | 9.3 → 10.8 | 6.2 → 6.6 | 7.0 | 3.8 |
| changing / 150 / SE  | 6.5 → 7.3   | 4.6 → 5.9  | 2.1 → 2.2 | 2.3 | 0.81 |
| changing / 1000 / BSE | 8.0 → 8.9  | 6.4 → 7.6  | 3.1 → 3.5 | 3.8 | 1.8 |

* **Static scenes:** with correct registration SVD-GD and MP-PCA beat per-frame NLM + VST for BSE. SVD-GD reaches the
  32-frame-mean oracle (3.7 at static/150/BSE). MP-PCA with 11×11 patches also wins for SE.
* **Changing scenes:** per-frame NLM + VST stays best. The qualitative guidance in METHODS §8 and GUI.md
  ("per-frame for changing scenes") therefore survives, but any statement that the series methods lose on static scenes
  would be false.
* **Mask effect:** it is large on its own. MP-PCA + VST at static/150/BSE is 4.37 with the 16-px mask and 3.08 in the
  common field.

**`gui_dev/eval_truth.py`.**
* The truth `T[j]` is in scene coordinates.
* Unregistered runs are compared without shifting it, so they are misaligned by d_j. Registered runs are shifted by
  −(d_j − d_0); the correct shift is −d_0 (line 11).
* `step=2` is hard-coded (line 8).

Corrected (`eval_thick.py`):

| run | thickness MAE as written | thickness MAE corrected |
|---|---|---|
| NLM + VST project run | 18.8 nm | 10.8 nm |
| MP-PCA project run | 24.1 nm | 14.8 nm |

*Action:*
* Fix the sign and score in the common field.
* Fix `eval_truth.py`.
* Re-run both scripts with several noise seeds and report confidence intervals (see issue 7).
* Write `docs/VALIDATION_DENOISING.md` only after that. It is referenced by METHODS.md and GUI.md but does not exist yet.

### 2. Chained registration: the error accumulates with scene change and the "0.2 px per pair" claim hides it

METHODS.md §8 (l. 128-132) says: "On synthetic movies the drift error is about 0.2 px per frame pair". It presents the
multi-baseline least squares as keeping "the random walk of a chain … from accumulating" (`io_movie.py:168-175`).

Measured with `reg_bench.py`: 40 frames, 300×400 px, dose 150, drift (0.3, −0.45) px/frame + 0.5 px jitter; errors vs
the true drift. The static movie uses the same drift with no scene change. The changing movie is `gui_dev/synmovie`.

| movie, channel, baselines | per-pair error, y: mean ± SD (px) | error after 39 pairs (y, x) px |
|---|---|---|
| static, BSE, chain (default) | 0.004 ± 0.043 | 0.17, 0.22 |
| static, BSE, 1-2-4-8-16 | 0.000 ± 0.040 | −0.01, −0.01 |
| static, SE, chain | −0.003 ± 0.026 | −0.13, 0.07 |
| changing, BSE, chain (default) | **0.048 ± 0.225** | **1.87, −1.43** (max 3.0) |
| changing, BSE, 1-2-4-8-16 | 0.105 ± 0.326 | **4.11, −3.29** (max 5.8) |
| changing, SE, chain | 0.147 ± 0.091 | **5.72, −0.93** |
| changing, SE, 1-2-4-8-16 | 0.458 ± 0.159 | **17.9, −4.2** |

What this means:
* The "0.2 px" is the per-pair SD on the changing movie.
* The dangerous part is the **bias**. The DoG band-pass (2–20 px, `io_movie.py:185`) removes the static smooth
  thickness field and keeps what moves: diffusing particles and growing or shrinking bubble edges. Registration therefore
  partly follows the scene, and the error grows *linearly*.
* The longer baselines are more biased, not less, and the fixed tolerance `1 + 0.5·sqrt(k)` px (`io_movie.py:204`)
  accepts them. The option is off by default, but METHODS presents it as an improvement.
* The GUI project runs confirm this (`drift_eval.py`): the SE + BSE run is up to 2.9 px off, and the SE-only run from
  the MP4 is up to 7.8 px off, monotonically.
* At 8 nm/px this is 20–60 nm of spurious displacement in 20 s, i.e. a 1–3 nm/s apparent drift. It enters the
  canvas-based particle trajectories and MSDs, object centroids and speeds, and dT/dt maps.
* A 1000-frame movie with the same per-pair bias would accumulate 50–150 px.

*Action:*
* Report the accumulated error, not the per-pair error, on changing scenes with realistic change rates.
* Mask changing regions: iterate registration → temporal-variance mask → re-registration.
* Register to a common or running reference (template update, keyframes) instead of a pure chain. Or fit a smooth drift
  model over time: stage and beam drift is smooth, so use a robust spline or polynomial.
* Scale the consistency tolerance with the measured pair precision.
* Provide a registration uncertainty, e.g. the spread of independently registered sub-tiles. The same spread also
  detects non-rigid motion.
* Test on a movie with fiducials.
* Minor naming point: `phase_cross_correlation(..., normalization=None)` (`io_movie.py:191`) is plain cross-correlation,
  not phase correlation as the docs say.

### 3. SE + BSE mode: contact areas and objects are biased low, small bubbles vanish, and "speed" is biased

Measured on the GUI project runs of `synmovie` against the truth (`obj_eval3.py`, `obj_eval2.py`, `depth_eval2.py`,
`depth_eval3.py`).

**False Au detections at bubble rims shrink the contact map.**
* The BSE particle detector finds a median of 32 "particles" per frame for 12 true particles.
* 420 of the 449 false detections lie within 8 px of a gas-pocket rim. The BSE thickness step at the rim is detected as
  a blob.
* Their masks (radius 3σ + `mask_extra_px` = 10–24 px) are removed from `f.valid` (`pipeline.py:125`). `se_contact_map`
  only marks valid pixels (`analysis.py:20`, called at `pipeline.py:310`), so the contact map is notched along every rim.

Object areas vs truth:

| run | largest object | second object |
|---|---|---|
| SE + BSE, NLM | median **−20 %** (range −26 to −7 %) | median −8.5 % (range **−51** to −4 %) |
| SE + BSE, MP-PCA | median −20 % | median −14 % |
| SE only (no particle masks), after removing the MP4 stretch | +0.1 to +1.5 % | −3.2 to +1.4 % |

* **Growth rate** of the growing bubble: 0.068 µm²/s vs 0.0758 true (−10 %). The SE-only run gives 0.0768.
* **The "about 2 %" claim** (GUI.md l. 96) therefore holds only for SE-only mode. Even there, 1.3 % comes from the
  simulator's MP4 writer rescaling 300-row frames to 304 rows (`macro_block_size=8`, `simulate.py:189`), which went unnoticed.
* **Real K-kit series:** the Au masks cover only 0.5–1.9 % of the frame, so the effect is small there. Tomorrow's
  low-dose movies with moving bubbles resemble the synthetic case.
* **Chart (d) "particle depth":** of the 49 depths in the SE + BSE run, 3 come from true particles, 38 from rim false
  positives and 8 from other false detections.

**Small bubbles are removed.** `se.min_area_px = 2000` (`config.py:48`) removes contact regions under 0.13 µm² at 8 nm/px
(r < 25 px), in both modes. The shrinking bubble's track ends 3–4 frames early (areas 1372–1886 px in truth). Nucleation
of small bubbles cannot be observed. The limit is in pixels, so its physical meaning changes with magnification: the
default 2000 px is 0.005 µm² at 60k, while the real 60k run was configured with 20 000 px = 0.05 µm².

**Mean speed is biased.** `mean_speed_nm_per_s` = path length / lifetime (`objects.py:113`) is a positively biased
estimator. The truly static bubbles get 3.3–3.8 nm/s (SE only) and 11–15 nm/s (SE + BSE).

**Watershed over-segments elongated objects.** Markers come from `peak_local_max(dist, min_distance=10)` with no
h-maxima or neck criterion (`objects.py:46`), tested with `ws_test.py`:
* one 150 × 40 px ellipse → **4 objects**;
* one 200 × 60 px ellipse → 4;
* a disc with a small bump → 2.

Dewetting fronts and coalescing bubbles are elongated, so this creates spurious split/merge events and fragmented tracks.

*Action:*
* Do not exclude particle masks from the SE contact map; fill through them (closing or majority fill), or use the SE
  channel's own validity.
* Reject edge responses in the particle detector, e.g. with the Hessian eigenvalue-ratio test of Lowe 2004.
* Express `min_area` in nm² and justify it by a detection-limit study.
* Use h-maxima markers (`skimage.morphology.h_maxima` on the distance transform) or a neck/compactness criterion.
* Replace path-length speed by net displacement or a regression slope with a CI.
* Validate area, boundary (IoU / boundary F-score / Hausdorff) and growth-rate bias against truth as a function of
  bubble radius.

### 4. Reported thickness uncertainties do not include the denoiser and fail coverage

`sT` is computed from the raw pixel σ with the white-noise Gaussian-smoothing formula `σ/(2√π s)` (`fusion.py:11-13`,
`pipeline.py:152/305`). This ignores:
* the NLM/BM3D step, which correlates the noise so that the 15-px smoothing no longer averages it by that factor;
* its bias (method noise);
* all systematic errors.

On the SE + BSE NLM run, liquid regions ≥ 40 px from gas rims, with particle masks excluded (`sT_coverage.py`,
`sT_coverage2.py`):

| quantity | value |
|---|---|
| median reported sT | 3.4 nm |
| robust SD of the actual error | 16.3 nm |
| random frame-to-frame part of the error (robust SD) | 6.6 nm, already 2× the reported sT |
| fraction with \|T − T_true\| < 1.96 sT | **39 %** (nominal 95 %) |
| same fraction, MP-PCA path | **21 %** (σ estimated on denoised frames, see issue 6; median sT 1.9 nm) |

These σ also set the inverse-variance channel fusion and the χ² disagreement map, which METHODS §3 presents as "a local
test of the detector models".

*Action:*
* Estimate the noise after denoising empirically: from independent half-data (even/odd frames, or interleaved pixels
  for single frames), a Monte-Carlo SURE-type divergence, or a parametric bootstrap through the full pipeline.
* Report random and systematic components separately.
* Validate coverage on the synthetic movies, with a table in the paper.

### 5. Segmentation in movies: per-frame k, per-frame standardisation and frame-relative tags make chart (d) "classes" misleading

Each frame is fit independently:
* the features are z-scored per frame (`multimodal.py:38`);
* k is chosen per frame by ICL/BIC;
* classes are renumbered by thickness per frame;
* tags ("thin", "thick", "rim/front", "wet/dry") come from thresholds *relative to that frame's class medians*
  (`multimodal.py:90-99`).

The chart then stacks area fractions **by tag** (`charts.py:98-103`). On `run_proj_SE_BSE` the scene changes smoothly
(one bubble grows, one shrinks), yet between frames 0-4:

| tag | frames 0 to 4 |
|---|---|
| "wet, normal" | 0.46, 0.51, 0.19, 0.53, 0.21 |
| "wet, thick" | 0.29, 0.24, 0.60, 0.21, 0.58 |

* In the MP-PCA run k varies from 4 to 7, and "wet, normal" is 0 in five frames while "wet, thick" jumps to 0.70–0.78.
* The 2-D "classes" layer (`display.py:94-96`) colours by per-frame class number, so colours are not linked over time.
  The objects layer, by contrast, uses track ids and is fine.
* The selected k sits at the upper bound of the search range:

| data | criterion | k selected (search range 2–7) |
|---|---|---|
| synthetic movie | ICL | 7 in 16/20 frames |
| real 12k series (run12_v4) | BIC | 7 in 9/9 frames |
| real 60k series (run60_v4) | BIC | 7 in 3/4 frames |

  On a real 12k frame ICL gives k = 2 with 80 000 pixels and k = 3 with 20 000 (`k_select.py`).
* Pixel-subsample "stability" (5/5) reproduces the same bias and is not evidence of validity. Neighbouring pixels are
  strongly correlated after 4–15 px smoothing, so the effective n is far smaller than n_fit.

*Principled alternatives for a series:*
* Standardise with series-wide statistics, or in physical units (nm, calibrated SE level).
* Choose k once for the series by ICL on a pooled, spatially thinned sample stratified over frames. Assess stability by
  resampling frames or spatial blocks, not pixels. Show the ICL/BIC-vs-k curves and flag boundary solutions.
* Fit one GMM on the pooled sample and classify every frame with it (`predict_proba`). Class identity is then fixed by
  construction. If intensities drift, refit per frame with a warm start from the series model
  (`means_init`/`precisions_init`, few EM iterations) or with a MAP prior, as in evolutionary clustering.
* If per-frame models must stay, match classes between frames by Hungarian assignment on a distance between Gaussian
  components (Bhattacharyya) or on map overlap on the canvas. Show births and deaths explicitly, and plot by matched
  identity, not by tag.
* Derive tags from absolute thresholds (nm; the series-wide SE contact threshold).

### 6. The series-denoising path of the GUI changes the data before the pipeline sees them as raw

`gui/project.py:143-160`: `register_stack` → `apply_shifts(order=1, mode='nearest')` → `denoise_stack` → `ArraySource`,
with registration then set to "none".

**(a) Bilinear interpolation changes the noise.** It reduces the noise variance per frame by
[(1−f_y)² + f_y²]·[(1−f_x)² + f_x²], i.e. down to 0.25 for half-pixel shifts. It also correlates the noise and blurs.
* MP-PCA/SVD assume i.i.d. noise across frames, and the VST model (median of per-frame fits) no longer matches any frame.
* Evidence from the sub-pixel run, whose frames are interpolated: VST bias at dose 50 is +1.40 grey (NLM + VST) and
  +1.90 grey (MP-PCA + VST), about **+11 to +15 nm of thickness** at 0.123 grey/nm.
* With integer drift it is +0.37 grey. My test with the model from an uninterpolated frame gives +0.13 grey
  (`vst_bias.py`).

**(b) `mode='nearest'` fabricates border data.** The last frame of `run_proj_SE_BSE_mppca` has 9 replicated rows at the
top and several replicated columns at the right, all `valid` (`pad_check2.py`). They enter thickness, volumes and exports.
Because every frame now looks fully imaged, `Volume4D.series`'s common-field logic is bypassed.

**(c) Denoised frames are treated as raw.** Detection, core-fraction depth, the noise σ and hence `sT` are all computed on
denoised, interpolated frames.
* `sT` median is 1.9 nm against an actual error of 19 nm (issue 4).
* Particle depths: reported σ_z is 12 nm against an MAE of 36 nm (24 matched particles).

*Action:*
* Denoise in the original frame geometry and register afterwards. Alternatively, use integer-pixel alignment for the
  denoiser and sub-pixel only for the canvas, or Fourier (phase-ramp) shifts, which are unitary and keep white noise
  white.
* Pad with NaN and carry a validity mask.
* Keep the raw frames for photometry, noise estimation and depth.

### 7. Benchmark scope: what a Nature Methods reviewer will ask for

Beyond issue 1, the benchmark cannot yet support a method-choice claim.

**Realism.**
* `simulate.make_movie` draws heteroscedastic *Gaussian* noise with Poisson variance (`simulate.py:169-171`), although
  the docstring and CHANGELOG say "Poisson-Gaussian". At 7–30 BSE counts/pixel the skewness matters for the VST: this is
  an inverse crime.
* The noise is white. SEM movies at short dwell times have noise correlated along the fast-scan axis, plus line noise.
* The SE ground truth is a two-level piecewise-constant image, which is ideal for NLM and TV.
* Needed: true Poisson counts, measured noise power spectra, and semi-synthetic scenes built from real high-dose or
  averaged frames.

**Statistics.**
* One seed, no confidence intervals, no paired comparisons. Several NLM/BM3D differences are a few per cent.
* Use ≥ 5 seeds and paired bootstrap CIs.
* Report each method at its default and at an oracle setting tuned on a separate seed. The ranking depends on
  parameters: the TV weight optimum is 1σ or 2σ depending on the case (`h_sweep.py`), and MP-PCA 7×7 vs 11×11 swaps order
  between static and changing scenes.

**Change rate.** A single, fast change rate is used: bubble edges move 1–2 px/frame and particles 1 px/frame. The
per-frame vs series verdict hinges on this, so sweep it (0, 0.1, 0.3, 1, 3 px/frame).

**Missing competitors designed for movies:**
* VBM4D / BM4D (Maggioni et al. 2012).
* Spatio-temporal NLM.
* Self-supervised methods, now standard in Nature Methods time-lapse papers: Noise2Void, Noise2Self, DeepInterpolation
  (Lecoq et al. 2021, *Nat. Methods*), Noise2Noise on even/odd frames.
* The trivial hybrid "NLM on a 3-frame mean".

**Metrics beyond grey-level RMSE:**
* SSIM / MS-SSIM.
* Bias vs intensity, to show the VST/inverse is unbiased at low counts.
* Edge metrics: boundary displacement and 10–90 % edge width.
* Small-object fidelity: Au peak excess, FWHM and core fraction, i.e. depth bias.
* Particle detection precision/recall and localisation error.
* SE contact IoU / boundary F-score.
* Object area and growth-rate bias.
* Resolution loss: FRC between independently denoised halves, or MTF from a slanted edge.
* Temporal response (lag and blur of a moving edge).
* Whiteness of the residual (method noise).
* Timing on stated hardware. The present `s_per_frame` values were measured on 2 shared cores.

**Measure the end product.**
* With the GUI default `smooth_sigma_px` = 15 px (`config.py:45`; the GUI's "0 = default"), the thickness MAE is
  9.3 nm (NLM) vs 13.8 nm (MP-PCA) in liquid away from rims, but **132 vs 128 nm within 12 px of gas rims**, whatever
  the denoiser (`eval_thick.py`).
* The effective lateral resolution of the thickness maps and of the 4-D model is therefore set by the 15-px Gaussian
  (120 nm at 12k), not by the denoiser. It changes with magnification because it is in pixels.
* The paper must state this and evaluate the denoisers on the final thickness, contact, object and depth outputs.

### 8. The Poisson-Gaussian noise model is biased on known data and unvalidated on real data

The GAT pipeline rests on `estimate_noise_model` (`denoise.py:37-58`). Tests with known (a, b) (`noise_model_test.py`,
`fewlevels.py`; 5 realisations each):

| condition | error |
|---|---|
| "flattest 30 %" gradient selection alone (flat ramp, no clipping) | a −3 to −4 % (without the selection: −0.5 to +0.5 %) |
| 8-bit clipping at low dose | a −6 to −11 % (the benchmark's own BSE fits are −6 to −11 %) |
| fine texture everywhere (period ~20 px) | variance +108 % |
| noise correlated along x over 2–3 px | a −9 to −16 %; `_sigma_mad` (horizontal differences, `denoise.py:74-75`) σ −33 to −45 % |
| σ ≤ 0.4 grey (few grey levels) | `_sigma_mad` = 0 |

* Excluding windows that contain clipped pixels does not remove the truncation bias of the neighbouring windows.
* On the synthetic data the downstream effect is small. The model error changes the VST bias by only about 0.1 grey, and
  the closed-form inverse is within 0.15 grey of the exact inverse (`vst_bias.py`).
* The real risk is untested assumptions on real data: white noise, and the var = a x + b form (SE detectors add
  scintillator/PMT excess noise).
* METHODS, the GUI tooltip and the CHANGELOG say the model is "fitted per series". The pipeline fits it **per frame**
  (`pipeline.py:143,167` call `denoise_image` without `noise`); only `denoise_stack` pools. The per-frame CV of a is
  1.5 % (BSE) and 3.8 % (SE), so this is harmless but mis-described.

*Action:*
* Validate on the real movies: the per-pixel temporal mean-variance of a registered static region is a direct,
  texture-free measurement of (a, b).
* Estimate the noise power spectrum and autocorrelation from frame differences. If the noise is coloured, use BM3D with
  a PSD (`sigma_psd` accepts one; Mäkinen et al. 2020 is already cited) and a MAD along y.
* Consider the wavelet-domain estimator of Foi et al. with their clipped-data model, which is what [33] actually does.

## Minor issues

1. **`igat` clipping order and floor** (`denoise.py:69-71`).
   * The code returns `a·max(I,0) − b/a` = α(max(I,0) − σ̃²) + μ. Mäkitalo & Foi clip after subtracting σ̃²:
     α·max(I − σ̃², 0) + μ. Outputs can therefore fall up to σ²/α below the offset (1.3 grey for BSE at dose 50).
   * `D` is floored at 0.8 to avoid the D⁻³ blow-up. Harmless here, but document both, or follow M&F exactly.
2. **`estimate_noise_model` fallbacks and weights.**
   * With < 50 windows it returns the whole-image variance, signal included (l. 47).
   * With < 2 bins it divides the median by 0.7. That is the χ²₂ ratio, inconsistent with the Wilson–Hilferty factor
     0.986 used for k = 48, and overestimates b by 41 % (l. 54).
   * The WLS weights are equal by construction, because the bins are quantiles (l. 55-56). The heteroscedastic variance
     of the bin medians, which Foi et al. handle by maximum likelihood, is ignored.
   * The χ² correction assumes independent Gaussian pixels.
3. **Robustness on low-noise 8-bit data.** `_sigma_mad` uses only fast-scan-axis differences and a median of
   integer-valued |d|. It returns 0 for σ ≤ 0.4 grey and moves in steps of about 1.05 grey above that. With `vst=False`,
   TV then crashes (`ZeroDivisionError`, `denoise.py:97`) and NLM silently does nothing.
4. **"strength 1 = the noise-matched default"** (`denoise.py:79`) holds for BM3D (σ_psd = 1 after VST).
   * NLM h = 0.9σ, with σ given and fast mode, is near the synthetic BSE optimum (0.8) and below the SE optimum (1.0–1.2).
     scikit-image's rule is "σ or slightly less"; its gallery uses 0.6σ in this mode.
   * The TV weight = σ and the fixed 1.5 px Gaussian are not noise-matched.
   * Consider Monte-Carlo SURE (Ramani, Blu & Unser 2008) or PURE for Poisson-Gaussian noise (Luisier et al. 2011).
   * Cite Darbon et al. 2008 for scikit-image's fast NLM; it was developed for cryo-EM.
5. **MP-PCA.**
   * Identical to DIPY only at stride 1. The default stride p//2 costs about 10 % RMSE (3.08 vs 2.79,
     `dipy_cmp.py`); state this.
   * The patch rule gives 7×7 for 32 frames (γ = 0.65).
   * The weights 1/(1 + kept) are from Manjón et al. 2013 (PLoS ONE 8, e73021); cite it.
   * After the VST σ = 1 is known. Either impose it, or report the MP estimate as a VST quality check (it gives 1.005
     here).
6. **SVD-GD.** After the VST the noise level is known, so the known-σ threshold λ*(β)·√n·σ is better defined than
   ω(β)·median. Centring along frames adds a null singular value to the median (`denoise.py:160-161`); drop it and use
   m − 1.
7. **Temporal window > 1 breaks the per-row clock.** `movie_scans` (`io_movie.py:161-162`) treats the mean of w frames as
   one frame of duration w·ft ending at the last frame.
   * The true mean acquisition time of row r is t_start + (w−1)ft/2 + r·ft/N. Row times are off by up to ±(w−1)ft/2,
     e.g. ±1 s for w = 5 and ft = 0.5 s.
   * METHODS §8 says the clock "applies unchanged".
   * Also, rigid per-frame registration ignores drift within a frame, which shears slow rasters. The package already has
     a per-row clock that could carry a per-row shift.
8. **Input and metadata.**
   * The OME-TIFF frame interval is not read; only ImageJ `finterval` is (`io_movie.py:51-55`), contrary to METHODS §8.
   * Video encoders may rescale frames to a multiple of the macro-block size. Warn when the decoded frame size is
     unexpected, because it changes the pixel size.
9. **`objects.py` details.**
   * `gas_mean_nm` uses `nan_to_num`, so invalid pixels count as 0 (l. 52).
   * The perimeter assumes square pixels (l. 57).
   * The growth-rate fit includes border-touching frames and gives no CI (l. 112).
   * Split/merge detection uses IoU ≥ 0.1, which misses small fragments (IoU ≈ A_frag/A_parent). Use intersection over
     the smaller area (l. 74-75).
   * Canvas placement uses `floor(shift)` (±0.5 px).
10. **Charts** (`gui/charts.py`, `volume4d.py`).
    * (c) excludes T ≤ 0, i.e. dry columns (`charts.py:78`), while the hover "median thickness" (`volume4d.py:220`)
      includes them, so the GUI shows two different medians. T clipped at the cap makes a spike.
    * (d) particle depth: per-frame quantiles are drawn from 1–4 particles (see the synthetic screenshot).
      * Show n per frame.
      * Require n ≥ 5 for the IQR band.
      * Show the typical σ_z. METHODS §7 itself says the depth errors are 2–3× underestimated.
      * Prefer per-track traces.
    * (a/b) volumes carry no uncertainty (calibration ±25–30 % without references). The per-frame-field fallback is
      only mentioned in the readout text.
    * `T_median_nm` uses each frame's own field, while the volumes use the common field.
11. **Documentation claims to correct.**
    * "exact unbiased inverse" (GUI tooltip, CHANGELOG) → closed-form approximation.
    * "BM3D: best quality per frame" (`panels.py` TIP): NLM + VST ≤ BM3D + VST in 11 of 12 cases of the integer-drift
      benchmark.
    * "phase correlation" → cross-correlation of band-passed frames.
    * The "about 2 %" object-area claim applies to SE-only mode only (issue 3).
    * `VALIDATION_DENOISING.md` is referenced but missing.
12. **Tests are too permissive to catch the biases above.**
    * `test_noise_model_and_gat` allows 20 % on a and |Δb| < 6 on b = 9.
    * There is no registration test on a changing scene, no test on an elongated object, and no test of the stack path's
      border handling.
13. **Performance note.** BM3D takes about 3–4 s per 240×320 frame here. A 1280×960 frame is about 16× more pixels, so
    roughly a minute per frame on 2 cores. GUI.md's "about 4 s per frame" should give the frame size.

## Questions to the authors

1. What is the noise power spectrum of the real SE and BSE movies, and is var = a x + b confirmed by the temporal
   mean-variance of a static region? Is the SE noise compatible with a single (a, b) per frame, given charging?
2. What frame rates and change rates (px/frame of bubble-edge motion) do you expect tomorrow? The per-frame vs series
   recommendation should be stated in those units.
3. Why is `smooth_sigma_px` = 15 px kept after denoising? What lateral resolution do you claim for the thickness maps
   and the 4-D model at 12k and at 60k?
4. How do you register SE-only movies, which have no static features, and how will you validate that drift (fiducials,
   window frame)?
5. Will movie particle depths be reported? At what detection threshold, and with what rejection of edge responses?
6. For the segmentation of movies, is a series-wide model acceptable to you? Are the per-frame tags intended as physics
   (absolute thresholds) or as descriptions relative to the frame?
7. Will you compare against a video denoiser (VBM4D) and a self-supervised method (Noise2Void, Noise2Self or
   DeepInterpolation)?

## Verdict

**Major revision.** The core algorithms are sound and mostly implemented as published. What needs revision:
* The benchmark and truth-evaluation errors (issue 1).
* The registration bias (issue 2).
* The SE + BSE object/contact bias (issue 3).
* The uncertainty coverage (issue 4).
* The "classes" chart (issue 5).
* The series-denoising path (issue 6).
* Task-level validation (issues 7 and 8).

Most fixes are local. The validation needs new runs with several seeds and should be reported with confidence intervals.

*Reproduction:* scripts and outputs are in `/home/claude/reviews/reviewer2_imaging_work/` (`dn/` holds the regenerated
benchmark data and the corrected JSON; `pylib/` holds DIPY 1.12.1 for the cross-check).
