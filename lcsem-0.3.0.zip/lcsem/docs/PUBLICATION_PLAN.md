# Publication plan: target *Nature Methods*

**Standing goal (recorded at the author's request, 27 Sep 2026):** this software and the physics behind it are being developed
for a methods paper in *Nature Methods*. Every design decision is made with that in mind:

* only peer-reviewed algorithms, each cited where it is used (`METHODS.md`);
* one open, installable, tested package that anyone can run on their own data (`lcsem`), with configuration files for every
  acquisition option (`docs/OPTIONS.md`);
* validation against ground truth that the reader can regenerate (`lcsem validate`, `docs/VALIDATION.md`);
* every number in the paper reproducible from raw data + a configuration file + a version tag.

## Claim (working title)

*Quantitative, time-resolved 3-D imaging of liquids, gas and nanoparticles in sealed liquid cells with a standard SEM.*

1. The raster is a clock: every pixel has its own acquisition time, so dynamics are measured at the line rate, not the frame rate.
2. Detector signals converted into physical quantities with a Monte Carlo model and internal/external references: liquid
   thickness (BSE, STEM), gas contact with the top membrane (SE), gas elsewhere (gap map), particle x, y, z.
3. Particle depth from a single scan at a single beam energy (image core fraction; BSE/STEM ratio) - no tilt series, no
   energy switching, so 3-D positions keep the temporal resolution.
4. Self-consistency: redundant references (dark, empty cell, Au standard, full cell) test the physics model on every data set.

## What the paper needs (checklist)

| item | status |
|---|---|
| Software: installable package, CLI, config files, tests, docs | v0.2 (this release) |
| Physics engine: Mott cross sections (ELSEPA), CSDA, validated against published BSE yields | engine done; **to do: benchmark vs published backscatter coefficients (e.g. Joy's database) and CASINO for SiN/water/Au** |
| Synthetic ground-truth validation for each option set | `lcsem validate` (v0.2) |
| Model-error test (what happens when the detector model is wrong, and which references reveal it) | `lcsem validate` (v0.2) |
| Real data, current K-kit (Au NPs, 12k and 60k series) | analysed (v0.1/v0.2) |
| **New acquisition with references**: dark (blanked), empty K-kit, full cell, Faraday cup current, certified Au standard | planned (see below) |
| **STEM-in-SEM channel** recorded with BSE + SE in the same scan | planned |
| Independent thickness check: optical interferometry of the window, or known channel height after complete filling, or EELS t/lambda in a TEM | planned |
| Independent particle-depth check: tilt pairs (+/-5 deg parallax) on the same particles | planned |
| Biological demonstration (e.g. rotavirus, M. Boyce) - feasibility simulated in `examples/rotavirus/` | simulation done; experiment planned |
| Comparison with existing approaches (liquid-cell TEM thickness by EELS; multi-energy SEM depth sectioning; STEM-in-SEM mass thickness) | to write |
| Data deposition (raw images + metadata + configs), code on GitHub with a Zenodo DOI | at submission |
| Nature Research reporting summary, statistics (bootstrap CIs, error propagation) | methods in place |

## Experiments that turn the method into a paper

1. **Calibration session** (one afternoon, same detector settings throughout): dark frames (beam blanked, brightness raised so
   that the dark level is > 0 on 8-bit), an empty K-kit, a filled K-kit before any gas forms, Faraday-cup current before and
   after, BSE + in-lens SE (+ E-T in BSE mode) + STEM in the same scan. This alone tests the Monte Carlo detector model
   (the Au-standard check) and gives the gap map.
2. **Dynamics** at 12-15 kV (0.5 um K-kit: 15 kV; STEM 20-25 kV if STEM is the main thickness channel), fixed cadence, SE
   every frame, known dose per frame.
3. **Depth validation**: tilt pairs (+/- 5 deg) on a field with immobilized and mobile 60 nm Au; compare parallax depth with the
   core-fraction and BSE/STEM-ratio depths.
4. **Biology**: rotavirus TLPs/DLPs adsorbed on the top membrane, STEM at 25-30 kV (see `examples/rotavirus/README.md` for
   the predicted contrast and dose).

## Figures (draft)

1. Concept: cell, detectors, signals; raster-as-clock.
2. Physics: S(T) per detector and kV; particle excess and core fraction vs depth; information per electron (Fisher).
3. Calibration and self-consistency: dark/empty/particle/full references; residual maps (chi2 BSE vs STEM).
4. Validation on ground truth: thickness, gas classes, particle z for each option set; model-error test.
5. Real data: 4-D liquid/gas maps, dT/dt and boundary-velocity maps; particle 3-D trajectories.
6. Outlook: biological particles (rotavirus) - predicted and measured.
