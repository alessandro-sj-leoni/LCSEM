# Response to the internal peer review of lcsem 0.3.0

Four independent reviewers (agents with separate briefs; reports in `docs/reviews/`) examined the 0.3.0 GUI release:
Reviewer 1 physics and modelling, Reviewer 2 image processing and statistics, Reviewer 3 software engineering,
Reviewer 4 usability for a liquid-cell microscopist. **Round 1:** all four recommended major revision (reports
`docs/reviews/reviewer*.md`; responses below). **Round 2:** all four recommended minor revision, Reviewer 1 conditional on
one new problem (N1) (reports `docs/reviews/reviewer*_round2.md`; responses in the section "Round 2" at the end). "Fixed"
means changed in the code, covered by a test where one is named, and re-validated; "Documented" means stated as a limitation
because a fix needs data or work beyond this revision. Tests: `tests/test_v030.py` (44 tests in the suite pass).

# Round 1

## Reviewer 1 (physics and modelling)

**M1 Analytical detector models (BSE 1 - exp(-T/L), STEM exp(-T/lambda)) contradict the Monte Carlo and fail with dark +
empty references.** Fixed by removal from the interface: the models do not follow the Monte Carlo curves of the BED-C
detector (membrane signal at T = 0, convex rise, abrupt saturation), their defaults were not reproducible, and the STEM form
is the thin-specimen TEM law. The GUI offers the Monte Carlo model (computed automatically and cached) or a curve file.
`calib.solve` now refuses dark + empty for any model with S(0) = 0 and a manual gain of 0. `lcsem.calib.analytical_curve`
stays in the library for comparison only. METHODS section 8 no longer describes the analytical models.

**M2 Silent 200 nm flat field in the GUI defaults; movie calibration untested.** Fixed: no default flat field ("not used");
a pre-flight check (`lcsem.gui.project.calibration_plan`, shown when *Run* is pressed and logged by `lcsem project`) lists
the calibration the references allow and its assumptions, and refuses to run when only a hidden assumption could set the
scale (test `test_calibration_plan_refuses_hidden_assumptions`). An assumed flat field must be typed in and is then shown
as ASSUMED in the view, the charts' run and the export README (`Volume4D.calibration_text`, `export_formats.provenance`).
The K-kit 1 runs of 0.2.1 used particles + an assumed 200 nm flat field; the screenshots now say so. Validation of the
movie path with dark/empty reference movies in 'auto': documented as open (it needs recorded references; the checklist in
`docs/GUI.md` asks for a dark frame and an empty cell). Black-level stability over long movies: documented.

**M3 Gas volumes biased or noise-dominated without a gap map; gas stored as 0 without SE.** Fixed in part: the gap under the
contact region is interpolated from the wet surroundings with a robust quadratic surface fitted away from the rims, and the
gas volume is the unclipped sum of (gap - T) over the contact region plus a margin of 2.5 smoothing lengths (no positive
noise bias; recovers the deficit the smoothing moves across the rim). Frames without SE give NaN gas (60k frames 4-6), SE-
only volumes are NaN. Validation (`docs/VALIDATION.md`): 0.93-0.98 of the true gas volume while the contact covers < 17 %
of the field; 0.63-0.70 when a large bubble sits on the thickest part of the bulge - documented, with the recommendation to
record a full-cell reference. Static-gap assumption and uncertainty bands: documented; bands are future work.

**M4 SE contact map not robust (per-frame Otsu gives 34-50 % contact in gas-free frames).** Fixed:
`lcsem.analysis.se_contact_map` divides the smoothed SE by a robust quadratic background (shading, drift), detects only
pixels darker than max(5 sigma of the smoothed relative SE, 5 %), grows each region to half its own core contrast and
removes regions below a minimum area in um2 (0.01 by default, settable in the GUI). Gas-free and shaded frames: 0 %
contact; bubbles of radius 10-130 px within 1-2 % (23 % over at r = 10 px, the resolution limit); test
`test_se_contact_map_no_false_contact_and_true_areas`. The mechanism (SE2 and charging; Cazaux 2004, Reimer 1998) and the
need to check the SE-dark = gas interpretation on each system are stated in METHODS section 8 and section 7.

**M5 Drawing conventions rendered and exported as if measured; false particles on rims.** Fixed: the model is called a
2.5-D layer model everywhere; the view states "top membrane drawn flat: all relief shows at the bottom membrane"; particles
without a measured depth are drawn as grey vertical lines through their column (not as spheres at the top); SE-only volumes
are NaN and labelled nominal; every export has a provenance README (mode, calibration and assumption, conventions,
unmeasured particles, gap source, dose). False particles: `detect_particles` now rejects edge-like responses (Hessian
ratio test of Lowe 2004 and an isolation test), 245-284 -> 0-4 false detections per 10 frames at 0.85-0.90 recall (test
`test_particles_not_detected_on_bubble_rims`). Separate label value for unmeasured particles in the voxel volumes and
smoothing of the bottom surface: documented (the tables flag them; the vertical-line display in the viewer).

**M6 Synthetic movie not physically consistent ("dose" is not a dose; limitations not documented).** Fixed: the noise is
now true Poisson counts plus read noise; the parameter is documented as a noise level (Poisson quanta per unit of detector
signal), not an incident dose, in the docstring, the CLI help and the docs; the docstring lists what is not modelled
(charging, beam effects, row-by-row acquisition, detector bandwidth, B0/g drift, scan distortions, pressure-dependent
bulging). Physically consistent per-detector noise from the Monte Carlo moments: future work.

**M7 No dose bookkeeping.** Fixed: `lcsem.dose` (fluence per frame I t_f / (e A), cumulative fluence counting every frame
scanned including skipped ones, frame-averaged dose rate, first-order absorbed dose in water with the Joy-Luo stopping power:
0.258 MGy per e/nm^2 at 15 keV, as the reviewer computed); probe current field in the Data tab; columns in summary.csv,
record in run_info.json, chart (d) "electron dose", line in the view, export README. Test `test_dose_bookkeeping`.
Radiolysis references (Schneider 2014, Grogan 2014) in METHODS. Depth-dose profile from the Monte Carlo: future work.

**M8 Row clock wrong for averaged movie frames.** Fixed: a time point averaging W frames is dated at the mean acquisition
time of each row (one frame duration, ending (W - 1)/2 frames before the last), its span stored as `support_s` (test
`test_movie_source_layouts_and_times`).

Minor: noise-model wording (per frame, excess-noise factor) and GAT-inverse wording corrected in METHODS; engine range
0.5-32 keV; STEM dark-field detectors get the right particle sign; SE-only gas height settable; object times from their
rows; METHODS says binary Otsu no longer, describes the new map; `top_membrane_dry` now works (particles are no longer holes
in the contact map); lateral resolution of the thickness stated (15 px). Correlated noise, lossy video, Swank factor,
aggregates, depth-dose: documented.

## Reviewer 2 (image processing and statistics)

**1 Benchmark registered the stacks with the wrong sign; truth misaligned in eval_truth.** Fixed: benchmark rewritten
(`docs/scripts/bench_denoise.py`): sign +(d - d0) as `register_stack`, whole-pixel drift (no interpolation), scoring over the
field imaged in every frame, three independent movies per case, true Poisson noise, SSIM and bias; `eval_movie_truth.py`
shifts each frame's truth by its drift. Results (`docs/VALIDATION_DENOISING.md`) now agree with the reviewer's corrected
numbers: MP-PCA best for static scenes, BM3D + VST best and NLM + VST close for changing scenes. The NLM run's thickness MAE
is 16.8 nm overall and 9.5 nm away from rims.

**2 Registration error accumulates on changing scenes; "0.2 px per pair" hides it.** Partly fixed: accumulated error now
reported (2-6 px over 40 frames of a scene without static features); a registration region of interest (a static area) and
"none" are offered in the GUI; the docstring and METHODS explain that registration needs static features, and that the
routine is cross-correlation of band-passed frames (not phase correlation). A median-template refinement was implemented
and tested: it made this case worse and is off by default. Smooth drift models and uncertainty from sub-tiles: future work.

**3 SE + BSE contact areas 20 % low, small bubbles removed, speed biased, watershed over-splits.** Fixed: particle masks no
longer cut the contact map and rim detections are rejected (area 0.987, IoU 0.983 of the truth); minimum area in um2
(0.01); net speed replaces path length; h-maxima markers keep elongated objects whole (tests
`test_row_clock_and_objects_split`, `test_objects_split_measure_and_track`). Growth rate of the growing bubble 0.0752 um2/s
(truth 0.0758). Boundary metrics vs bubble radius: in `docs/VALIDATION.md` (radius 10-130 px).

**4 Reported thickness uncertainties do not cover the errors (39 %).** Documented (METHODS section 7, VALIDATION): the
statistical errors ignore the denoiser and all systematic errors and are lower bounds. An empirical error model (even/odd
frames, bootstrap through the pipeline) is future work.

**5 Per-frame segmentation makes the classes chart misleading.** Mitigated: the chart is no longer shown by default, says
"per frame", and warns that the number and tags of classes can change between frames; METHODS section 7 states it. A
series-wide model (pooled fit, predict per frame) is planned.

**6 Series-denoising path interpolates, fabricates borders, and treats denoised frames as raw.** Fixed: frames are aligned by
whole pixels (no interpolation), denoised on the common field, put back in their own geometry (pixels outside the common
field are left raw, nothing is fabricated), the pipeline registers them as usual, and the raw frames are kept for particle
detection, photometry and noise estimates (`MovieFrame.raw_src`). End-to-end: particles and contact identical to the
undenoised run.

**7 Benchmark scope.** Partly addressed: three seeds with SD, SSIM, bias, task-level metrics (thickness, contact, particles),
two scene types, three noise levels. Change-rate sweep, coloured noise, semi-synthetic scenes and self-supervised/video
denoisers: listed as not covered in `docs/VALIDATION_DENOISING.md`.

**8 Noise model biased on known data, unvalidated on real data; "fitted per series" is per frame.** Documented and wording
fixed (per frame; per series for the series methods; assumes white noise). Recommendation to check it on the real movies
with the temporal mean-variance of a static region (VALIDATION_DENOISING.md section 3).

Minor: `_sigma_mad` uses both axes and a quantisation floor (no TV crash); MP-PCA patch 2 sqrt(T) and Manjon 2013 cited;
SVD-GD uses the known-noise threshold after VST; OME TimeIncrement read; MP4 rescaling in the simulator removed; objects'
NaN handling; charts use one definition of the thickness distribution and require n >= 5 for depth statistics; doc claims
corrected ("exact unbiased inverse", "best quality", "phase correlation", "about 2 %" now SE-only with numbers).

## Reviewer 3 (software engineering)

**1 GUI-to-pipeline mapping (substring bug, SE-only JEOL crash, reference exclusion, kV override).** Fixed: tokenised modes
(test `test_modes_map_to_detectors`); SE-only works in `group_scans`; reference exclusion compares paths without extension
and case; no scan at the configured kV falls back to the metadata kV with a warning.

**2 Worker lifecycle (close during job, SystemExit, no serialisation, abort coverage).** Fixed: `BaseException` is caught and
reported; one job at a time (Run, Export, Open, Load disabled while busy); closing the window aborts and waits (terminate
only after 60 s); the pipeline raises ValueError instead of SystemExit; export checks abort between formats; the series-
denoising path checks abort between channels (test `test_worker_reports_systemexit_and_serialises_jobs`). Abort inside the
first Monte Carlo run and the registration: documented.

**3 Unvalidated movie inputs.** Fixed: bit depth read from the file and data above it stop the run; interleaved frame time
= parts / fps; OME TimeIncrement; natural sort; averaged-frame clock; manual g = 0 refused; pixel size required.
Per-detector time offset for interleaved SE/BSE: documented.

**4 Memory growth with movie length.** Documented and estimated: the log gives the memory estimate (80 bytes per pixel and
time point) before the run; video frames are decoded on demand; the prefetch queue holds at most one frame; GUI.md gives
the numbers. Streaming per-frame outputs: future work.

**5 Re-running into a folder makes it unreadable.** Fixed: a non-empty output folder gets a new sub-folder per run; frames
listed in run_info.json; clear errors for empty or mixed folders (test `test_rerun_goes_to_a_new_folder_and_opens`).

**6 Export check overstated; MATLAB v7.3 fails; NRRD/NIfTI units differ; false failures.** Fixed: every layer of the first,
middle and last frame compared voxel by voxel, voxel size and origin checked (test `test_export_check_detects_corruption`);
MATLAB v7.3 works (test `test_matlab_v73_branch`); NRRD and NIfTI both in micrometres labelled mm, NRRD in LPS; mesh without
surfaces and missing reader libraries are "not checked", not failures; one voxel-centre origin in every format.

**7 Packaging.** Fixed: curves inside the package (wheel checked), extras completed (pynrrd, vtk, qtpy; dipy removed),
Python >= 3.10 (3.11 tested), napari >= 0.9, license field, MANIFEST.in, conda environment with matplotlib-base and vtk-base
(no second Qt). CI on Windows/macOS: not available here - documented as untested.

**8 Tests.** 10 tests added for the paths above (worker, run_project for BSE-only and SE-only movies, re-runs, exports,
MATLAB v7.3, calibration plan, SE contact map, rim particles, dose, objects).

Minor: charts with BIC-only segmentation, empty-run errors, explicit OPEN_WITH, `lcsem export --list`, unknown formats
refused, video probing without full decode, TCYX documented, stack methods with JEOL sources warned and replaced by NLM,
bm3d hidden when not installed, relative project paths, lcsem version in projects, safe run names, glob escaping, Imaris
date from the file names, bounded prefetch and executor shutdown, closed files. Remaining minor items (asymmetric membranes
in the GUI, atomic curve-cache writes, stale export sub-folders) are listed for the next release.

## Reviewer 4 (usability)

**M1 Default calibration for movies.** Fixed as Reviewer 1 M2 (pre-flight plan, no default flat field, calibration shown
in the view and README). GUI.md has an acquisition checklist asking for a dark frame and an empty cell.

**M2 Unsafe silent defaults.** Fixed: bit depth from the file; pixel size must be entered; frame time filled from the file
with a message (and the interleaved factor), no silent 1 s (message when unknown); start time 00:00:00 (relative).
Monte Carlo progress in the GUI and BSE detector choice: documented / future.

**M3 File layouts.** Fixed: crop before splitting; *Preview first frame* shows each detector as it will be read; duplicate
frames detected with a suggested step; different movie lengths warned. Time offset between separate SE/BSE files: future.

**M4 False particles on rims, bubble areas 20 % low.** Fixed (Reviewer 1 M5, Reviewer 2 item 3).

**M5 SE contact map and objects (Otsu in gas-free frames, hidden 2000-px floor, "thin" = 20th percentile).** Fixed: new
contact map (Reviewer 1 M4); minimum area in um2 exposed in the GUI; "thin" objects need an explicit limit (removed from
the GUI list).

**M6 The display cannot be checked against the data.** Fixed: 2-D maps dock with the thickness map (colour bar, hover
readout of thickness +- error), the SE contact outline on the SE frame and the input frames with the detected particles,
following the time slider.

**M7 Trust indicators.** Fixed: calibration, dose and conventions in the view; unmeasured particles drawn differently;
SE-only volumes NaN with a note; class caveat; depth statistics from >= 5 particles with a note on the error model.

**M8 Robustness (empty selection hangs, re-run breaks, max liquid ignored).** Fixed (Reviewer 3 items 2 and 5); the
"max liquid shown" setting is passed to the 4-D model.

Minor: layout on small screens (scrollable tabs, no horizontal scroll bars), tooltips added on the new controls, frame
numbering explained, playback speed, chart saving, record movie (MP4/GIF), screenshot of the view only, light-yellow Au
(distinct from the gas orange by lightness), mode stated in the view; export how-tos (z exaggeration per program,
napari-ome-zarr, Fiji 3D Viewer channels, Blender units, TrackMate importer); Windows installation steps; `dipy` removed;
Python version corrected; VALIDATION_DENOISING.md written.

## Not changed, with reasons

* The flat top membrane convention is kept (the images measure the column, not how the membranes share the bulging); it is
  stated in the view, the docs and every export. A symmetric split is a one-line option for the future.
* Per-frame segmentation is kept for single images (its validated use in 0.2.1); for movies it is labelled and not shown by
  default until the series-wide model exists.
* The registration chain stays the default for movies with static features; the ROI and "none" cover the others.

# Round 2

All four reviewers checked the revision of round 1 against their major points and recommended minor revision
(`docs/reviews/reviewer1_physics_round2.md`, `reviewer2_imaging_round2.md`, `reviewer3_software_round2.md`,
`reviewer4_usability_round2.md`). Reviewer 2's round-2 report was written by a new instance of the reviewer (the first was
stopped before it finished), from the round-1 report and this response. Their new points and what was done:

## Reviewer 1 (physics and modelling), round 2 - minor revision, conditional on N1

**N1 The SE contact map collapsed when gas covers more than about half the field.** Fixed. The background of the SE is now
found in one of two ways (`lcsem.analysis._background`): if the distribution of the smoothed SE is bimodal (two peaks at
least twice the detection floor apart with a valley between them), the field is modelled as two surface states sharing one
smooth shading, s = B (1 + c g), fitted in log space to the whole field (a bias-field model with two classes, Wells et al.
1996) - B is then determined everywhere and not extrapolated from the wet part; otherwise the robust fit starts from the
brighter half as before and also ignores bright structure (a bump of thicker liquid no longer creates false contact
around it). Synthetic tests (12k-like contrast and noise, 5 % shading): discs covering 36-80 % and drying fronts covering
30-90 % of the field are found at 0.97-0.99 of their area with < 0.1 % false contact; gas-free frames (noise, shading,
bulging SE2, a +60 % bright bump) give 0 %. Limits: with less than 5 % of the field wet no background can be found (a
disc covering 96 % gives no contact), and SE texture beyond the 5 % floor in the wet region is taken for contact. Frames
with contact over half the field are flagged (`se_contact_flag`, and a CHECK line in the view). Real 12k series (frames
numbered from 0): frames 3, 4 and 7 now give 0.66, 0.55 and 0.43 contact (0.14, 0.16 and 0.12 before) - the large SE-dark
area is found as a whole - and are flagged (83, 70 and 53 % of the analysed field). Whether that area is gas at the top
membrane cannot be decided from the SE alone: under the assumed flat-field calibration of these data it is 18-30 nm thinner
than the SE-bright part in frames 3, 4 and 7, but 8-21 nm thicker in frames 5 and 6, where gas at the top should make it
thinner; a full-cell reference would decide it. The same frames exposed a second failure: the gap interpolated from the
small wet part gave -5.8 um3 of "gas" in frame 3. Frames in which the contact covers more than half of the field (or the
wet surroundings are under a quarter of it) now have no gas value (NaN, `gas_measured` in the maps) unless a full-cell
reference gives the gap. Test: `test_se_contact_map_high_coverage_and_drying_front`.

**N2 SE contrast below 5 % is not detected.** Fixed as requested: the detection floor is written in the view ("SE contact
detected where the SE is >= 5 % darker than the wet background (detection limit)"), in `summary.csv`
(`se_detection_floor`, `se_contrast`) and in METHODS section 7; the 60k series (about 3 % contrast) therefore shows no
contact.

**N3 Dose of averaged time points undercounted.** Fixed: a time point averaging W frames carries W frame fluences and its
cumulative dose runs to the end of its last frame (`lcsem.dose.table(n_raw=...)`; test `test_dose_of_averaged_time_points`).

**Leftovers.** `config.py` no longer defaults to a 200 nm flat field (`references.flat = None`; `lcsem run` with 'auto' and no
references now stops with the message of `calib.solve`); the `analytical_curve` docstring says the models are for comparison
only and why; the CHANGELOG no longer lists them as a feature.

**M2 (movie calibration in 'auto' untested).** Fixed: `simulate.make_movie` writes dark, empty-cell and full-cell reference
movies, reference movies are read with the movie's layout and crop, and a run in 'auto' with the dark and empty-cell movies
was validated: B0 = 30.01 (true 30), g = 599.8 (600); thickness bias 0.8 nm, MAE 9.0 nm, as with the true
parameters (0.5 / 8.9). With the full-cell reference as well, the gas volume is 0.95 of the truth
(without it 0.93). Test: `test_auto_calibration_from_reference_movies`.

**M3 gas volumes.** Each frame now has a statistical standard deviation of the gas volume (Reviewer 4, point 1); it does not
include the interpolation bias, which dominates without a gap map (0.93 of the truth on the new movie); the
full-cell reference reduces it (0.95 of the truth).

**M6 synthetic movie.** Regenerated with true Poisson noise (and reference movies); every validation number of this round
comes from the new movie. The depth path stays untested on movies: the synthetic movies are 8-bit and most particles
saturate (as in real 8-bit recordings); particle depth needs 16-bit data or a lower gain (it was validated on the 16-bit
synthetic JEOL series, docs/VALIDATION.md).

## Reviewer 2 (image processing and statistics), round 2 - minor revision

**New 1 The isolation test removed pairs and particles next to steps.** Fixed (`imageproc.detect_particles`): detection runs
from the finest scale up (a peak found at a scale is kept there; at coarse scales a particle next to a step merges with
it), and the ring test became a sector test on three rings (1, 1.5, 2 x max(2.5 sigma, 3 px)): a peak is rejected when a
ring reaches half of it on a long arc or on opposite sides (a ridge through it), kept when only one side does (a neighbour,
a nearby step). Recall of pairs 6-14 px apart 0.98-1.00 (was 0.00-0.03 at 8-10 px; 5 px: 0.6), particles 3-20 px inside a
25-grey step 1.00 (was 0-0.2), rims without particles 0 false detections per image (141 without the tests); on the new
synthetic movie recall 0.89 with 2 (of 215) false detections in 20 frames. Test: `test_particle_pairs_and_particles_at_steps_are_kept`.

**New 2 Skipping frames inflated the registration error.** Fixed: the drift of a movie is measured on every frame between
the first and the last time point and subsampled (`io_movie.register_movie`, used by the pipeline, the SE-only path and the
series denoising). Maximum error over 40 frames at a step of 4: BSE 2.2 px, SE 2.7 px on the regenerated movie (4.2 and 11.9
px when only the analysed frames are chained; on the first movie 2.8 and 5.7 px against 5.2 and 21 px) - the same as at
step 1. METHODS section 8 and the docstrings give these numbers; trajectories and object speeds are flagged as including the
registration error when no static region was given (`object_tracks.csv`, `drift_reference`; METHODS section 7).

**New 3 Series denoising on the common field of the whole movie.** Fixed: blocks of 32 time points, each aligned and
denoised on its own common field; pixels outside it are flagged (maps key `denoised`), and the run no longer stops when the
total drift exceeds the frame.

**New 4 The segmentation input was denoised twice.** Fixed: the segmentation's own NLM is skipped when the frames were
already denoised.

**New 5 Stale validation material.** Fixed: new movie (true Poisson, 360 x 480 px, side-by-side MP4 without padding), all runs repeated
with the final code (docs/VALIDATION.md, docs/VALIDATION_DENOISING.md); METHODS gives the sT coverage of round 2 (51-53 %);
the MP-PCA patch satisfies p^2 >= 4T (13 x 13 for 32 frames).

**Point 4 sT coverage.** Stated next to every +-: the maps' TIFF description, the hover readout and METHODS say that sT is a
lower bound, about 2.3x too small on synthetic movies. An empirical error from even/odd frames needs static scenes; not
added.

**Point 5 classes.** `segmentation_classes.csv` has `k_at_limit` (the criterion chose the largest k searched) and the chart
note says what it means; the classes chart stays off by default for movies.

**Point 7 benchmark scope / default denoiser.** Added end-to-end runs at a five times lower signal and a series method on the new movie
(docs/VALIDATION_DENOISING.md, section 2). The reviewer is right that the reported quantities barely depend on the denoiser:
at noise level 150, no denoising gives bias -0.3 / MAE 8.2 nm, NLM + VST 0.5 / 8.9, MP-PCA + VST 0.3 / 8.6, with identical
contact, particles and gas; at level 30, NLM + VST removes most of the noise-induced bias of the non-linear calibration
(-2.2 -> -0.5 nm) at the same MAE (12.3-12.4 nm). The unsupported claim ("denoising matters for segmentation, contact
edges") is removed; NLM + VST stays the default for the low-signal bias, and the docs say that "none" is as good at
moderate noise. A change-rate sweep, coloured noise, a real-data check (even/odd frames) and learned video denoisers remain
open (docs/VALIDATION_DENOISING.md, section 3).

**Point 8 noise model.** METHODS now states the fit bias on the benchmark data (slope 0.86-0.89 of the truth; < 0.4 grey after
the inverse) and that the model is unchecked on real data.

## Reviewer 3 (software engineering), round 2 - minor revision

**A SE-only JEOL series mixed the two SE detectors.** Fixed: the primary channel of a JEOL series is one detector - the first
of its listed signals present in the folder, i.e. the chosen SE detector (`io_jeol.group_scans`); the detector of every
frame is recorded (`summary.csv`, column `se_signal`) and the log notes when an SE + BSE series pairs different SE detectors
in different frames (test `test_se_only_jeol_uses_one_detector`). This applies to the K-kit 1 12k series itself: its SE is
the E-T (LED) image in frames 0-2 and the in-lens (UED) image in frames 3-8, so contact areas should be compared within
each group.

**B The close filter aborted the job before napari's confirmation.** Fixed: the event filter is gone; a running job is
registered with napari's task manager, so napari's own "Close window?" dialog lists it. Cancel leaves the job running;
accepting makes napari cancel the task, and our callback aborts the job and waits for its thread. Threads are never
terminated (test `test_close_asks_napari_and_aborts_only_when_accepted`).

**C NRRD and NIfTI mirrored in ITK.** Fixed: the NIfTI affine flips x and y (RAS), so ITK reads both formats on the same LPS
grid; the read-back check now compares the NIfTI origin and directions as well (EXPORT_FORMATS.md explains the view in RAS
viewers).

**D Runs of the two revisions indistinguishable.** Fixed without renaming the release the user asked for: every run
(`run_info.json`, key `build`) and project (`_lcsem_build`) records `lcsem.build_id()` = version + revision date + a hash
of the source files.

**Point 4, memory.** The estimate now includes series denoising (input, output and raw stacks and the denoiser's working set
on one 32-frame block) and is checked against the free memory before a GUI run starts (the run is refused if it cannot
fit, with what to reduce); series denoising works in 32-frame blocks; the histogram reads one frame, not the stack; movie
recording streams frames to the file; the QC figure shows at most 12 frames. Still kept in memory: all frames of a run
(stated; streaming the per-frame outputs remains future work).

**Point 7, packaging.** `license = "MIT"` with `license-files` (setuptools >= 77; the wheel builds without the warning),
Python >= 3.11 (napari 0.9 requires it; 3.11 tested). CITATION.cff: the authors, repository and DOI are to be filled in by
the authors at deposition (marked in the file). vtk-base without Qt on Windows/macOS: not testable here (stated).

**Point 8, tests.** Added: CLI (`test_cli_commands`: export --list, options, movie-info with the repeat step, export of a
run), close during a job, SE-only JEOL detector choice, the high-coverage SE contact, pairs and particles at steps, dose of
averaged frames, and a movie run in 'auto' with dark and empty-cell reference movies.

## Reviewer 4 (usability), round 2 - minor revision

**1 Negative gas volumes without an uncertainty.** Fixed: every frame has a statistical standard deviation of the gas volume
(`summary.csv` `gas_top_volume_sd_um3`: the scatter of the same sum where there is no gas, from the spatially correlated
residual of the wet surroundings - lcsem.analysis.sum_sd, within 6 % of simulation); chart (b) shows +-2 sd and draws
frames consistent with no gas as hollow points; the hover gives the value +- sd. The bias of the gap interpolation is not
in this sd (stated in the chart note and METHODS): record a full-cell reference for gas volumes.

**2 The pre-flight plan assumed the particles would work.** Fixed: when the calibration fails because no particle near the
top membrane could serve as the gain standard, the message says so and asks for an empty cell or an assumed flat field,
instead of asking for the dark frame already given.

**3 Suggested step capped at 40 frames.** Fixed: *Probe files* reads on (up to 10x) until it has seen complete runs of
repeated frames; a 20-frame repeat period now gives step 20; if no run completes, it says "at least N".

**4 The main warning in the view was cut off.** Fixed: the view text is wrapped at 92 characters per line.

**5 Wrong message in the SE-only 2-D maps.** Fixed: "no thickness channel recorded (SE only: nominal thickness)".

**Viewing a run wrote into the run folder.** Fixed: the 4-D model cache lives in a per-user cache folder
(`LCSEM_CACHE_DIR`, default `~/.cache/lcsem` or `%LOCALAPPDATA%\lcsem\cache`).

**M2 prefilled values not shown.** Fixed: before a run, the acquisition values it will use (kV, pixel size, membranes,
particle size, bit depth, frame time, frames, probe current) are listed with "check these values".

**M3 swapped halves run silently.** Addressed: a thickness map that is nearly constant or at the ends of the detector curve
over much of the field is reported in the log and `run_info.json` (`warnings`) with the likely causes (detector order,
layout, bit depth, calibration). A separator in the middle of the frame and a time offset between separate files: still
future work (stated).

**M7 error bands and axes from zero.** Gas: band as above; both volume charts now include zero. Liquid: the calibration
uncertainty is systematic (calibration_report.json) and not drawn.

**Movie path in 'auto' with real references.** The simulator now writes dark, empty-cell and full-cell reference movies,
and a run in 'auto' was validated end to end (see Reviewer 1, M2).

## Not changed in round 2, with reasons

* **An empirical random error from even/odd frames (Reviewer 2, point 4).** It needs static scenes; instead sT is labelled a
  lower bound, about 2.3x too small, wherever it is shown.
* **A series-wide segmentation model (Reviewer 2, point 5).** Frame-by-frame classes stay off by default for movies and are
  flagged (`k_at_limit`).
* **Memory: all frames of a run are still held (Reviewer 3, point 4).** Estimated, checked against the free memory before a
  GUI run, reduced for series denoising; streaming the per-frame outputs is future work.
* **Particle depth from 8-bit movies (Reviewer 1, M6).** Saturated particles get no depth; depth needs 16-bit data or a
  lower gain (stated in VALIDATION.md and GUI.md).
* **Liquid-volume error band (Reviewer 4, M7).** The liquid volume's uncertainty is dominated by the calibration
  (systematic, in `calibration_report.json`), not drawn as a band.
* **A separator in the middle of a side-by-side frame, a time offset between separate SE/BSE files (Reviewer 4, M3).** Future
  work; *Preview first frame* shows what is read.
* **CITATION.cff authors and DOI (Reviewer 3, point 7).** To be filled in by the authors at deposition.
* **vtk-base without Qt on Windows/macOS (Reviewer 3, point 7).** Not testable here.
