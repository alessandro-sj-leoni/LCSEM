# Validation of the denoisers (lcsem 0.3.0)

Question: which denoiser should be used for SEM movies of liquid cells, and does the choice change the results lcsem
reports? Answer in short: **for scenes that change (bubbles forming and moving, particles diffusing) use a per-frame
denoiser - BM3D + variance stabilisation (VST) is best, non-local means (NLM) + VST is within 5-25 % of it and 20x faster
(the default); for a static or slowly changing scene MP-PCA + VST is best.** The series methods (MP-PCA, SVD threshold,
temporal averaging) blur whatever changes within the frames they pool. For the quantities lcsem reports the choice matters
little (section 2): at the default smoothing of the thickness maps (15 px) the denoiser changes the thickness bias by at
most 2 nm and the mean error by less than 1 nm, and leaves the SE contact, the particles and the gas volumes unchanged.
NLM + VST stays the default because it removes most of the thickness bias that noise causes through the non-linear
calibration at low signal (-2.2 -> -0.5 nm at noise level 30); without denoising the result is as good at moderate noise.

## 1. Image-level benchmark

Scripts: `docs/scripts/bench_denoise.py` (results: `docs/denoise_benchmark.json`) and `docs/scripts/eval_movie_truth.py`. Data: synthetic SE + BSE movies from
`lcsem.simulate.make_movie` (24 frames of 240 x 320 px, 8 nm pixels, BSE from the Monte Carlo curve of a 15 kV BED-C
detector, 30 nm SiN membranes, bulging cell, gas pockets, 12 Au particles of 60 nm; Poisson-Gaussian noise: Poisson counts
of `dose` quanta per unit of detector signal plus Gaussian read noise of 4 grey levels, 8-bit). Two scenes: **changing**
(pockets grow and shrink, particles random-walk 1 px per frame) and **static** (no change except drift). Three noise levels
(`dose` 50, 150, 1000 quanta per unit signal - these set the signal-to-noise ratio, given as the PSNR of the raw frames;
they are not incident electron doses). Three independent movies (seeds) per case. Frames drift by whole pixels and are
registered with the true drift (the convention of `lcsem.io_movie.register_stack`), so no interpolation enters; scored over
the field imaged in every frame, away from 8-bit clipping, on the 6 middle frames (the series methods see all 24 frames).
Metrics: RMSE and mean error (bias) against the noise-free frames, SSIM (Z. Wang, A. C. Bovik, H. R. Sheikh, E. P. Simoncelli, IEEE Trans. Image Process. 13, 600-612 (2004)). VST: generalized Anscombe
transform with the noise model fitted to the first frame (`estimate_noise_model`), closed-form unbiased inverse.

**RMSE** (grey levels, mean ± SD over 3 noise realisations; lower is better)

| scene / noise level / detector | raw PSNR (dB) | none | Gaussian | TV | NLM | NLM + VST | BM3D + VST | temporal mean (5) | SVD-GD + VST | MP-PCA | MP-PCA + VST |
|---|---|---|---|---|---|---|---|---|---|---|---|
| changing / 50 / BSE | 17.7 | 33.07 ± 0.07 | 8.17 ± 0.02 | 5.68 ± 0.11 | 6.61 ± 0.11 | 5.82 ± 0.13 | **4.68 ± 0.10** | 16.98 ± 0.05 | 14.06 ± 0.14 | 11.03 ± 0.19 | 8.33 ± 0.09 |
| changing / 50 / SE | 27.7 | 10.47 ± 0.01 | 4.78 ± 0.00 | 1.60 ± 0.01 | 1.37 ± 0.00 | 1.16 ± 0.01 | **1.15 ± 0.01** | 8.33 ± 0.01 | 5.82 ± 0.01 | 3.12 ± 0.01 | 2.94 ± 0.01 |
| changing / 150 / BSE | 22.3 | 19.53 ± 0.02 | 6.38 ± 0.01 | 3.81 ± 0.13 | 4.08 ± 0.07 | 3.64 ± 0.08 | **3.27 ± 0.01** | 12.06 ± 0.08 | 10.49 ± 0.09 | 7.48 ± 0.13 | 6.14 ± 0.03 |
| changing / 150 / SE | 31.4 | 6.87 ± 0.01 | 4.54 ± 0.00 | 2.23 ± 0.09 | 0.91 ± 0.01 | 0.77 ± 0.00 | **0.71 ± 0.00** | 7.55 ± 0.00 | 4.18 ± 0.01 | 2.02 ± 0.01 | 1.97 ± 0.01 |
| changing / 1000 / BSE | 29.6 | 8.41 ± 0.01 | 5.44 ± 0.03 | 2.00 ± 0.03 | 1.96 ± 0.04 | 1.79 ± 0.03 | **1.74 ± 0.02** | 9.13 ± 0.09 | 5.92 ± 0.06 | 3.53 ± 0.04 | 3.27 ± 0.02 |
| changing / 1000 / SE | 35.0 | 4.56 ± 0.00 | 4.42 ± 0.00 | 1.49 ± 0.06 | 0.58 ± 0.00 | 0.52 ± 0.00 | **0.45 ± 0.00** | 7.19 ± 0.00 | 2.98 ± 0.00 | 1.33 ± 0.00 | 1.32 ± 0.00 |
| static / 50 / BSE | 17.1 | 35.42 ± 0.04 | 8.27 ± 0.03 | 5.77 ± 0.05 | 6.40 ± 0.05 | 5.81 ± 0.06 | 4.72 ± 0.03 | 15.86 ± 0.02 | 7.34 ± 0.02 | 4.47 ± 0.04 | **4.43 ± 0.03** |
| static / 50 / SE | 27.5 | 10.74 ± 0.02 | 4.57 ± 0.01 | 1.57 ± 0.01 | 1.26 ± 0.07 | 1.11 ± 0.03 | 1.15 ± 0.01 | 4.79 ± 0.01 | 2.23 ± 0.00 | 1.09 ± 0.01 | **1.09 ± 0.01** |
| static / 150 / BSE | 21.7 | 21.00 ± 0.03 | 6.19 ± 0.02 | 3.82 ± 0.06 | 4.05 ± 0.08 | 3.68 ± 0.07 | 3.30 ± 0.03 | 9.39 ± 0.02 | 4.31 ± 0.00 | 2.88 ± 0.04 | **2.82 ± 0.05** |
| static / 150 / SE | 31.2 | 7.01 ± 0.00 | 4.29 ± 0.00 | 1.80 ± 0.34 | 0.91 ± 0.01 | 0.75 ± 0.01 | 0.72 ± 0.01 | 3.13 ± 0.01 | 1.47 ± 0.00 | 0.72 ± 0.01 | **0.72 ± 0.01** |
| static / 1000 / BSE | 29.1 | 8.94 ± 0.00 | 5.01 ± 0.02 | 2.08 ± 0.10 | 1.99 ± 0.04 | 1.87 ± 0.03 | 1.79 ± 0.00 | 4.00 ± 0.01 | 1.85 ± 0.00 | 1.44 ± 0.00 | **1.42 ± 0.01** |
| static / 1000 / SE | 34.9 | 4.59 ± 0.00 | 4.17 ± 0.01 | 1.37 ± 0.17 | 0.56 ± 0.00 | 0.49 ± 0.00 | 0.48 ± 0.00 | 2.05 ± 0.00 | 0.99 ± 0.00 | 0.47 ± 0.00 | **0.47 ± 0.00** |

**SSIM** (mean over 3 realisations; higher is better)

| scene / noise level / detector | raw PSNR (dB) | none | Gaussian | TV | NLM | NLM + VST | BM3D + VST | temporal mean (5) | SVD-GD + VST | MP-PCA | MP-PCA + VST |
|---|---|---|---|---|---|---|---|---|---|---|---|
| changing / 50 / BSE | 17.7 | 0.131 | 0.727 | 0.882 | 0.815 | 0.898 | **0.934** | 0.286 | 0.444 | 0.746 | 0.801 |
| changing / 50 / SE | 27.7 | 0.401 | 0.938 | 0.988 | 0.984 | 0.992 | **0.996** | 0.699 | 0.764 | 0.942 | 0.950 |
| changing / 150 / BSE | 22.3 | 0.244 | 0.857 | 0.939 | 0.918 | 0.956 | **0.963** | 0.481 | 0.586 | 0.818 | 0.855 |
| changing / 150 / SE | 31.4 | 0.587 | 0.959 | 0.946 | 0.993 | 0.997 | **0.998** | 0.815 | 0.836 | 0.973 | 0.975 |
| changing / 1000 / BSE | 29.6 | 0.546 | 0.938 | 0.978 | 0.978 | **0.984** | 0.984 | 0.763 | 0.759 | 0.922 | 0.935 |
| changing / 1000 / SE | 35.0 | 0.755 | 0.969 | 0.975 | 0.998 | 0.998 | **0.999** | 0.880 | 0.898 | 0.988 | 0.988 |
| static / 50 / BSE | 17.1 | 0.108 | 0.699 | 0.872 | 0.827 | 0.890 | **0.929** | 0.287 | 0.599 | 0.919 | 0.918 |
| static / 50 / SE | 27.5 | 0.382 | 0.938 | 0.988 | 0.987 | 0.992 | **0.996** | 0.736 | 0.926 | 0.993 | 0.993 |
| static / 150 / BSE | 21.7 | 0.207 | 0.846 | 0.938 | 0.921 | 0.953 | **0.960** | 0.490 | 0.798 | 0.955 | 0.956 |
| static / 150 / SE | 31.2 | 0.574 | 0.962 | 0.966 | 0.992 | 0.997 | **0.998** | 0.864 | 0.967 | 0.997 | 0.997 |
| static / 1000 / BSE | 29.1 | 0.508 | 0.941 | 0.974 | 0.977 | **0.981** | 0.981 | 0.818 | 0.950 | 0.980 | 0.980 |
| static / 1000 / SE | 34.9 | 0.751 | 0.972 | 0.979 | 0.997 | 0.999 | **0.999** | 0.937 | 0.985 | 0.999 | 0.999 |

Mean error (bias) at the lowest dose: below 0.3 grey levels for every method with VST (for comparison, 1 grey level is
about 8 nm of liquid in the synthetic BSE frames).

Time per frame (240 x 320 px, 2 shared CPU cores): Gaussian 0.003 s, TV 0.03 s, MP-PCA 0.04 s, SVD-GD 0.13 s, NLM 0.19 s,
BM3D 3.8 s. A 1280 x 960 frame takes about 16x longer (BM3D about a minute).

**Reading the tables.**
* Changing scene: BM3D + VST has the lowest RMSE and highest SSIM in every case; NLM + VST follows (5-25 % higher RMSE);
  the series methods are 2-3x worse than NLM because they pool frames in which bubble edges and particles have moved.
* Static scene: MP-PCA (with or without VST) is best for the BSE channel and equal to BM3D for SE: it combines the frames
  and adapts spatially (PCA of patches x frames). SVD-GD reduces to the mean of all frames (its threshold removes every
  component of a static scene); the 5-frame temporal mean to the mean of 5.
* VST improves NLM (for example 6.6 -> 5.8 at the lowest BSE dose) and MP-PCA (11.0 -> 8.3 in the changing scene).

## 2. Effect on the reported quantities

Runs of the whole pipeline through the GUI project runner (`lcsem.gui.project.run_project`) on the regenerated synthetic
SE + BSE movie of `docs/VALIDATION.md` (second review round: 40 frames of 360 x 480 px, true Poisson noise, every 2nd
frame analysed, manual calibration with the true detector parameters, 60 nm particles), compared with the ground truth
(`truth_movie.npz`, each frame's truth shifted by its drift; `docs/scripts/eval_movie_truth.py`), at the noise level of
the benchmark (150) and at a five times lower signal (30):

| noise level | denoiser | thickness bias (nm) | thickness MAE (nm) | MAE > 12 px from gas rims (nm) | SE contact area / truth | contact IoU | particle recall | false particles | gas at the top / truth |
|---|---|---|---|---|---|---|---|---|---|
| 150 | none | -0.3 | 8.2 | 6.1 | 0.987 | 0.985 | 0.89 | 2 of 215 | 0.926 |
| 150 | NLM + VST (default) | 0.5 | 8.9 | 6.4 | 0.987 | 0.985 | 0.89 | 2 of 215 | 0.929 |
| 150 | MP-PCA + VST (blocks of 32) | 0.3 | 8.6 | 6.2 | 0.987 | 0.985 | 0.89 | 2 of 215 | 0.926 |
| 30 | none | -2.2 | 12.3 | 10.0 | 0.988 | 0.986 | 0.82 | 8 of 204 | 0.925 |
| 30 | NLM + VST (default) | -0.5 | 12.4 | 10.0 | 0.987 | 0.985 | 0.82 | 8 of 204 | 0.931 |
| 150 | SE only (NLM, side-by-side MP4) | - | - | - | 0.988 | 0.987 | - | - | - |

(liquid thickness 560-800 nm; the thickness errors are dominated by the 15-px smoothing of the calibration, which sets the
lateral resolution of the thickness maps - about 120 nm at 8 nm pixels - and by the rims of the gas pockets.) Particles are
detected and measured on the raw frames in every case (series-denoised frames are used for the thickness only), and the SE
contact map smooths the SE itself, so neither depends on the denoiser. The gas volume without a gap map is limited by the
interpolation of the gap (0.93 of the truth), not by noise. Before the fixes of 0.3.0 the SE contact area was 20 % too small
in SE + BSE runs (particle masks notched every bubble rim) and 68 % of the particle detections were false (bubble rims);
both are corrected (`lcsem.analysis.se_contact_map`, `lcsem.imageproc.detect_particles`, `docs/VALIDATION.md`).

Bubble growth (objects table, SE + BSE and SE only): 0.0758 and -0.0273 um2/s for the growing and the shrinking pocket
(truth 0.0758 and -0.0273).

## 3. What this benchmark does not cover

White noise only (real detectors can correlate noise along the fast-scan axis; BM3D accepts a noise power spectrum);
an idealised SE contrast (two levels) that favours NLM, BM3D and TV; one rate of change of the scene; no charging, beam
effects or detector drift (see `lcsem.simulate.make_movie`). Self-supervised and video-specific denoisers (Noise2Void,
DeepInterpolation, VBM4D) were not compared. On real movies, check the noise model with the temporal mean and variance of a
static region, and compare denoisers on a region you understand before choosing one.
