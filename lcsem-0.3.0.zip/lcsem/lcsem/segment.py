"""Per-frame unsupervised multimodal segmentation (option "segmentation"): features (liquid thickness at two scales,
non-local-means-denoised SE at two scales, |grad T|) -> z-score -> PCA -> Gaussian mixture in PC space, with the number of
classes chosen by ICL (separated phases) and by BIC (finer levels). Method and references in lcsem.multimodal (Pearson 1901;
Hotelling 1933; Dempster et al. 1977; Biernacki et al. 2000; Schwarz 1978; Buades et al. 2005 for the denoising).

This is the recipe of the K-kit 1 figure (fig7_PCA_GMM_segmentation): thickness denoised with non-local means (patch 7,
distance 11, h = 1.0 sigma) and pre-smoothed (4 px at >= 5 nm pixels, 6 px below), SE denoised with non-local means (patch 5,
distance 9, h = 0.9 sigma), fine/coarse scales 4/15 px (>= 5 nm pixels) or 8/25 px, fixed random seed.

Per frame it writes: class maps (-1 outside), class-probability stacks (float, one plane per class: continuous, not binary),
and one row per class for segmentation_classes.csv (area, SE level, thickness, gradient, overlap with the Otsu contact map,
plain-language tag). It runs inside `lcsem run` (on the primary thickness channel denoised and smoothed at the fine scale only), or afterwards on a
finished run with `lcsem segment run_dir`.
"""
from __future__ import annotations
import os, glob, json, numpy as np
from .multimodal import feature_stack, pca_gmm_segment, class_table, interpret, select_k_stability
from .imageproc import denoise_nlm, smooth_masked

def scales_for(px_nm, cfg_seg):
    if cfg_seg.get('fine_px') and cfg_seg.get('coarse_px'): return cfg_seg['fine_px'], cfg_seg['coarse_px']
    return (4, 15) if px_nm >= 5.0 else (8, 25)          # the scales used for the K-kit 1 12k / 60k figures

def segment_frame(T, se, valid, dark, px_nm, cfg_seg, seed=None, T_ready=False):
    """T_ready: T is already denoised and smoothed at the fine scale (as the pipeline passes it); otherwise it is denoised here"""
    ok = valid & np.isfinite(T) & np.isfinite(se)
    sk = int(cfg_seg.get('skip_rows') or 0)
    if sk: ok[:sk] = False
    if ok.sum() < 5000: return None
    seed = int(cfg_seg.get('seed', 0)) if seed is None else int(seed)
    se_dn = denoise_nlm(se, ~ok)[0] if cfg_seg.get('nlm', True) else se
    if T_ready or not cfg_seg.get('nlm', True): T_dn = T
    else:
        T_dn, _ = denoise_nlm(np.where(ok, T, np.nanmedian(T[ok])), ~ok, patch=7, distance=11, h_factor=1.0)
        T_dn = smooth_masked(T_dn, ~ok, 4.0 if px_nm >= 5.0 else 6.0)
    fine, coarse = scales_for(px_nm, cfg_seg)
    X, names, maps = feature_stack(T_dn, se_dn, ok, fine, coarse, fine)
    res = {}
    for crit in cfg_seg.get('criteria', ['icl', 'bic']):
        kr = tuple(cfg_seg.get('k_range', (2, 7))); st = None
        if int(cfg_seg.get('stability_runs') or 0) > 0 and crit in cfg_seg.get('stability_criteria', ['icl']):   # k = most frequent choice over subsamples
            st = select_k_stability(X, kr, n_fit=int(cfg_seg.get('stability_n_fit') or cfg_seg.get('n_fit', 80000)),   # same size as the final fit: ICL/BIC depend on n
                                     n_runs=int(cfg_seg['stability_runs']), criterion=crit, seed=seed)
            kr = (st['k'], st['k'])
        o = pca_gmm_segment(X, ok, k_range=kr, n_fit=int(cfg_seg.get('n_fit', 80000)), smooth_post=3.0, seed=seed, criterion=crit)
        rows, lab = class_table(o['labels'], maps['T_fine'], maps['SE_fine'], maps['gradT'], ok); rows = interpret(rows)
        # reorder the posterior planes to the thickness-ordered class numbers
        order = np.arange(o['k'])
        for c_old in range(o['k']):
            m = (o['labels'] == c_old) & (lab >= 0)
            if m.any(): order[c_old] = int(np.bincount(lab[m]).argmax())
        P = np.zeros_like(o['post_maps'])
        for c_old in range(o['k']): P[order[c_old]] = o['post_maps'][c_old]
        for r in rows: r['otsu_dark_frac'] = float(dark[(lab == r['cls']) & ok].mean()) if dark is not None and ((lab == r['cls']) & ok).any() else np.nan
        pc = np.full((2,) + T.shape, np.nan, np.float32); pc[0][ok] = o['scores_valid'][:, 0]; pc[1][ok] = o['scores_valid'][:, 1]
        k_max = int(tuple(cfg_seg.get('k_range', (2, 7)))[1])
        for r in rows:
            r['k_stability'] = (f"{st['freq'].get(o['k'], 0)}/{st['n']}" if st else '')
            r['k_choices'] = (' '.join(f'k{a}:{b}' for a, b in sorted(st['freq'].items())) if st else '')
            r['k_at_limit'] = bool(o['k'] >= k_max)       # the criterion chose the largest k searched: more structure than classes (review round 2)
        res[crit] = dict(labels=lab.astype(np.int16), prob=np.where(ok[None], P, np.nan).astype(np.float32), rows=rows, k=o['k'], explained=o['explained'],
                         loadings=o['loadings'], pc=pc, names=names, valid=ok, ic=o.get(crit, o.get('bic')), stability=st)
    return res

def write_prob_stack(fn, arr, px, info=''):
    import tifffile
    tifffile.imwrite(fn, np.asarray(arr, np.float32), imagej=True, resolution=(1.0 / px[0], 1.0 / px[1]), metadata={'unit': 'nm', 'axes': 'ZYX', 'Info': info}, compression='zlib')

def write_frame(out_dir, tag, seg, px, frame, time_str):
    """writes the per-frame outputs; returns the rows for segmentation_classes.csv"""
    from .volume import write_map_tiff
    rows = []
    for crit, sres in seg.items():
        write_map_tiff(os.path.join(out_dir, tag + f'_classes_{crit}.tif'), sres['labels'].astype(np.float32), px, f'PCA+GMM classes ({crit.upper()}), ordered by thickness; -1 outside')
        write_prob_stack(os.path.join(out_dir, tag + f'_class_prob_{crit}.tif'), sres['prob'], px, f'PCA+GMM class probabilities ({crit.upper()}), one plane per class')
        np.save(os.path.join(out_dir, tag + f'_class_prob_{crit}.npy'), sres['prob'])
        for r_ in sres['rows']:
            rows.append(dict(frame=frame, time=time_str, criterion=crit, k=sres['k'], **{k_: (float(v_) if isinstance(v_, (np.floating, float)) else v_) for k_, v_ in r_.items()}))
    return rows

def pick_frames(n, cfg_seg):
    if cfg_seg.get('figure_frame_list'): return set(int(i) for i in cfg_seg['figure_frame_list'] if int(i) < n)
    nfig = int(cfg_seg.get('figure_frames', 4)); return set(np.unique(np.linspace(0, n - 1, min(nfig, n)).round().astype(int)).tolist())

def overview_figure(items, fn, px=None):
    """PCA + GMM overview in the style of the K-kit 1 figure: PC1, PC2 maps, ICL classes (+ Otsu contact), BIC levels, PC1-PC2 scatter, class list"""
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    from matplotlib.colors import ListedColormap, LinearSegmentedColormap
    BG, INK, INK2, MUTED, AX = '#1a1a19', '#ffffff', '#c3c2b7', '#898781', '#383835'
    CAT = ['#3987e5', '#d95926', '#199e70', '#c98500', '#d55181', '#008300', '#9085e9', '#e66767']
    DIV = LinearSegmentedColormap.from_list('d', ['#1c5cab', '#3987e5', '#383835', '#e66767', '#b83a3a'])
    n = len(items); RH = 3.5; Hf = RH * n + 1.2; fig = plt.figure(figsize=(19.2, Hf), facecolor=BG)
    fig.text(0.012, 1 - 0.35 / Hf, 'PCA of the joint thickness + SE feature space and unsupervised Gaussian-mixture segmentation', fontsize=16, weight='semibold', color=INK, va='center')
    fig.text(0.012, 1 - 0.75 / Hf, 'Features per pixel: liquid thickness at two scales, denoised SE at two scales, |grad T|; z-scored; PCA; Gaussian mixture in PC space. '
             'Classes by ICL (separated phases) and by BIC (finer levels).', fontsize=10, color=INK2, va='center')
    for j, it in enumerate(items):
        oi, ob = it['seg'].get('icl'), it['seg'].get('bic'); base = oi or ob; valid = base['valid']; H = RH / Hf; y0 = 1 - (1.1 / Hf) - (j + 1) * H + 0.02 * H
        axs = [fig.add_axes([x, y0, 0.155, H * 0.86]) for x in (0.012, 0.175, 0.338, 0.501)]
        for ax in axs: ax.set_xticks([]); ax.set_yticks([]); ax.set_facecolor('#0d0d0d'); [sp.set_color(AX) for sp in ax.spines.values()]
        for k in range(2):
            v = base['pc'][k]; lim = np.nanpercentile(np.abs(v), 98); axs[k].imshow(v, cmap=DIV, vmin=-lim, vmax=lim)
            ld = base['loadings'][k]; axs[k].set_title(f'PC{k+1} ({100*base["explained"][k]:.0f} %): T {0.5*(ld[0]+ld[1]):+.2f}  SE {0.5*(ld[2]+ld[3]):+.2f}  grad {ld[4]:+.2f}', color=INK2, fontsize=8.5, loc='left')
        if oi:
            lab = np.where(oi['labels'] >= 0, oi['labels'], np.nan); axs[2].imshow(lab, cmap=ListedColormap(CAT[:oi['k']]), vmin=-0.5, vmax=oi['k'] - 0.5, interpolation='nearest')
            if it.get('dark') is not None: axs[2].contour(it['dark'].astype(float), [0.5], colors='w', linewidths=0.6)
            axs[2].set_title(f'ICL: k = {oi["k"]}' + (f' ({oi["stability"]["freq"].get(oi["k"], 0)}/{oi["stability"]["n"]} subsamples)' if oi.get('stability') else '') + '; white = SE contact', color=INK2, fontsize=8.5, loc='left')
        if ob:
            lab = np.where(ob['labels'] >= 0, ob['labels'], np.nan); axs[3].imshow(lab, cmap='Blues', vmin=-0.5, vmax=ob['k'] - 0.5, interpolation='nearest')
            axs[3].set_title(f'BIC: k = {ob["k"]} levels' + (f' ({ob["stability"]["freq"].get(ob["k"], 0)}/{ob["stability"]["n"]})' if ob.get('stability') else '') + ' by thickness', color=INK2, fontsize=8.5, loc='left')
        axsc = fig.add_axes([0.685, y0 + 0.12 * H, 0.145, H * 0.64], facecolor=BG)
        if oi:
            pc1, pc2, lab = oi['pc'][0][valid], oi['pc'][1][valid], oi['labels'][valid]; ok_ = np.isfinite(pc1) & (lab >= 0)
            rng = np.random.default_rng(0); idx = rng.choice(np.flatnonzero(ok_), min(40000, ok_.sum()), replace=False)
            for c in range(oi['k']): mm = lab[idx] == c; axsc.scatter(pc1[idx][mm], pc2[idx][mm], s=1, color=CAT[c % 8], alpha=0.25, rasterized=True)
        axsc.set_xlabel('PC1', fontsize=8, color=INK2); axsc.set_ylabel('PC2', fontsize=8, color=INK2); axsc.tick_params(labelsize=7, colors=MUTED)
        [axsc.spines[sp].set_visible(False) for sp in ('top', 'right')]; axsc.set_title(f'frame {it["frame"]}  {it["time"]}', color=INK, fontsize=10, loc='left')
        axt = fig.add_axes([0.845, y0, 0.15, H * 0.80]); axt.axis('off')
        for q, r in enumerate(base['rows']):
            axt.text(0.0, 0.95 - q * 0.14, '■', color=CAT[r['cls'] % 8], fontsize=12, transform=axt.transAxes, va='top')
            axt.text(0.12, 0.95 - q * 0.14, f'{100*r["area_frac"]:.0f} % | SE {r["se_mean"]:.0f} | {r["T_median"]:.0f} nm\n|grad T| {r["grad_median"]:.1f} | Otsu-dark {r.get("otsu_dark_frac", float("nan")):.2f}\n{r["tag"]}',
                     color=INK2, fontsize=8, transform=axt.transAxes, va='top')
    fig.savefig(fn, dpi=90, facecolor=BG); plt.close(fig)

def segment_run(run_dir, cfg_seg=None, log=print, frames=None, csv_name='segmentation_classes.csv', figure=True):
    """(re)compute the segmentation of a finished run from its *_maps.npz files (thickness, SE, masks), e.g. with other options"""
    import pandas as pd
    info = json.load(open(os.path.join(run_dir, 'run_info.json'))); cfg = info['config']; px = tuple(cfg['pixel_nm'])
    from .config import DEFAULTS
    cs = dict(DEFAULTS['segmentation']); cs.update(cfg.get('segmentation') or {}); cs.update(cfg_seg or {}); name = cfg.get('name', 'series')
    for k_ in ('stability_runs', 'stability_n_fit'):                    # runs made before these options existed
        if k_ not in (cfg.get('segmentation') or {}) and k_ not in (cfg_seg or {}): cs[k_] = DEFAULTS['segmentation'][k_]
    files = sorted(glob.glob(os.path.join(run_dir, f'{name}_*_maps.npz'))); S = pd.read_csv(os.path.join(run_dir, 'summary.csv'))
    pick = pick_frames(len(files), cs); rows, items = [], []
    for i, fn in enumerate(files):
        if frames is not None and i not in frames: continue
        m = np.load(fn); tag = os.path.basename(fn)[:-9]
        se_keys = [k for k in m.files if k.startswith('se_')]
        if not se_keys: log(f'  frame {i}: no SE channel, skipped'); continue
        valid = m['valid'] & ~m['au']; t_str = str(S.loc[i, 'time_end']) if i < len(S) else ''
        Tin, ready = (m['T_seg'], True) if 'T_seg' in m.files else (m['T'], False)
        seg = segment_frame(Tin, m[se_keys[0]], valid, m['dark'], px[0], cs, T_ready=ready)
        if not seg: log(f'  frame {i}: too few valid pixels'); continue
        rows += write_frame(run_dir, tag, seg, px, i, t_str)
        log(f'  frame {i} {t_str}: ' + ', '.join(f'{c.upper()} k = {v["k"]}' for c, v in seg.items()))
        if i in pick: items.append(dict(frame=i, time=t_str, seg=seg, dark=m['dark']))
    if rows: pd.DataFrame(rows).to_csv(os.path.join(run_dir, csv_name), index=False)
    if items and figure: overview_figure(items, os.path.join(run_dir, 'segmentation_overview.png'))
    return rows

def overview_only(run_dir, frames, cfg_seg=None, fn=None, log=print):
    """recompute the segmentation of a few frames of a finished run and draw only the overview figure (no files rewritten)"""
    import pandas as pd
    from .config import DEFAULTS
    info = json.load(open(os.path.join(run_dir, 'run_info.json'))); cfg = info['config']; px = tuple(cfg['pixel_nm'])
    cs = dict(DEFAULTS['segmentation']); cs.update(cfg.get('segmentation') or {}); cs.update(cfg_seg or {}); name = cfg.get('name', 'series')
    files = sorted(glob.glob(os.path.join(run_dir, f'{name}_*_maps.npz'))); S = pd.read_csv(os.path.join(run_dir, 'summary.csv')); items = []
    for i in frames:
        m = np.load(files[i]); se_keys = [k for k in m.files if k.startswith('se_')]
        if not se_keys: continue
        Tin, ready = (m['T_seg'], True) if 'T_seg' in m.files else (m['T'], False)
        seg = segment_frame(Tin, m[se_keys[0]], m['valid'] & ~m['au'], m['dark'], px[0], cs, T_ready=ready)
        if seg: items.append(dict(frame=i, time=str(S.loc[i, 'time_end']), seg=seg, dark=m['dark'])); log(f'  frame {i}: ICL k = {seg["icl"]["k"] if "icl" in seg else "-"}')
    overview_figure(items, fn or os.path.join(run_dir, 'segmentation_overview.png')); return items
