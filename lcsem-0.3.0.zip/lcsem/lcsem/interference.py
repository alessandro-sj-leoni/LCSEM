"""Removal of scan-synchronous periodic interference (mains/inverter pickup) from slow-scan SEM frames.

Pickup at a fixed frequency appears in a raster image as a plane wave whose pixel period does not depend on the
magnification. Two treatments:
  * short periods (< `long_period` px): narrow FFT notches at the detected peaks (standard periodic-noise filtering,
    Gonzalez & Woods, Digital Image Processing, ch. 5).
  * long periods: the wave is fitted in sliding row windows; it is subtracted only if its amplitude is constant and its phase
    drifts linearly over the whole frame (the signature of a stationary oscillator). Localized real structure fails that
    test and is kept. This avoids the classic notch-filter artefact of removing real features that share a spatial frequency.
Use `deinterfere(image, valid_mask)`; the returned log lists every peak with period, strength and what was done."""
import numpy as np
from scipy import ndimage as ndi
def find_peaks(a, mask, pmin=25, pmax=1000, k_sigma=5.0, nmax=30, radius=1):
    mu=a[mask].mean(); a0=np.where(mask,a-mu,0)
    win=np.outer(np.hanning(a.shape[0]),np.hanning(a.shape[1]))
    P=np.abs(np.fft.fft2(a0*win))**2
    ky=np.fft.fftfreq(a.shape[0])[:,None]; kx=np.fft.fftfreq(a.shape[1])[None,:]; kr=np.hypot(ky,kx)
    band=(kr>1/pmax)&(kr<1/pmin)&(kx>0)
    med=np.median(P[band]); mad=np.median(np.abs(P[band]-med))*1.4826; thr=med+k_sigma*mad
    Pw=np.where(band,P,0); yy,xx=np.ogrid[:a.shape[0],:a.shape[1]]; peaks=[]
    for _ in range(nmax):
        i=np.unravel_index(np.argmax(Pw),Pw.shape)
        if Pw[i]<thr: break
        peaks.append(dict(kx=float(kx[0,i[1]]),ky=float(ky[i[0],0]),period=float(1/kr[i]),strength=float(Pw[i]/med),iy=int(i[0]),ix=int(i[1])))
        d=np.hypot(((yy-i[0]+a.shape[0]//2)%a.shape[0])-a.shape[0]//2, ((xx-i[1]+a.shape[1]//2)%a.shape[1])-a.shape[1]//2); Pw[d<=radius]=0
    return peaks
def wave_test_and_fit(a, mask, kx, ky, win_rows=24, step=12):
    """sliding-window complex amplitude of a plane wave; a stationary pickup has a constant amplitude and a linearly
    drifting phase over the whole frame; localized real structure does not. Returns (is_stationary, model, info)."""
    H,W=a.shape; X=np.arange(W)[None,:]; Y=np.arange(H)[:,None]
    ph=2*np.pi*(kx*X+ky*Y); C=np.cos(ph); S=np.sin(ph); mu=np.median(a[mask])
    rows=[]; A=[]
    for y0 in range(0,H-win_rows+1,step):
        sl=slice(y0,y0+win_rows); m=mask[sl]
        if m.sum()<2000: continue
        r=(a[sl]-mu)[m]; cc=C[sl][m]; ss=S[sl][m]
        coef,*_=np.linalg.lstsq(np.c_[cc,ss],r,rcond=None)
        rows.append(y0+win_rows/2); A.append(coef[0]-1j*coef[1])
    rows=np.array(rows); A=np.array(A); amp=np.abs(A)
    bad=dict(amp=0.0,cv=9.0,phase_rms=9.0,ok=0.0,span=0.0)
    if len(A)<8: return False, np.zeros_like(a), bad
    ok=amp<=np.percentile(amp,60)            # least-contaminated windows
    med=float(np.median(amp[ok])); mad=float(np.median(np.abs(amp[ok]-med))*1.4826+1e-6)
    phase=np.unwrap(np.angle(A[ok])); p=np.polyfit(rows[ok],phase,1); resid=phase-np.polyval(p,rows[ok])
    span=float((rows[ok].max()-rows[ok].min())/H)
    stationary=bool((med>0.35) and (mad/med<0.4) and (np.std(resid)<0.5) and (span>0.5))
    phi=np.polyval(p,Y.astype(float))
    model=(med*np.cos(ph+phi)).astype(np.float32) if stationary else np.zeros_like(a)
    return stationary, model, dict(amp=med,cv=mad/med,phase_rms=float(np.std(resid)),ok=float(ok.mean()),span=span)
def deinterfere(im, mask, passes=2, long_period=170, pmax=1000):
    a=im.astype(np.float32).copy(); log=[]
    for p in range(passes):
        peaks=find_peaks(a,mask,pmax=pmax,radius=3)
        if not peaks: break
        for pk in peaks:
            if pk['period']>=long_period:
                st,model,info=wave_test_and_fit(a,mask,pk['kx'],pk['ky'])
                if st: a=a-model
                log.append((p,round(pk['period']),round(pk['strength']),'wave' if st else 'kept',round(info['amp'],2),round(info['cv'],2),round(info['phase_rms'],2)))
            else:
                yy,xx=np.ogrid[:a.shape[0],:a.shape[1]]; mu=a[mask].mean(); G=np.fft.fft2(np.where(mask,a-mu,0)); keep=np.ones(a.shape,bool)
                for (iy,ix) in [(pk['iy'],pk['ix']),((-pk['iy'])%a.shape[0],(-pk['ix'])%a.shape[1])]:
                    d=np.hypot(((yy-iy+a.shape[0]//2)%a.shape[0])-a.shape[0]//2, ((xx-ix+a.shape[1]//2)%a.shape[1])-a.shape[1]//2); keep&=~(d<=3)
                a=(np.real(np.fft.ifft2(np.where(keep,G,0)))+mu).astype(np.float32); log.append((p,round(pk['period']),round(pk['strength']),'notch'))
    return a, log
