"""Configuration: defaults, merging, validation and the option matrix.

A run is described by one JSON file. Everything has a default except the data folder and the pixel size. The options
that change what is measured are:

  channels     which detectors were recorded and what each is used for
                 BSE  (thickness)   annular BSE detector, e.g. JEOL BED-C
                 STEM (thickness)   transmission detector below the cell (BF/ADF), optional
                 SE   (contact)     in-lens (UED) and/or Everhart-Thornley (LED) secondary electrons, optional
  references   extra acquisitions that fix the detector response instead of assuming it
                 dark        beam blanked (or Faraday cup) frames with the same detector settings -> black level (offset)
                 empty       an empty (dry) K-kit with the same settings                       -> signal at T = 0 -> gain
                 full        this cell completely filled, before any gas forms                  -> local gap map h(x, y)
                 flat        frames whose flat field has an assumed thickness (legacy)          -> black level
                 particles   Au standards of known size in the field                            -> gain (and a check)
                 current     probe current per frame (Faraday cup / log)                        -> dose normalization
  calibration  'auto' picks the best-determined model from the references present and reports the redundant ones as
               consistency checks; or force: dark+empty, dark+particles, particles+flat, two_references, manual
  depth        particle depth estimators: core_fraction (one detector, one kV), channel_ratio (BSE/STEM from one scan),
               energy_ratio (frames at two kV), stereo (tilt pairs)
"""
from __future__ import annotations
import json, copy, warnings, os

DEFAULTS = dict(
    name='series',
    folder=None, prefix='', select={},
    pixel_nm=None,
    bits=8,                        # image bit depth: 8 (0-255, clipping handled) or 16; record 16-bit if you can
    beam=dict(kV=None, current_pA=None, current_csv=None),            # kV None: read from metadata (CM_ACCEL_VOLT)
    cell=dict(membranes_nm=[30.0, 30.0], channel_nm=None, liquid='H2O', membrane='SiN'),
    channels=dict(
        BSE=dict(signal='BED_C', role='thickness', detector='BEDC'),
        SE=dict(signal=['UED', 'LED'], role='contact'),
        STEM=None,                                                     # e.g. dict(signal='STEM', role='thickness', detector=dict(kind='stem', mrad=[0, 100]))
    ),
    pair_window_s=10.0,
    references=dict(dark=None, empty=None, full=None, flat=None, particles=dict(diameter_nm=38.0, cv=None, material='Au'),    # flat: dict(frames='all', T_nm=...) = an ASSUMED flat field, no default
                    current=None),
    calibration=dict(mode='auto', per_frame_gain=True, gain_change_threshold=0.25, use_particles=True),
    curves={},                     # {'BSE': 'file.json', 'STEM': ...}; missing ones are generated with the Monte Carlo and cached
    mc=dict(n=300000, cache_dir=None, water_nm=[0, 25, 50, 100, 150, 200, 300, 400, 500, 700, 1000, 1500]),
    frame_edge=False, frame_edge_margin_px=12,
    particles=dict(sigma_min=1.5, sigma_max=6.0, threshold=6.0, aperture_px=12, annulus_px=[16, 28], mask_extra_px=6),
    smooth_sigma_px=15, nlm=False, deinterfere=False, deinterfere_pmax=170,
    frame_time=dict(fast_s=3.2, slow_s=30.0, sigma_split=40.0),
    skip_rows=200,
    se=dict(sigma_px=6, min_area_um2=0.01, min_area_px=None, open_iter=3, k_sigma=5.0, min_contrast=0.05, film_threshold_nm=5.0, combine='any'),
    gas=dict(other_threshold_nm=30.0),          # SE-bright pixels with gap - T above this are gas not touching the top membrane (needs a gap map)
    fusion=dict(thickness='inverse_variance'),
    depth=dict(methods=['core_fraction'], tables=None, pixel_blur_nm=2.0, curve=None),   # curve: separate Monte Carlo file for the depth models
    segmentation=dict(enabled=True, criteria=['icl', 'bic'], nlm=True, k_range=[2, 7], n_fit=80000, fine_px=None, coarse_px=None, seed=0,
                      stability_runs=5, stability_n_fit=None, stability_criteria=['icl'], skip_rows=0, figure_frames=4, figure_frame_list=None),   # skip_rows: first scan lines left out (e.g. a transient at the frame start)
    amira=dict(enabled=False, bin=4, dz_nm=10.0),
    tracking=dict(enabled=True, max_disp_nm=250.0, max_gap=1),
    dynamics=dict(enabled=True),
    volume=dict(dz_nm=5.0, write=True, write_4d=True, bin=1, T_cap_nm=1500.0),
    drift_csv=None, reference_frame=-1, max_drift_px=600,
    reference_frames='all',
)

LEGACY = {  # v0.1 keys -> v0.2
    'bse_signal': ('channels', 'BSE', 'signal'), 'se_signals': ('channels', 'SE', 'signal'),
    'curve': ('curves', 'BSE'), 'particle_diameter_nm': ('references', 'particles', 'diameter_nm'),
}

def _merge(a, b):
    for k, v in b.items():
        if isinstance(v, dict) and isinstance(a.get(k), dict): _merge(a[k], v)
        else: a[k] = copy.deepcopy(v)
    return a

def load_config(path_or_dict):
    cfg = json.load(open(path_or_dict)) if isinstance(path_or_dict, str) else copy.deepcopy(path_or_dict)
    out = copy.deepcopy(DEFAULTS)
    # legacy v0.1 configuration keys
    for old, path in LEGACY.items():
        if old in cfg:
            v = cfg.pop(old); d = cfg
            for p in path[:-1]: d = d.setdefault(p, {})
            d[path[-1]] = v
    if 'volume' in cfg and 'membrane_nm' in cfg['volume']: cfg.setdefault('cell', {})['membranes_nm'] = cfg['volume'].pop('membrane_nm')
    if 'calibration' in cfg and cfg['calibration'].get('reference_T_nm') is not None:
        cfg.setdefault('references', {}).setdefault('flat', {})['T_nm'] = cfg['calibration'].pop('reference_T_nm')
    if 'reference_frames' in cfg: cfg.setdefault('references', {}).setdefault('flat', {})['frames'] = cfg['reference_frames']
    _merge(out, cfg)
    if isinstance(path_or_dict, str): out['_config_dir'] = os.path.dirname(os.path.abspath(path_or_dict))
    validate(out)
    return out

def validate(cfg):
    if not cfg.get('folder'): raise ValueError('config: "folder" (image folder) is required')
    if not cfg.get('pixel_nm') or len(cfg['pixel_nm']) != 2: raise ValueError('config: "pixel_nm": [x, y] in nm is required (measure it with a grating)')
    ch = cfg['channels']
    th = [k for k, v in ch.items() if v and v.get('role') == 'thickness']
    se_only = str(cfg.get('mode', '')).replace(' ', '').lower() == 'seonly'
    if not th and not se_only: raise ValueError('config: at least one channel with role "thickness" (BSE or STEM) is needed (or mode "SE only")')
    if se_only and not ch.get('SE'): raise ValueError('config: mode "SE only" needs the SE channel')
    mode = cfg['calibration']['mode']
    if mode not in ('auto', 'dark+empty', 'dark+particles', 'particles+flat', 'two_references', 'manual', 'dark+flat', 'empty+particles'):
        raise ValueError(f'config: unknown calibration mode {mode}')
    for m in cfg['depth']['methods']:
        if m not in ('core_fraction', 'channel_ratio', 'energy_ratio', 'stereo'): raise ValueError(f'config: unknown depth method {m}')
    if 'channel_ratio' in cfg['depth']['methods'] and not (ch.get('STEM') and ch.get('BSE')):
        warnings.warn('depth method channel_ratio needs both BSE and STEM channels; it will be skipped')
    return True

OPTION_MATRIX = [
    # (option, what you need to record, what it gives, without it)
    ('BSE channel', 'annular BSE detector (BED-C) images', 'liquid thickness in the column; particle photometry and depth (core fraction)', 'required unless STEM is used'),
    ('STEM channel', 'transmission detector below the cell, recorded in the same scan', '10-60x more thickness information per electron for T < ~500 nm; BSE/STEM ratio -> particle depth from one scan; independent check of the BSE thickness', 'BSE only'),
    ('SE channel(s)', 'in-lens (UED) and/or E-T (LED) SE in the same scan', 'where gas touches the top membrane (contact map) -> gas placed at the top', 'gas cannot be placed vertically'),
    ('dark reference', 'frames with the beam blanked (same detector settings)', 'black level measured, not assumed', 'black level from the flat-field assumption or a second reference'),
    ('empty reference', 'an empty (dry) K-kit at the same kV, current and detector settings', 'signal at T = 0 -> gain without particles; with dark: fully instrument-calibrated thickness', 'gain from particles'),
    ('full reference', 'this cell completely filled (before gas forms)', 'local gap h(x, y) incl. membrane bulging -> total gas = h - T, also gas that does not touch the top membrane', 'gap assumed uniform (median of the wet region)'),
    ('particle standard', 'isolated Au spheres of certified size in the field', 'gain (internal standard) and a consistency check of the Monte Carlo detector model', 'gain from empty+dark references'),
    ('probe current', 'Faraday-cup reading or current log per frame', 'frames at different currents on one scale; dose per frame', 'constant current assumed'),
    ('two kV', 'frames at a second beam energy (e.g. 8-10 kV) between main frames', 'particle depth from the energy ratio', 'core fraction / channel ratio only'),
    ('tilt pairs', 'frames at +/- a few degrees stage tilt', 'particle depth from parallax', '-'),
]

def option_table_markdown():
    rows = ['| option | record | gives | without it |', '|---|---|---|---|']
    rows += [f'| {a} | {b} | {c} | {d} |' for a, b, c, d in OPTION_MATRIX]
    return '\n'.join(rows)
