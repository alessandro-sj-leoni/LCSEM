"""Detector calibration: grey level -> liquid thickness, for any thickness channel (BSE or STEM).

Model (per channel):   grey = B0 + g * S(T)
  S(T)  Monte Carlo signal per primary electron of that detector for liquid thickness T in the cell (lcsem.mc.curves)
  B0    black level (detector offset), g gain (grey per unit signal per primary; proportional to probe current x dwell)
The two constants are fixed by whatever references were recorded, in this order of preference ('auto' mode):
  dark + empty       B0 = beam-blanked level; g = (empty-cell level - B0) / S(0)         (instrument calibration)
  dark + particles   B0 = dark; g = particle excess / Monte Carlo excess                  (internal standard)
  empty + particles  g from particles; B0 = empty level - g S(0)
  particles + flat   g from particles; B0 from a flat field of assumed thickness          (v0.1 behaviour)
  dark + flat        B0 = dark; g from the flat field of assumed thickness
  two_references     two regions of known thickness
Every reference that is present but not used by the chosen model is turned into a consistency check (e.g. with dark +
empty + particles, the particle excess predicted by the Monte Carlo is compared with the measured one: this tests the
detector model itself). Using a known-signal internal standard follows quantitative BSE practice [Lloyd, Mineral. Mag. 51,
3 (1987)]; aperture photometry [Howell, PASP 101, 616 (1989)].
"""
from __future__ import annotations
import json, numpy as np
from scipy.optimize import brentq

class ChannelCurve:
    """S(T), its inverse and slope, the per-primary second moment, and the particle-standard excess for one detector.
    Reads v2 curve files (lcsem.mc.curves.make_curve; pick the detector by label) and v0.1 files."""
    def __init__(self, path_or_dict, detector=None):
        d = json.load(open(path_or_dict)) if isinstance(path_or_dict, str) else path_or_dict
        self.meta = d; self.T = np.asarray(d['water_nm'], float)
        if d.get('version', 1) >= 2:
            det = detector or list(d['detectors'])[0]; q = d['detectors'][det]; self.detector = det
            self.S = np.asarray(q['S'], float); self.m2 = np.asarray(q['m2'], float)
            self.particle = d.get('particle'); self.legacy_particle = None
        else:
            self.detector = 'BEDC'; self.S = np.asarray(d['S'], float); self.m2 = None; self.particle = None; self.legacy_particle = d.get('particle')
        self.sign = 1.0 if self.S[-1] >= self.S[0] else -1.0            # BSE rises with T, transmission falls
        self.slope_end = (self.S[-1] - self.S[-2]) / (self.T[-1] - self.T[-2])
    @property
    def E0(self): return self.meta.get('E0_keV', 15.0)
    def S_of_T(self, T):
        T = np.asarray(T, float); s = np.interp(T, self.T, self.S)
        return np.where(T > self.T[-1], self.S[-1] + (T - self.T[-1]) * self.slope_end, s)
    def T_of_S(self, S):
        S = np.asarray(S, float); x, y = (self.S, self.T) if self.sign > 0 else (self.S[::-1], self.T[::-1])
        # S(T) can saturate: invert on the monotonic part only
        keep = np.r_[True, np.diff(x) > 0]; x, y = x[keep], y[keep]
        t = np.interp(S, x, y)
        if self.slope_end != 0:
            beyond = (S > self.S[-1]) if self.sign > 0 else (S < self.S[-1])
            t = np.where(beyond, self.T[-1] + (S - self.S[-1]) / self.slope_end, t)
        return np.clip(t, 0, None)
    def dS_dT(self, T):
        g = np.gradient(self.S, self.T); return np.interp(np.asarray(T, float), self.T, g)
    def m2_of_T(self, T):
        return np.interp(np.asarray(T, float), self.T, self.m2) if self.m2 is not None else np.full(np.shape(T), np.nan)
    # ---------------- particle standard ----------------
    def particle_rows(self, depth=None):
        if not self.particle: return []
        return [p for p in self.particle['profiles'] if depth is None or p['depth'] == depth]
    def particle_dB(self, T):
        """v0.1 name: integrated excess of the particle standard (no aperture)"""
        return self.particle_excess(T, None, None, 'mean')
    def particle_excess(self, T, aperture_nm=None, annulus_nm=None, depth='mid'):
        """Monte Carlo excess of the standard (signal per primary x nm^2) measured with the same aperture photometry as the
        data (aperture radius and background annulus in nm); interpolated in T; depth 'top'/'mid'/'bot' or 'mean'"""
        if self.legacy_particle is not None:
            p = self.legacy_particle; return float(np.interp(T, p['water_nm'], p['dB_keV_nm2']))
        if not self.particle: raise ValueError('curve file has no particle standard')
        deps = ['top', 'mid', 'bot'] if depth == 'mean' else [depth]
        vals = []
        for dep in deps:
            rows = sorted(self.particle_rows(dep), key=lambda r: r['T_nm'])
            if not rows: continue
            ex = [profile_aperture(np.asarray(r['edges']), np.asarray(r['det'][self.detector]['prof']), aperture_nm, annulus_nm) for r in rows]
            vals.append(np.interp(T, [r['T_nm'] for r in rows], ex))
        return float(np.mean(vals))

def profile_aperture(edges, prof, ra=None, annulus=None):
    """aperture photometry on a radial excess profile: integral within ra minus ra-area x mean in the annulus"""
    ann = np.pi * (edges[1:] ** 2 - edges[:-1] ** 2); C = np.concatenate([[0], np.cumsum(prof * ann)])
    if ra is None: return float(C[-1])
    Ci = lambda x: np.interp(x, edges, C)
    bg = 0.0
    if annulus is not None:
        a0, a1 = annulus; a1 = min(a1, edges[-1]); bg = (Ci(a1) - Ci(a0)) / (np.pi * (a1 ** 2 - a0 ** 2))
    return float(Ci(ra) - np.pi * ra ** 2 * bg)

class Calibration:
    def __init__(self, curve: ChannelCurve, B0: float, g: float, note: str = '', sB0=0.0, sg=0.0):
        self.curve, self.B0, self.g, self.note, self.sB0, self.sg = curve, float(B0), float(g), note, float(sB0), float(sg)
    def thickness(self, grey):
        return self.curve.T_of_S((np.asarray(grey, float) - self.B0) / self.g)
    def grey(self, T):
        return self.B0 + self.g * self.curve.S_of_T(T)
    def sigma_T(self, T, sigma_grey):
        """statistical thickness error for a grey-level error sigma_grey (e.g. pixel noise after smoothing)"""
        sl = np.abs(self.g * self.curve.dS_dT(T)); return np.where(sl > 0, sigma_grey / np.maximum(sl, 1e-12), np.inf)
    def sigma_T_calibration(self, T):
        """error of T from the uncertainties of B0 and g"""
        S = self.curve.S_of_T(T); sl = np.abs(self.g * self.curve.dS_dT(T)) + 1e-12
        return np.sqrt(self.sB0 ** 2 + (S * self.sg) ** 2) / sl
    def scaled(self, factor, note=''):
        return Calibration(self.curve, self.B0, self.g * factor, (self.note + '; ' + note).strip('; '), self.sB0, self.sg * factor)
    def to_dict(self): return dict(B0=self.B0, g=self.g, sB0=self.sB0, sg=self.sg, note=self.note, detector=self.curve.detector, curve=self.curve.meta.get('description', ''))
    # ---- constructors (kept from v0.1) ----
    @staticmethod
    def from_particles(curve, particle_excess_grey_px2, px_area_nm2, grey_ref, T_ref, T_particle=None, note='', aperture_nm=None, annulus_nm=None):
        T_particle = T_ref if T_particle is None else T_particle
        g = particle_excess_grey_px2 * px_area_nm2 / curve.particle_excess(T_particle, aperture_nm, annulus_nm, 'mean')
        B0 = grey_ref - g * curve.S_of_T(T_ref)
        return Calibration(curve, B0, g, note or f'gain from particle excess {particle_excess_grey_px2:.0f} grey px2; black level from grey {grey_ref:.1f} = {T_ref:.0f} nm')
    @staticmethod
    def from_two_references(curve, grey1, T1, grey2, T2, note=''):
        s1, s2 = curve.S_of_T(T1), curve.S_of_T(T2); g = (grey1 - grey2) / (s1 - s2); B0 = grey1 - g * s1
        return Calibration(curve, B0, g, note or f'two references: {grey1:.1f}->{T1:.0f} nm, {grey2:.1f}->{T2:.0f} nm')

# ThicknessCurve kept as an alias for v0.1 code
ThicknessCurve = ChannelCurve

def solve(curve: ChannelCurve, refs: dict, mode='auto', T_particle=None, aperture_nm=None, annulus_nm=None, A_mc=None):
    """Calibrate one channel from the references available.
    refs keys (all optional; values are grey levels of this channel with their standard errors):
      dark=(grey, err)                 beam blanked
      empty=(grey, err)                empty (dry) cell, T = 0
      particles=(excess_grey_nm2, err) single-particle excess x pixel area (grey * nm^2)
      flat=(grey, err, T_nm)           flat field of assumed thickness
      two=((grey1, T1), (grey2, T2))
      manual=(B0, g)
    Returns (Calibration, report dict with the model used and the consistency checks)."""
    have = {k for k, v in refs.items() if v is not None}
    order = [('dark+empty', {'dark', 'empty'}), ('dark+particles', {'dark', 'particles'}), ('empty+particles', {'empty', 'particles'}),
             ('particles+flat', {'particles', 'flat'}), ('dark+flat', {'dark', 'flat'}), ('two_references', {'two'}), ('manual', {'manual'})]
    if mode == 'auto':
        cand = [m for m, need in order if need <= have]
        if not cand: raise ValueError(f'calibration: not enough references ({sorted(have)}); record a dark frame and an empty cell, or use Au standards + a flat field')
        mode = cand[0]
    S0 = float(curve.S_of_T(0.0)); Tp = T_particle if T_particle is not None else 300.0
    if mode == 'dark+empty' and abs(S0) < 1e-6:
        raise ValueError('calibration dark+empty needs a detector model with a signal from the empty cell (S(0) > 0); this model has none')
    if mode == 'manual' and (refs.get('manual') is None or not refs['manual'][1]):
        raise ValueError('manual calibration: the gain g must not be 0')
    Amc = (lambda: A_mc) if A_mc is not None else (lambda: curve.particle_excess(Tp, aperture_nm, annulus_nm, 'mean'))
    if mode == 'dark+empty':
        (B0, sB0), (ge, se) = refs['dark'], refs['empty']; g = (ge - B0) / S0; sg = np.hypot(se, sB0) / abs(S0); note = f'dark {B0:.2f}; empty cell {ge:.2f} = S(0) {S0:.4f}'
    elif mode == 'dark+particles':
        (B0, sB0), (A, sA) = refs['dark'], refs['particles']; g = A / Amc(); sg = sA / Amc(); note = f'dark {B0:.2f}; particle excess {A:.0f} grey nm2 / MC {Amc():.1f}'
    elif mode == 'empty+particles':
        (ge, se), (A, sA) = refs['empty'], refs['particles']; g = A / Amc(); sg = sA / Amc(); B0 = ge - g * S0; sB0 = np.hypot(se, S0 * sg); note = f'particles -> g; empty {ge:.2f} -> B0'
    elif mode == 'particles+flat':
        (A, sA), (gf, sf, Tf) = refs['particles'], refs['flat']; g = A / Amc(); sg = sA / Amc(); B0 = gf - g * float(curve.S_of_T(Tf)); sB0 = np.hypot(sf, float(curve.S_of_T(Tf)) * sg)
        note = f'particles -> g; flat field {gf:.2f} assumed {Tf:.0f} nm -> B0'
    elif mode == 'dark+flat':
        (B0, sB0), (gf, sf, Tf) = refs['dark'], refs['flat']; Sf = float(curve.S_of_T(Tf)); g = (gf - B0) / Sf; sg = np.hypot(sf, sB0) / Sf; note = f'dark {B0:.2f}; flat {gf:.2f} assumed {Tf:.0f} nm'
    elif mode == 'two_references':
        (g1, T1), (g2, T2) = refs['two']; c = Calibration.from_two_references(curve, g1, T1, g2, T2); B0, g, sB0, sg, note = c.B0, c.g, 0.0, 0.0, c.note
    elif mode == 'manual':
        B0, g = refs['manual']; sB0 = sg = 0.0; note = 'manual'
    else: raise ValueError(mode)
    cal = Calibration(curve, B0, g, f'{mode}: {note}', sB0, sg)
    # ---- consistency checks with the references not used ----
    checks = []
    if 'particles' in have and 'particles' not in mode and (curve.particle is not None or curve.legacy_particle is not None):
        A, sA = refs['particles']; pred = g * Amc()
        checks.append(dict(check='particle excess measured / predicted', value=A / pred, err=np.hypot(sA / pred, A * sg * Amc() / pred ** 2),
                           meaning='1 = the Monte Carlo detector model reproduces the particle standard; the ratio is the detector-model scale error'))
    if 'dark' in have and 'dark' not in mode:
        B0d, sd = refs['dark']; checks.append(dict(check='black level: dark frame - model', value=B0d - B0, err=np.hypot(sd, sB0), meaning='grey levels; 0 = consistent'))
    if 'empty' in have and 'empty' not in mode:
        ge, se = refs['empty']; Te = float(cal.thickness(ge)); checks.append(dict(check='empty cell read as thickness (nm)', value=Te, err=float(cal.sigma_T(max(Te, 1.0), se)), meaning='0 = consistent'))
    if 'flat' in have and 'flat' not in mode:
        gf, sf, Tf = refs['flat']; Tm = float(cal.thickness(gf)); checks.append(dict(check=f'flat field thickness (assumed {Tf:.0f} nm)', value=Tm, err=float(cal.sigma_T(Tm, sf)), meaning='measured thickness of the reference region'))
    return cal, dict(mode=mode, B0=B0, g=g, sB0=sB0, sg=sg, note=note, checks=checks, references=sorted(have))

def single_particle_excess(excess_values, lo=0.0):
    """mode of the excess distribution (kernel density) = single-particle level when aggregates are present"""
    from scipy.stats import gaussian_kde
    v = np.asarray(excess_values, float); v = v[np.isfinite(v) & (v > lo)]
    if v.size < 8: return float(np.median(v)) if v.size else np.nan
    k = gaussian_kde(v, bw_method=0.25); xs = np.linspace(v.min(), np.percentile(v, 99), 1000); return float(xs[np.argmax(k(xs))])

def single_particle_excess_err(excess_values):
    v = np.asarray(excess_values, float); v = v[np.isfinite(v)]
    if v.size < 3: return np.nan
    mad = 1.4826 * np.median(np.abs(v - np.median(v))); return float(1.2533 * mad / np.sqrt(v.size))


# ------------------------------------------------------------------------------------------------ analytical detector models
# Shape parameters of the analytical models, fitted to the lcsem Monte Carlo curves of water in a 30/30 nm SiN cell
# (BED-C 15-65 deg; STEM bright field < 100 mrad): BSE information length L and STEM attenuation length lambda (nm).
ANALYTICAL_DEFAULTS = {'bse_L': {10: 180.0, 12: 358.0, 15: 944.0, 20: 1e5, 25: 1e5, 30: 1e5},
                       'stem_lambda': {10: 357.0, 12: 365.0, 15: 396.0, 20: 478.0, 25: 587.0, 30: 707.0}}

def analytical_curve(kind='bse', E0_keV=15.0, length_nm=None, T_max=5000.0):
    """simple analytical curve shapes, kept for comparisons only - NOT used by the pipeline or the interface:
    kind 'bse':  S(T) = 1 - exp(-T / L)   (a saturating curve with length L)
    kind 'stem': S(T) = exp(-T / lambda)  (an exponential attenuation)
    Their shapes do not follow the Monte Carlo curves of a membrane cell (e.g. the BSE shape has S(0) = 0, while the
    membranes backscatter: a dark + empty calibration is impossible with it), so thickness from them is biased; the
    internal review (docs/REVIEW_RESPONSE.md, Reviewer 1 M1) removed them from the interface. Default L / lambda:
    interpolated (log) in the table above. No particle model."""
    key = 'bse_L' if kind == 'bse' else 'stem_lambda'; tab = ANALYTICAL_DEFAULTS[key]
    if not length_nm:
        Es = np.array(sorted(tab)); Ls = np.log([tab[e] for e in Es]); length_nm = float(np.exp(np.interp(E0_keV, Es, Ls)))
    T = np.concatenate([np.linspace(0, 100, 11), np.linspace(125, T_max, 80)])
    S = (1 - np.exp(-T / length_nm)) if kind == 'bse' else np.exp(-T / length_nm)
    return dict(version=1, water_nm=T.tolist(), S=S.tolist(), E0_keV=E0_keV, analytical=kind, length_nm=length_nm,
                description=f'analytical {kind} model, {"L" if kind == "bse" else "lambda"} = {length_nm:.0f} nm at {E0_keV:g} kV')
