"""Unsupervised multimodal segmentation of a BSE/SE frame pair: PCA of a per-pixel feature stack, then a Gaussian mixture
in the principal-component space with the number of classes chosen by the Bayesian information criterion.

  PCA                        Pearson, Philos. Mag. 2, 559 (1901); Hotelling, J. Educ. Psychol. 24, 417 (1933); Jolliffe, Principal Component Analysis (2002)
  Gaussian mixture / EM      Dempster, Laird & Rubin, J. R. Stat. Soc. B 39, 1 (1977)
  model selection           BIC: Schwarz, Ann. Stat. 6, 461 (1978); ICL (BIC penalized by the classification entropy, which
                             selects separated clusters rather than a density fit): Biernacki, Celeux & Govaert, IEEE PAMI 22, 719 (2000)
  posterior smoothing        a light Gaussian smoothing of the class posteriors before the arg-max (probabilistic relaxation),
                             which removes salt-and-pepper labels without a Markov random field
The features are (all computed with normalized convolution so that masked pixels do not leak):
  T_fine   liquid thickness (or BSE grey) at a fine scale        T_coarse  the same at a coarse scale
  SE_fine  SE at a fine scale                                    SE_coarse the same at a coarse scale
  |grad T| gradient magnitude of the fine thickness (rims and fronts)
Classes are reported with their area fraction, mean SE, median thickness and gradient, which is what identifies them
(e.g. dry+thin, dry+normal, wet, rim). The classes are ordered by their median thickness.
"""
from __future__ import annotations
import numpy as np
from scipy import ndimage as ndi
from .imageproc import smooth_masked

def feature_stack(T, se, valid, fine=4.0, coarse=15.0, grad_scale=4.0):
    """returns (features [n_valid, 5], feature names, full-frame maps dict)"""
    inv = ~valid
    Tf = smooth_masked(np.nan_to_num(T, nan=float(np.nanmedian(T))), inv, fine); Tc = smooth_masked(np.nan_to_num(T, nan=float(np.nanmedian(T))), inv, coarse)
    Sf = smooth_masked(np.nan_to_num(se, nan=float(np.nanmedian(se))), inv, fine); Sc = smooth_masked(np.nan_to_num(se, nan=float(np.nanmedian(se))), inv, coarse)
    gy, gx = np.gradient(smooth_masked(np.nan_to_num(T, nan=float(np.nanmedian(T))), inv, grad_scale)); G = np.hypot(gy, gx)
    maps = dict(T_fine=Tf, T_coarse=Tc, SE_fine=Sf, SE_coarse=Sc, gradT=G)
    X = np.stack([m[valid] for m in maps.values()], axis=1).astype(np.float32)
    return X, list(maps.keys()), maps

def pca_gmm_segment(X, valid, k_range=(2, 7), n_fit=120000, var_keep=0.95, smooth_post=3.0, seed=0, return_models=False, criterion='icl'):
    """z-score, PCA (keep components explaining `var_keep` of the variance, at least 2), GMM with BIC over k_range,
    posteriors smoothed and arg-maxed. Returns dict(labels [ny,nx] with -1 outside, scores, pca, gmm, bic, k)."""
    from sklearn.decomposition import PCA
    from sklearn.mixture import GaussianMixture
    rng = np.random.default_rng(seed)
    mu, sd = X.mean(axis=0), X.std(axis=0) + 1e-9; Z = (X - mu) / sd
    pca = PCA().fit(Z[rng.choice(len(Z), min(n_fit, len(Z)), replace=False)])
    ncomp = max(2, int(np.searchsorted(np.cumsum(pca.explained_variance_ratio_), var_keep) + 1))
    S = pca.transform(Z)[:, :ncomp]
    sub = S[rng.choice(len(S), min(n_fit, len(S)), replace=False)]
    bic, icl, models = [], [], []
    for k in range(k_range[0], k_range[1] + 1):
        g = GaussianMixture(k, covariance_type='full', n_init=2, random_state=seed, reg_covar=1e-4).fit(sub); models.append(g); b = g.bic(sub); bic.append(b)
        p = g.predict_proba(sub); icl.append(b - 2 * np.sum(p * np.log(p + 1e-12)))     # ICL = BIC + 2 * classification entropy
    kbest = int(np.argmin(icl if criterion == 'icl' else bic)); gmm = models[kbest]; k = k_range[0] + kbest
    post = gmm.predict_proba(S)
    ny, nx = valid.shape; P = np.zeros((k, ny, nx), np.float32)
    for c in range(k):
        m = np.zeros((ny, nx), np.float32); m[valid] = post[:, c]; P[c] = smooth_masked(m, ~valid, smooth_post) if smooth_post else m
    labels = np.where(valid, np.argmax(P, axis=0), -1).astype(np.int16)
    out = dict(labels=labels, ncomp=ncomp, explained=pca.explained_variance_ratio_[:ncomp].tolist(), loadings=pca.components_[:ncomp].tolist(), k=k, bic=bic, icl=icl, scores_valid=S, post_maps=P)
    if return_models: out.update(pca=pca, gmm=gmm, mu=mu, sd=sd)
    return out

def select_k_stability(X, k_range=(2, 7), n_fit=20000, var_keep=0.95, n_runs=10, criterion='icl', seed=0):
    """How robust is the number of classes? The model choice (ICL or BIC over k_range) is repeated on n_runs independent random
    subsamples of the pixels, each with its own PCA and GMM initialisation; returns the most frequent k and the frequencies
    (subsampling stability in the spirit of Meinshausen & Buehlmann 2010 and Lange et al. 2004)."""
    from sklearn.decomposition import PCA
    from sklearn.mixture import GaussianMixture
    mu, sd = X.mean(axis=0), X.std(axis=0) + 1e-9; Z = (X - mu) / sd; wins = []
    for r in range(n_runs):
        rng = np.random.default_rng(seed + 1000 + r); sub = Z[rng.choice(len(Z), min(n_fit, len(Z)), replace=False)]
        pca = PCA().fit(sub); nc = max(2, int(np.searchsorted(np.cumsum(pca.explained_variance_ratio_), var_keep) + 1)); S = pca.transform(sub)[:, :nc]
        vals = []
        for k in range(k_range[0], k_range[1] + 1):
            g = GaussianMixture(k, covariance_type='full', n_init=1, random_state=seed + r, reg_covar=1e-4).fit(S); b = g.bic(S)
            if criterion == 'icl': pp = g.predict_proba(S); b = b - 2 * np.sum(pp * np.log(pp + 1e-12))
            vals.append(b)
        wins.append(k_range[0] + int(np.argmin(vals)))
    ks, counts = np.unique(wins, return_counts=True); order = np.lexsort((ks, -counts))      # most frequent; ties -> fewer classes
    return dict(k=int(ks[order[0]]), freq={int(a): int(b) for a, b in zip(ks, counts)}, n=int(n_runs))

def class_table(labels, T, se, gradT, valid, order_by='T'):
    """per class: area fraction, mean SE, median thickness, median gradient; classes relabelled in order of thickness"""
    rows = []
    for c in np.unique(labels[valid]):
        m = (labels == c) & valid
        rows.append(dict(cls=int(c), area_frac=float(m.mean() / valid.mean()), se_mean=float(np.nanmean(se[m])), T_median=float(np.nanmedian(T[m])),
                         T_p25=float(np.nanpercentile(T[m], 25)), T_p75=float(np.nanpercentile(T[m], 75)), grad_median=float(np.nanmedian(gradT[m]))))
    rows.sort(key=lambda r: r['T_median'] if order_by == 'T' else r['se_mean'])
    remap = {r['cls']: i for i, r in enumerate(rows)}
    for i, r in enumerate(rows): r['cls'] = i
    new = labels.copy()
    for old, nw in remap.items(): new[labels == old] = nw
    return rows, new

def interpret(rows, se_dark_thr=None, T_ref=None, grad_thr=None):
    """attach a plain-language tag to each class from its SE level, thickness and gradient relative to the frame"""
    ses = np.array([r['se_mean'] for r in rows]); Ts = np.array([r['T_median'] for r in rows]); gs = np.array([r['grad_median'] for r in rows])
    se_thr = se_dark_thr if se_dark_thr is not None else 0.5 * (ses.min() + ses.max()); T_ref = T_ref if T_ref is not None else float(np.median(Ts))
    grad_thr = grad_thr if grad_thr is not None else 2.0 * float(np.median(gs))
    for r in rows:
        wet = 'wet' if r['se_mean'] >= se_thr else 'dry'
        th = 'thin' if r['T_median'] < 0.85 * T_ref else ('thick' if r['T_median'] > 1.25 * T_ref else 'normal')
        r['tag'] = ('rim/front' if r['grad_median'] > grad_thr else f'{wet}, {th}')
    return rows
