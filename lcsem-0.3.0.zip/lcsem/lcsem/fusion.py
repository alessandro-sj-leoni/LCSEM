"""Combining the thickness maps of several channels (BSE, STEM) of the same scan.

Each channel gives T_k(x, y) with a statistical error s_k(x, y) (pixel noise after smoothing / |g dS/dT|). The fused map is
the inverse-variance weighted mean (the maximum-likelihood estimate for independent Gaussian errors), and
chi2 = sum_k (T_k - T)^2 / s_k^2 (k - 1 degrees of freedom) flags pixels where the channels disagree more than their noise
allows - a local test of the detector models (e.g. contamination, charging, a wrong membrane thickness).
"""
from __future__ import annotations
import numpy as np

def smoothed_noise(sigma_px, smooth_sigma_px):
    """standard deviation of white pixel noise after a Gaussian smoothing of width smooth_sigma_px (pixels)"""
    return sigma_px / (2 * np.sqrt(np.pi) * max(smooth_sigma_px, 0.5))

def fuse(T_maps: dict, s_maps: dict, min_weight_frac=0.0):
    keys = [k for k in T_maps if T_maps[k] is not None]
    if len(keys) == 1:
        k = keys[0]; return T_maps[k], s_maps[k], np.zeros_like(T_maps[k]), {k: np.ones_like(T_maps[k])}
    W = {k: np.where(np.isfinite(T_maps[k]) & np.isfinite(s_maps[k]) & (s_maps[k] > 0), 1.0 / np.maximum(s_maps[k], 1e-6) ** 2, 0.0) for k in keys}
    wsum = sum(W.values())
    T = sum(W[k] * np.nan_to_num(T_maps[k]) for k in keys) / np.where(wsum > 0, wsum, np.nan)
    s = 1.0 / np.sqrt(np.where(wsum > 0, wsum, np.nan))
    chi2 = sum(W[k] * (np.nan_to_num(T_maps[k]) - np.nan_to_num(T)) ** 2 for k in keys)
    frac = {k: W[k] / np.where(wsum > 0, wsum, np.nan) for k in keys}
    return T.astype(np.float32), s.astype(np.float32), chi2.astype(np.float32), frac
