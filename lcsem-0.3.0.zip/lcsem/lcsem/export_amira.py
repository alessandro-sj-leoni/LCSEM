"""Export of a finished run to Amira (AmiraMesh .am files), for volume rendering and isosurfaces of the time series.

    lcsem amira run_dir [--out amira_dir] [--bin 4] [--dz 10]

Per frame, on the drift-corrected canvas, physical coordinates in nm; z = height above the bottom of the volume, so the beam
comes from +z and the top membrane is at the top. Only the cell edges and the Au particles are binary, as 1:
  *_liquid_fraction.am   fraction of each voxel filled with liquid (0-255 = 0-1; partial volumes at the interfaces, so an
                         isosurface at 128 is a smooth liquid surface - not binary)
  *_gas_fraction.am      fraction of each voxel filled with gas (at the top membrane and elsewhere), same encoding
  *_cell_walls.am        1 in the SiN membranes and where the field of view lies outside the window (the edges of the liquid cell)
  *_au_nps.am            1 in the voxels the Au particles occupy (at their measured depth when available), 0 elsewhere
  *_au_nps.surf          the Au particles as spheres of their true size (Amira HxSurface), for rendering without voxel steps
  *_thickness_nm.am      2-D liquid thickness (float), *_time_s.am 2-D acquisition time (float)
  *_particles.landmarkAscii   particle centres (nm) as an Amira landmark set
  *_class_prob_<crit>.am      PCA+GMM class probabilities (float, one slice per class), if the segmentation ran
Areas of the canvas not imaged in a frame (drift) are 0 in every volume. AmiraMesh: x fastest, then y, then z;
BoundingBox = centres of the first and last voxels.
"""
from __future__ import annotations
import os, json, glob, numpy as np, pandas as pd

_TYPES = {np.dtype('uint8'): 'byte', np.dtype('int16'): 'short', np.dtype('uint16'): 'ushort', np.dtype('int32'): 'int', np.dtype('float32'): 'float'}

COMPRESS = True          # HxZip (zlib) data sections: Amira and Fiji's AmiraMesh reader read them; ~20-100x smaller volumes

def write_am(fn, data, bbox, content='', compress=None):
    """data: (nz, ny, nx) or (ny, nx) array; bbox: (xmin, xmax, ymin, ymax, zmin, zmax) of the voxel centres (nm).
    compress: HxZip (zlib) encoding of the data section (default COMPRESS)"""
    import zlib
    a = np.asarray(data)
    if a.ndim == 2: a = a[None]
    if a.dtype not in _TYPES: a = a.astype(np.float32)
    nz, ny, nx = a.shape; t = _TYPES[a.dtype]
    payload = np.ascontiguousarray(a).astype(a.dtype.newbyteorder('<')).tobytes()
    do_zip = COMPRESS if compress is None else bool(compress)
    if do_zip: payload = zlib.compress(payload, 6); enc = f'@1(HxZip,{len(payload)})'
    else: enc = '@1'
    hdr = ('# AmiraMesh BINARY-LITTLE-ENDIAN 2.1\n\n'
           f'define Lattice {nx} {ny} {nz}\n\n'
           'Parameters {\n'
           f'    Content "{nx}x{ny}x{nz} {t}, uniform coordinates{(", " + content) if content else ""}",\n'
           f'    BoundingBox {bbox[0]:.4f} {bbox[1]:.4f} {bbox[2]:.4f} {bbox[3]:.4f} {bbox[4]:.4f} {bbox[5]:.4f},\n'
           '    CoordType "uniform"\n'
           '}\n\n'
           f'Lattice {{ {t} Data }} {enc}\n\n'
           '# Data section follows\n@1\n')
    with open(fn, 'wb') as f:
        f.write(hdr.encode('ascii')); f.write(payload); f.write(b'\n')


def read_am(fn):
    """read a uniform-lattice AmiraMesh file written by write_am (raw or HxZip): returns (array (nz, ny, nx), header text)"""
    import re, zlib
    raw = open(fn, 'rb').read(); i0 = raw.index(b'# Data section follows\n@1\n') + len(b'# Data section follows\n@1\n'); hdr = raw[:i0].decode('latin1')
    nx, ny, nz = map(int, re.search(r'define Lattice (\d+) (\d+) (\d+)', hdr).groups())
    t = re.search(r'Lattice \{ (\w+) Data \} @1(\(HxZip,(\d+)\))?', hdr); dt = {v: k for k, v in _TYPES.items()}[t.group(1)].newbyteorder('<')
    body = zlib.decompress(raw[i0:i0 + int(t.group(3))]) if t.group(2) else raw[i0:i0 + nx * ny * nz * dt.itemsize]
    return np.frombuffer(body, dt).reshape(nz, ny, nx), hdr

def write_landmarks(fn, xyz):
    xyz = np.asarray(xyz, float).reshape(-1, 3)
    with open(fn, 'w') as f:
        f.write(f'# AmiraMesh 3D ASCII 2.0\n\n\ndefine Markers {len(xyz)}\n\nParameters {{\n    NumSets 1,\n    ContentType "LandmarkSet"\n}}\n\n'
                'Markers { float[3] Coordinates } @1\n\n# Data section follows\n@1\n')
        for x, y, z in xyz: f.write(f'{x:.3f} {y:.3f} {z:.3f}\n')

def icosphere(level=2):
    t = (1 + 5 ** 0.5) / 2
    v = [(-1, t, 0), (1, t, 0), (-1, -t, 0), (1, -t, 0), (0, -1, t), (0, 1, t), (0, -1, -t), (0, 1, -t), (t, 0, -1), (t, 0, 1), (-t, 0, -1), (-t, 0, 1)]
    f = [(0, 11, 5), (0, 5, 1), (0, 1, 7), (0, 7, 10), (0, 10, 11), (1, 5, 9), (5, 11, 4), (11, 10, 2), (10, 7, 6), (7, 1, 8),
         (3, 9, 4), (3, 4, 2), (3, 2, 6), (3, 6, 8), (3, 8, 9), (4, 9, 5), (2, 4, 11), (6, 2, 10), (8, 6, 7), (9, 8, 1)]
    v = [np.array(p, float) / np.linalg.norm(p) for p in v]
    for _ in range(level):
        cache = {}; nf = []
        def mid(a, b):
            key = (min(a, b), max(a, b))
            if key not in cache:
                m = v[a] + v[b]; v.append(m / np.linalg.norm(m)); cache[key] = len(v) - 1
            return cache[key]
        for a, b, c in f:
            ab, bc, ca = mid(a, b), mid(b, c), mid(c, a); nf += [(a, ab, ca), (b, bc, ab), (c, ca, bc), (ab, bc, ca)]
        f = nf
    return np.array(v), np.array(f)

def write_spheres_surf(fn, centers, radius, level=2, material='Au', color=(0.93, 0.66, 0.0)):
    """spheres as an Amira HyperSurface (ASCII): one patch, inner region = material, outer = Exterior"""
    V0, F0 = icosphere(level); V, F = [], []
    for i, c in enumerate(np.asarray(centers, float).reshape(-1, 3)):
        V.append(V0 * radius + c); F.append(F0 + i * len(V0))
    with open(fn, 'w') as f:
        f.write('# HyperSurface 0.1 ASCII\n\nParameters {\n    Materials {\n        Exterior {\n            Id 1\n        }\n'
                f'        {material} {{\n            Id 2,\n            Color {color[0]:.3f} {color[1]:.3f} {color[2]:.3f}\n        }}\n    }}\n'
                '    BoundaryIds {\n        Name "BoundaryConditions"\n    }\n}\n\n')
        if not V: f.write('Vertices 0\n\nNBranchingPoints 0\nNVerticesOnCurves 0\nBoundaryCurves 0\nPatches 0\n'); return
        V = np.concatenate(V); F = np.concatenate(F)
        f.write(f'Vertices {len(V)}\n'); f.write(''.join(f'        {x:.3f} {y:.3f} {z:.3f}\n' for x, y, z in V))
        f.write(f'\nNBranchingPoints 0\nNVerticesOnCurves 0\nBoundaryCurves 0\nPatches 1\n{{\nInnerRegion {material}\nOuterRegion Exterior\nBoundaryID 0\nBranchingPoints 0\n\n')
        f.write(f'Triangles {len(F)}\n'); f.write(''.join(f'  {a + 1} {b + 1} {c + 1}\n' for a, b, c in F)); f.write('}\n')

def _fraction(a, b, z0, dz):
    """fraction of each voxel [z0 + k dz, z0 + (k + 1) dz] covered by the interval [a, b] (a, b: 2-D arrays of depth)"""
    lo = z0[:, None, None]; hi = lo + dz
    return np.clip((np.minimum(b[None], hi) - np.maximum(a[None], lo)) / dz, 0, 1)

def _canvas(run_dir):
    info = json.load(open(os.path.join(run_dir, 'run_info.json')))
    H, W, ymin, xmin = info['canvas']; return info, np.array(info['drift']), int(H), int(W), int(ymin), int(xmin)

def _to_canvas(img, shift, H, W, ymin, xmin, fill=np.nan, order=1):
    from scipy.ndimage import shift as nd_shift
    dy, dx = shift; out = np.full((H, W), fill, np.float32)
    a = np.asarray(img, np.float32)
    if order == 0: s_ = nd_shift(np.nan_to_num(a, nan=0), (dy - np.floor(dy), dx - np.floor(dx)), order=0)
    else:
        m = np.isfinite(a).astype(np.float32); s_ = nd_shift(np.nan_to_num(a, nan=0), (dy - np.floor(dy), dx - np.floor(dx)), order=1)
        w = nd_shift(m, (dy - np.floor(dy), dx - np.floor(dx)), order=1); s_ = np.where(w > 0.99, s_, np.nan)
    iy, ix = int(np.floor(dy)) - ymin, int(np.floor(dx)) - xmin
    h, w_ = min(a.shape[0], H - iy), min(a.shape[1], W - ix)
    out[iy:iy + h, ix:ix + w_] = s_[:h, :w_]; return out

def _bin(a, b, how='mean'):
    ny, nx = a.shape[0] // b * b, a.shape[1] // b * b; v = a[:ny, :nx].reshape(ny // b, b, nx // b, b)
    with np.errstate(all='ignore'):
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', RuntimeWarning)
            return np.nanmean(v, axis=(1, 3)) if how == 'mean' else np.nanmax(v, axis=(1, 3))

def export_run(run_dir, out_dir=None, bin=4, dz=10.0, t_mem=None, T_cap=1500.0, log=print, volume=None):
    """write the Amira files of a finished run; the volumes come from lcsem.volume4d.Volume4D (the same voxels the GUI shows
    and every other export writes)"""
    from .volume4d import Volume4D
    V = volume or Volume4D(run_dir, bin=bin, dz=dz, t_mem=t_mem, T_cap=T_cap)
    out_dir = out_dir or os.path.join(run_dir, 'amira'); os.makedirs(out_dir, exist_ok=True)
    name, bin, dz, t_mem, Zmax, nz, ny, nx = V.name, V.bin, V.dz, V.t_mem, V.Zmax, V.nz, V.ny, V.nx
    d_part = V.d_part; Rp = d_part / 2; pxb = (V.px[0] * bin, V.px[1] * bin)
    oz, oy, ox = V.origin_nm                                             # voxel-centre origin, as every other export and the viewer
    bbox = (ox, ox + pxb[0] * (nx - 1), oy, oy + pxb[1] * (ny - 1), oz, oz + dz * (nz - 1))
    bb2 = (bbox[0], bbox[1], bbox[2], bbox[3], 0.0, 0.0)
    S = V.summary; P = V.particles; times, plist = [], []
    for i, tag in enumerate(V.tags):
        vol = V.frame(i); m = V.m2; inside, imaged = m['inside'][i], m['imaged'][i]
        write_am(os.path.join(out_dir, f'{tag}_liquid_fraction.am'), vol['liquid'], bbox, 'liquid fraction x 255')
        write_am(os.path.join(out_dir, f'{tag}_gas_fraction.am'), vol['gas'], bbox, 'gas fraction x 255')
        write_am(os.path.join(out_dir, f'{tag}_cell_walls.am'), vol['walls'], bbox, 'membranes and window frame = 1')
        write_am(os.path.join(out_dir, f'{tag}_au_nps.am'), vol['au'], bbox, 'Au particles = 1')
        # SE contact (gas touching the top membrane, including films too thin to change the liquid thickness): fraction of the
        # SE-dark pixels in each column, drawn in the voxel layer just under the top membrane (0-255), and as a 2-D map
        write_am(os.path.join(out_dir, f'{tag}_top_contact.am'), vol['contact'], bbox, 'SE contact fraction x 255 in the layer under the top membrane')
        write_am(os.path.join(out_dir, f'{tag}_se_contact_fraction.am'), np.where(inside, m['dark'][i], np.nan).astype(np.float32), bb2, 'fraction of SE-dark pixels (gas at the top membrane)')
        write_am(os.path.join(out_dir, f'{tag}_thickness_nm.am'), np.where(inside, m['T'][i], np.nan).astype(np.float32), bb2, 'liquid thickness nm')
        write_am(os.path.join(out_dir, f'{tag}_time_s.am'), np.where(imaged, m['time'][i], np.nan).astype(np.float32), bb2, 'acquisition time s since midnight')
        pts = []
        if len(P):
            for _, r in P[P['frame'] == i].iterrows():
                xc, yc = float(r['x_nm']), float(r['y_nm'])
                if not (0 <= xc < nx * pxb[0] and 0 <= yc < ny * pxb[1]): continue
                zu = Zmax - float(r['depth_nm']); pts.append((xc, yc, zu))
                plist.append(dict(frame=i, name=tag, x_nm=xc, y_nm=yc, z_amira_nm=zu, depth_below_top_membrane_nm=float(r['depth_nm']) - t_mem[0],
                                  z_measured=bool(r['z_measured']), track=r.get('track', -1)))
        write_spheres_surf(os.path.join(out_dir, f'{tag}_au_nps.surf'), pts, Rp)
        if pts: write_landmarks(os.path.join(out_dir, f'{tag}_particles.landmarkAscii'), pts)
        for crit in ('icl', 'bic'):
            pf = os.path.join(run_dir, f'{tag}_class_prob_{crit}.npy')
            if os.path.exists(pf):
                pr = np.load(pf); pr = np.stack([_bin(_to_canvas(p_, V.drift[i], V.H, V.W, V.ymin, V.xmin), bin)[:ny, :nx] for p_ in pr])
                write_am(os.path.join(out_dir, f'{tag}_class_prob_{crit}.am'), pr.astype(np.float32), (bb2[0], bb2[1], bb2[2], bb2[3], 0.0, float(len(pr) - 1)), f'{crit.upper()} class probabilities, z = class')
        times.append(dict(frame=i, name=tag, time=S.loc[i, 'time_end'] if i < len(S) and 'time_end' in S else '',
                          liquid_median_nm=float(S.loc[i, 'liquid_nm_median']) if i < len(S) and 'liquid_nm_median' in S else np.nan,
                          n_particles=len(pts), n_particles_z_measured=sum(1 for q in plist if q['frame'] == i and q['z_measured'])))
        log(f'  amira: frame {i} written')
    pd.DataFrame(times).to_csv(os.path.join(out_dir, 'time_series.csv'), index=False)
    pd.DataFrame(plist).to_csv(os.path.join(out_dir, 'particles_amira_coordinates.csv'), index=False)
    nzm = sum(q['z_measured'] for q in plist)
    with open(os.path.join(out_dir, 'README_AMIRA.txt'), 'w') as fh:
        fh.write(f'''Amira files for run {name} ({V.n} frames). Units: nm. Voxel {pxb[0]:.2f} x {pxb[1]:.2f} x {dz:.1f} nm (x, y binned {bin}x; z = height above
the bottom of the volume; the beam comes from +z; the top membrane occupies z = {Zmax - t_mem[0]:.0f}-{Zmax:.0f} nm).

Only the edges of the liquid cell and the Au particles are binary (= 1). Liquid and gas are stored as the fraction of each voxel
they fill (0-255 = 0-1), so their surfaces are smooth (partial volumes), not staircases. Liquid thicker than {V.T_cap:.0f} nm is
drawn as {V.T_cap:.0f} nm (the thickness maps keep the measured value up to that cap).

Load: File > Open Time Series Data (or File > Open Data and accept "load as time series"), select all *_liquid_fraction.am;
repeat for *_gas_fraction.am, *_cell_walls.am, *_au_nps.am. The Time Series Control steps through the frames.
Suggested display:
  liquid_fraction  Volume Rendering (colormap blue, range 0-255) or Isosurface, threshold 128 (smooth liquid surface)
  gas_fraction     Isosurface, threshold 128, orange
  cell_walls       Isosurface, threshold 0.5, grey, transparency ~0.7 (membranes and window frame = the cell edges)
  au_nps           Isosurface, threshold 0.5, gold (1 = particle); or open *_au_nps.surf (Surface View) for exact spheres
  top_contact      Volume Rendering or Isosurface at 128: where gas touches the top membrane (SE contact), also where the gas
                   film is too thin to change the liquid thickness; *_se_contact_fraction.am is the same as a 2-D map
  *_particles.landmarkAscii   Landmark View (particle centres; set the point size to the particle diameter, {d_part:.0f} nm)
  thickness_nm / time_s       2-D maps (Ortho Slice); class_prob_icl / _bic: probability of each class, one slice per class
The liquid layer is thin compared with the field of view: scale z (Transform Editor, e.g. x 10) to see its relief.
The top membrane is drawn flat and every change of the column (liquid + gas) shows at the bottom membrane: the images measure
what is in each column, not how the two membranes share the bulging.
Particle depth: {nzm} of {len(plist)} particle positions have a measured depth; the others are drawn just under the top membrane
(column z_measured in particles_amira_coordinates.csv). Frames and times: time_series.csv.
Areas of the canvas not imaged in a frame (drift) are empty (0) in every volume.
''')
    log(f'amira export: {V.n} frames -> {out_dir}  (lattice {nx} x {ny} x {nz}, voxel {pxb[0]:.1f} x {pxb[1]:.1f} x {dz:.0f} nm)')
    return out_dir
