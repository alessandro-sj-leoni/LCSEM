"""Time-resolved 3-D volumes of a finished run, built lazily frame by frame (for the GUI, the Amira export and all other
exports).

Every column of the drift-corrected canvas is a stack of layers - top membrane, gas at the top, liquid, gas elsewhere,
bottom membrane - measured per pixel (lcsem.pipeline). Here the columns are binned laterally (`bin`) and converted to voxels
of height `dz`: liquid and gas as the exact fraction of each voxel they fill (0-255), the membranes and the window frame as
walls (1), the Au particles as spheres at their measured depth (1), and the SE contact (gas touching the top membrane) as a
fraction in the voxel layer under the top membrane. The top membrane is drawn flat; every change of the column shows at the
bottom membrane. z = height above the bottom of the volume (the beam comes from +z). Areas not imaged in a frame are 0.

    V = Volume4D(run_dir, bin=4, dz=10)
    vol = V.frame(3)                       # dict of (nz, ny, nx) uint8 arrays: liquid, gas, walls, au, contact
    da = V.dask('liquid')                  # (T, nz, ny, nx) dask array for napari (computed when displayed)
"""
from __future__ import annotations
import os, glob, json, numpy as np, pandas as pd

KINDS = ('liquid', 'gas', 'contact', 'walls', 'au')
_CACHE_VERSION = 6          # bump when _build_2d changes (cached volume2d files are rebuilt)

def cache_dir():
    """per-user cache folder for the binned 2-D model of runs (viewing a run never writes into the run folder):
    LCSEM_CACHE_DIR, else %LOCALAPPDATA%\\lcsem\\cache (Windows) or ~/.cache/lcsem"""
    d = os.environ.get('LCSEM_CACHE_DIR')
    if not d:
        base = os.environ.get('LOCALAPPDATA') if os.name == 'nt' else os.environ.get('XDG_CACHE_HOME')
        d = os.path.join(base or os.path.join(os.path.expanduser('~'), '.cache'), 'lcsem', 'cache') if os.name == 'nt' or base else os.path.join(os.path.expanduser('~'), '.cache', 'lcsem')
    return d

def _cache_path(run_dir, b):
    import hashlib
    key = hashlib.sha1(os.path.normcase(os.path.abspath(run_dir)).encode()).hexdigest()[:16]
    return os.path.join(cache_dir(), f'volume2d_{key}_bin{int(b)}.npz')

def _fraction(a, b, z0, dz):
    """fraction of each voxel [z0, z0 + dz) filled by the interval [a, b) of its column (float32, (nz, ny, nx))"""
    lo = np.asarray(z0, np.float32)[:, None, None]; hi = lo + np.float32(dz)
    f = np.minimum(np.asarray(b, np.float32)[None], hi); f -= np.maximum(np.asarray(a, np.float32)[None], lo); f /= np.float32(dz)
    return np.clip(f, 0, 1, out=f)

def _to_canvas(img, shift, H, W, ymin, xmin, fill=np.nan, order=1):
    from scipy.ndimage import shift as nd_shift
    dy, dx = shift; out = np.full((H, W), fill, np.float32); a = np.asarray(img, np.float32)
    fy, fx = dy - np.floor(dy), dx - np.floor(dx)
    if order == 0: s_ = nd_shift(np.nan_to_num(a, nan=0), (fy, fx), order=0)
    else:
        m = np.isfinite(a).astype(np.float32); s_ = nd_shift(np.nan_to_num(a, nan=0), (fy, fx), order=1)
        w = nd_shift(m, (fy, fx), order=1); s_ = np.where(w > 0.99, s_, np.nan)
    iy, ix = int(np.floor(dy)) - ymin, int(np.floor(dx)) - xmin
    h, w_ = min(a.shape[0], H - iy), min(a.shape[1], W - ix)
    out[iy:iy + h, ix:ix + w_] = s_[:h, :w_]; return out

def _bin(a, b):
    import warnings
    ny, nx = a.shape[0] // b * b, a.shape[1] // b * b; v = a[:ny, :nx].reshape(ny // b, b, nx // b, b)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', RuntimeWarning); return np.nanmean(v, axis=(1, 3))

class Volume4D:
    def __init__(self, run_dir, bin=4, dz=10.0, t_mem=None, T_cap=1500.0, cache=True, progress=None):
        self.run_dir = run_dir; self.bin = int(bin); self.dz = float(dz)
        fi = os.path.join(run_dir, 'run_info.json')
        if not os.path.exists(fi): raise FileNotFoundError(f'{run_dir} is not an lcsem run folder (no run_info.json)')
        with open(fi) as fh: info = json.load(fh)
        self.info = info; cfg = info['config']; self.cfg = cfg
        self.px = tuple(cfg['pixel_nm']); self.name = cfg.get('name', 'series'); self.mode = info.get('mode', '')
        self.t_mem = tuple(t_mem or cfg.get('cell', {}).get('membranes_nm', (30.0, 30.0)))
        self.d_part = float(cfg.get('references', {}).get('particles', {}).get('diameter_nm', 38.0))
        H, W, ymin, xmin = [int(v) for v in info['canvas']]; self.H, self.W, self.ymin, self.xmin = H, W, ymin, xmin
        self.drift = np.array(info['drift'], float)
        if info.get('tags'):                                     # the frames of this run (a re-run into the same folder leaves others)
            self.files = [os.path.join(run_dir, t + '_maps.npz') for t in info['tags']]
            miss = [f for f in self.files if not os.path.exists(f)]
            if miss: raise FileNotFoundError(f'{len(miss)} map files of this run are missing, e.g. {os.path.basename(miss[0])}')
        else:
            self.files = sorted(glob.glob(os.path.join(glob.escape(run_dir), f'{glob.escape(self.name)}_*_maps.npz')))
        self.n = len(self.files)
        if self.n == 0: raise ValueError(f'{run_dir}: no frames (no *_maps.npz files) - the analysis did not finish?')
        if len(info.get('drift', [])) != self.n:
            raise ValueError(f'{run_dir}: {self.n} map files but {len(info.get("drift", []))} frames in run_info.json - several runs were written '
                             'into this folder; run again into a new folder')
        self.tags = [os.path.basename(f)[:-9] for f in self.files]
        self.summary = pd.read_csv(os.path.join(run_dir, 'summary.csv')) if os.path.exists(os.path.join(run_dir, 'summary.csv')) else pd.DataFrame()
        self.T_cap = float(T_cap); cp = _cache_path(run_dir, self.bin); self.m2 = None
        if cache and os.path.exists(cp) and os.path.getmtime(cp) >= max(os.path.getmtime(f) for f in self.files):
            z = np.load(cp)
            fresh = 'version' in z.files and int(z['version']) == _CACHE_VERSION and float(z['T_cap']) == self.T_cap
            if fresh: self.m2 = {k: z[k] for k in z.files if k not in ('version', 'T_cap')}
        if self.m2 is None:
            self.m2 = self._build_2d(progress)
            if cache:
                try: os.makedirs(os.path.dirname(cp), exist_ok=True); np.savez_compressed(cp, version=_CACHE_VERSION, T_cap=self.T_cap, **self.m2)
                except OSError: pass                                  # no writable cache folder: no cache
        tot = (self.m2['T'] + self.m2['gt'] + self.m2['go'])[self.m2['inside']]
        Zl = min(T_cap, float(np.percentile(tot, 99.8)) if tot.size else T_cap)
        Zmax = self.t_mem[0] + Zl + self.t_mem[1] + self.dz; self.Zmax = float(np.ceil(Zmax / (5 * self.dz)) * 5 * self.dz)
        self.nz = int(round(self.Zmax / self.dz)); self.depth0 = np.arange(self.nz) * self.dz
        self.ny, self.nx = self.m2['T'].shape[1:]
        self.spacing = (self.dz, self.px[1] * self.bin, self.px[0] * self.bin)          # (z, y, x) nm
        # centre of voxel (0, 0, 0) in nm (z, y, x): original pixel i is centred at i * px (as the particle coordinates), a binned
        # voxel covers pixels j*b .. j*b + b - 1; voxel k covers heights k*dz .. (k+1)*dz. Every export writes this origin.
        self.origin_nm = (0.5 * self.dz, 0.5 * (self.bin - 1) * self.px[1], 0.5 * (self.bin - 1) * self.px[0])
        self.times = self.m2['t_mean']
        self.particles = self._particles()
        import threading, collections
        self._cache = collections.OrderedDict(); self._lock = threading.Lock(); self._pool = None
        self.cache_mb = float(os.environ.get('LCSEM_CACHE_MB', 1500))

    # ------------------------------------------------------------------------------------------------ 2-D layer maps
    def _build_2d(self, progress=None):
        b = self.bin; H, W, ymin, xmin = self.H, self.W, self.ymin, self.xmin; out = {k: [] for k in ('T', 'gt', 'go', 'gs', 'inside', 'imaged', 'outwin', 'dark', 'time', 'sT')}
        tm, se_ok, nominal, gas_ok = [], [], [], []
        for i, fn in enumerate(self.files):
            if progress: progress(i / max(self.n, 1), f'reading frame {i + 1}/{self.n}')
            m = np.load(fn); sh = self.drift[i]
            T = _to_canvas(m['T'], sh, H, W, ymin, xmin)
            imaged = _to_canvas(np.ones(m['T'].shape, np.float32), sh, H, W, ymin, xmin, 0, 0) > 0.5
            valid = _to_canvas((m['valid'] | m['au']).astype(np.float32), sh, H, W, ymin, xmin, 0, 0) > 0.5
            valid &= np.isfinite(T)
            ow = _to_canvas(m['outwin'].astype(np.float32), sh, H, W, ymin, xmin, 0, 0) > 0.5 if 'outwin' in m.files else np.zeros((H, W), bool)
            gt = _to_canvas(np.nan_to_num(m['gas_top']), sh, H, W, ymin, xmin); go = _to_canvas(np.nan_to_num(m['gas_other']), sh, H, W, ymin, xmin) if 'gas_other' in m.files else np.zeros((H, W), np.float32)
            dk = _to_canvas(m['dark'].astype(np.float32), sh, H, W, ymin, xmin, 0, 0) if 'dark' in m.files else np.zeros((H, W), np.float32)
            sT = _to_canvas(m['sT'], sh, H, W, ymin, xmin) if 'sT' in m.files else np.full((H, W), np.nan, np.float32)
            gs = _to_canvas(np.nan_to_num(m['gas_signed']), sh, H, W, ymin, xmin) if 'gas_signed' in m.files else gt
            se_ok.append(bool(m['se_measured']) if 'se_measured' in m.files else any(k.startswith('se_') for k in m.files))   # older runs: SE stored?
            nominal.append(bool(m['nominal']) if 'nominal' in m.files else False)
            gas_ok.append(bool(m['gas_measured']) if 'gas_measured' in m.files else se_ok[-1])     # no gap (contact over most of the field)
            rt = m['row_t']; tmap = _to_canvas(np.broadcast_to(rt[:, None], m['T'].shape).astype(np.float32), sh, H, W, ymin, xmin)
            inside = _bin(valid.astype(np.float32), b) > 0.5
            Tc = np.clip(np.nan_to_num(T), 0, self.T_cap)                 # no negative thickness; at most T_cap is drawn
            out['T'].append(np.where(inside, np.nan_to_num(_bin(np.where(valid, Tc, np.nan), b)), 0).astype(np.float32))
            out['gt'].append(np.where(inside, np.nan_to_num(_bin(np.where(valid, gt, np.nan), b)), 0).astype(np.float32))
            out['go'].append(np.where(inside, np.nan_to_num(_bin(np.where(valid, go, np.nan), b)), 0).astype(np.float32))
            out['gs'].append(np.where(inside, np.nan_to_num(_bin(np.where(valid, gs, np.nan), b)), 0).astype(np.float32))
            out['sT'].append(_bin(np.where(valid, sT, np.nan), b).astype(np.float32))
            out['inside'].append(inside); out['imaged'].append(_bin(imaged.astype(np.float32), b) > 0.5)
            out['outwin'].append((_bin(ow.astype(np.float32), b) > 0.5)); out['dark'].append(np.nan_to_num(_bin(np.where(valid, dk, np.nan), b)).astype(np.float32))
            out['time'].append(_bin(tmap, b).astype(np.float32)); tm.append(float(np.nanmean(rt)))
        r = {k: np.stack(v) for k, v in out.items()}; r['t_mean'] = np.array(tm); r['outwin'] &= r['imaged']
        r['se_ok'] = np.array(se_ok, bool); r['nominal'] = np.array(nominal, bool); r['gas_ok'] = np.array(gas_ok, bool)
        return r

    def _particles(self):
        fn = os.path.join(self.run_dir, 'particles.csv')
        if not os.path.exists(fn): return pd.DataFrame()
        P = pd.read_csv(fn)
        if not len(P) or 'x_nm' not in P: return pd.DataFrame()
        R = self.d_part / 2; z = P['z_nm'] if 'z_nm' in P else pd.Series(np.nan, index=P.index)
        P['z_measured'] = np.isfinite(z); P['depth_nm'] = self.t_mem[0] + np.where(np.isfinite(z), z, R)     # centre depth from the top of the volume
        P['z_up_nm'] = self.Zmax - P['depth_nm'] if hasattr(self, 'Zmax') else np.nan
        return P

    # ------------------------------------------------------------------------------------------------ 3-D per frame
    def frame(self, i, kinds=KINDS):
        m = self.m2; T, gt, go, inside, outwin = m['T'][i], m['gt'][i], m['go'][i], m['inside'][i], m['outwin'][i]
        a1 = np.full(T.shape, self.t_mem[0]); b1 = a1 + gt; b2 = b1 + T; b3 = b2 + go; b4 = b3 + self.t_mem[1]; d0 = self.depth0; out = {}
        flip = lambda v: v[::-1]
        if 'liquid' in kinds:
            liq = _fraction(b1, b2, d0, self.dz); liq[:, ~inside] = 0; out['liquid'] = flip(np.rint(255 * liq)).astype(np.uint8)
        if 'gas' in kinds:
            gas = _fraction(a1, b1, d0, self.dz) + _fraction(b2, b3, d0, self.dz); gas[:, ~inside] = 0; out['gas'] = flip(np.rint(255 * np.clip(gas, 0, 1))).astype(np.uint8)
        if 'walls' in kinds:
            w = np.maximum(_fraction(np.zeros_like(a1), a1, d0, self.dz), _fraction(b3, b4, d0, self.dz)); w[:, ~inside] = 0; w[:, outwin] = 1
            out['walls'] = flip((w > 0.5).astype(np.uint8))
        if 'contact' in kinds:
            c = np.zeros((self.nz, self.ny, self.nx), np.uint8); kt = min(int(self.t_mem[0] // self.dz), self.nz - 1)
            c[kt] = np.rint(255 * np.clip(np.where(inside, m['dark'][i], 0), 0, 1)).astype(np.uint8); out['contact'] = flip(c)
        if 'au' in kinds:
            au = np.zeros((self.nz, self.ny, self.nx), np.uint8); R = self.d_part / 2
            if len(self.particles):
                pb = (self.px[0] * self.bin, self.px[1] * self.bin); Zc = self.depth0 + self.dz / 2
                for _, r in self.particles[self.particles['frame'] == i].iterrows():
                    xc, yc, zc = float(r['x_nm']), float(r['y_nm']), float(r['depth_nm']); ix, iy = int(xc // pb[0]), int(yc // pb[1])
                    if not (0 <= ix < self.nx and 0 <= iy < self.ny): continue
                    y0, y1, x0, x1 = max(0, iy - 3), min(self.ny, iy + 4), max(0, ix - 3), min(self.nx, ix + 4)
                    Y, X = np.mgrid[y0:y1, x0:x1]; rr2 = ((X + 0.5) * pb[0] - xc) ** 2 + ((Y + 0.5) * pb[1] - yc) ** 2
                    for k in range(self.nz):
                        dzz = Zc[k] - zc
                        if abs(dzz) <= R: au[k, y0:y1, x0:x1][rr2 + dzz ** 2 <= R * R] = 1
                    au[int(min(self.nz - 1, max(0, zc // self.dz))), iy, ix] = 1
            out['au'] = flip(au)
        return out

    def cached(self, i):
        """all kinds of frame i, computed once and kept in a least-recently-used cache (LCSEM_CACHE_MB, default 1500 MB)"""
        with self._lock:
            if i in self._cache: self._cache.move_to_end(i); return self._cache[i]
        out = self.frame(i)
        with self._lock:
            self._cache[i] = out; per = sum(a.nbytes for a in out.values()) / 1e6
            while len(self._cache) > 1 and len(self._cache) * per > self.cache_mb: self._cache.popitem(last=False)
        return out

    def prefetch(self, i):
        """compute frame i in a background thread (the next time point while the current one is shown); at most one request
        is pending, so scrubbing the slider does not queue every frame it passes"""
        if not (0 <= i < self.n) or i in self._cache: return
        if getattr(self, '_pending', None) is not None and not self._pending.done(): return
        if self._pool is None:
            from concurrent.futures import ThreadPoolExecutor
            self._pool = ThreadPoolExecutor(1)
        self._pending = self._pool.submit(self.cached, i)

    def close(self):
        """stop the prefetch thread and free the frame cache"""
        if self._pool is not None: self._pool.shutdown(wait=False, cancel_futures=True); self._pool = None
        with self._lock: self._cache.clear()

    def dask(self, kind):
        import dask, dask.array as da
        f = dask.delayed(lambda i: self.cached(i)[kind], pure=True)
        return da.stack([da.from_delayed(f(i), shape=(self.nz, self.ny, self.nx), dtype=np.uint8) for i in range(self.n)])

    # ------------------------------------------------------------------------------------------------ 2-D maps and tables
    def map2d(self, key, i=None):
        """(T, ny, nx) float: 'thickness', 'sigma', 'gas_top', 'gas_other', 'contact', 'time'; with i: only frame i (ny, nx)"""
        k = {'thickness': 'T', 'sigma': 'sT', 'gas_top': 'gt', 'gas_other': 'go', 'contact': 'dark', 'time': 'time'}[key]
        a = (self.m2[k] if i is None else self.m2[k][i]).astype(np.float32)          # astype copies
        if key != 'time': a[~(self.m2['inside'] if i is None else self.m2['inside'][i])] = np.nan
        return a

    def classes(self, crit='icl'):
        """(T, ny, nx) class labels (argmax of the class probabilities, on the canvas; -1 outside) if the segmentation ran"""
        out = np.full((self.n, self.ny, self.nx), -1, np.int16); found = False
        for i, tag in enumerate(self.tags):
            pf = os.path.join(self.run_dir, f'{tag}_class_prob_{crit}.npy')
            if not os.path.exists(pf): continue
            pr = np.load(pf); pc = np.stack([_bin(_to_canvas(p_, self.drift[i], self.H, self.W, self.ymin, self.xmin), self.bin) for p_ in pr])
            ok = np.isfinite(pc).all(axis=0); lab = np.where(ok, np.argmax(np.nan_to_num(pc, nan=-1), axis=0), -1); out[i] = lab; found = True
        return out if found else None

    def points(self):
        """particle points for napari: (N, 4) array (t, z_up, y, x) in nm (z_up = height above the bottom of the volume)"""
        if not len(self.particles): return np.zeros((0, 4))
        P = self.particles; return np.stack([P['frame'].values, (self.Zmax - P['depth_nm']).values, P['y_nm'].values, P['x_nm'].values], axis=1).astype(float)

    def tracks(self):
        """particle tracks for napari: (N, 5) (track, t, z_up, y, x)"""
        P = self.particles
        if not len(P) or 'track' not in P: return np.zeros((0, 5))
        Q = P[P['track'] >= 0].sort_values(['track', 'frame'])
        return np.stack([Q['track'].values, Q['frame'].values, (self.Zmax - Q['depth_nm']).values, Q['y_nm'].values, Q['x_nm'].values], axis=1).astype(float)

    def time_labels(self):
        if len(self.summary) and 'time_end' in self.summary: return [str(v) for v in self.summary['time_end']]
        return [f'{t:.1f} s' for t in self.times]

    def series(self):
        """per-frame time series for the charts: liquid and gas volume, SE contact area, median thickness, dose. Volumes and areas
        are summed over the field imaged in every frame (drift moves the edges of the field; summing over each frame's own field
        would add that to the time series), unless that common field is under half the mean field, then over each frame's field
        (column 'field' says which; 'field_um2' is its area). The gas volume is the unclipped sum of (gap - thickness) around the
        contact regions (lcsem.pipeline: unbiased by noise); NaN in frames without SE. SE-only runs: volumes NaN (nominal)."""
        pa = (self.px[0] * self.bin) * (self.px[1] * self.bin) / 1e6          # um^2 per binned pixel
        m = self.m2; ins = m['inside']; common = ins.all(axis=0)
        use_common = self.n > 1 and common.sum() >= 0.5 * float(np.mean(ins.sum(axis=(1, 2))))
        mk = [common if use_common else ins[i] for i in range(self.n)]
        se_ok = m.get('se_ok', np.ones(self.n, bool)); nominal = m.get('nominal', np.zeros(self.n, bool)) | ('SE only' in (self.mode or ''))
        gs = m.get('gs', m['gt'])
        liq = np.array([(m['T'][i][mk[i]]).sum() * pa / 1e3 for i in range(self.n)])
        gas = np.array([((gs[i] + m['go'][i])[mk[i]]).sum() * pa / 1e3 for i in range(self.n)])
        con = np.array([(m['dark'][i][mk[i]]).sum() * pa for i in range(self.n)])
        gas_ok = m.get('gas_ok', se_ok)
        gas[~se_ok | ~gas_ok] = np.nan; con[~se_ok] = np.nan; liq[nominal] = np.nan; gas[nominal] = np.nan
        Tmed = [float(np.median(m['T'][i][ins[i]])) if ins[i].any() and not nominal[i] else np.nan for i in range(self.n)]
        S = pd.DataFrame(dict(frame=np.arange(self.n), time_s=self.times, liquid_um3=liq, gas_um3=gas, contact_um2=con,
                              field_um2=[mk[i].sum() * pa for i in range(self.n)], field=['common' if use_common else 'per frame'] * self.n,
                              area_um2=[ins[i].sum() * pa for i in range(self.n)], T_median_nm=Tmed, se_measured=se_ok, nominal=nominal))
        for c in ('dose_frame_e_nm2', 'dose_cum_e_nm2', 'dose_cum_MGy'):
            S[c] = self.summary[c].values[:self.n] if c in self.summary and len(self.summary) >= self.n else np.nan
        # statistical sd of the gas volume (pipeline: correlated residual of the wet surroundings; whole frame); NaN if unknown
        sd = self.summary['gas_top_volume_sd_um3'].values[:self.n].astype(float) if 'gas_top_volume_sd_um3' in self.summary and len(self.summary) >= self.n else np.full(self.n, np.nan)
        S['gas_sd_um3'] = np.where(np.isfinite(S['gas_um3'].values), sd, np.nan)
        fl = self.summary['se_contact_flag'].fillna('').astype(str).values[:self.n] if 'se_contact_flag' in self.summary and len(self.summary) >= self.n else [''] * self.n
        S['se_contact_flag'] = fl
        return S

    def calibration_text(self):
        """one line: how the thickness scale was set (shown in the viewer and the export READMEs)"""
        if 'SE only' in (self.mode or ''): return 'SE only: no thickness measured (nominal 3-D model)'
        cm = self.info.get('calibration_modes') or {c: str(d.get('note', '')).split(':')[0] for c, d in (self.info.get('calibration') or {}).items()}
        if not cm: return 'calibration: unknown'
        t = 'calibration ' + ', '.join(f'{c} {mm}' for c, mm in cm.items())
        if any('flat' in str(mm) for mm in cm.values()):
            T = (self.cfg.get('references') or {}).get('flat') or {}
            t += f' - ASSUMED flat field {T.get("T_nm", "?")} nm: absolute thickness scales with this assumption'
        elif not any('empty' in str(mm) for mm in cm.values()): t += ' (no empty-cell check of the detector-model scale)'
        return t

    def se_text(self, i):
        """one line on the SE contact of frame i: the detection floor (SE contrast below it is not detected: N2) and the flag for
        contact over half of the field"""
        S = self.summary
        if not len(S) or 'se_detection_floor' not in S: return ''
        r = S.iloc[min(i, len(S) - 1)]; fl = r.get('se_detection_floor', np.nan)
        if not np.isfinite(fl): return 'SE contact: not measured in this frame (no SE)'
        t = f'SE contact detected where the SE is >= {100 * fl:.0f} % darker than the wet background (detection limit)'
        flag = r.get('se_contact_flag', '')
        if isinstance(flag, str) and flag: t += f'\nCHECK: {flag}'
        return t

    def dose_text(self, i):
        S = self.summary
        if 'dose_frame_e_nm2' not in S or not len(S) or not np.isfinite(S['dose_frame_e_nm2'].iloc[min(i, len(S) - 1)]): return 'dose: probe current not given'
        r = S.iloc[min(i, len(S) - 1)]
        return f'dose {r["dose_frame_e_nm2"]:.3g} e/nm2 per frame, {r["dose_cum_e_nm2"]:.3g} e/nm2 so far (~{r["dose_cum_MGy"]:.3g} MGy)'
