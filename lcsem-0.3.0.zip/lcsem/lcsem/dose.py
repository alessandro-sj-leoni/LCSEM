"""Electron dose bookkeeping for SEM series and movies of liquid cells.

Per frame (the scanned field, uniform raster):
    fluence   D = I t_f / (e A)                     electrons per nm^2 (I probe current, t_f frame time, A scanned area)
    rate      D / t_f                               electrons per nm^2 per s, averaged over the frame (the local rate while the
                                                    probe dwells on a pixel is (frame time / dwell time) times higher)
    absorbed  D_abs = D (S / rho)                   Gy in water at the top of the liquid, to first order: the collision stopping
                                                    power at the beam energy (Joy & Luo 1989, as the Monte Carlo engine), not
                                                    including backscattered electrons, the slowing down along the path and
                                                    secondary electrons leaving the volume; 1 e/nm^2 is about 0.26 MGy at
                                                    15 keV and 0.14 MGy at 30 keV.
The cumulative fluence counts every frame scanned from the first one (movies: all raw frames up to the time point, also the
frames skipped by a frame step); exposures outside the recorded frames (focusing, surveys, references) are not known and
not included. Radiolysis of water produces H2 and other species at these doses and can itself nucleate bubbles (Schneider
et al., J. Phys. Chem. C 118, 22373 (2014); Grogan et al., Nano Lett. 14, 359 (2014)); report doses with every measurement.
"""
from __future__ import annotations
import numpy as np

E_CHARGE = 1.602176634e-19

def water_stopping_MeV_cm2_g(E_keV):
    """Joy-Luo collision stopping power of water (mass stopping power, MeV cm^2/g) at E keV"""
    E = float(E_keV); tot = 0.0
    for c, ZA, J in ((2 * 1.008 / 18.015, 1.0 / 1.008, 0.0192), (15.999 / 18.015, 8.0 / 15.999, 0.095)):
        tot += c * ZA * np.log(1.166 * (E + 0.85 * J) / J)
    return 7.85e4 * tot / E / 1000.0

def frame_fluence(current_pA, frame_s, ny, nx, px_nm):
    """electrons per nm^2 deposited by one frame over its scanned field (nan if the current is not known)"""
    if not current_pA or not frame_s: return float('nan')
    area = float(ny) * float(nx) * float(px_nm[0]) * float(px_nm[1])
    return float(current_pA) * 1e-12 * float(frame_s) / E_CHARGE / area

def absorbed_Gy(fluence_e_nm2, E_keV):
    """first-order absorbed dose in water (Gy) for a fluence in electrons per nm^2 at E keV"""
    return float(fluence_e_nm2) * 1e14 * water_stopping_MeV_cm2_g(E_keV) * 1.602176634e-10

def table(frames_s, frame_index, current_pA, ny, nx, px_nm, E_keV, n_raw=None):
    """per time point: fluence of its data (all n_raw raw frames averaged into it: a temporal window of W frames gives W
    frame fluences), cumulative fluence up to the end of its last raw frame (all frames scanned up to it; frame_index = the
    raw number of the first frame of each time point, e.g. movie frame numbers, or None for consecutive scans) and the
    first-order absorbed dose"""
    fl1 = np.array([frame_fluence(current_pA, f, ny, nx, px_nm) for f in frames_s])
    w = np.ones(len(fl1)) if n_raw is None else np.maximum(np.asarray(n_raw, float), 1.0)
    fl = fl1 * w
    if frame_index is not None and np.all(np.isfinite(fl1)):
        cum = (np.asarray(frame_index, float) + w) * fl1
    else:
        cum = np.cumsum(fl)
    return dict(dose_frame_e_nm2=fl, dose_cum_e_nm2=cum, dose_rate_e_nm2_s=fl1 / np.maximum(np.asarray(frames_s, float), 1e-12),
                dose_cum_MGy=np.array([absorbed_Gy(c, E_keV) / 1e6 if np.isfinite(c) else np.nan for c in cum]), frames_averaged=w)
