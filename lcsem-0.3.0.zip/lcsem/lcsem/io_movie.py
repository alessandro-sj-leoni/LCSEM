"""Movies and image stacks as time series.

Readers: multi-frame TIFF / OME-TIFF (tifffile), AVI / MP4 / MOV / MKV (imageio-ffmpeg), and folders of single images
(TIFF / PNG, in natural order: img2 before img10). Each detector is either in its own file, or several detectors are packed
into one file: side by side, one above the other, or interleaved frame by frame (SE, BSE, SE, BSE, ...; a multi-channel
TIFF hyperstack TCYX, e.g. a Fiji composite, is the interleaved layout with parts = number of channels). Colour frames are
converted to grey by the mean of the colour channels (or one chosen channel). An optional crop is applied to the whole
frame before it is split into parts (so a data bar or a separator line can be cut away first).

Every movie frame becomes an `io_jeol.Scan` whose channels are `MovieFrame`s with their own end-of-frame time and frame
duration, so `lcsem.pipeline.run(cfg, out_dir, scans=...)` processes movies exactly like JEOL image series (per-line times,
drift, calibration, particles, segmentation, volumes). Options: a frame range and stride, and a temporal window (the mean of
`window` consecutive frames per time point, for low-dose movies).

    from lcsem.io_movie import MovieSource, movie_scans
    src = {'SE': MovieSource('run_se.avi'), 'BSE': MovieSource('run_bse.avi')}
    scans = movie_scans(src, frame_time_s=0.5, t0_s=10 * 3600, mag=12000, kv=15)
"""
from __future__ import annotations
import os, glob, dataclasses, numpy as np

VIDEO_EXT = ('.avi', '.mp4', '.mov', '.mkv', '.wmv', '.m4v', '.mpg', '.mpeg')
IMAGE_EXT = ('.tif', '.tiff', '.png', '.bmp', '.jpg', '.jpeg')
SIGNAL = {'BSE': 'BED_C', 'SE': 'UED', 'SE_ET': 'LED', 'STEM': 'STEM'}

def _natural_key(s):
    import re
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r'(\d+)', os.path.basename(s))]

def _to_grey(a, colour=None):
    a = np.asarray(a)
    if a.ndim == 3 and a.shape[-1] in (3, 4):
        a = a[..., :3].astype(np.float32)
        return a[..., int(colour)] if colour is not None else a.mean(axis=-1)
    return a.astype(np.float32)

class _Reader:
    """random access to the raw frames of one file or folder"""
    def __init__(self, path, colour=None, cache_mb=2048):
        self.path = path; self.colour = colour; self.kind = None; self.fps = None; self.meta = {}
        if os.path.isdir(path):
            files = sorted((f for f in glob.glob(os.path.join(glob.escape(path), '*')) if f.lower().endswith(IMAGE_EXT)), key=_natural_key)
            if not files: raise ValueError(f'no images in {path}')
            self.kind, self.files, self.n = 'folder', files, len(files)
            import imageio.v3 as iio3
            self.dtype = np.asarray(iio3.imread(files[0])).dtype
        elif path.lower().endswith(('.tif', '.tiff')):
            import tifffile
            self.kind = 'tiff'; self._tf = tifffile.TiffFile(path); s = self._tf.series[0]; shp = s.shape
            ax = s.axes                                          # e.g. 'TYX', 'IYX', 'YX', 'TYXS', 'ZYX', 'TCYX'
            self._arr = None; self.dtype = s.dtype; self.axes = ax
            self.channels = int(shp[ax.index('C')]) if 'C' in ax else 1
            try: self._arr = s.asarray(out='memmap')             # uncompressed: memory-mapped, no copy
            except Exception: self._arr = None
            if self._arr is None and np.prod(shp) * s.dtype.itemsize < cache_mb * 2 ** 20: self._arr = s.asarray()
            self._axes = ax; self._shape = shp
            yx = [i for i, a in enumerate(ax) if a in 'YX']; lead = [i for i, a in enumerate(ax) if a not in 'YXS']
            self.n = int(np.prod([shp[i] for i in lead])) if lead else 1
            if self._arr is not None: self._flat = self._arr.reshape((self.n,) + tuple(shp[i] for i in range(len(shp)) if i not in lead))
            try:
                d = self._tf.imagej_metadata or {}
                if d.get('finterval'): self.fps = 1.0 / float(d['finterval'])
                self.meta.update({k: d[k] for k in ('finterval', 'unit', 'spacing') if k in d})
            except Exception: pass
            if self.fps is None and self._tf.ome_metadata:           # OME-TIFF: Pixels TimeIncrement (seconds unless stated)
                import re
                m = re.search(r'TimeIncrement="([0-9.eE+-]+)"', self._tf.ome_metadata); u = re.search(r'TimeIncrementUnit="([^"]+)"', self._tf.ome_metadata)
                if m and float(m.group(1)) > 0:
                    f = {'s': 1.0, 'ms': 1e-3, 'µs': 1e-6, 'us': 1e-6, 'min': 60.0}.get(u.group(1) if u else 's', 1.0); self.fps = 1.0 / (float(m.group(1)) * f)
        elif path.lower().endswith(VIDEO_EXT):
            import imageio.v2 as iio
            self.kind = 'video'; self._rd = iio.get_reader(path, 'ffmpeg'); md = self._rd.get_meta_data(); self.meta = dict(md)
            self.fps = md.get('fps'); n = md.get('nframes'); self.dtype = np.dtype(np.uint8); self._cache = None; self._lru = {}
            if not n or n == float('inf'):
                try: n = self._rd.count_frames()
                except Exception: n = None
            if n is None: raise ValueError(f'cannot count the frames of {path}')
            self.n = int(n); self._cache_ok = self.n * np.prod(md.get('size', (1024, 1024))) * 4 < cache_mb * 2 ** 20
        else:
            raise ValueError(f'unsupported file type: {path}')

    def raw(self, i):
        if i < 0 or i >= self.n: raise IndexError(i)
        if self.kind == 'folder':
            import imageio.v3 as iio3
            return _to_grey(iio3.imread(self.files[i]), self.colour)
        if self.kind == 'tiff':
            if self._arr is not None: return _to_grey(self._flat[i], self.colour)
            return _to_grey(self._tf.pages[i].asarray(), self.colour)
        if self._cache is not None: return self._cache[i]
        if i in self._lru: return self._lru[i]
        a = _to_grey(self._rd.get_data(i), self.colour)                    # decoded on demand (sequential access is fast)
        self._lru[i] = a
        if len(self._lru) > (self.n if self._cache_ok else 16): self._lru.pop(next(iter(self._lru)))
        return a

class MovieSource:
    """one detector's frames: a file or folder, optionally one part of a packed layout.
    layout: 'single', 'side_by_side' (parts left to right), 'top_bottom' (parts top to bottom), 'interleaved' (frame k of
    part p is raw frame k * parts + p; also a TCYX hyperstack with parts = channels). crop: (y0, y1, x0, x1) applied to the
    whole raw frame before splitting (e.g. to remove a data bar or a separator)."""
    def __init__(self, path, layout='single', part=0, parts=2, colour=None, crop=None, reader=None):
        self.path = path; self.layout = layout; self.part = int(part); self.parts = int(parts) if layout != 'single' else 1
        self.crop = crop; self.r = reader or _Reader(path, colour)
    def __len__(self):
        return self.r.n // self.parts if self.layout == 'interleaved' else self.r.n
    @property
    def fps(self):
        f = self.r.fps
        return (f / self.parts) if (f and self.layout == 'interleaved') else f
    def get(self, i):
        a = self.r.raw(i * self.parts + self.part) if self.layout == 'interleaved' else self.r.raw(i)
        if self.crop: y0, y1, x0, x1 = self.crop; a = a[y0:y1, x0:x1]
        if self.layout == 'side_by_side':
            w = a.shape[1] // self.parts; a = a[:, self.part * w:(self.part + 1) * w]
        elif self.layout == 'top_bottom':
            h = a.shape[0] // self.parts; a = a[self.part * h:(self.part + 1) * h]
        return np.ascontiguousarray(a, np.float32)
    def shape(self):
        return self.get(0).shape

class AveragedSource:
    """mean of `window` consecutive frames of a source per output frame (frames start, start + step, ...)"""
    def __init__(self, src, window=1):
        self.src = src; self.window = max(1, int(window))
    def __len__(self): return len(self.src) - self.window + 1
    def get(self, i):
        return np.mean([self.src.get(i + k) for k in range(self.window)], axis=0).astype(np.float32) if self.window > 1 else self.src.get(i)

class ArraySource:
    """frames already in memory (T, Y, X) - e.g. the output of a stack denoiser"""
    def __init__(self, arr, fps=None):
        self.a = arr; self.fps = fps
    def __len__(self): return len(self.a)
    def get(self, i): return np.asarray(self.a[i], np.float32)

@dataclasses.dataclass
class MovieFrame:
    """a movie frame dressed as an io_jeol.Frame (time_s = end of the frame, seconds since midnight)"""
    path: str
    time_s: float
    signal: str
    mag: float
    stage: tuple
    probe: str = ''
    kv: float = 0.0
    name: str = ''
    frame_s: float = 1.0
    index: int = 0
    src: object = None
    support_s: float = 0.0                 # time spanned by the frames averaged into this time point (0 = one frame)
    raw_src: object = None                 # the undenoised frames when src holds stack-denoised ones (photometry, noise)
    movie_index: int = -1                  # frame number in the movie file (for names and the cumulative dose)
    denoised_mask: object = None           # series denoising: pixels that were denoised (the others lie outside the block's common field)
    def load(self) -> np.ndarray:
        return self.src.get(self.index)
    def load_raw(self) -> np.ndarray:
        return (self.raw_src or self.src).get(self.index)

def probe(path, n_check=40):
    """description of a movie file or folder without decoding all of it: number of frames, frame shape, frame rate (None if
    the file does not store it), the raw data type and a suggested bit depth, grey range of the first frame, axes (TIFF), and
    near-duplicate frames (screen recordings of a slow scan repeat frames: then use 'step' = suggested_step)"""
    r = _Reader(path); a = r.raw(0); dt = np.dtype(getattr(r, 'dtype', a.dtype))
    bits = 8 if dt.itemsize == 1 else (16 if dt.kind in 'ui' and dt.itemsize == 2 else (32 if dt.kind in 'ui' else None))
    d = dict(path=path, kind=r.kind, n_frames=r.n, shape=tuple(a.shape), fps=r.fps, dtype=str(dt), bits=bits, min=float(a.min()), max=float(a.max()),
             axes=getattr(r, 'axes', ''), channels=getattr(r, 'channels', 1))
    # near-duplicate consecutive frames: mean |difference| well below that of two independent noisy frames (2 sigma / sqrt(pi)).
    # A screen recording of a slow scan repeats each SEM frame many times: the check is extended (up to 10 x n_check frames)
    # until at least three complete runs of repeats are seen, so the suggested step is not capped by the frames checked.
    k = min(r.n, n_check); dup = []
    if k >= 3:
        from .denoise import _sigma_mad
        sig = _sigma_mad(a); prev = a; i = 1; kmax = min(r.n, 10 * n_check)
        def _runs(dd):
            out, c = [], 1
            for x in dd:
                if x: c += 1
                else: out.append(c); c = 1
            return out, c                                                # complete runs, the run still open at the end
        while i < kmax:
            b = r.raw(i); dup.append(float(np.mean(np.abs(b - prev))) < 0.3 * 2 * sig / np.sqrt(np.pi)); prev = b; i += 1
            if i >= k:
                done, _ = _runs(dup)
                if np.mean(dup) <= 0.3 or len(done) >= 4: break         # few repeats, or enough complete runs (the first may be cut)
        done, last = _runs(dup); full = done[1:] if len(done) > 1 else done   # the first run may have started before frame 0
        d['duplicate_fraction'] = float(np.mean(dup)); d['frames_checked'] = i
        if d['duplicate_fraction'] > 0.3:
            d['suggested_step'] = int(np.median(full)) if full else int(last)
            if not full: d['suggested_step_note'] = f'at least {last}: no complete run of repeated frames in the {i} frames checked'
        else: d['suggested_step'] = 1
    return d

def movie_scans(sources: dict, frame_time_s=None, fps=None, t0_s=0.0, mag=0.0, kv=15.0, stage=(0.0, 0.0, 0.0, 0.0, 0.0),
                start=0, stop=None, step=1, window=1, primary=None, signals=None, name='movie'):
    """Scans from movies: sources = {'SE': MovieSource, 'BSE': MovieSource, 'STEM': MovieSource} (any subset).
    Frame duration: frame_time_s, else 1 / fps (argument, else the file's frame rate, else 1 s). With window > 1 each time
    point is the mean of `window` consecutive frames; its row clock is that of the mean acquisition time of each row."""
    srcs = {c: (AveragedSource(s, window) if window > 1 else s) for c, s in sources.items() if s is not None}
    if not srcs: raise ValueError('no movie sources')
    n = min(len(s) for s in srcs.values()); stop = n if stop is None else min(int(stop), n)
    f0 = next(iter(sources.values())); rate = fps or getattr(f0, 'fps', None)
    ft = float(frame_time_s) if frame_time_s else (1.0 / float(rate) if rate else 1.0)
    prim = primary or next((c for c in ('BSE', 'STEM', 'SE') if c in srcs), list(srcs)[0])
    sig = dict(SIGNAL); sig.update(signals or {})
    from .io_jeol import Scan
    out = []
    for k, i in enumerate(range(int(start), stop, max(1, int(step)))):
        # a window of W frames: every row is recorded W times; its mean time is that of one frame ending (W - 1) / 2 frames
        # before the last one, so the per-row clock keeps the single-frame duration (the window's span is in `support_s`)
        t_end = t0_s + (i + window) * ft - 0.5 * (window - 1) * ft
        ch = {c: MovieFrame(path=getattr(getattr(s, 'src', s), 'path', '') or name, time_s=t_end, signal=sig.get(c, c), mag=mag, stage=tuple(stage),
                            kv=kv, name=f'f{i:05d}', frame_s=ft, index=i, src=s, support_s=ft * window, movie_index=i) for c, s in srcs.items()}      # run tags: <name>_<k>_f<movie frame>
        out.append(Scan(channels=ch, primary=prim, index=k))
    return out

def register_stack(frames, upsample=20, ref=0, particles=True, max_step_px=20, baselines=(1,), refine=0, roi=None):
    """rigid drift of a stack (T, Y, X) referred to frame `ref`.
    1. Neighbour chain: the shift between consecutive frames by cross-correlation of band-passed (difference of Gaussians,
       2-20 px), Tukey-windowed frames with sub-pixel refinement (Guizar-Sicairos et al. 2008); particle voting (Groth 1986)
       only when the correlation gives an implausibly large step. Optional longer baselines (e.g. (1, 2, 4, 8, 16)) combined
       by least squares as in cryo-EM motion correction (Li et al. 2013), kept only where consistent with the chain.
    2. Optional template refinement (`refine` passes): every frame registered again to the temporal median of the aligned
       frames. Experimental: on the synthetic movies (no static features) it made the error larger, so it is off by default.
    roi = (y0, y1, x0, x1): measure the drift only inside a region that does not change (e.g. the edge of the window frame,
    a scratch, particles stuck to a membrane). Registration needs static features: a chain follows whatever moves, and on a
    synthetic movie in which everything moves or changes (bubbles, diffusing particles) it drifted by 2-6 px over 40 frames.
    Returns the shifts (T, 2) in pixels (dy, dx) that register each frame onto frame `ref` (apply them with apply_shifts)."""
    from scipy.ndimage import gaussian_filter
    from scipy.signal.windows import tukey
    from skimage.registration import phase_cross_correlation
    from .imageproc import detect_particles, register_by_particles
    T = len(frames)
    if T < 2: return np.zeros((T, 2))
    if roi is not None:
        y0, y1, x0, x1 = [int(v) for v in roi]; frames = [np.asarray(f, np.float32)[y0:y1, x0:x1] for f in frames]
    A0 = np.asarray(frames[0], np.float32); ny, nx = A0.shape; win = np.outer(tukey(ny, 0.25), tukey(nx, 0.25))
    pre, blobs = [], []
    for i in range(T):
        a = np.asarray(frames[i], np.float32); b = gaussian_filter(a, 2.0) - gaussian_filter(a, 20.0); pre.append((b - b.mean()) * win)
        if particles:
            try: blobs.append(detect_particles(a, None, 1.5, 6.0, 6.0, sat_level=float(a.max()) + 1))
            except Exception: blobs.append(np.zeros((0, 3)))
        else: blobs.append(None)
    def pair(i, j, k):
        d = np.asarray(phase_cross_correlation(pre[j], pre[i], upsample_factor=upsample, normalization=None)[0], float)
        if np.hypot(*d) <= max_step_px * k or not particles: return d                  # sub-pixel; particle voting is only a fallback
        if blobs[i] is not None and len(blobs[i]) >= 3 and len(blobs[j]) >= 3:          # (integer particle positions: +-0.5 px)
            r = register_by_particles(blobs[j], blobs[i], max_shift=4 * max_step_px * k, bin_px=2, refine_px=3)
            if r is not None and r[2] >= 3: return np.array(r[:2], float)
        return d
    chain = np.zeros((T, 2)); rows, rhs = [], []
    for i in range(1, T):                                                        # 1. neighbour chain
        d = pair(i, i - 1, 1); chain[i] = chain[i - 1] + d; rows.append((i, i - 1)); rhs.append(d)
    for k in baselines:                                                          # 2. longer baselines, kept only if consistent
        if k == 1: continue
        for i in range(k, T):
            j = i - k; d = pair(i, j, k)
            if np.hypot(*(d - (chain[i] - chain[j]))) <= 1.0 + 0.25 * np.sqrt(k) * 2: rows.append((i, j)); rhs.append(d)
    M = np.zeros((len(rows) + 1, T)); R = np.zeros((len(rows) + 1, 2))
    for n, ((i, j), d) in enumerate(zip(rows, rhs)): M[n, i] = 1; M[n, j] = -1; R[n] = d
    M[-1, 0] = 1                                                                 # anchor (removed below)
    w = np.ones(len(M))
    if len(rows) == T - 1: S = chain.copy()                                      # chain only: no least squares needed
    else:
        for _ in range(3):                                                       # least squares with Huber-type re-weighting
            S = np.linalg.lstsq(M * w[:, None], R * w[:, None], rcond=None)[0]
            res = np.hypot(*(M @ S - R).T); c = 1.5 * max(np.median(res[:-1]), 0.1); w = np.where(res <= c, 1.0, c / np.maximum(res, 1e-9)); w[-1] = 10.0
    if refine and T >= 3:                                                        # 2. median-template refinement
        from scipy.ndimage import shift as nd_shift
        bp = [np.asarray(frames[i], np.float32) for i in range(T)]
        bp = [gaussian_filter(a, 2.0) - gaussian_filter(a, 20.0) for a in bp]
        for _ in range(int(refine)):
            al = np.stack([nd_shift(b, S[i] - S[0], order=1, mode='constant', cval=np.nan) for i, b in enumerate(bp)])
            tmpl = np.nan_to_num(np.nanmedian(al, axis=0)); tmpl = (tmpl - tmpl.mean()) * win
            for i in range(T):
                a = np.nan_to_num(al[i]); r = np.asarray(phase_cross_correlation(tmpl, (a - a.mean()) * win, upsample_factor=upsample, normalization=None)[0], float)
                if np.hypot(*r) <= max_step_px: S[i] = S[i] + r
    return S - S[ref]

def register_movie(get, indices, ref=0, upsample=20, max_step_px=20, roi=None, should_abort=None, progress=None):
    """drift of the time points `indices` of a movie, measured on EVERY frame between the first and the last of them and
    subsampled afterwards (chaining only the analysed frames of a movie read with a frame step makes each link span more
    scene change: on the synthetic movie the error at step 4 was 1.7-3.7 times that at step 1 - internal review, round 2).
    get(i) returns movie frame i; frames are streamed (two in memory). Same neighbour chain as register_stack (band-passed,
    Tukey-windowed phase correlation, Guizar-Sicairos et al. 2008), optionally inside roi = (y0, y1, x0, x1). Returns the
    shifts (len(indices), 2) that register each time point onto time point `ref` (a position in `indices`)."""
    from scipy.ndimage import gaussian_filter
    from scipy.signal.windows import tukey
    from skimage.registration import phase_cross_correlation
    idx = [int(i) for i in indices]
    if len(idx) < 2: return np.zeros((len(idx), 2))
    i0, i1 = min(idx), max(idx); win = None; prev = None; chain = {i0: np.zeros(2)}; acc = np.zeros(2)
    def pre(a):
        nonlocal win
        a = np.asarray(a, np.float32)
        if roi is not None: y0, y1, x0, x1 = [int(v) for v in roi]; a = a[y0:y1, x0:x1]
        if win is None: win = np.outer(tukey(a.shape[0], 0.25), tukey(a.shape[1], 0.25))
        b = gaussian_filter(a, 2.0) - gaussian_filter(a, 20.0); return (b - b.mean()) * win
    for k, i in enumerate(range(i0, i1 + 1)):
        if should_abort is not None and should_abort():
            from .pipeline import Aborted; raise Aborted('aborted by the user')
        if progress and k % 50 == 0: progress(k / max(i1 - i0, 1), f'drift: frame {i} of {i0}-{i1}')
        cur = pre(get(i))
        if prev is not None:
            d = np.asarray(phase_cross_correlation(prev, cur, upsample_factor=upsample, normalization=None)[0], float)
            if np.hypot(*d) > max_step_px: d = np.zeros(2)                     # implausible jump between neighbours: no step
            acc = acc + d; chain[i] = acc.copy()
        prev = cur
    S = np.array([chain[i] for i in idx]); return S - S[ref % len(idx)]

def apply_shifts(frames, shifts, order=1):
    from scipy.ndimage import shift as nd_shift
    return np.stack([nd_shift(np.asarray(f, np.float32), s, order=order, mode='nearest') for f, s in zip(frames, shifts)])
