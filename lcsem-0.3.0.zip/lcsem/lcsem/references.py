"""Reference acquisitions: dark (beam blanked), empty cell, full cell, flat field, particle standard, probe current.

Config (all optional):
  "references": {
     "dark":  {"files": ["dark_001.tif", ...]}            or {"time_from": "10:10:00", "time_to": "10:11:00"}
     "empty": {"files": [...]}                             an empty (dry) K-kit, same kV / current / detector settings
     "full":  {"files": [...]}                             this cell completely filled, before any gas: local gap map
     (movies: {"movie": {"BSE": "ref.tif", ...}, "layout": "side_by_side", "parts": 2, "part": {"BSE": 1}, "crop": ""} -
      every frame of the file, read with the movie's layout and crop)
     "flat":  {"frames": "all" | [0, 1], "T_nm": 200}      flat field of the series itself with an assumed thickness
     "particles": {"diameter_nm": 60, "cv": 0.05, "material": "Au"}
     "current": {"pA": 120.0} or {"csv": "current_log.csv"} (columns time_s or time (hh:mm:ss), current_pA)
  }
Files are JEOL images (NAME.tif + NAME.txt); each is assigned to a channel by its CM_SIGNAL. Reference levels are robust
means over unclipped pixels (8-bit data clipped at 0 is flagged: raise the brightness so that the dark level is above 0).
"""
from __future__ import annotations
import os, numpy as np, pandas as pd
from . import io_jeol as J

def _frames_for(spec, folder, prefix='', channels=None):
    if not spec: return []
    out = []
    if spec.get('movie'):                              # {channel: movie or image file}: every frame of it is a reference frame
        from .io_movie import MovieSource, MovieFrame
        lay = spec.get('layout', 'single'); crop = tuple(int(v) for v in str(spec.get('crop') or '').replace(',', ' ').split()) or None
        for c, f in spec['movie'].items():
            if not f: continue
            src = MovieSource(f, crop=crop) if lay == 'single' else MovieSource(f, layout=lay, part=int((spec.get('part') or {}).get(c, 0)), parts=int(spec.get('parts', 2)), crop=crop)
            sig = (channels or {}).get(c) or {}; s = sig.get('signal', c) if sig else c; s = s[0] if isinstance(s, list) else s
            n = min(len(src), int(spec.get('max_frames', 50)))
            out += [MovieFrame(path=f, time_s=0.0, signal=s, mag=0.0, stage=(0, 0, 0), name=f'{os.path.basename(f)}_{i}', index=i, src=src) for i in range(n)]
    if spec.get('files'):
        for f in spec['files']:
            p = f if os.path.isabs(f) else os.path.join(folder, f)
            if not p.endswith('.tif'): p += '.tif'
            m = J.read_meta(p[:-4] + '.txt') if os.path.exists(p[:-4] + '.txt') else {}
            out.append(J.Frame(path=p, time_s=J.hms_to_s(m['CM_TIME']) if 'CM_TIME' in m else 0.0, signal=m.get('CM_SIGNAL', spec.get('signal', '?')),
                               mag=float(m.get('CM_MAG', 0)), stage=(0, 0, 0), kv=float(m.get('CM_ACCEL_VOLT', 0)), name=os.path.basename(p)[:-4]))
    if spec.get('time_from'):
        t0, t1 = J.hms_to_s(spec['time_from']), J.hms_to_s(spec['time_to'])
        out += [f for f in J.scan_folder(folder, prefix) if t0 <= f.time_s <= t1]
    return out

def channel_of(frame, channels: dict):
    for name, ch in channels.items():
        if not ch: continue
        sig = ch['signal'] if isinstance(ch['signal'], list) else [ch['signal']]
        if frame.signal in sig: return name
    return None

def level(frames, lo=0.0, hi=255.0, valid=None):
    """mean level of reference frames corrected for 8-bit clipping (censored normal, Cohen 1959):
    (mean, standard error incl. frame-to-frame scatter, clipped fraction)"""
    from .imageproc import noise_sigma_censored, unclip_mean
    ms, clip = [], []
    for f in frames:
        a = f.load(); m = np.ones(a.shape, bool) if valid is None else valid
        c = (a <= lo) | (a >= hi); clip.append(float(c[m].mean()))
        if clip[-1] > 0.002:
            sig = noise_sigma_censored(a, m, lo, hi); ms.append(float(unclip_mean(np.array([a[m].mean()]), max(sig, 0.5), lo, hi)[0]))
        else:
            ms.append(float(a[m].mean()))
    ms = np.array(ms, float); ms = ms[np.isfinite(ms)]
    if ms.size == 0: return np.nan, np.nan, 1.0
    se = float(np.std(ms, ddof=1) / np.sqrt(ms.size)) if ms.size > 1 else 0.02 * abs(ms[0]) + 0.1
    return float(ms.mean()), se, float(np.mean(clip))

def load_references(cfg):
    hi = float(2 ** int(cfg.get('bits', 8)) - 1)
    """returns dict: per reference type, per channel -> dict(mean, err, clipped, frames) ; plus 'current' function"""
    refs = {}; R = cfg.get('references') or {}; ch = cfg['channels']
    for kind in ('dark', 'empty', 'full'):
        fr = _frames_for(R.get(kind), cfg['folder'], cfg.get('prefix', ''), cfg['channels'])
        if not fr: continue
        by = {}
        for f in fr:
            c = channel_of(f, ch)
            if c: by.setdefault(c, []).append(f)
        refs[kind] = {}
        for c, lst in by.items():
            mean, err, clip = level(lst, 0.0, hi)
            refs[kind][c] = dict(mean=mean, err=err, clipped=clip, frames=lst)
    refs['current'] = current_function(R.get('current'))
    return refs

def current_function(spec):
    if not spec: return None
    if 'pA' in spec: v = float(spec['pA']); return lambda t: v
    if 'csv' in spec:
        d = pd.read_csv(spec['csv'])
        t = d['time_s'].to_numpy(float) if 'time_s' in d else np.array([J.hms_to_s(x) for x in d['time']])
        i = d['current_pA'].to_numpy(float); o = np.argsort(t); t, i = t[o], i[o]
        return lambda tt: float(np.interp(tt, t, i))
    return None

def warnings_for(refs):
    w = []
    for kind in ('dark', 'empty'):
        for c, d in (refs.get(kind) or {}).items():
            if d['clipped'] > 0.01: w.append(f'{kind} reference of {c}: {100*d["clipped"]:.0f} % of pixels clipped - raise the brightness (offset) so that the dark level is above 0')
    return w
