import os, sys, argparse, json
def main(argv=None):
    ap = argparse.ArgumentParser(prog='lcsem', description='quantitative liquid-cell SEM (see METHODS.md and docs/OPTIONS.md)')
    sub = ap.add_subparsers(dest='cmd', required=True)
    r = sub.add_parser('run', help='run the pipeline on a configuration file'); r.add_argument('config'); r.add_argument('out_dir'); r.add_argument('-q', '--quiet', action='store_true')
    l = sub.add_parser('list', help='list the image series (scans, channels, kV) in a folder'); l.add_argument('folder'); l.add_argument('--prefix', default='')
    m = sub.add_parser('mc-curve', help='Monte Carlo calibration curve for any detector (arguments as lcsem.mc.curves)'); m.add_argument('args', nargs=argparse.REMAINDER)
    s = sub.add_parser('simulate', help='write a synthetic K-kit data set with ground truth'); s.add_argument('out_dir'); s.add_argument('--frames', type=int, default=8)
    s.add_argument('--curve', required=True, help='curve file with BEDC and stem_0_100 detectors and a particle standard (lcsem mc-curve --detector BEDC stem:0:100)')
    v = sub.add_parser('validate', help='validation on synthetic ground truth for all option sets'); v.add_argument('out_dir'); v.add_argument('--quick', action='store_true')
    o = sub.add_parser('options', help='print the option matrix (what each optional acquisition gives)')
    sg = sub.add_parser('segment', help='(re)compute the PCA + GMM segmentation of a finished run'); sg.add_argument('run_dir')
    sg.add_argument('--skip-rows', type=int, default=None); sg.add_argument('--frames', default=None, help='frames for the overview figure, e.g. 0,3,6,8')
    am = sub.add_parser('amira', help='export a finished run to Amira (.am volumes, non-binary liquid/gas fractions)'); am.add_argument('run_dir'); am.add_argument('--out', default=None)
    am.add_argument('--bin', type=int, default=4); am.add_argument('--dz', type=float, default=10.0)
    g = sub.add_parser('gui', help='the graphical interface (napari): processing options, 3-D volumes with a time slider, charts, export')
    g.add_argument('path', nargs='?', default=None, help='a finished run folder or a saved project (.json) to open')
    pj = sub.add_parser('project', help='run a project saved from the GUI, without the GUI'); pj.add_argument('project'); pj.add_argument('--out', default=None)
    ex = sub.add_parser('export', help='export a finished run to Amira, Imaris, ImageJ/Fiji, OME-TIFF/Zarr, ParaView, 3D Slicer, ITK, MRC, meshes, MATLAB, HDF5, CSV/Excel, TrackMate')
    ex.add_argument('run_dir', nargs='?', default=None); ex.add_argument('--out', default=None); ex.add_argument('--formats', default='amira,tiff,ome-tiff,imaris,vtk,csv',
                    help='comma-separated; "all" for every format; list: lcsem export --list'); ex.add_argument('--bin', type=int, default=4)
    ex.add_argument('--dz', type=float, default=10.0); ex.add_argument('--no-check', action='store_true', help='skip reading every file back'); ex.add_argument('--list', action='store_true')
    ob = sub.add_parser('objects', help='bubbles / objects of a finished run: watershed, measurements, tracking over time'); ob.add_argument('run_dir')
    ob.add_argument('--source', default='se_contact', choices=['se_contact', 'gas', 'thin', 'class']); ob.add_argument('--min-area', type=int, default=100); ob.add_argument('--min-distance', type=int, default=10)
    mp = sub.add_parser('movie-info', help='frames, size, frame rate and grey range of movie / stack files'); mp.add_argument('files', nargs='+')
    sm = sub.add_parser('simulate-movie', help='synthetic SE/BSE/STEM movies with ground truth (for testing the movie mode)'); sm.add_argument('out_dir')
    sm.add_argument('--curve', required=True); sm.add_argument('--frames', type=int, default=40); sm.add_argument('--dose', type=float, default=150.0, help='noise level: Poisson quanta per pixel per unit of detector signal (not the incident electron dose)')
    a = ap.parse_args(argv)
    if a.cmd == 'run':
        from .pipeline import load_config, run
        run(load_config(a.config), a.out_dir, verbose=not a.quiet)
    elif a.cmd == 'list':
        from . import io_jeol as J
        fr = J.scan_folder_all(a.folder, a.prefix)
        print(J.describe_scans(J.group_scans(fr, {'BSE': dict(signal='BED_C', role='thickness'), 'STEM': dict(signal=['STEM', 'TED', 'BF', 'DF'], role='thickness'), 'SE': dict(signal=['UED', 'LED', 'SEI'], role='contact')})))
    elif a.cmd == 'mc-curve':
        from .mc import curves; sys.argv = ['lcsem mc-curve'] + a.args; curves.main()
    elif a.cmd == 'simulate':
        from .calib import ChannelCurve
        from . import simulate as S
        S.make_dataset(a.out_dir, {'BSE': ChannelCurve(a.curve, 'BEDC'), 'STEM': ChannelCurve(a.curve, 'stem_0_100')}, n_frames=a.frames, bits=16)
        cfg = S.config_for(a.out_dir, (8.0, 8.0), curves={'BSE': dict(file=a.curve, detector='BEDC'), 'STEM': dict(file=a.curve, detector='stem_0_100')}, bits=16)
        json.dump(cfg, open(a.out_dir.rstrip('/') + '_config.json', 'w'), indent=1); print('data and', a.out_dir.rstrip('/') + '_config.json', 'written')
    elif a.cmd == 'validate':
        from .validate import main as vm
        vm(a.out_dir, quick=a.quick)
    elif a.cmd == 'segment':
        from .segment import segment_run
        o = {}
        if a.skip_rows is not None: o['skip_rows'] = a.skip_rows
        if a.frames: o['figure_frame_list'] = [int(v) for v in a.frames.split(',')]
        segment_run(a.run_dir, o)
    elif a.cmd == 'amira':
        from .export_amira import export_run
        export_run(a.run_dir, a.out, bin=a.bin, dz=a.dz)
    elif a.cmd == 'options':
        from .config import option_table_markdown; print(option_table_markdown())
    elif a.cmd == 'gui':
        from .gui.app import main as gm
        gm([a.path] if a.path else [])
    elif a.cmd == 'project':
        from .gui.project import load_project, run_project
        print('run folder:', run_project(load_project(a.project), out_dir=a.out))
    elif a.cmd == 'export':
        from .export_formats import FORMATS, OPEN_WITH, export_all
        if a.list or not a.run_dir:
            for f in FORMATS: print(f'{f:10s} {OPEN_WITH.get(f, "")}')
            return
        fm = list(FORMATS) if a.formats == 'all' else [f.strip() for f in a.formats.split(',') if f.strip()]
        M = export_all(a.run_dir, a.out or os.path.join(a.run_dir, 'export'), fm, bin=a.bin, dz=a.dz, check=not a.no_check)
        print(M[['format', 'n_files', 'size_mb', 'read_back', 'reader']].to_string(index=False))
    elif a.cmd == 'objects':
        from .objects import analyse_run
        O = analyse_run(a.run_dir, a.source, a.min_area, a.min_distance); print(f'{len(O)} objects in {O["frame"].nunique() if len(O) else 0} frames -> objects.csv, object_tracks.csv, object_events.csv')
    elif a.cmd == 'movie-info':
        from .io_movie import probe
        for f in a.files:
            d = probe(f); print(f'{f}: {d["n_frames"]} frames, {d["shape"][1]} x {d["shape"][0]} px, {d["kind"]} {d["dtype"]} ({d["bits"] or "?"}-bit), '
                                f'fps {d["fps"] or "not stored"}, grey {d["min"]:.0f}-{d["max"]:.0f}' + (f', axes {d["axes"]}' if d.get('axes') else ''))
            if d.get('duplicate_fraction', 0) > 0.3:
                print(f'  {100 * d["duplicate_fraction"]:.0f} % near-duplicate consecutive frames (screen recording?): use step {d["suggested_step"]}'
                      + (f' ({d["suggested_step_note"]})' if d.get('suggested_step_note') else ''))
    elif a.cmd == 'simulate-movie':
        from .calib import ChannelCurve
        from . import simulate as S
        S.make_movie(a.out_dir, {'BSE': ChannelCurve(a.curve, 'BEDC'), 'STEM': ChannelCurve(a.curve, 'stem_0_100')}, n_frames=a.frames, dose_e_px=a.dose,
                     channels=('SE', 'BSE', 'STEM')); print('movies and ground truth written to', a.out_dir)
if __name__ == '__main__':
    main()
