"""Validation on synthetic ground truth: one data set with everything recorded (BSE, STEM, SE, dark, empty and full-cell
references, Au standards), analysed with different subsets of it - the option combinations a user may have - and compared
with the truth.

    lcsem validate out_dir [--quick]

Reported per option set: calibration (B0, g vs truth), liquid-thickness error (median bias and robust spread, all frames),
gas classification (top / elsewhere) accuracy, particle depth error. A second data set is generated with a deliberately
wrong detector model (the images are formed with a different angular acceptance than the one assumed by the analysis) to
show which references detect and absorb a model error.
"""
from __future__ import annotations
import os, json, glob, numpy as np, pandas as pd
from .calib import ChannelCurve
from . import simulate as SIM
from .config import load_config
from .pipeline import run

OPTION_SETS = [
    ('BSE | particles + flat (v0.1)',          ('BSE', 'SE'), {'flat': 500.0}, True),
    ('BSE | dark + particles',                 ('BSE', 'SE'), ('dark',), True),
    ('BSE | dark + empty',                     ('BSE', 'SE'), ('dark', 'empty'), False),
    ('BSE | dark + empty + particles (check)', ('BSE', 'SE'), ('dark', 'empty'), True),
    ('BSE | dark + empty + full cell',         ('BSE', 'SE'), ('dark', 'empty', 'full'), False),
    ('STEM | dark + empty',                    ('STEM', 'SE'), ('dark', 'empty'), False),
    ('BSE + STEM | dark + empty + full cell',  ('BSE', 'STEM', 'SE'), ('dark', 'empty', 'full'), True),
    ('BSE + STEM, no SE | dark + empty + full',('BSE', 'STEM'), ('dark', 'empty', 'full'), False),
]

def curves_for(cache_dir, kv=15.0, T_list=(200.0, 400.0, 600.0, 800.0), d=60.0, detectors=('BEDC', 'stem:0:100'), n=300000):
    from .mc.curves import cached_curve
    d_, fn = cached_curve(cache_dir, E0=kv, detectors=tuple(detectors), t_mem=(30.0, 30.0), membrane='SiN', liquid='H2O',
                          water=(0, 25, 50, 100, 150, 200, 300, 400, 500, 600, 700, 800, 1000, 1200), n=n, particle=d, material='Au', particle_T=tuple(T_list),
                          depths=('top', 'f0.25', 'mid', 'f0.75', 'bot'))
    return fn

def evaluate(run_dir, data_dir, px):
    truth = json.load(open(os.path.join(data_dir, 'truth.json')))
    S = pd.read_csv(os.path.join(run_dir, 'summary.csv')); errs = []; gas_ok = []; gas_n = 0
    for i in range(len(S)):
        m = np.load(glob.glob(os.path.join(run_dir, f'*_{i:02d}_*_maps.npz'))[0]); tr = np.load(os.path.join(data_dir, f'truth_{i:02d}.npz'))
        dy, dx = truth['frames'][i]['drift']
        from scipy.ndimage import shift as sh
        Tt = sh(tr['T'], (-dy, -dx), order=1, mode='nearest'); gt = sh(tr['gas_top'], (-dy, -dx), order=0, mode='nearest'); gb = sh(tr['gas_bot'], (-dy, -dx), order=0, mode='nearest')
        ok = m['valid'] & np.isfinite(m['T']); ok[:12] = ok[-12:] = False; ok[:, :12] = ok[:, -12:] = False
        # exclude a band around the gas edges (smoothing)
        from scipy.ndimage import binary_dilation
        edge = binary_dilation((gt > 0) ^ binary_dilation(gt > 0, iterations=1), iterations=8) | binary_dilation((gb > 0) ^ binary_dilation(gb > 0, iterations=1), iterations=8)
        e = (m['T'] - Tt)[ok & ~edge]; errs.append(e)
        cls_true = np.where(gt > 0, 1, np.where(gb > 0, 2, 0))[ok & ~edge]
        cls_est = np.where(m['dark'], 1, np.where(np.nan_to_num(m['gas_other']) > 0, 2, 0))[ok & ~edge] if 'gas_other' in m else None
        if cls_est is not None: gas_ok.append((cls_true == cls_est).mean())
    e = np.concatenate(errs)
    out = dict(T_bias_nm=float(np.median(e)), T_spread_nm=float(1.4826 * np.median(np.abs(e - np.median(e)))), T_p95_abs_nm=float(np.percentile(np.abs(e), 95)),
               gas_class_accuracy=float(np.mean(gas_ok)) if gas_ok else np.nan)
    P = pd.read_csv(os.path.join(run_dir, 'particles.csv')) if os.path.exists(os.path.join(run_dir, 'particles.csv')) else pd.DataFrame()
    if len(P) and 'z_nm' in P:
        dz = []; szs = []
        for i, fr in enumerate(truth['frames']):
            dy, dx = fr['drift']; tp = np.array([(p['x_px'] - dx, p['y_px'] - dy, p['z_nm']) for p in fr['particles']])
            for _, r in P[P['frame'] == i].iterrows():
                if not np.isfinite(r.get('z_nm', np.nan)): continue
                d2 = (tp[:, 0] - r['x_px']) ** 2 + (tp[:, 1] - r['y_px']) ** 2; j = int(np.argmin(d2))
                if d2[j] < 9: dz.append(r['z_nm'] - tp[j, 2]); szs.append(r['sz_nm'])
        if dz:
            dz = np.array(dz); sz = np.array(szs); ok = sz < 100
            out.update(z_usable_frac=float(ok.mean()), n_z=int(ok.sum()))
            if ok.any():
                e = dz[ok]; out.update(z_bias_nm=float(np.median(e)), z_rms_nm=float(np.sqrt(np.mean(e ** 2))), z_mad_nm=float(1.4826 * np.median(np.abs(e - np.median(e)))),
                                       z_pull_std=float(np.std(e / sz[ok])))
    rep = json.load(open(os.path.join(run_dir, 'calibration_report.json')))
    for c, r in rep.items():
        out[f'{c}_mode'] = r['mode']; out[f'{c}_B0'] = r['B0']; out[f'{c}_g'] = r['g']
        for ch in r['checks']: out[f'{c}_check: {ch["check"]}'] = f'{ch["value"]:.3g} +- {ch["err"]:.2g}'
    return out

def main(out_dir, quick=False, cache_dir=None, log=print):
    os.makedirs(out_dir, exist_ok=True); cache_dir = cache_dir or os.path.join(out_dir, 'mc_cache')
    fn = curves_for(cache_dir); curve_b = ChannelCurve(fn, 'BEDC'); curve_s = ChannelCurve(fn, 'stem_0_100')
    px = (8.0, 8.0); rows = []
    for tag, true_curves in (('correct_model', None), ('model_error', 'wrong')):
        data = os.path.join(out_dir, f'data_{tag}')
        tc = None
        if true_curves == 'wrong':        # images formed with a BSE detector of different acceptance (20-55 deg): the analysis assumes 15-65
            from .mc.curves import cached_curve
            d2, fn2 = cached_curve(cache_dir, E0=15.0, detectors=('bse:20:55:E-2', 'stem:0:100'), t_mem=(30.0, 30.0), membrane='SiN', liquid='H2O',
                                   water=(0, 25, 50, 100, 150, 200, 300, 400, 500, 600, 700, 800, 1000, 1200), n=300000, particle=60.0, material='Au',
                                   particle_T=(200.0, 400.0, 600.0, 800.0), depths=('top', 'f0.25', 'mid', 'f0.75', 'bot'))
            wb = ChannelCurve(d2, 'bse_20_55'); wb.detector = 'bse_20_55'; tc = {'BSE': wb, 'STEM': curve_s}
        if not os.path.exists(os.path.join(data, 'truth.json')):
            SIM.make_dataset(data, {'BSE': curve_b, 'STEM': curve_s}, n_frames=4 if quick else 8, shape=(360, 480) if quick else (480, 640), px=px, true_curves=tc, bits=16)
        sets = OPTION_SETS if not quick else OPTION_SETS[:3] + OPTION_SETS[5:7]
        for name, chans, refs, use_p in sets:
            if true_curves == 'wrong' and not any(k in name for k in ('dark + empty + particles', 'particles + flat', 'dark + particles', 'BSE | dark + empty')): continue
            rd = os.path.join(out_dir, f'run_{tag}_' + ''.join(ch for ch in name if ch.isalnum())[:40])
            cfg = SIM.config_for(data, px, chans, refs if isinstance(refs, (tuple, dict)) else (), name='syn', curves={c: dict(file=fn, detector=('BEDC' if c == 'BSE' else 'stem_0_100')) for c in chans if c in ('BSE', 'STEM')}, d_nm=60.0, bits=16,
                                 depth=('core_fraction', 'channel_ratio') if ('BSE' in chans and 'STEM' in chans) else ('core_fraction',))
            if isinstance(refs, dict): cfg['references']['flat'] = dict(frames='all', T_nm=refs['flat'])
            cfg['calibration']['use_particles'] = use_p
            cfg = load_config(cfg)
            try:
                run(cfg, rd, verbose=False); r = evaluate(rd, data, px)
            except Exception as ex:
                r = dict(error=str(ex)[:200])
            r.update(data=tag, option_set=name); rows.append(r); log(f'{tag:14s} {name:42s} ' + ', '.join(f'{k} {v:.3g}' if isinstance(v, float) else f'{k} {v}' for k, v in r.items() if k not in ('data', 'option_set')))
    df = pd.DataFrame(rows); df.to_csv(os.path.join(out_dir, 'validation.csv'), index=False)
    truth = json.load(open(os.path.join(out_dir, 'data_correct_model', 'truth.json')))['detectors']
    with open(os.path.join(out_dir, 'VALIDATION.md'), 'w') as f:
        f.write('# Validation on synthetic ground truth\n\n')
        f.write(f'True detector constants: BSE B0 {truth["BSE"]["B0"]}, g {truth["BSE"]["g"]}; STEM B0 {truth["STEM"]["B0"]}, g {truth["STEM"]["g"]}\n\n')
        cols = ['data', 'option_set', 'T_bias_nm', 'T_spread_nm', 'T_p95_abs_nm', 'gas_class_accuracy', 'z_bias_nm', 'z_mad_nm', 'n_z'] + [c for c in df.columns if c.endswith('_B0') or c.endswith('_g') or 'check' in c]
        cols = [c for c in cols if c in df.columns]
        f.write(df[cols].to_markdown(index=False, floatfmt='.3g') if hasattr(df, 'to_markdown') else df[cols].to_string(index=False))
    return df
