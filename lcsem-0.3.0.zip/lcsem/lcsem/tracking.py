"""Particle trajectories: frame-to-frame linking of drift-corrected detections by minimum-cost assignment with a distance
gate and gap closing [Jaqaman et al., Nat. Methods 5, 695 (2008), simplified to one linking pass; assignment by the
Hungarian algorithm, Kuhn, Nav. Res. Logist. Q. 2, 83 (1955)]. Mean-squared displacements with the static localization
error subtracted [Michalet, Phys. Rev. E 82, 041914 (2010)].
Every point keeps its own acquisition time (the scan row time), so velocities and MSDs use true time differences."""
from __future__ import annotations
import numpy as np, pandas as pd
from scipy.optimize import linear_sum_assignment

def link(det: pd.DataFrame, max_disp_nm=250.0, max_gap=1, cols=('x_nm', 'y_nm')):
    """det: one row per detection with columns frame, x_nm, y_nm (canvas coordinates) [, z_nm, t_s, ...].
    Returns det with a 'track' column."""
    det = det.sort_values('frame').reset_index(drop=True).copy(); det['track'] = -1
    frames = sorted(det['frame'].unique()); next_id = 0; active = {}          # track -> (last index, last frame)
    for f in frames:
        cur = det.index[det['frame'] == f].to_numpy()
        cand = [(tid, i) for tid, (i, lf) in active.items() if 0 < f - lf <= max_gap + 1]
        if cand and len(cur):
            P = det.loc[[i for _, i in cand], list(cols)].to_numpy(); Q = det.loc[cur, list(cols)].to_numpy()
            D = np.hypot(P[:, None, 0] - Q[None, :, 0], P[:, None, 1] - Q[None, :, 1])
            gap = np.array([f - active[t][1] for t, _ in cand])[:, None]
            C = np.where(D <= max_disp_nm * np.sqrt(gap), D, 1e9)
            r, c = linear_sum_assignment(C); used = set()
            for a, b in zip(r, c):
                if C[a, b] >= 1e9: continue
                tid = cand[a][0]; det.loc[cur[b], 'track'] = tid; active[tid] = (cur[b], f); used.add(b)
            new = [k for k in range(len(cur)) if k not in used]
        else: new = list(range(len(cur)))
        for k in new:
            det.loc[cur[k], 'track'] = next_id; active[next_id] = (cur[k], f); next_id += 1
        active = {t: v for t, v in active.items() if f - v[1] <= max_gap + 1}
    return det

def msd(track: pd.DataFrame, sigma_loc_nm=0.0, dims=('x_nm', 'y_nm')):
    """time-averaged MSD vs lag (in frames) with the true time lags; localization error 2 d sigma^2 subtracted"""
    tr = track.sort_values('frame'); X = tr[list(dims)].to_numpy(); t = tr['t_s'].to_numpy() if 't_s' in tr else tr['frame'].to_numpy().astype(float)
    rows = []
    for lag in range(1, len(tr)):
        d2 = ((X[lag:] - X[:-lag]) ** 2).sum(axis=1); dt = t[lag:] - t[:-lag]
        rows.append(dict(lag=lag, dt_s=float(np.mean(dt)), msd_nm2=float(np.mean(d2) - 2 * len(dims) * sigma_loc_nm ** 2), n=int(len(d2))))
    return pd.DataFrame(rows)

def track_table(det: pd.DataFrame):
    rows = []
    for tid, g in det.groupby('track'):
        g = g.sort_values('frame')
        d = np.hypot(np.diff(g['x_nm']), np.diff(g['y_nm'])); dt = np.diff(g['t_s']) if 't_s' in g else np.diff(g['frame'])
        row = dict(track=int(tid), n_points=len(g), first_frame=int(g['frame'].iloc[0]), last_frame=int(g['frame'].iloc[-1]),
                   path_nm=float(d.sum()), net_nm=float(np.hypot(g['x_nm'].iloc[-1] - g['x_nm'].iloc[0], g['y_nm'].iloc[-1] - g['y_nm'].iloc[0])),
                   mean_speed_nm_s=float(np.sum(d) / np.sum(dt)) if len(dt) and np.sum(dt) > 0 else np.nan)
        if 'z_nm' in g: row.update(z_first_nm=float(g['z_nm'].iloc[0]), z_last_nm=float(g['z_nm'].iloc[-1]), z_range_nm=float(np.nanmax(g['z_nm']) - np.nanmin(g['z_nm'])) if g['z_nm'].notna().any() else np.nan)
        rows.append(row)
    return pd.DataFrame(rows)
