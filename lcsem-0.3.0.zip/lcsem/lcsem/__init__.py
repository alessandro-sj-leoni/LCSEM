"""lcsem - quantitative liquid-cell SEM: liquid thickness from BSE, gas contact from SE, per-pixel time, 3-D label volumes.

    lcsem gui                              graphical interface: processing options, 3-D volumes with a time slider, charts, export
    lcsem run config.json out_dir          full pipeline on a JEOL image series
    lcsem project project.json             run a project saved from the GUI (JEOL series or SE/BSE/STEM movies)
    lcsem export run_dir --formats all     Amira, Fiji, OME-TIFF/Zarr, Imaris, ParaView, Slicer, ChimeraX, meshes, MATLAB, ...
    lcsem mc-curve --E0 15 ...             regenerate the BSE-vs-thickness calibration curve with the Monte Carlo engine
    lcsem list folder                      list the series found in a folder

See METHODS.md for the physics, the algorithms and the references.
"""
__version__ = '0.3.0'
__build__ = '2026-09-29'          # date of the revision after the second internal review round


def build_id():
    """version + revision date + a hash of the source files: recorded in every run (run_info.json) and project, so results of
    two revisions of the same version can be told apart"""
    import hashlib, os
    h = hashlib.sha1(); root = os.path.dirname(os.path.abspath(__file__))
    for d, _, fs in sorted(os.walk(root)):
        for f in sorted(fs):
            if f.endswith('.py'):
                with open(os.path.join(d, f), 'rb') as fh: h.update(fh.read())
    return f'{__version__}+{__build__}.{h.hexdigest()[:10]}'
