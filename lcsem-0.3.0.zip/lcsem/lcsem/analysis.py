"""SE contact maps, gas-gap maps, discrete levels, statistics with spatial bootstrap.

  Otsu / multi-Otsu thresholds    Otsu, IEEE Trans. SMC 9, 62 (1979); Liao, Chen & Chung, J. Inf. Sci. Eng. 17, 713 (2001)
  isotonic regression (PAVA)      Barlow, Bartholomew, Bremner & Brunk, Statistical Inference under Order Restrictions (1972)
  block bootstrap                 Kuensch, Ann. Stat. 17, 1217 (1989)
  Spearman rank correlation       Spearman, Am. J. Psychol. 15, 72 (1904)
"""
from __future__ import annotations
import numpy as np
from scipy import ndimage as ndi
from scipy.stats import spearmanr
from skimage.filters import threshold_otsu, threshold_multiotsu
from .imageproc import smooth_masked

def _upper_mode(v, min_sep=0.05, min_mass=0.05, max_depth=0.6):
    """is the distribution of the smoothed SE bimodal, with a brighter mode that can be the wet background? Two peaks of the
    smoothed histogram (prominence >= 5 % of the highest) separated by a valley at most `max_depth` x the lower of the two
    peaks, the peaks at least `min_sep` apart relative to the brighter one, and each side holding >= `min_mass` of the pixels.
    Returns the grey value of the valley below the brightest such mode, or None (unimodal, skewed or weakly separated
    distributions: a bright tail of thicker liquid is not a second population)."""
    from scipy.signal import find_peaks
    lo, hi = np.percentile(v, [0.5, 99.5])
    if not hi > lo: return None
    h, e = np.histogram(v, bins=128, range=(lo, hi)); h = ndi.gaussian_filter1d(h.astype(float), 2.0); c = 0.5 * (e[1:] + e[:-1])
    pk, _ = find_peaks(np.r_[0.0, h, 0.0], prominence=0.05 * h.max()); pk = pk - 1
    if len(pk) < 2: return None
    cum = np.cumsum(h) / h.sum()
    for j in range(len(pk) - 1, 0, -1):                                   # from the brightest peak down
        hi_p = pk[j]
        for i in range(j - 1, -1, -1):
            lo_p = pk[i]; vly = lo_p + int(np.argmin(h[lo_p:hi_p + 1]))
            if (h[vly] <= max_depth * min(h[lo_p], h[hi_p]) and (c[hi_p] - c[lo_p]) >= min_sep * abs(c[hi_p])
                    and cum[vly] >= min_mass and 1 - cum[vly] >= min_mass):
                return float(c[vly])
    return None

def _background(s, valid, order=2, iters=8, noise=0.0, min_sep=0.10, return_info=False):
    """smooth SE background B (shading, slow detector drift across the field) at the level of the wet (SE-bright) surface.
    Two cases, decided by the distribution of the smoothed SE:
      * bimodal (`_upper_mode`: two surface states, wet above the valley, contact below, peaks at least `min_sep` apart -
        twice the detection floor in se_contact_map, so the split is not made near the floor): s = B (1 + c g) with one smooth B
        shared by both states, fitted in log space to all pixels with the state g as an extra regressor (multiplicative
        shading acts on both states, so B is determined everywhere and not extrapolated from the wet part - a contact
        covering most of the field, a drying front); g re-assigned at half contrast until stable; outliers (|res| > 3.5 sd)
        dropped. The brighter state is the background: SE-dark = gas, never the reverse. Bias-field + class models:
        Wells et al., IEEE Trans. Med. Imaging 15, 429 (1996);
      * otherwise (unimodal, including skewed): robust polynomial fitted from the brighter half, dropping pixels more than
        3 sd below (gas contact) or 4 sd above it (bright structure such as thicker liquid), sd from the kept residuals and at
        least `noise`.
    info: 'start' ('two surface states' / 'brighter half'), 'bright_fraction' (share of the field in the background state)."""
    ny, nx = s.shape; yy, xx = np.mgrid[0:ny, 0:nx]; yy = yy / ny - 0.5; xx = xx / nx - 0.5
    terms = [np.ones_like(xx)] + [xx ** i * yy ** (d - i) for d in range(1, order + 1) for i in range(d + 1)]
    A = np.stack([t[valid] for t in terms], axis=1); v = s[valid].astype(np.float64); step = max(1, v.size // 50000)
    vly = _upper_mode(v, min_sep=min_sep)
    if vly is not None and np.all(v > 0):
        lv = np.log(v); g = v <= vly; keep = np.ones(v.size, bool); nl = float(noise) / max(float(np.median(v)), 1e-9); coef = None
        for _ in range(iters):
            X = np.column_stack([A, g.astype(np.float64)]); idx = np.where(keep)[0][::step]
            if idx.size < 10 * X.shape[1] or g.all() or not g.any(): break
            coef = np.linalg.lstsq(X[idx], lv[idx], rcond=None)[0]; res = lv - X @ coef
            sd = max(1.4826 * np.median(np.abs(res[keep] - np.median(res[keep]))), nl, 1e-9)
            keep = np.abs(res) < 3.5 * sd
            new = (lv - A @ coef[:-1]) < 0.5 * min(coef[-1], 0.0)             # contact: below half of the fitted contrast
            if np.array_equal(new, g): break
            g = new
        if coef is not None and coef[-1] < 0:
            bg = np.exp(sum(ci * t for ci, t in zip(coef[:-1], terms)))
            info = dict(start='two surface states', bright_fraction=float((~g).mean()), order=order, state_contrast=float(np.expm1(coef[-1])))
            return (bg, info) if return_info else bg
    keep = v >= np.percentile(v, 50); c = None
    for _ in range(iters):
        idx = np.where(keep)[0][::step]
        if idx.size < 10 * len(terms): break
        c = np.linalg.lstsq(A[idx], v[idx], rcond=None)[0]; r = v - A @ c
        sd = max(1.4826 * np.median(np.abs(r[keep] - np.median(r[keep]))), float(noise), 1e-6)
        new = (r > -3.0 * sd) & (r < 4.0 * sd)                            # drop gas contact and bright structure
        if np.array_equal(new, keep): break
        keep = new
    if c is None: c = np.array([np.median(v)] + [0.0] * (len(terms) - 1))
    bg = sum(ci * t for ci, t in zip(c, terms))
    info = dict(start='brighter half', bright_fraction=float(keep.mean()), order=order, state_contrast=np.nan)
    return (bg, info) if return_info else bg

def smooth_surface(z, valid, order=2):
    """robust 2-D polynomial (default quadratic) fitted to z on the valid pixels (outliers both ways down-weighted), evaluated
    everywhere: the local gap of the liquid layer under gas, interpolated from the wet surroundings"""
    ny, nx = z.shape; yy, xx = np.mgrid[0:ny, 0:nx]; yy = yy / ny - 0.5; xx = xx / nx - 0.5
    terms = [np.ones_like(xx)] + [xx ** i * yy ** (d - i) for d in range(1, order + 1) for i in range(d + 1)]
    m = valid & np.isfinite(z); A = np.stack([t[m] for t in terms], axis=1); v = z[m]; w = np.ones(v.size)
    step = max(1, v.size // 50000); idx = np.arange(0, v.size, step)
    for _ in range(4):
        c = np.linalg.lstsq(A[idx] * w[idx, None], v[idx] * w[idx], rcond=None)[0]; r = v - A @ c
        s = 1.4826 * np.median(np.abs(r)) + 1e-9; w = 1.0 / np.maximum(1.0, np.abs(r) / (2.5 * s))
    return sum(ci * t for ci, t in zip(c, terms))

def se_contact_map(se, valid, sigma=6.0, min_area=2000, open_iter=3, skip_rows=0, k_sigma=5.0, min_contrast=0.05, noise_sigma=None,
                   return_info=False):
    """binary map of the SE-dark region (gas touching the top membrane). Returns (dark_mask, edge_threshold, smoothed_se)
    [, info]. Robust to frames without gas, to shading and to SE drift between frames:
      1. SE smoothed (normalised convolution over the valid pixels, sigma px) and divided by its smooth background (robust
         quadratic surface fitted to the pixels not markedly darker than it): r = SE / background - 1;
      2. detection: pixels darker than max(k_sigma x the noise of r, min_contrast) - the noise of r follows from the pixel noise
         (robust MAD of neighbour differences, or noise_sigma) divided by 2 sqrt(pi) sigma for Gaussian smoothing. A frame
         without gas therefore gives no contact (instead of the half of the field a per-frame Otsu split of noise gives);
      3. edges at half contrast: the final map is r < 0.5 x the median r of the detected pixels, kept where it touches a
         detection (so the area is not biased by the detection threshold); cleaned by opening/closing (open_iter) and removal
         of components smaller than min_area pixels.
    info: noise of r, contrast (median r of the contact), detection and edge thresholds, and 'contact' (False when nothing
    significant was found)."""
    from .denoise import _sigma_mad
    valid = valid.copy()
    if skip_rows: valid[:skip_rows] = False
    s = smooth_masked(se, ~valid, sigma)
    info = dict(noise_r=np.nan, contrast=0.0, det_threshold=np.nan, edge_threshold=np.nan, contact=False, coverage=0.0, high_coverage=False,
                start='', bright_fraction=np.nan, min_contrast=float(min_contrast))
    if valid.sum() < 100: return (np.zeros(se.shape, bool), np.nan, s, info) if return_info else (np.zeros(se.shape, bool), np.nan, s)
    sig_raw = noise_sigma if noise_sigma is not None else _sigma_mad(np.where(valid, se, np.nanmedian(se[valid])))
    sig_s = float(sig_raw / (2 * np.sqrt(np.pi) * max(sigma, 0.5)))
    bg, binfo = _background(s, valid, noise=sig_s, min_sep=2 * min_contrast, return_info=True); bg = np.where(np.abs(bg) > 1e-6, bg, 1e-6); r = s / bg - 1.0
    noise_r = float(sig_s / max(float(np.median(bg[valid])), 1e-6))
    t_det = -max(k_sigma * noise_r, min_contrast); det = (r < t_det) & valid
    info.update(noise_r=noise_r, det_threshold=t_det, start=binfo['start'], bright_fraction=binfo['bright_fraction'])
    dark = np.zeros(se.shape, bool); t_edge = np.nan
    if det.sum() >= max(10, min_area // 4):
        # per detected region: its edge at half of its own core contrast (10th percentile of r inside it)
        dl, nd = ndi.label(det); cores = ndi.labeled_comprehension(r, dl, np.arange(1, nd + 1), lambda v: np.percentile(v, 10), float, 0.0)
        t_pix = np.zeros(se.shape, np.float32)
        for k, c in enumerate(cores, start=1):
            if (dl == k).sum() >= 4: t_pix[dl == k] = 0.5 * c
        # grow each region into its half-contrast surroundings (a few smoothing lengths at most)
        grow = ndi.grey_erosion(t_pix, size=int(4 * sigma) | 1)                   # most negative threshold nearby
        cand = (r < grow) & (grow < 0) & valid
        lab, n = ndi.label(cand)
        if n:
            hit = np.unique(lab[det & cand]); dark = np.isin(lab, hit[hit > 0])
        contrast = float(np.percentile(r[det], 10)); t_edge = 0.5 * contrast
        info.update(contrast=contrast, edge_threshold=t_edge)
    if open_iter and dark.any(): dark = ndi.binary_opening(dark, iterations=open_iter); dark = ndi.binary_closing(dark, iterations=open_iter) & valid
    lab, n = ndi.label(dark)
    if n:
        sz = ndi.sum(dark, lab, range(1, n + 1)); dark = np.isin(lab, 1 + np.where(sz > min_area)[0])
    info['contact'] = bool(dark.any()); info['coverage'] = float(dark[valid].mean()) if valid.any() else 0.0
    info['high_coverage'] = info['coverage'] > 0.5          # the background then rests on less than half of the field: flagged
    return (dark, t_edge, s, info) if return_info else (dark, t_edge, s)

def contact_summary(infos):
    """summary.csv fields from the info of se_contact_map (dict channel -> info): detection floor (the SE contrast below which
    no contact is detected), the contrast found, how the background was set and a flag for contact over half the field"""
    if not infos: return {}
    floors = [-i['det_threshold'] for i in infos.values() if np.isfinite(i.get('det_threshold', np.nan))]
    flags = [f'{c}: contact {100 * i["coverage"]:.0f} % of the analysed field, background from the bright {100 * i["bright_fraction"]:.0f} %'
             for c, i in infos.items() if i.get('high_coverage')]
    return dict(se_detection_floor=float(max(floors)) if floors else np.nan,
                se_contrast=float(min(i.get('contrast', 0.0) for i in infos.values())),
                se_background='; '.join(f'{c}: {i.get("start", "")}' for c, i in infos.items()),
                se_contact_flag='; '.join(flags))

def sum_sd(resid, mask, region, max_lag=64):
    """standard error of the sum of a spatially correlated error field over the pixels of `region`, with the covariance
    estimated from `resid` on `mask` (e.g. gap - thickness where there is no gas: noise, calibration smoothing and the misfit
    of the gap surface): Var = sum over lags t of C(t) R(t), C the covariance of the field (masked autocovariance, robustly
    clipped, lags inside the first zero of its radial profile and at most max_lag px) and R the number of pixel pairs of the
    region at that lag - the variance of a spatial sum of a stationary field (Cressie, Statistics for Spatial Data, Wiley 1993).
    Returns (sd, sigma, A_c): sd in the units of resid x pixels, sigma the robust sd of resid, A_c its correlation area (px)."""
    m = mask & np.isfinite(resid); region = np.asarray(region, bool)
    if m.sum() < 200 or not region.any(): return (np.nan, np.nan, np.nan) if region.any() else (0.0, np.nan, np.nan)
    v = resid[m]; med = np.median(v); sig = 1.4826 * float(np.median(np.abs(v - med)))
    r = np.where(m, np.clip(resid - med, -5 * sig, 5 * sig), 0.0); w = m.astype(float); g = region.astype(float)
    P = [int(2 ** np.ceil(np.log2(n + max_lag + 1))) for n in r.shape]
    ac = lambda a: np.fft.irfft2(np.abs(np.fft.rfft2(a, P)) ** 2, P)
    L = max_lag; idx = np.r_[0:L + 1, -L:0]; sel = np.ix_(idx, idx)
    C = ac(r)[sel] / np.maximum(ac(w)[sel], 1.0); R = ac(g)[sel]
    yy, xx = np.meshgrid(idx, idx, indexing='ij'); rr = np.hypot(yy, xx)
    prof = ndi.mean(C / max(C[0, 0], 1e-12), labels=np.rint(rr).astype(int), index=np.arange(L + 1))
    neg = np.flatnonzero(prof <= 0); r0 = int(neg[0]) if neg.size else L + 1; inside = rr < r0
    var = float((C * R)[inside].sum()); Ac = float(np.clip((C[inside] / max(C[0, 0], 1e-12)).sum(), 1.0, None))
    return float(np.sqrt(max(var, 0.0))), sig, Ac

def gas_gap(T, dark, valid, exclude=None, skip_rows=0):
    """gas-layer thickness on the top membrane = wet reference thickness - local thickness, inside the SE-dark region.
    The wet reference is the median thickness of the SE-bright part of the same frame."""
    wet = valid & ~dark
    if exclude is not None: wet &= ~exclude
    if skip_rows: wet[:skip_rows] = False
    Tref = float(np.nanmedian(T[wet])) if wet.sum() > 0.05 * valid.sum() else float(np.nanmedian(T[valid]))
    g = np.where(dark, np.clip(Tref - T, 0, None), 0.0).astype(np.float32); g[~valid] = np.nan
    return g, Tref

def se_levels(se_dn, region, n_levels=4):
    """multi-Otsu levels of the (denoised) SE inside `region`; 0 = darkest. Returns (level map with -1 outside, thresholds)."""
    thr = threshold_multiotsu(se_dn[region], classes=n_levels)
    lev = np.digitize(se_dn, thr).astype(np.int8); lev[~region] = -1
    return lev, thr

def monotone_fit(x, y, n_sub=60000, seed=0):
    """isotonic (non-decreasing) regression of y on x, plus Spearman rank correlation; returns (predict function, rho, p)"""
    from sklearn.isotonic import IsotonicRegression
    rng = np.random.default_rng(seed); i = np.flatnonzero(np.isfinite(x) & np.isfinite(y))
    if i.size > n_sub: i = rng.choice(i, n_sub, replace=False)
    ir = IsotonicRegression(increasing=True, out_of_bounds='clip').fit(x[i], y[i]); rho, p = spearmanr(x[i], y[i])
    return ir.predict, float(rho), float(p)

def block_bootstrap_median(values2d, block=32, n_boot=300, seed=0):
    """median of a 2-D field (NaN = not included) with a 95 % CI from a block bootstrap that respects spatial correlation
    (Kuensch 1989): non-overlapping `block` x `block` tiles are resampled with replacement."""
    rng = np.random.default_rng(seed); ys, xs = np.nonzero(np.isfinite(values2d)); vals = values2d[ys, xs]
    if vals.size == 0: return np.nan, np.nan, np.nan
    bid = (ys // block) * 100000 + (xs // block); ub, inv = np.unique(bid, return_inverse=True); nbk = ub.size
    order = np.argsort(inv); vo = vals[order]; io = inv[order]; starts = np.searchsorted(io, np.arange(nbk)); ends = np.r_[starts[1:], vals.size]
    meds = []
    for _ in range(n_boot):
        pick = rng.integers(0, nbk, size=nbk); sel = np.concatenate([vo[starts[p]:ends[p]] for p in pick]); meds.append(np.median(sel))
    return float(np.median(vals)), float(np.percentile(meds, 2.5)), float(np.percentile(meds, 97.5))

def region_table(T, regions: dict, se=None, block=32):
    """median thickness (+95 % CI) and mean SE for named boolean regions"""
    rows = []
    for name, m in regions.items():
        v = np.where(m, T, np.nan); med, lo, hi = block_bootstrap_median(v, block=block)
        rows.append(dict(region=name, n_px=int(np.isfinite(v).sum()), liquid_nm=med, ci95_lo=lo, ci95_hi=hi, se_mean=float(np.nanmean(se[m])) if se is not None else np.nan))
    return rows
