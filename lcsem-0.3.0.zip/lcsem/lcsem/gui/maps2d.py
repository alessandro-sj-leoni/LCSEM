"""2-D maps dock: the data behind the 3-D model of the frame shown, so every rendering can be checked against the images.

(a) liquid thickness (nm) with a colour bar (NaN = not measured: masked, hatched background); (b) SE contact map over the SE
frame; (c) the primary thickness frame (BSE or STEM, as recorded) with the detected particles (yellow: depth measured,
grey rings: depth not measured); (d) the SE frame. Frame coordinates (before drift correction). Hovering over (a) shows the
thickness and its statistical error under the cursor. Input frames are shown for runs made with lcsem >= 0.3 (they store
2 x 2 binned previews in the maps files).
"""
from __future__ import annotations
import numpy as np, pandas as pd, os
from qtpy.QtWidgets import QWidget, QVBoxLayout, QLabel, QSizePolicy
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from matplotlib.colors import LinearSegmentedColormap

SURF, INK, INK2, GRID = '#262930', '#ffffff', '#c3c2b7', '#3d4148'
THICK = LinearSegmentedColormap.from_list('lcsem_thickness', ['#10233f', '#3987e5', '#cfe3ff'])      # one hue, dark to light
THICK.set_bad('#3d4148')


class MapsWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self); lay.setContentsMargins(4, 4, 4, 4)
        self.fig = Figure(figsize=(5.2, 4.6), facecolor=SURF, layout='constrained'); self.canvas = FigureCanvasQTAgg(self.fig); lay.addWidget(self.canvas, 1)
        self.readout = QLabel(' '); self.readout.setStyleSheet(f'color: {INK2};'); self.readout.setWordWrap(True)
        self.readout.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred); lay.addWidget(self.readout)
        self.canvas.mpl_connect('motion_notify_event', self._hover); self.rv = None; self.i = -1; self.setMinimumHeight(300); self._empty()

    def _empty(self):
        self.fig.clear(); ax = self.fig.add_subplot(111); ax.set_facecolor(SURF); ax.axis('off')
        ax.text(0.5, 0.5, 'open or run an analysis', color=INK2, ha='center', va='center'); self.canvas.draw_idle()

    def set_run(self, rv):
        self.rv = rv; self.P = rv.V.particles if len(rv.V.particles) else pd.DataFrame(); self.i = -1; self.set_time(rv.frame_index())

    def set_time(self, i):
        if self.rv is None: return
        i = int(min(max(i, 0), self.rv.V.n - 1))
        if i == self.i: return
        self.i = i; m = np.load(self.rv.V.files[i]); self.m = {k: m[k] for k in m.files if k in ('T', 'sT', 'dark', 'valid') or k.startswith('prev_')}
        self.fig.clear(); axs = self.fig.subplots(2, 2)
        for ax in axs.ravel():
            ax.set_facecolor(SURF); ax.set_xticks([]); ax.set_yticks([])
            for s in ax.spines.values(): s.set_color(GRID)
        T = np.array(self.m['T'], float); nominal = 'SE only' in (self.rv.V.mode or '')
        fin = T[np.isfinite(T)]; lo, hi = (np.percentile(fin, [2, 98]) if fin.size else (0, 1))
        im = axs[0, 0].imshow(np.ma.masked_invalid(T), cmap=THICK, vmin=lo, vmax=hi, interpolation='nearest')
        cb = self.fig.colorbar(im, ax=axs[0, 0], fraction=0.046, pad=0.02); cb.ax.tick_params(colors=INK2, labelsize=7); cb.outline.set_edgecolor(GRID)
        cb.set_label('nm', color=INK2, fontsize=7)
        axs[0, 0].set_title(f'a  {"nominal " if nominal else ""}liquid thickness', color=INK, fontsize=9, loc='left')
        prev = {k[5:]: np.array(v, float) for k, v in self.m.items() if k.startswith('prev_')}
        se_key = next((k for k in prev if k.startswith('SE') or k.startswith('UED') or k.startswith('LED')), None)
        prim_key = next((k for k in prev if k in ('BSE', 'STEM')), None)
        dark = self.m.get('dark')
        base = prev.get(se_key) if se_key else None
        if base is not None:
            axs[0, 1].imshow(base, cmap='gray', interpolation='nearest')
            if dark is not None: axs[0, 1].contour(dark[::2, ::2][:base.shape[0], :base.shape[1]].astype(float), levels=[0.5], colors=['#199e70'], linewidths=1.2)
        elif dark is not None: axs[0, 1].imshow(dark, cmap='gray', vmin=0, vmax=1.5, interpolation='nearest')
        axs[0, 1].set_title('b  SE contact (green outline)', color=INK, fontsize=9, loc='left')
        if prim_key:
            axs[1, 0].imshow(prev[prim_key], cmap='gray', interpolation='nearest'); axs[1, 0].set_title(f'c  {prim_key} frame + particles', color=INK, fontsize=9, loc='left')
            if len(self.P) and 'x_px' in self.P:
                q = self.P[self.P['frame'] == i]; mm = q['z_measured'].values.astype(bool) if 'z_measured' in q else np.ones(len(q), bool)
                axs[1, 0].scatter(q['x_px'].values[mm] / 2, q['y_px'].values[mm] / 2, s=14, facecolors='#ffe680', edgecolors='none')
                axs[1, 0].scatter(q['x_px'].values[~mm] / 2, q['y_px'].values[~mm] / 2, s=18, facecolors='none', edgecolors='#9aa0a6', linewidths=0.8)
        else:
            why = 'no thickness channel recorded\n(SE only: nominal thickness)' if nominal else 'input frame not stored\n(run made with lcsem < 0.3)'
            axs[1, 0].text(0.5, 0.5, why, color=INK2, ha='center', va='center', fontsize=8, transform=axs[1, 0].transAxes)
            axs[1, 0].set_title('c  thickness-channel frame', color=INK, fontsize=9, loc='left')
        if base is not None: axs[1, 1].imshow(base, cmap='gray', interpolation='nearest'); axs[1, 1].set_title(f'd  {se_key} frame', color=INK, fontsize=9, loc='left')
        else:
            axs[1, 1].text(0.5, 0.5, 'no SE frame', color=INK2, ha='center', va='center', fontsize=8, transform=axs[1, 1].transAxes); axs[1, 1].set_title('d  SE frame', color=INK, fontsize=9, loc='left')
        self.ax_T = axs[0, 0]; self.canvas.draw_idle()
        self.readout.setText(f'frame {i + 1}: frame coordinates (before drift correction); previews binned 2 x 2')

    def _hover(self, ev):
        if self.rv is None or ev.inaxes is not getattr(self, 'ax_T', None) or ev.xdata is None: return
        y, x = int(round(ev.ydata)), int(round(ev.xdata)); T = self.m['T']
        if 0 <= y < T.shape[0] and 0 <= x < T.shape[1]:
            s = self.m.get('sT'); st = f' +- {s[y, x]:.0f} (statistical; a lower bound, ~2.3x too small on synthetic data)' if s is not None and np.isfinite(s[y, x]) else ''
            self.readout.setText(f'x {x} y {y} px: thickness {T[y, x]:.0f} nm{st}' + ('   SE contact' if self.m.get('dark') is not None and self.m['dark'][y, x] else ''))

    def save_png(self, fn):
        self.fig.savefig(fn, dpi=150, facecolor=SURF)
