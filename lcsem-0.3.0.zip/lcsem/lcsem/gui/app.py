"""lcsem GUI: napari viewer + docked panels.

    lcsem gui                      empty session
    lcsem gui RUN_DIR              open a finished run (folder with run_info.json)
    lcsem gui PROJECT.json         load a saved project
"""
from __future__ import annotations
import os, sys, json
import numpy as np

def _volume_job(run_dir, bin, dz, T_cap=1500.0, log=None, progress=None, should_abort=None):
    from ..volume4d import Volume4D
    return Volume4D(run_dir, bin=bin, dz=dz, T_cap=T_cap, progress=progress)

def _export_job(run_dir, out_dir, formats, volume, check, log=None, progress=None, should_abort=None):
    from ..export_formats import export_all
    return export_all(run_dir, out_dir, formats, volume=volume, check=check, log=log or print, progress=progress, should_abort=should_abort)

def _project_job(p, log=None, progress=None, should_abort=None):
    from .project import run_project
    return run_project(p, log=log or print, progress=progress, should_abort=should_abort)

def _running(th):
    try: return th.isRunning()
    except RuntimeError: return False


class LcsemApp:
    def __init__(self, viewer=None, show=True):
        import napari
        from qtpy.QtWidgets import QTabWidget
        from .panels import DataPanel, ProcessingPanel, RunPanel, DisplayPanel, ExportPanel, _scroll
        from .charts import ChartsWidget
        from .project import new_project
        self.viewer = viewer or napari.Viewer(title='lcsem - quantitative 4-D liquid-cell SEM', show=show)
        self.project = new_project(); self.rv = None; self.jobs = []
        self.data, self.proc, self.runp, self.disp, self.exp = DataPanel(), ProcessingPanel(), RunPanel(), DisplayPanel(), ExportPanel()
        self.tabs = QTabWidget()
        for w, name in ((self.data, '1 Data'), (self.proc, '2 Processing'), (self.runp, '3 Run'), (self.disp, '4 Display'), (self.exp, '5 Export')):
            self.tabs.addTab(_scroll(w), name)
        from .maps2d import MapsWidget
        self.charts = ChartsWidget(); self.maps = MapsWidget()
        win = self.viewer.window
        self.dock_panels = win.add_dock_widget(self.tabs, name='lcsem', area='right')
        self.dock_charts = win.add_dock_widget(self.charts, name='charts (follow the time slider)', area='right')
        try:
            self.dock_maps = win.add_dock_widget(self.maps, name='2-D maps (data behind the 3-D model)', area='right', tabify=True)
            self.dock_charts.raise_()
        except Exception: self.dock_maps = None
        self.layout_docks()
        try:
            from qtpy.QtCore import QTimer
            QTimer.singleShot(300, self.layout_docks)                           # again once the window has its final size
        except Exception: pass
        # signals
        self.runp.run.clicked.connect(self.run_analysis); self.runp.abort.clicked.connect(self.abort)
        self.runp.save.clicked.connect(self.save_project); self.runp.load.clicked.connect(self.load_project_dialog)
        self.data.open_run.connect(self.open_run); self.data.preview.connect(self.preview_movies)
        self.disp.zx_changed.connect(self.set_z); self.disp.render.currentTextChanged.connect(self.set_rendering); self.disp.iso.valueChanged.connect(self.set_iso)
        self.disp.ndisp.clicked.connect(lambda: setattr(self.viewer.dims, 'ndisplay', 5 - self.viewer.dims.ndisplay))
        self.disp.reset.clicked.connect(self.reset_view); self.disp.shot.clicked.connect(self.screenshot_dialog); self.disp.play.clicked.connect(self.play)
        self.disp.view_requested.connect(self.set_view); self.disp.psize.valueChanged.connect(self.set_particle_size)
        self.disp.movie.clicked.connect(self.record_movie_dialog); self.charts.save.clicked.connect(self.save_charts_dialog)
        self.exp.go.clicked.connect(self.export)
        self.viewer.dims.events.current_step.connect(self._time_changed)
        self._job = None; self._task_id = None
        # closing the window while a job runs: the job is registered with napari's task manager, so napari's own "Close window?"
        # dialog lists it; only when the close is accepted does napari cancel it (our callback aborts the job and waits for its
        # thread, which is never terminated). Cancelling the dialog leaves the job running.

    def layout_docks(self):
        """right-hand column: settings above (40 %), charts below (60 %); 600 px wide"""
        try:
            from qtpy.QtCore import Qt
            w = self.viewer.window._qt_window; h = max(w.height() - 120, 600)
            w.resizeDocks([self.dock_panels, self.dock_charts], [int(0.4 * h), int(0.6 * h)], Qt.Vertical)
            w.resizeDocks([self.dock_panels], [600], Qt.Horizontal)
        except Exception: pass

    # ---------------------------------------------------------------------------------------------- project
    def gather(self):
        self.data.to_project(self.project); self.proc.to_project(self.project)
        self.project['volume']['z_exaggeration'] = 'auto' if self.disp.zauto.isChecked() else self.disp.zx.value(); return self.project

    def set_project(self, p):
        self.project = p; self.data.from_project(p); self.proc.from_project(p); zx = p['volume'].get('z_exaggeration', 'auto')
        self.disp.zauto.setChecked(zx in (None, 'auto', 0))
        if not self.disp.zauto.isChecked(): self.disp.zx.setValue(int(zx))

    def save_project(self):
        from qtpy.QtWidgets import QFileDialog
        from .project import save_project
        fn = QFileDialog.getSaveFileName(None, 'Save project', 'lcsem_project.json', 'JSON (*.json)')[0]
        if fn: save_project(self.gather(), fn); self.runp.message(f'project saved: {fn}')

    def load_project_dialog(self):
        from qtpy.QtWidgets import QFileDialog
        fn = QFileDialog.getOpenFileName(None, 'Load project', '', 'JSON (*.json)')[0]
        if fn: self.load_project(fn)

    def load_project(self, fn):
        from .project import load_project
        self.set_project(load_project(fn)); self.runp.message(f'project loaded: {fn}')

    # ---------------------------------------------------------------------------------------------- jobs
    def busy(self):
        return self._job is not None

    def _start(self, fn, *args, done=None, **kw):
        """one job at a time; the controls that start jobs are disabled while it runs"""
        from . import worker
        if self.busy():
            self.runp.message('a job is running: wait for it or press Abort'); return None
        th, job = worker.start(self.viewer.window._qt_window, fn, *args, on_done=None, on_fail=None, on_progress=self.runp.progress, on_message=self.runp.message, **kw)
        job.finished.connect(lambda res, j=job: self._job_finished(j, res, done)); job.failed.connect(lambda msg, j=job: self._job_failed(j, msg))
        self._job = (th, job); self.jobs.append((th, job)); self._set_busy(True)
        try:
            from napari.utils.task_status import Status
            name = getattr(fn, '__name__', 'job').strip('_').replace('_', ' ')
            self._task_id = self.viewer.window._register_task_status('lcsem', Status.BUSY, f'{name} running (closing aborts it)',
                                                                     cancel_callback=lambda: self.shutdown_jobs() or True)
        except Exception: self._task_id = None
        return job

    def _task_done(self, ok=True):
        if self._task_id is None: return
        try:
            from napari.utils.task_status import Status
            self.viewer.window._update_task_status(self._task_id, Status.COMPLETED if ok else Status.FAILED, '')
        except Exception: pass
        self._task_id = None

    def _set_busy(self, b):
        self.runp.abort.setEnabled(b)
        for wdg in (self.runp.run, self.runp.load, self.exp.go, self.data.ropen): wdg.setEnabled(not b)

    def _job_finished(self, job, res, done):
        if self._job is not None and self._job[1] is job: self._job = None; self._task_done(True)
        self._set_busy(False)
        if done is not None: done(res)

    def _job_failed(self, job, msg):
        if self._job is not None and self._job[1] is job: self._job = None; self._task_done(False)
        self._failed(msg)

    def _idle(self):
        self._set_busy(self.busy())

    def _failed(self, msg):
        self._set_busy(self.busy()); self.runp.message('ERROR: ' + msg); self.runp.progress(0, msg.splitlines()[0])
        try:
            from napari.utils.notifications import show_error
            show_error('lcsem: ' + msg.splitlines()[0])
        except Exception: pass

    def abort(self):
        if self._job is not None:
            try: self._job[1].abort()
            except RuntimeError: pass
        self.runp.message('abort requested (the current step finishes first)')

    def shutdown_jobs(self, timeout_s=600.0):
        """abort the running job and wait for its thread (it stops at its next check), so closing the window never destroys a
        running thread. The thread is never terminated (unsafe while it runs Python code); after timeout_s the wait ends."""
        import time
        from qtpy.QtWidgets import QApplication
        for th, job in self.jobs:
            try:
                if th.isRunning():
                    job.abort(); t0 = time.time(); self.runp.message('closing: aborting the running job (it stops at its next step)')
                    while th.isRunning() and time.time() - t0 < timeout_s: QApplication.processEvents(); th.wait(100)
            except RuntimeError: pass
        self.jobs = [(t, j) for t, j in self.jobs if _running(t)]; self._job = None; self._task_done(False)

    def run_analysis(self):
        from .project import calibration_plan, acquisition_summary
        p = self.gather()
        if p['source'] == 'run': return self.open_run(p['run_dir'])
        if not p['out_dir']: self.runp.message('choose an output folder (Processing > output)'); return
        mode, ass, prob = calibration_plan(p)
        self.runp.message('calibration plan: ' + str(mode) + ''.join(f'\n  - {x}' for x in ass))
        if not prob: self.runp.message(acquisition_summary(p))
        if not prob and p['source'] == 'movie':                  # memory: refuse a run that cannot fit, before it starts
            try:
                import psutil
                from .project import memory_estimate
                gb, nt, _ = memory_estimate(p); free = psutil.virtual_memory().available / 1e9
                self.runp.message(f'memory: about {gb:.1f} GB needed for {nt} time points, {free:.1f} GB free')
                if gb > 0.9 * free:
                    prob = [f'the analysis needs about {gb:.1f} GB but only {free:.1f} GB are free: use a frame step, a crop, a temporal window or fewer frames (Data tab)']
            except Exception as e_: self.runp.message(f'memory check skipped: {e_}')
        if prob:
            self.tabs.setCurrentIndex(2); self.runp.message('NOT STARTED: ' + ' / '.join(prob)); self.runp.progress(0, 'not started: see the log'); return
        self.tabs.setCurrentIndex(2); self.runp.message(f'running {p["mode"]} on {p["source"]} data -> {p["out_dir"]}')
        self._start(_project_job, p, done=self._analysis_done)

    def _analysis_done(self, run_dir):
        self.runp.message(f'analysis finished: {run_dir}'); self.open_run(run_dir)

    def open_run(self, run_dir):
        if not run_dir or not os.path.exists(os.path.join(run_dir, 'run_info.json')):
            self.runp.message(f'not an lcsem run folder: {run_dir}'); return
        p = self.gather(); self.runp.message(f'loading {run_dir} ...')
        self._start(_volume_job, run_dir, int(p['volume']['bin']), float(p['volume']['dz_nm']), float(p['volume'].get('T_cap_nm', 1500.0)), done=lambda V: self._show(run_dir, V))

    def _show(self, run_dir, V):
        from .display import RunView, default_view
        if self.rv is not None: self.rv.remove()
        zx = 'auto' if self.disp.zauto.isChecked() else self.disp.zx.value()
        self.rv = RunView(self.viewer, run_dir, V.bin, V.dz, zx, volume=V, particle_size=self.disp.psize.value() or None)
        self.disp.zx.blockSignals(True); self.disp.zx.setValue(int(round(self.rv.zx))); self.disp.zx_lab.setText(f'{self.rv.zx:g}x'); self.disp.zx.blockSignals(False)
        self.viewer.dims.set_current_step(0, 0)
        default_view(self.viewer, self.rv); self.charts.set_run(self.rv); self.exp.out.edit.setText(self.exp.out.edit.text() or os.path.join(run_dir, 'export'))
        try: self.maps.set_run(self.rv)
        except Exception as e: self.runp.message(f'2-D maps: {e}')
        self.runp.progress(1.0, f'showing {V.n} time points of {os.path.basename(run_dir)} ({V.nz} x {V.ny} x {V.nx} voxels)')

    def export(self):
        if self.rv is None: self.runp.message('open or run an analysis first'); return
        out = self.exp.out.edit.text() or os.path.join(self.rv.run_dir, 'export'); fm = self.exp.formats()
        self.tabs.setCurrentIndex(2); self.runp.message(f'export {", ".join(fm)} -> {out}')
        self._start(_export_job, self.rv.run_dir, out, fm, self.rv.V, self.exp.check.isChecked(), done=self._export_done)

    def _export_done(self, M):
        self.exp.show_manifest(M); self.tabs.setCurrentIndex(4); self.runp.message('export finished')

    def preview_movies(self):
        """the first frame of each detector as the analysis will read it, side by side in 2-D (layout, part and crop applied)"""
        from .project import movie_sources
        p = self.gather()
        for lay in [l for l in self.viewer.layers if l.name.startswith('preview ')]: self.viewer.layers.remove(lay)
        try: src = movie_sources(p)
        except Exception as e: self.data.info.setText(f'preview: {e}'); return
        x0 = 0.0; txt = []
        for c, s in src.items():
            a = s.get(0); lay = self.viewer.add_image(a, name=f'preview {c}', colormap='gray', translate=(0, x0)); x0 += a.shape[1] * 1.05
            txt.append(f'{c}: {a.shape[1]} x {a.shape[0]} px, grey {a.min():.0f}-{a.max():.0f}')
        self.viewer.dims.ndisplay = 2; self.viewer.reset_view()
        self.data.info.setText('preview (left to right: ' + ', '.join(src) + '): ' + '; '.join(txt) + '. Au particles should be bright in BSE and absent in SE; '
                               'bubbles (gas at the top membrane) dark in SE. Remove the preview layers in the layer list when done.')

    # ---------------------------------------------------------------------------------------------- display
    def _time_changed(self, event=None):
        if self.rv is not None:
            i = self.rv.frame_index(); self.charts.set_time(i)
            try: self.maps.set_time(i)
            except Exception: pass

    def set_z(self, zx):
        if self.rv is not None: self.rv.set_z_exaggeration(zx); self.rv._on_time()

    def set_particle_size(self, d):
        if self.rv is not None: self.rv.set_particle_size(d or self.rv.default_particle_size())

    VIEWS = {'oblique': (35.0, -25.0), 'top': (90.0, 0.0), 'side': (0.0, 0.0)}
    def set_view(self, key):
        from .display import default_view
        el, az = self.VIEWS[key]; default_view(self.viewer, self.rv, elevation=el, azimuth=az)

    def set_rendering(self, mode):
        if self.rv is not None and 'liquid' in self.rv.layers: self.rv.layers['liquid'].rendering = mode

    def set_iso(self, k):
        if self.rv is None: return
        for n in ('liquid', 'gas'):
            if n in self.rv.layers: self.rv.layers[n].iso_threshold = float(k)

    def reset_view(self):
        from .display import default_view
        default_view(self.viewer, self.rv)

    def play(self):
        try:
            qt = self.viewer.window._qt_viewer; qt.dims.play(0, fps=float(self.disp.fps.value()))
        except Exception as e: self.runp.message(f'play: {e}')

    def record_movie_dialog(self):
        from qtpy.QtWidgets import QFileDialog
        if self.rv is None: self.runp.message('open or run an analysis first'); return
        fn = QFileDialog.getSaveFileName(None, 'Record the 3-D view over time', 'lcsem_3d.mp4', 'MP4 video (*.mp4);;GIF (*.gif)')[0]
        if fn: self.record_movie(fn)

    def record_movie(self, fn, fps=None):
        """every time point of the current 3-D view (as seen: camera, layers, z exaggeration) into an MP4 or GIF; frames are
        streamed to the file (not kept in memory), cropped to the size of the first one (even, for the video codec)"""
        import imageio.v2 as iio
        from qtpy.QtWidgets import QApplication
        fps = float(fps or self.disp.fps.value()); cur = self.rv.frame_index(); n = self.rv.V.n; hw = None
        gif = fn.lower().endswith('.gif')
        w = iio.get_writer(fn, mode='I', duration=1000.0 / fps, loop=0) if gif else iio.get_writer(fn, fps=fps, macro_block_size=2)
        try:
            for i in range(n):
                self.viewer.dims.set_current_step(0, i); QApplication.processEvents()
                im = self.viewer.screenshot(canvas_only=True, flash=False)[..., :3]
                if hw is None: hw = (im.shape[0] // 2 * 2, im.shape[1] // 2 * 2)
                if im.shape[0] < hw[0] or im.shape[1] < hw[1]:                    # the canvas shrank: pad to the first size
                    pad = np.zeros(hw + (3,), im.dtype); pad[:min(hw[0], im.shape[0]), :min(hw[1], im.shape[1])] = im[:hw[0], :hw[1]]; im = pad
                w.append_data(np.ascontiguousarray(im[:hw[0], :hw[1]])); self.runp.progress((i + 1) / n, f'recording frame {i + 1}/{n}')
        finally:
            w.close(); self.viewer.dims.set_current_step(0, cur)
        self.runp.message(f'movie written: {fn} ({n} frames, {fps:g} per second)'); return fn

    def save_charts_dialog(self):
        from qtpy.QtWidgets import QFileDialog
        fn = QFileDialog.getSaveFileName(None, 'Save the charts', 'lcsem_charts.png', 'PNG (*.png);;PDF (*.pdf);;SVG (*.svg)')[0]
        if fn: self.charts.save_png(fn); self.runp.message(f'charts saved: {fn}')

    def screenshot_dialog(self):
        from qtpy.QtWidgets import QFileDialog
        fn = QFileDialog.getSaveFileName(None, 'Screenshot of the 3-D view', 'lcsem_view.png', 'PNG (*.png)')[0]
        if fn: self.screenshot(fn, canvas_only=True)

    def screenshot(self, fn, canvas_only=False):
        import imageio.v3 as iio
        img = self.viewer.screenshot(canvas_only=canvas_only, flash=False); iio.imwrite(fn, img); return fn

def main(argv=None):
    import napari
    argv = sys.argv[1:] if argv is None else argv
    app = LcsemApp()
    if argv:
        a = argv[0]
        if os.path.isdir(a): app.data.source.setCurrentIndex(2); app.data.rdir.edit.setText(a); app.open_run(a)
        elif a.endswith('.json'): app.load_project(a)
    napari.run()

if __name__ == '__main__':
    main()
