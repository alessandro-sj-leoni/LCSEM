"""The GUI panels (Qt widgets docked in napari). Each panel reads from and writes to the project dict (lcsem.gui.project)."""
from __future__ import annotations
import os, json
from qtpy.QtCore import Qt, Signal
from qtpy.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox, QLabel, QLineEdit, QPushButton, QComboBox,
                            QSpinBox, QDoubleSpinBox, QCheckBox, QFileDialog, QStackedWidget, QPlainTextEdit, QProgressBar, QScrollArea,
                            QTableWidget, QTableWidgetItem, QSlider, QGridLayout, QSizePolicy, QHeaderView)
from .project import MODES, MODELS, CAL_MODES, LAYOUTS
from .. import denoise as DN

TIP = {
    'nlm': 'Non-local means (Buades, Coll & Morel 2005): averages similar patches; strong on piecewise-smooth SE/BSE frames.',
    'bm3d': 'BM3D (Dabov et al. 2007): collaborative filtering of similar blocks; slow (seconds per frame; about a minute for 1280 x 960).',
    'tv': 'Total variation (Rudin, Osher & Fatemi 1992; Chambolle 2004): edge-preserving, fast.',
    'gaussian': 'Gaussian smoothing: the classical baseline.',
    'mppca': 'Marchenko-Pastur PCA (Veraart et al. 2016): PCA of patches x frames, noise components removed by random-matrix theory. Movies only. '
             'Pools frames: best when the scene changes slowly; blurs fast changes (docs/VALIDATION_DENOISING.md).',
    'svd_gd': 'Optimal singular-value hard threshold (Gavish & Donoho 2014) on tiles x frames. Movies only; for slowly changing scenes.',
    'temporal_mean': 'Sliding temporal mean over 5 frames (baseline). Movies only.',
    'temporal_median': 'Sliding temporal median over 5 frames (baseline). Movies only.',
    'none': 'No denoising (the thickness maps are still smoothed by the calibration).',
    'vst': 'Variance stabilisation: generalized Anscombe transform (Poisson-Gaussian noise model fitted per frame, or per series for the series methods; '
           'after Foi et al. 2008) before the denoiser, and the closed-form approximation of its exact unbiased inverse after it (Makitalo & Foi 2011, 2013).',
}

def _file_row(parent, placeholder='', folder=False, filt='All files (*)'):
    w = QWidget(parent); h = QHBoxLayout(w); h.setContentsMargins(0, 0, 0, 0); e = QLineEdit(); e.setPlaceholderText(placeholder); b = QPushButton('...'); b.setFixedWidth(28)
    def pick():
        p = QFileDialog.getExistingDirectory(parent, placeholder) if folder else QFileDialog.getOpenFileName(parent, placeholder, '', filt)[0]
        if p: e.setText(p)
    b.clicked.connect(pick); h.addWidget(e, 1); h.addWidget(b); w.edit = e; return w

def _dspin(v, lo, hi, step=1.0, dec=2, suffix=''):
    s = QDoubleSpinBox(); s.setRange(lo, hi); s.setDecimals(dec); s.setSingleStep(step); s.setValue(v)
    if suffix: s.setSuffix(' ' + suffix)
    return s

def _ispin(v, lo, hi):
    s = QSpinBox(); s.setRange(lo, hi); s.setValue(v); return s

def _scroll(inner):
    sa = QScrollArea(); sa.setWidgetResizable(True); sa.setWidget(inner); sa.setFrameShape(QScrollArea.NoFrame)
    sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff); return sa

# ------------------------------------------------------------------------------------------------------------------ 1 Data
class DataPanel(QWidget):
    open_run = Signal(str)
    preview = Signal()
    def __init__(self, parent=None):
        super().__init__(parent); v = QVBoxLayout(self)
        f = QFormLayout(); self.name = QLineEdit('series'); f.addRow('name', self.name)
        self.source = QComboBox(); self.source.addItems(['JEOL image series (folder)', 'Movies / image stacks', 'Finished lcsem run']); f.addRow('source', self.source)
        v.addLayout(f); self.stack = QStackedWidget(); v.addWidget(self.stack)
        # JEOL
        w = QWidget(); fj = QFormLayout(w); self.jfolder = _file_row(self, 'folder with NAME.tif + NAME.txt', folder=True); fj.addRow('folder', self.jfolder)
        self.jprefix = QLineEdit(); self.jprefix.setPlaceholderText('file name prefix, e.g. 20260821'); fj.addRow('prefix', self.jprefix)
        self.jscan = QPushButton('List series in folder'); fj.addRow(self.jscan); self.jseries = QComboBox(); fj.addRow('series', self.jseries)
        self.jmag = _dspin(0, 0, 1e7, 1000, 0, 'x'); fj.addRow('magnification', self.jmag)
        self.jfrom = QLineEdit(); self.jfrom.setPlaceholderText('hh:mm:ss'); self.jto = QLineEdit(); self.jto.setPlaceholderText('hh:mm:ss')
        fj.addRow('from', self.jfrom); fj.addRow('to', self.jto); self.stack.addWidget(w)
        self.jscan.clicked.connect(self._scan_jeol); self.jseries.currentIndexChanged.connect(self._pick_series)
        # Movies
        w = QWidget(); fm = QFormLayout(w); self.mfile = {}
        for c in ('SE', 'BSE', 'STEM'):
            self.mfile[c] = _file_row(self, f'{c} movie (TIFF stack, AVI, MP4, folder)', filt='Movies and stacks (*.tif *.tiff *.avi *.mp4 *.mov *.mkv);;All files (*)'); fm.addRow(f'{c} file', self.mfile[c])
        self.mlayout = QComboBox(); self.mlayout.addItems(LAYOUTS); fm.addRow('layout', self.mlayout)
        self.mparts = _ispin(2, 1, 4); fm.addRow('parts per frame', self.mparts)
        self.mpart = {c: _ispin(i, 0, 3) for i, c in enumerate(('SE', 'BSE', 'STEM'))}
        hp = QHBoxLayout(); [hp.addWidget(QLabel(c)) or hp.addWidget(self.mpart[c]) for c in ('SE', 'BSE', 'STEM')]; fm.addRow('part index', hp)
        self.mft = _dspin(0, 0, 3600, 0.1, 4, 's'); self.mft.setToolTip('frame time; 0 = from the file frame rate'); fm.addRow('frame time', self.mft)
        self.mt0 = QLineEdit('00:00:00'); self.mt0.setToolTip('clock time of the start of the first frame (hh:mm:ss); 00:00:00 = times relative to the start')
        fm.addRow('start time', self.mt0)
        self.mstart = _ispin(0, 0, 10 ** 7); self.mstop = _ispin(0, 0, 10 ** 7); self.mstop.setToolTip('0 = to the end'); self.mstep = _ispin(1, 1, 10 ** 5); self.mwin = _ispin(1, 1, 1000)
        fr = QHBoxLayout(); [fr.addWidget(QLabel(t)) or fr.addWidget(s) for t, s in (('start', self.mstart), ('stop', self.mstop), ('step', self.mstep))]; fm.addRow('frames', fr)
        self.mwin.setToolTip('each time point = mean of this many consecutive frames'); fm.addRow('temporal window', self.mwin)
        self.mcrop = QLineEdit(); self.mcrop.setPlaceholderText('y0 y1 x0 x1 of the whole frame, before splitting (optional: data bar, separator)'); fm.addRow('crop', self.mcrop)
        self.mreg = QComboBox(); self.mreg.addItems(['phase', 'none']); self.mreg.setToolTip('drift correction: cross-correlation of band-passed neighbouring frames (phase), or none (stable stage)')
        self.mroi = QLineEdit(); self.mroi.setPlaceholderText('y0 y1 x0 x1 of a region that does not change (optional)')
        self.mroi.setToolTip('registration needs static features: choose e.g. the window edge or particles stuck to a membrane; bubbles and moving particles bias it')
        hr = QHBoxLayout(); hr.addWidget(self.mreg); hr.addWidget(self.mroi, 1); fm.addRow('drift correction', hr)
        self.mprobe = QPushButton('Probe files'); self.mprev = QPushButton('Preview first frame')
        self.mprev.setToolTip('show the first frame of each detector as it will be read (layout, part, crop): check that SE and BSE are the right way round')
        hb = QHBoxLayout(); hb.addWidget(self.mprobe); hb.addWidget(self.mprev); fm.addRow(hb)
        self.mprobe.clicked.connect(self._probe); self.mprev.clicked.connect(self.preview.emit); self.stack.addWidget(w)
        # finished run
        w = QWidget(); fr_ = QFormLayout(w); self.rdir = _file_row(self, 'lcsem output folder (run_info.json)', folder=True); fr_.addRow('run folder', self.rdir)
        self.ropen = QPushButton('Open run'); fr_.addRow(self.ropen); self.ropen.clicked.connect(lambda: self.open_run.emit(self.rdir.edit.text())); self.stack.addWidget(w)
        self.source.currentIndexChanged.connect(self.stack.setCurrentIndex)
        # common acquisition parameters
        g = QGroupBox('acquisition and cell'); fc = QFormLayout(g)
        self.px = _dspin(0.0, 0.0, 1e4, 0.1, 3, 'nm'); self.py = _dspin(0.0, 0.0, 1e4, 0.1, 3, 'nm')
        for s_ in (self.px, self.py): s_.setSpecialValueText('enter'); s_.setToolTip('pixel size of the images: measure it on a grating or read it from the scale bar (required)')
        hp = QHBoxLayout(); hp.addWidget(QLabel('x')); hp.addWidget(self.px); hp.addWidget(QLabel('y')); hp.addWidget(self.py); fc.addRow('pixel size', hp)
        self.kv = _dspin(15.0, 0.5, 30.0, 1.0, 1, 'kV'); fc.addRow('beam energy', self.kv)
        self.cur = _dspin(0.0, 0.0, 1e6, 10.0, 1, 'pA'); self.cur.setSpecialValueText('unknown'); self.cur.setToolTip('probe current: electron dose per frame and cumulative (e/nm2, MGy); 0 = unknown')
        fc.addRow('probe current', self.cur)
        self.bits = QComboBox(); self.bits.addItems(['8', '16']); fc.addRow('bit depth', self.bits)
        self.mem = _dspin(30.0, 0, 500, 5, 1, 'nm'); fc.addRow('SiN membranes', self.mem)
        self.chan = _dspin(500.0, 0, 1e5, 50, 0, 'nm'); fc.addRow('channel height', self.chan)
        self.part = _dspin(38.0, 1, 1000, 1, 1, 'nm'); fc.addRow('Au particle diameter', self.part)
        self.fedge = QCheckBox('Si window frame in view'); fc.addRow(self.fedge)
        self.skip = _ispin(0, 0, 10000); self.skip.setToolTip('first scan lines left out of the flat-field / segmentation (e.g. a transient)'); fc.addRow('skip first rows', self.skip)
        v.addWidget(g); self.info = QLabel(''); self.info.setWordWrap(True); v.addWidget(self.info); v.addStretch(1)

    def _scan_jeol(self):
        from .. import io_jeol as J
        try:
            fr = J.scan_folder_all(self.jfolder.edit.text(), self.jprefix.text())
            ch = {'BSE': dict(signal='BED_C', role='thickness'), 'STEM': dict(signal=['STEM', 'TED', 'BF', 'DF'], role='thickness'), 'SE': dict(signal=['UED', 'LED', 'SEI'], role='contact')}
            series = J.group_scans(fr, ch); self._series = sorted(series.items(), key=lambda kv: kv[1][0].time_s)
            self.jseries.clear()
            for (x, y, mag), lst in self._series:
                chans = sorted({c for s in lst for c in s.channels}); self.jseries.addItem(f'{mag:.0f}x  {len(lst)} scans  {lst[0].time_str[:8]}-{lst[-1].time_str[:8]}  {"+".join(chans)}  {lst[0].kv:g} kV')
            self.info.setText(f'{len(fr)} images, {len(series)} series')
        except Exception as e: self.info.setText(f'could not read the folder: {e}')

    def _pick_series(self, i):
        if not getattr(self, '_series', None) or i < 0: return
        (x, y, mag), lst = self._series[i]; self.jmag.setValue(mag); self.jfrom.setText(lst[0].time_str[:8]); self.jto.setText(lst[-1].time_str[:8]); self.kv.setValue(lst[0].kv or self.kv.value())

    def _probe(self):
        """reads each movie's header and first frames: frames, size, frame rate, bit depth, near-duplicate frames"""
        from ..io_movie import probe
        out = []; lay = self.mlayout.currentText(); parts = self.mparts.value() if lay != 'separate files' else 1
        for c, w in self.mfile.items():
            f = w.edit.text()
            if not f: continue
            try:
                d = probe(f)
                out.append(f'{c}: {d["n_frames"]} frames {d["shape"][1]} x {d["shape"][0]} px, {d["kind"]} {d["dtype"]}, grey {d["min"]:.0f}-{d["max"]:.0f}, '
                           f'frame rate {d["fps"] or "not stored"}' + (f', axes {d["axes"]}' if d.get('axes') else ''))
                if d.get('bits') in (8, 16) and self.bits.currentText() != str(d['bits']):
                    self.bits.setCurrentText(str(d['bits'])); out.append(f'  bit depth set to {d["bits"]} (from the file)')
                if d.get('bits') == 8 and d['max'] > 255: out.append('  WARNING: values above 255 in an 8-bit file?')
                if d['fps'] and not self.mft.value():
                    per = (parts if lay == 'interleaved frames' else 1) / d['fps']; self.mft.setValue(per)
                    out.append(f'  frame time set to {per:.4g} s from the file frame rate' + (f' x {parts} interleaved parts' if lay == 'interleaved frames' else '') +
                               ' - check it: screen recordings store the recording rate, not the SEM frame time')
                elif not d['fps'] and not self.mft.value(): out.append('  no frame rate in the file: enter the frame time (else 1 s is assumed)')
                if d.get('duplicate_fraction', 0) > 0.3:
                    out.append(f'  {100 * d["duplicate_fraction"]:.0f} % of consecutive frames are near-duplicates (screen recording?): '
                               f'use step {d["suggested_step"]} and the SEM frame time' + (f' ({d["suggested_step_note"]})' if d.get('suggested_step_note') else ''))
            except Exception as e: out.append(f'{c}: {e}')
        self.info.setText('\n'.join(out) or 'choose the movie files first')

    def to_project(self, p):
        p['name'] = self.name.text() or 'series'; p['source'] = ('jeol', 'movie', 'run')[self.source.currentIndex()]
        p['jeol'].update(folder=self.jfolder.edit.text(), prefix=self.jprefix.text(), mag=self.jmag.value(), time_from=self.jfrom.text(), time_to=self.jto.text())
        mv = p['movie']; mv['files'] = {c: w.edit.text() for c, w in self.mfile.items()}; mv['layout'] = self.mlayout.currentText(); mv['parts'] = self.mparts.value()
        mv['part'] = {c: s.value() for c, s in self.mpart.items()}; mv['frame_time_s'] = self.mft.value(); mv['t0'] = self.mt0.text()
        mv['start'], mv['stop'], mv['step'], mv['window'] = self.mstart.value(), self.mstop.value(), self.mstep.value(), self.mwin.value(); mv['crop'] = self.mcrop.text()
        p['registration'] = dict(method=self.mreg.currentText(), roi=self.mroi.text()); p['beam_current_pA'] = self.cur.value()
        p['run_dir'] = self.rdir.edit.text(); p['pixel_nm'] = [self.px.value(), self.py.value()]; p['kV'] = self.kv.value(); p['bits'] = int(self.bits.currentText())
        p['membranes_nm'] = [self.mem.value()] * 2; p['channel_nm'] = self.chan.value(); p['particle_nm'] = self.part.value(); p['mag'] = self.jmag.value()
        p['frame_edge'] = self.fedge.isChecked(); p['skip_rows'] = self.skip.value(); return p

    def from_project(self, p):
        self.name.setText(p['name']); self.source.setCurrentIndex({'jeol': 0, 'movie': 1, 'run': 2}[p['source']])
        j = p['jeol']; self.jfolder.edit.setText(j['folder']); self.jprefix.setText(j['prefix']); self.jmag.setValue(float(j.get('mag') or 0)); self.jfrom.setText(j.get('time_from', '')); self.jto.setText(j.get('time_to', ''))
        mv = p['movie']
        for c, w in self.mfile.items(): w.edit.setText(mv['files'].get(c, ''))
        self.mlayout.setCurrentText(mv['layout']); self.mparts.setValue(int(mv['parts']))
        for c, s in self.mpart.items(): s.setValue(int(mv['part'].get(c, 0)))
        self.mft.setValue(float(mv['frame_time_s'])); self.mt0.setText(mv['t0']); self.mstart.setValue(int(mv['start'])); self.mstop.setValue(int(mv['stop']))
        self.mstep.setValue(int(mv['step'])); self.mwin.setValue(int(mv['window'])); self.mcrop.setText(str(mv.get('crop') or ''))
        rg = p.get('registration') or {}; self.mreg.setCurrentText(rg.get('method', 'phase') if rg.get('method') in ('phase', 'none') else 'phase'); self.mroi.setText(str(rg.get('roi') or ''))
        self.cur.setValue(float(p.get('beam_current_pA') or 0))
        self.rdir.edit.setText(p.get('run_dir', '')); self.px.setValue(p['pixel_nm'][0]); self.py.setValue(p['pixel_nm'][1]); self.kv.setValue(p['kV'])
        self.bits.setCurrentText(str(p['bits'])); self.mem.setValue(p['membranes_nm'][0]); self.chan.setValue(p['channel_nm']); self.part.setValue(p['particle_nm'])
        self.fedge.setChecked(bool(p.get('frame_edge'))); self.skip.setValue(int(p.get('skip_rows', 0)))

# ------------------------------------------------------------------------------------------------------------------ 2 Processing
class ProcessingPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent); v = QVBoxLayout(self)
        g = QGroupBox('detectors'); f = QFormLayout(g); self.mode = QComboBox(); self.mode.addItems(MODES); f.addRow('combination', self.mode)
        self.se_sig = QComboBox(); self.se_sig.addItems(['UED', 'LED', 'SEI']); self.se_sig.setToolTip('JEOL signal name of the SE detector (UED in-lens, LED E-T)'); f.addRow('SE detector', self.se_sig)
        self.mode_note = QLabel(''); self.mode_note.setWordWrap(True); f.addRow(self.mode_note); v.addWidget(g)
        g = QGroupBox('detector model (thickness)'); f = QFormLayout(g); self.model = QComboBox(); self.model.addItems(MODELS); f.addRow('model', self.model)
        self.curve = _file_row(self, 'Monte Carlo curve (.json, lcsem mc-curve)', filt='Curve (*.json)'); f.addRow('curve file', self.curve)
        self.depth_curve = _file_row(self, 'particle depth curve (.json, optional)', filt='Curve (*.json)'); f.addRow('depth curve', self.depth_curve)
        self.mrad = QLineEdit('0 100'); self.mrad.setToolTip('STEM detector acceptance in mrad (inner outer)'); f.addRow('STEM mrad', self.mrad); v.addWidget(g)
        g = QGroupBox('calibration and references'); f = QFormLayout(g); self.cal = QComboBox(); self.cal.addItems(CAL_MODES); f.addRow('mode', self.cal)
        self.flat = _dspin(0.0, 0, 1e5, 10, 0, 'nm'); self.flat.setSpecialValueText('not used (no assumption)')
        self.flat.setToolTip('ASSUMED median liquid thickness of all frames (modes ...+flat). Every absolute thickness then scales with this assumption. '
                             'Leave at "not used" and record a dark frame (beam blanked) instead: with the Au particles it calibrates without assumptions.')
        f.addRow('assumed flat field', self.flat)
        self.usep = QCheckBox('use Au particles as gain standard'); self.usep.setChecked(True); f.addRow(self.usep)
        self.B0 = {c: _dspin(0, -1e6, 1e6, 1, 2) for c in ('BSE', 'STEM')}; self.g = {c: _dspin(0, -1e7, 1e7, 1, 2) for c in ('BSE', 'STEM')}
        for c in ('BSE', 'STEM'):
            h = QHBoxLayout(); h.addWidget(QLabel('B0')); h.addWidget(self.B0[c]); h.addWidget(QLabel('g')); h.addWidget(self.g[c]); f.addRow(f'manual {c}', h)
        self.refs = {}
        for kind in ('dark', 'empty', 'full'):
            for c in ('BSE', 'STEM', 'SE'):
                self.refs[(kind, c)] = _file_row(self, f'{kind} reference, {c}', filt='Images and movies (*.tif *.tiff *.avi *.mp4);;All files (*)')
                f.addRow(f'{kind} {c}', self.refs[(kind, c)])
        v.addWidget(g)
        import importlib.util
        g = QGroupBox('denoising'); f = QFormLayout(g); self.dn = QComboBox()
        self.dn.addItems([m for m in DN.METHODS if m != 'bm3d' or importlib.util.find_spec('bm3d') is not None]); self.dn.setCurrentText('nlm'); f.addRow('method', self.dn)
        self.vst = QCheckBox('variance stabilisation (Poisson-Gaussian)'); self.vst.setChecked(True); self.vst.setToolTip(TIP['vst']); f.addRow(self.vst)
        self.strength = _dspin(1.0, 0.1, 5.0, 0.1, 2); f.addRow('strength', self.strength); self.dn_se = QCheckBox('also denoise SE'); self.dn_se.setChecked(True); f.addRow(self.dn_se)
        self.smooth = _dspin(0, 0, 100, 1, 1, 'px'); self.smooth.setToolTip('smoothing of the grey level before calibration; 0 = default (15 px)'); f.addRow('calibration smoothing', self.smooth)
        self.dn_note = QLabel(''); self.dn_note.setWordWrap(True); f.addRow(self.dn_note); v.addWidget(g)
        self.dn.currentTextChanged.connect(lambda m: self.dn_note.setText(TIP.get(m, ''))); self.dn_note.setText(TIP['nlm'])
        g = QGroupBox('particles, segmentation, objects'); f = QFormLayout(g)
        self.pdet = QCheckBox('detect Au particles'); self.pdet.setChecked(True); f.addRow(self.pdet); self.pthr = _dspin(6.0, 2, 50, 0.5, 1, 'sigma'); f.addRow('particle threshold', self.pthr)
        self.seg = QCheckBox('PCA + Gaussian-mixture segmentation (needs SE)'); self.seg.setChecked(True); f.addRow(self.seg)
        self.crit = QComboBox(); self.crit.addItems(['ICL and BIC', 'ICL', 'BIC']); f.addRow('criteria', self.crit)
        self.stab = _ispin(5, 0, 50); self.stab.setToolTip('random subsamples used to choose the number of classes (0 = off, faster)'); f.addRow('stability runs', self.stab)
        self.nfit = _ispin(80000, 5000, 10 ** 7); f.addRow('pixels per fit', self.nfit)
        self.se_area = _dspin(0.01, 0.0001, 100, 0.005, 4, 'µm²'); self.se_area.setToolTip('smallest SE contact region kept (about 110 nm diameter for 0.01 µm²)')
        self.se_smooth = _dspin(6.0, 1.0, 50, 1.0, 1, 'px'); self.se_smooth.setToolTip('smoothing of the SE before the contact map')
        h = QHBoxLayout(); h.addWidget(QLabel('min area')); h.addWidget(self.se_area); h.addWidget(QLabel('smoothing')); h.addWidget(self.se_smooth); f.addRow('SE contact', h)
        self.se_gas = _dspin(50.0, 1.0, 5000, 10, 0, 'nm'); self.se_gas.setToolTip('SE only: nominal gas height drawn where the SE shows contact (not measured)'); f.addRow('SE-only gas height', self.se_gas)
        self.obj = QCheckBox('bubbles / objects (watershed + tracking)'); self.obj.setChecked(True); f.addRow(self.obj)
        self.osrc = QComboBox(); self.osrc.addItems(['se_contact', 'gas']); f.addRow('object source', self.osrc)
        self.omin = _ispin(100, 1, 10 ** 7); f.addRow('min object area (px)', self.omin); self.odist = _ispin(10, 1, 1000); f.addRow('watershed min distance (px)', self.odist)
        v.addWidget(g)
        g = QGroupBox('3-D volume'); f = QFormLayout(g); self.vbin = _ispin(4, 1, 64); f.addRow('lateral binning', self.vbin); self.vdz = _dspin(10.0, 0.5, 1000, 1, 1, 'nm'); f.addRow('voxel height', self.vdz)
        self.vcap = _dspin(1500, 100, 1e5, 100, 0, 'nm'); f.addRow('max liquid shown', self.vcap); v.addWidget(g)
        g = QGroupBox('output'); f = QFormLayout(g); self.out = _file_row(self, 'output folder', folder=True); f.addRow('folder', self.out); v.addWidget(g); v.addStretch(1)
        self.mode.currentTextChanged.connect(self._mode_note); self._mode_note(self.mode.currentText())

    def _mode_note(self, m):
        notes = {'SE only': 'SE marks where gas touches the top membrane; no thickness is measured (nominal 3-D model).',
                 'BSE only': 'thickness and particle depth from BSE (core fraction).',
                 'SE + BSE': 'thickness (BSE), gas at the top membrane (SE), particles in 3-D.',
                 'SE + BSE + STEM': 'fused BSE + STEM thickness (10-60x more information per electron below ~0.5 um), particle depth from the BSE/STEM ratio, gas from SE.',
                 'BSE + STEM': 'fused thickness and BSE/STEM particle depth; no gas placement without SE.',
                 'STEM only': 'thickness from transmission; no particle depth from one detector at one kV.',
                 'SE + STEM': 'thickness from STEM, gas at the top membrane from SE.'}
        self.mode_note.setText(notes.get(m, ''))

    def to_project(self, p):
        p['mode'] = self.mode.currentText(); p['se_signal'] = self.se_sig.currentText()
        try: mr = [float(v) for v in self.mrad.text().replace(',', ' ').split()][:2]
        except Exception: mr = [0.0, 100.0]
        p['model'].update(kind=self.model.currentText(), curve_file=self.curve.edit.text(), stem_mrad=mr, depth_curve=self.depth_curve.edit.text())
        p['calibration'].update(mode=self.cal.currentText(), flat_T_nm=self.flat.value(), use_particles=self.usep.isChecked(),
                                B0={c: s.value() for c, s in self.B0.items()}, g={c: s.value() for c, s in self.g.items()})
        for (kind, c), w in self.refs.items(): p['references'][kind][c] = w.edit.text()
        p['denoise'].update(method=self.dn.currentText(), vst=self.vst.isChecked(), strength=self.strength.value(), se=self.dn_se.isChecked()); p['smooth_sigma_px'] = self.smooth.value()
        p['particles'].update(detect=self.pdet.isChecked(), threshold=self.pthr.value())
        p['segmentation'].update(enabled=self.seg.isChecked(), criteria={'ICL and BIC': ['icl', 'bic'], 'ICL': ['icl'], 'BIC': ['bic']}[self.crit.currentText()],
                                 stability_runs=self.stab.value(), n_fit=self.nfit.value())
        p['objects'].update(enabled=self.obj.isChecked(), source=self.osrc.currentText(), min_area_px=self.omin.value(), min_distance_px=self.odist.value())
        p['se_min_area_um2'] = self.se_area.value(); p['se_sigma_px'] = self.se_smooth.value(); p['se_gas_nm'] = self.se_gas.value()
        p['volume'].update(bin=self.vbin.value(), dz_nm=self.vdz.value(), T_cap_nm=self.vcap.value()); p['out_dir'] = self.out.edit.text(); return p

    def from_project(self, p):
        self.mode.setCurrentText(p['mode']); self.se_sig.setCurrentText(p.get('se_signal', 'UED')); m = p['model']
        self.model.setCurrentText(m['kind'] if m['kind'] in MODELS else MODELS[0]); self.curve.edit.setText(m.get('curve_file', '')); self.depth_curve.edit.setText(m.get('depth_curve', ''))
        self.mrad.setText(' '.join(f'{v:g}' for v in m.get('stem_mrad', [0, 100])))
        c = p['calibration']; self.cal.setCurrentText(c['mode']); self.flat.setValue(float(c.get('flat_T_nm') or 0)); self.usep.setChecked(bool(c.get('use_particles', True)))
        for k in ('BSE', 'STEM'): self.B0[k].setValue(float(c['B0'].get(k, 0))); self.g[k].setValue(float(c['g'].get(k, 0)))
        for (kind, ch), w in self.refs.items(): w.edit.setText(p['references'][kind].get(ch, ''))
        d = p['denoise']; self.dn.setCurrentText(d['method']); self.vst.setChecked(bool(d['vst'])); self.strength.setValue(float(d['strength'])); self.dn_se.setChecked(bool(d.get('se', True)))
        self.smooth.setValue(float(p.get('smooth_sigma_px') or 0)); self.pdet.setChecked(bool(p['particles']['detect'])); self.pthr.setValue(float(p['particles']['threshold']))
        s = p['segmentation']; self.seg.setChecked(bool(s['enabled'])); self.crit.setCurrentText({('icl', 'bic'): 'ICL and BIC', ('icl',): 'ICL', ('bic',): 'BIC'}.get(tuple(s['criteria']), 'ICL and BIC'))
        self.stab.setValue(int(s['stability_runs'])); self.nfit.setValue(int(s['n_fit'])); o = p['objects']; self.obj.setChecked(bool(o['enabled'])); self.osrc.setCurrentText(o['source'])
        self.omin.setValue(int(o['min_area_px'])); self.odist.setValue(int(o['min_distance_px'])); vv = p['volume']; self.vbin.setValue(int(vv['bin'])); self.vdz.setValue(float(vv['dz_nm']))
        self.se_area.setValue(float(p.get('se_min_area_um2', 0.01))); self.se_smooth.setValue(float(p.get('se_sigma_px', 6.0))); self.se_gas.setValue(float(p.get('se_gas_nm', 50.0)))
        self.vcap.setValue(float(vv['T_cap_nm'])); self.out.edit.setText(p.get('out_dir', ''))

# ------------------------------------------------------------------------------------------------------------------ 3 Run
class RunPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent); v = QVBoxLayout(self)
        h = QHBoxLayout(); self.run = QPushButton('Run analysis'); self.abort = QPushButton('Abort'); self.abort.setEnabled(False)
        self.run.setStyleSheet('font-weight: bold;'); h.addWidget(self.run); h.addWidget(self.abort); v.addLayout(h)
        h = QHBoxLayout(); self.save = QPushButton('Save project...'); self.load = QPushButton('Load project...'); h.addWidget(self.save); h.addWidget(self.load); v.addLayout(h)
        self.bar = QProgressBar(); self.bar.setRange(0, 1000); v.addWidget(self.bar); self.status = QLabel('ready'); self.status.setWordWrap(True); v.addWidget(self.status)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True); self.log.setMaximumBlockCount(5000); v.addWidget(self.log, 1)
    def progress(self, f, m=''):
        self.bar.setValue(int(1000 * max(0.0, min(1.0, f))))
        if m: self.status.setText(m)
    def message(self, m): self.log.appendPlainText(m)

# ------------------------------------------------------------------------------------------------------------------ 4 Display
class DisplayPanel(QWidget):
    zx_changed = Signal(float)
    view_requested = Signal(str)
    def __init__(self, parent=None):
        super().__init__(parent); v = QVBoxLayout(self); f = QFormLayout()
        self.zx = QSlider(Qt.Horizontal); self.zx.setRange(1, 40); self.zx.setValue(5); self.zx_lab = QLabel('5x')
        self.zauto = QCheckBox('auto'); self.zauto.setChecked(True); self.zauto.setToolTip('choose the exaggeration from the field of view when a run is opened (1x at 60k, 5x at 12k)')
        h = QHBoxLayout(); h.addWidget(self.zx, 1); h.addWidget(self.zx_lab); h.addWidget(self.zauto); f.addRow('z exaggeration', h)
        self.zx.valueChanged.connect(lambda k: (self.zx_lab.setText(f'{k}x'), self.zx_changed.emit(float(k)))); self.zx.sliderMoved.connect(lambda *_: self.zauto.setChecked(False))
        self.render = QComboBox(); self.render.addItems(['iso', 'translucent', 'attenuated_mip', 'mip', 'average']); f.addRow('liquid rendering', self.render)
        self.iso = _ispin(128, 1, 255); self.iso.setToolTip('isosurface level of the liquid and gas fractions (128 = half-filled voxel)'); f.addRow('iso level (0-255)', self.iso)
        self.psize = _dspin(0, 0, 5000, 10, 0, 'nm'); self.psize.setSpecialValueText('auto'); self.psize.setToolTip('display diameter of the Au spheres; 0 = automatic (true size, at least 0.8 % of the field)')
        f.addRow('Au sphere size', self.psize)
        h = QHBoxLayout(); self.views = {}
        for key, lab in (('oblique', 'oblique'), ('top', 'top (SEM view)'), ('side', 'side (x-z)')):
            b = QPushButton(lab); b.clicked.connect(lambda _=False, k=key: self.view_requested.emit(k)); h.addWidget(b); self.views[key] = b
        f.addRow('view', h)
        self.ndisp = QPushButton('2-D / 3-D'); self.reset = QPushButton('reset view'); h = QHBoxLayout(); h.addWidget(self.ndisp); h.addWidget(self.reset); f.addRow(h)
        self.shot = QPushButton('screenshot...'); self.play = QPushButton('play time series'); self.movie = QPushButton('record movie...')
        self.movie.setToolTip('every time point of the 3-D view as seen now, into an MP4 or GIF'); self.fps = _dspin(2.0, 0.1, 60, 0.5, 1, 'fps')
        h = QHBoxLayout(); h.addWidget(self.play); h.addWidget(self.fps); h.addWidget(self.movie); h.addWidget(self.shot); f.addRow(h)
        v.addLayout(f)
        help_ = QLabel('Rotate: drag. Zoom: wheel. Pan: shift + drag. Time: slider at the bottom of the viewer (frames counted from 0 there, from 1 in the text).\n'
                       'Layers (left): liquid (blue), gas (orange), SE contact (green, gas touching the top membrane), cell walls (grey), '
                       'Au particles (light yellow spheres at their measured depth; grey vertical lines: depth not measured, anywhere in that column), '
                       'particle tracks, thickness map, classes and objects (2-D maps under the volume). The 2-D maps dock (next to the charts) shows '
                       'the thickness map with a colour bar and the input frames. Layer model: the top membrane is drawn flat and every change of '
                       'the column shows at the bottom membrane; z is exaggerated as stated in the view.')
        help_.setWordWrap(True); v.addWidget(help_)
        v.addStretch(1)

# ------------------------------------------------------------------------------------------------------------------ 5 Export
class ExportPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent); from ..export_formats import FORMATS, OPEN_WITH, available
        v = QVBoxLayout(self); g = QGroupBox('formats'); grid = QGridLayout(g); self.fmt = {}
        for i, f in enumerate(FORMATS):
            ok, hint = available(f); cb = QCheckBox(f); cb.setToolTip(OPEN_WITH.get(f, '') + ('' if ok else f'\nnot available here: {hint}'))
            cb.setChecked(ok and f in ('amira', 'tiff', 'ome-tiff', 'imaris', 'vtk', 'csv')); cb.setEnabled(ok); self.fmt[f] = cb; grid.addWidget(cb, i // 3, i % 3)
        v.addWidget(g); f = QFormLayout(); self.out = _file_row(self, 'export folder', folder=True); f.addRow('folder', self.out)
        self.check = QCheckBox('read every file back to check it'); self.check.setChecked(True); f.addRow(self.check)
        self.go = QPushButton('Export'); self.go.setStyleSheet('font-weight: bold;'); f.addRow(self.go); v.addLayout(f)
        self.table = QTableWidget(0, 4); self.table.setHorizontalHeaderLabels(['format', 'files', 'MB', 'checked / open with']); self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        v.addWidget(self.table, 1)
    def formats(self): return [f for f, cb in self.fmt.items() if cb.isChecked()]
    def show_manifest(self, M):
        self.table.setRowCount(len(M))
        for r, row in enumerate(M.itertuples()):
            for c, val in enumerate((row.format, str(row.n_files), f'{row.size_mb:.1f}', f'{"ok" if row.read_back else ("?" if row.read_back is None else "FAILED")} ({row.reader}); {row.open_with}')):
                self.table.setItem(r, c, QTableWidgetItem(val))
