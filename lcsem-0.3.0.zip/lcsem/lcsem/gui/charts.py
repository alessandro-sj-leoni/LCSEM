"""Charts dock: time series and per-frame distributions of the current run, following the napari time slider.

(a) liquid volume and (b) gas volume in the field of view vs time; (c) thickness distribution of the current frame;
(d) selectable: particle depth vs time (tracks), segmentation class areas, bubble (object) areas, or SE contact area; by
default the first of these the run has.
Colours: the validated categorical palette, dark-surface steps (lcsem dataviz rules); one axis per chart; the current time
point is marked in every time-series chart; hovering a chart shows the nearest value below it.
"""
from __future__ import annotations
import os, numpy as np, pandas as pd
from qtpy.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QComboBox, QLabel
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure

SURF, INK, INK2, GRID = '#262930', '#ffffff', '#c3c2b7', '#3d4148'
C = ['#3987e5', '#d95926', '#199e70', '#c98500', '#d55181', '#008300', '#9085e9', '#e66767']      # dark-surface steps, fixed order
SEQ = '#3987e5'

class ChartsWidget(QWidget):
    PANEL_D = ('particle depth', 'segmentation classes (ICL)', 'bubbles / objects', 'SE contact area', 'electron dose')
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self); lay.setContentsMargins(4, 4, 4, 4)
        from qtpy.QtWidgets import QPushButton
        row = QHBoxLayout(); row.addWidget(QLabel('chart (d):')); self.sel = QComboBox(); self.sel.addItems(self.PANEL_D); row.addWidget(self.sel); row.addStretch(1)
        self.save = QPushButton('save...'); self.save.setToolTip('save the four charts as PNG, PDF or SVG'); row.addWidget(self.save)
        lay.addLayout(row)
        self.fig = Figure(figsize=(5.2, 4.6), facecolor=SURF, layout='constrained'); self.canvas = FigureCanvasQTAgg(self.fig); lay.addWidget(self.canvas, 1)
        self.readout = QLabel(' '); self.readout.setStyleSheet(f'color: {INK2};'); self.readout.setWordWrap(True)      # long notes must not widen the dock
        from qtpy.QtWidgets import QSizePolicy
        self.readout.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred); lay.addWidget(self.readout)
        self.sel.currentIndexChanged.connect(lambda *_: self.redraw())
        self.canvas.mpl_connect('motion_notify_event', self._hover)
        self.rv = None; self.i = 0; self.series = None; self._vlines = []; self._note = ''; self.setMinimumHeight(380); self._draw_empty()

    # ---------------------------------------------------------------------------------------------------- data
    def set_run(self, rv):
        self.rv = rv; V = rv.V; self.series = V.series(); self.t = self.series['time_s'].values - self.series['time_s'].values[0]
        rd = V.run_dir
        self.P = V.particles if len(V.particles) else pd.DataFrame()
        self.seg = pd.read_csv(os.path.join(rd, 'segmentation_classes.csv')) if os.path.exists(os.path.join(rd, 'segmentation_classes.csv')) else pd.DataFrame()
        self.obj = pd.read_csv(os.path.join(rd, 'objects.csv')) if os.path.exists(os.path.join(rd, 'objects.csv')) and os.path.getsize(os.path.join(rd, 'objects.csv')) > 5 else pd.DataFrame()
        self.i = rv.frame_index()
        # chart (d): the first kind of data this run has
        nm = int(self.P['z_measured'].sum()) if len(self.P) and 'z_measured' in self.P else (len(self.P) if 'depth_nm' in self.P else 0)
        has = {0: nm >= max(10, 0.2 * len(self.P)), 2: len(self.obj) > 0, 3: True}      # depth: enough measured positions; classes only on request
        k = next(j for j in (0, 2, 3) if has[j]); self.sel.blockSignals(True); self.sel.setCurrentIndex(k); self.sel.blockSignals(False)
        self.redraw()

    def set_time(self, i):
        if self.rv is None: return
        self.i = int(min(max(i, 0), self.rv.V.n - 1))
        for ln in self._vlines: ln.set_xdata([self.t[self.i]] * 2)
        self._hist(); self.canvas.draw_idle()

    # ---------------------------------------------------------------------------------------------------- drawing
    def _style(self, ax, title, xl='time (s)', yl=''):
        ax.set_facecolor(SURF); ax.set_title(title, color=INK, fontsize=9, loc='left'); ax.set_xlabel(xl, color=INK2, fontsize=8); ax.set_ylabel(yl, color=INK2, fontsize=8)
        ax.tick_params(colors=INK2, labelsize=7); ax.grid(color=GRID, lw=0.6)
        for s in ('top', 'right'): ax.spines[s].set_visible(False)
        for s in ('left', 'bottom'): ax.spines[s].set_color(GRID)

    def _draw_empty(self):
        self.fig.clear(); ax = self.fig.add_subplot(111); ax.set_facecolor(SURF); ax.axis('off')
        ax.text(0.5, 0.5, 'open or run an analysis\n(Data and Processing panels)', color=INK2, ha='center', va='center', fontsize=10); self.canvas.draw_idle()

    def redraw(self):
        if self.rv is None: return self._draw_empty()
        self._note = ''
        self.fig.clear(); self._vlines = []; gs = self.fig.add_gridspec(2, 2); S = self.series; t = self.t
        self.ax_a = self.fig.add_subplot(gs[0, 0]); self.ax_b = self.fig.add_subplot(gs[0, 1]); self.ax_c = self.fig.add_subplot(gs[1, 0]); self.ax_d = self.fig.add_subplot(gs[1, 1])
        for ax, col, key, title in ((self.ax_a, C[0], 'liquid_um3', 'a  liquid volume (µm³)'), (self.ax_b, C[1], 'gas_um3', 'b  gas volume (µm³), band +-2 sd')):
            y = S[key].values.astype(float); ms = 3 if len(t) > 30 else 5
            if np.isfinite(y).any():
                if key == 'gas_um3' and np.isfinite(S['gas_sd_um3'].values.astype(float)).any():
                    sd = S['gas_sd_um3'].values.astype(float); ax.fill_between(t, y - 2 * sd, y + 2 * sd, color=col, alpha=0.22, linewidth=0)
                    zero = np.abs(y) < 2 * np.nan_to_num(sd, nan=0.0)             # consistent with no gas: hollow markers
                    ax.plot(t, y, color=col, lw=2); ax.plot(t[~zero], y[~zero], ls='none', marker='o', ms=ms, color=col)
                    ax.plot(t[zero], y[zero], ls='none', marker='o', ms=ms, markerfacecolor=SURF, markeredgecolor=col, markeredgewidth=1.2)
                    if zero.any(): self._note = 'gas: hollow points are consistent with no gas (|V| < 2 sd; sd from the scatter of the gap surface ' \
                                                'around the contact, not including the bias of the gap interpolation - METHODS)'
                else: ax.plot(t, y, color=col, lw=2, marker='o', ms=ms)
                lo, hi = np.nanmin(y), np.nanmax(y)
                if key == 'gas_um3' and np.isfinite(S['gas_sd_um3'].values.astype(float)).any(): lo, hi = np.nanmin(y - 2 * sd), np.nanmax(y + 2 * sd)
                lo2, hi2 = min(0.0, lo), max(0.0, hi); span = (hi2 - lo2) or 1.0; ax.set_ylim(lo2 - 0.05 * span, hi2 + 0.05 * span)   # the axis includes zero
                if key == 'gas_um3': ax.axhline(0, color=INK2, lw=0.8)
            self._style(ax, title)
            if not np.isfinite(y).all():
                why = 'not measured: SE only (nominal model)' if S['nominal'].all() else ('gas not measured in some frames:\nno SE, or contact over most of the field' if key == 'gas_um3' else 'not measured')
                _note(ax, why)
            self._vlines.append(ax.axvline(t[self.i], color=INK2, lw=1, ls='--'))
        self._panel_d(); self._hist(first=True); self.canvas.draw_idle()
        fld = f'volumes and areas over the field imaged in every frame ({S["field_um2"].iloc[0]:.1f} µm²)' if S['field'].iloc[0] == 'common' else 'volumes over each frame\'s imaged field'
        self.readout.setText('; '.join(x for x in (fld, self._note) if x))

    def _hist(self, first=False):
        ax = self.ax_c; ax.clear(); V = self.rv.V; T = V.map2d('thickness', self.i); T = T[np.isfinite(T)]          # dry columns (0 nm) included
        nominal = 'SE only' in (self.rv.V.mode or '')
        self._style(ax, f'c  {"nominal " if nominal else ""}thickness, frame {self.i + 1}', 'thickness (nm)', 'pixels')
        if T.size:
            ax.hist(T, bins=60, color=SEQ, edgecolor=SURF, linewidth=0.5); med = float(np.median(T))
            ax.axvline(med, color=INK, lw=1); ax.text(med, ax.get_ylim()[1] * 0.92, f' median {med:.0f} nm', color=INK, fontsize=7, clip_on=True).set_in_layout(False)
        if not first: self.canvas.draw_idle()

    def _panel_d(self):
        ax = self.ax_d; which = self.sel.currentText(); t0 = self.series['time_s'].values[0]
        if which == 'particle depth' and len(self.P) and 'depth_nm' in self.P:
            P = self.P; m = (P['z_measured'] if 'z_measured' in P else pd.Series(True, index=P.index)).values.astype(bool)
            fr = np.clip(P['frame'].values.astype(int), 0, len(self.t) - 1); dep = (P['depth_nm'] - V_tmem(self.rv)).values
            ax.scatter(self.t[fr[m]], dep[m], s=6, color=C[3], alpha=0.35, linewidths=0)
            g = pd.DataFrame(dict(f=fr[m], d=dep[m])).groupby('f')['d']; q = g.quantile([0.25, 0.5, 0.75]).unstack(); n = g.size()
            q = q[n.reindex(q.index).values >= 5] if len(q) else q                   # a median and IQR only from 5 or more particles
            if len(q):
                tq = self.t[q.index.values]; ax.fill_between(tq, q[0.25], q[0.75], color=C[3], alpha=0.25, linewidth=0)
                ax.plot(tq, q[0.5], color=C[3], lw=2, marker='o', ms=3)
            ax.invert_yaxis(); self._style(ax, 'd  particle depth (median, IQR, n >= 5)', yl='under the top membrane (nm)')
            n0 = int((~m).sum()); self._note = (f'particle depth: {int(m.sum())} measured positions, {n0} without depth (saturated, crowded or in gas); '
                                                'per-particle errors are 2-3x the reported ones (METHODS section 7)')
        elif which.startswith('segmentation') and len(self.seg):
            crit = 'icl' if (self.seg['criterion'] == 'icl').any() else self.seg['criterion'].iloc[0]
            q = self.seg[self.seg['criterion'] == crit]; tab = q.pivot_table(index='frame', columns='tag', values='area_frac', aggfunc='sum').fillna(0)
            lim = bool(q['k_at_limit'].any()) if 'k_at_limit' in q else False
            self._note = ('classes are fitted frame by frame (their number and tags can change between frames): compare frames with care'
                          + ('; in some frames the criterion chose the largest number of classes searched (k at its limit): the classes '
                             'split continuous variations rather than separate phases' if lim else ''))
            fr = tab.index.values; tt = self.t[np.clip(fr, 0, len(self.t) - 1)]
            ax.stackplot(tt, (tab.values * 100).T, colors=C[:tab.shape[1]], labels=[str(c) for c in tab.columns], edgecolor=SURF, linewidth=1)
            ax.legend(fontsize=6, loc='lower left', ncol=2, labelcolor=INK, frameon=True, facecolor=SURF, edgecolor=GRID, framealpha=0.85)
            self._style(ax, f'd  classes ({crit.upper()}), per frame', yl='area (%)'); ax.set_ylim(0, 100)
        elif which.startswith('bubbles') and len(self.obj):
            O = self.obj; big = O.groupby('track')['area_um2'].max().sort_values(ascending=False).index[:5]
            for k, tr in enumerate(big):
                g = O[O['track'] == tr].sort_values('time_s'); ax.plot(g['time_s'] - t0, g['area_um2'], color=C[k], lw=2, marker='o', ms=3, label=f'object {tr}')
            ax.legend(fontsize=6, frameon=False, labelcolor=INK2); self._style(ax, 'd  largest objects', yl='area (µm²)')
        elif which == 'electron dose' and np.isfinite(self.series['dose_cum_e_nm2'].values.astype(float)).any():
            ax.plot(self.t, self.series['dose_cum_e_nm2'], color=C[4], lw=2, marker='o', ms=3); self._style(ax, 'd  cumulative electron dose', yl='e / nm²')
            self._note = 'dose over the scanned field from the probe current and the frame time (lcsem.dose); ~0.26 MGy per e/nm2 in water at 15 keV'
        else:
            ax.plot(self.t, self.series['contact_um2'], color=C[2], lw=2, marker='o', ms=3); self._style(ax, 'd  SE contact area', yl='area (µm²)')
            if which != 'SE contact area': _note(ax, f'({which}: no data in this run)')
        self._vlines.append(ax.axvline(self.t[self.i], color=INK2, lw=1, ls='--'))

    def _hover(self, ev):
        if self.rv is None or ev.inaxes is None or ev.xdata is None: return
        if ev.inaxes in (self.ax_a, self.ax_b):
            j = int(np.argmin(np.abs(self.t - ev.xdata))); S = self.series
            sd = S['gas_sd_um3'][j] if 'gas_sd_um3' in S else np.nan; fl = S['se_contact_flag'][j] if 'se_contact_flag' in S else ''
            self.readout.setText(f'frame {j + 1}: t = {self.t[j]:.1f} s   liquid {S["liquid_um3"][j]:.3f} µm³   gas {S["gas_um3"][j]:.3f}'
                                 + (f' +- {sd:.3f}' if np.isfinite(sd) else '') + f' µm³   SE contact {S["contact_um2"][j]:.2f} µm²   '
                                 f'median thickness {S["T_median_nm"][j]:.0f} nm' + (f'   CHECK: {fl}' if isinstance(fl, str) and fl else ''))
        elif ev.inaxes is self.ax_c: self.readout.setText(f'thickness {ev.xdata:.0f} nm')
        else: self.readout.setText(f't = {ev.xdata:.1f} s   value {ev.ydata:.3g}')

    def save_png(self, fn):
        self.fig.savefig(fn, dpi=150, facecolor=SURF)

def _note(ax, text):
    """a small note inside the axes that never resizes the layout (constrained layout would shrink the axes to fit a long text)"""
    t = ax.text(0.02, 0.97, text, transform=ax.transAxes, color=INK2, fontsize=7, va='top', clip_on=True); t.set_in_layout(False); return t

def V_tmem(rv):
    return rv.V.t_mem[0]
