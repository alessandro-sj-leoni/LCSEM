"""lcsem graphical interface (napari-based): `lcsem gui` or `lcsem-gui`.

Tabs: 1 Data (JEOL image series, SE/BSE/STEM movies or a finished run), 2 Processing (detector combination, detector
model - Monte Carlo or analytical - calibration and references, denoising, segmentation, objects, volume), 3 Run (progress,
log, abort, save/load project), 4 Display (3-D layers, z exaggeration, rendering, views), 5 Export (Amira, Fiji,
OME-TIFF/Zarr, Imaris, ParaView, Slicer, ChimeraX/IMOD, meshes, MATLAB, HDF5, CSV/Excel, TrackMate); a charts dock below
the tabs follows the time slider. See docs/GUI.md.
The time slider at the bottom of the viewer steps through the time points; the 3-D view rotates with the mouse.
"""
