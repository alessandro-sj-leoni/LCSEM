"""Long tasks (analysis, loading, export) in a background thread, so the viewer stays responsive; progress, log messages and
the result come back as Qt signals; an abort flag is checked by the pipeline loops."""
from __future__ import annotations
import traceback, threading
from qtpy.QtCore import QObject, QThread, Signal

class Job(QObject):
    progress = Signal(float, str)
    message = Signal(str)
    finished = Signal(object)
    failed = Signal(str)

    def __init__(self, fn, *args, **kw):
        super().__init__(); self.fn, self.args, self.kw = fn, args, kw; self._abort = threading.Event()

    def abort(self): self._abort.set()
    def aborted(self): return self._abort.is_set()

    def run(self):
        try:
            res = self.fn(*self.args, log=lambda *a: self.message.emit(' '.join(str(x) for x in a)),
                          progress=lambda f, m='': self.progress.emit(float(f), str(m)), should_abort=self.aborted, **self.kw)
            self.finished.emit(res)
        except BaseException as e:                         # also SystemExit / KeyboardInterrupt: the GUI must always hear back
            name = type(e).__name__
            self.failed.emit('aborted by the user' if name == 'Aborted' else f'{name}: {e}\n{traceback.format_exc()}')

def start(parent, fn, *args, on_done=None, on_fail=None, on_progress=None, on_message=None, **kw):
    """run fn(*args, log=..., progress=..., should_abort=..., **kw) in a QThread; returns (thread, job)"""
    th = QThread(parent); job = Job(fn, *args, **kw); job.moveToThread(th)
    th.started.connect(job.run)
    if on_done: job.finished.connect(on_done)
    if on_fail: job.failed.connect(on_fail)
    if on_progress: job.progress.connect(on_progress)
    if on_message: job.message.connect(on_message)
    job.finished.connect(th.quit); job.failed.connect(th.quit)
    th.finished.connect(job.deleteLater); th.start()
    return th, job
