"""Showing a finished run in napari: 4-D image layers (time, z, y, x) for liquid, gas, SE contact, cell walls and Au
particles; 2-D maps (thickness, segmentation classes, objects) as slabs under the volume; particle points and tracks.
The time axis is napari's first dimension, so the slider at the bottom of the viewer steps through the time points."""
from __future__ import annotations
import os, glob, numpy as np
from ..volume4d import Volume4D

def _wrap(text, width=92):
    """wrap the lines of the view text so that none is cut at the edge of the canvas (long calibration warnings)"""
    import textwrap
    return '\n'.join('\n'.join(textwrap.wrap(ln, width, subsequent_indent='  ')) if len(ln) > width else ln for ln in text.split('\n'))

PALETTE = {'liquid': '#3987e5', 'gas': '#d95926', 'SE contact': '#199e70', 'Au': '#ffe680', 'walls': '#9aa0a6'}     # lcsem dark-surface palette
# (Au: a light yellow, distinct from the gas orange by lightness as well as hue, also for deuteranopes)


def _cmap(name, hexcol):
    """black -> colour at 50 % -> lighter tint: iso surfaces at the 50 % level show the palette colour itself"""
    from napari.utils.colormaps import Colormap
    c = np.array([int(hexcol[i:i + 2], 16) / 255 for i in (1, 3, 5)]); light = c + 0.45 * (1 - c)
    return Colormap(colors=[[0, 0, 0, 1], [*c, 1], [*light, 1]], controls=[0, 0.5, 1], name=f'lcsem_{name}', display_name=f'lcsem {name}')


LAYER_STYLE = {
    'liquid': dict(rendering='iso', iso_threshold=128, contrast_limits=(0, 255), opacity=0.5, blending='translucent'),
    'gas': dict(rendering='iso', iso_threshold=128, contrast_limits=(0, 255), opacity=0.9, blending='translucent'),
    'SE contact': dict(rendering='iso', iso_threshold=128, contrast_limits=(0, 255), opacity=0.7, blending='translucent'),
    'cell walls': dict(rendering='iso', iso_threshold=0.5, contrast_limits=(0, 1), opacity=0.15, blending='translucent'),
}
LAYER_CMAP = {'liquid': 'liquid', 'gas': 'gas', 'SE contact': 'SE contact', 'cell walls': 'walls'}


def auto_z_exaggeration(V):
    """a round z exaggeration (1, 2, 3, 5, 10, 20) that makes the typical column (membranes + liquid + gas) about 15 % of the
    lateral field of view: 60k fields (2 um) get 1x, 12k fields (10 um) 5x"""
    m = V.m2; ins = m['inside']; tot = (m['T'] + m['gt'] + m['go'])[ins]
    col = float(np.median(tot)) + sum(V.t_mem) if tot.size else V.Zmax
    lateral = max(V.ny * V.spacing[1], V.nx * V.spacing[2]); want = 0.15 * lateral / max(col, 1.0)
    steps = np.array([1, 2, 3, 5, 10, 20]); return int(steps[np.argmin(np.abs(np.log(steps / max(want, 0.5))))])


def _camera(v):
    """viewer.scene.camera (napari >= 0.9) or viewer.camera"""
    sc = getattr(v, 'scene', None)
    return sc.camera if sc is not None and hasattr(sc, 'camera') else v.camera


def _overlay(v, name):
    """canvas overlay 'text' or 'scale_bar' (napari >= 0.9: viewer.canvas.overlays.<name>; before: viewer.text_overlay / scale_bar)"""
    try: return getattr(v.canvas.overlays, name)
    except Exception: return getattr(v, 'text_overlay' if name == 'text' else 'scale_bar')


class RunView:
    """the layers of one run in a napari viewer, with the z exaggeration applied to all of them"""
    def __init__(self, viewer, run_dir, bin=4, dz=10.0, z_exaggeration='auto', progress=None, volume=None, particle_size=None):
        self.viewer = viewer; self.run_dir = run_dir
        self.V = volume or Volume4D(run_dir, bin=bin, dz=dz, progress=progress)
        self.zx = float(auto_z_exaggeration(self.V) if z_exaggeration in (None, 'auto', 0) else z_exaggeration)
        self.se_only = 'SE only' in (self.V.mode or '')
        self.layers = {}; self._build(particle_size)

    def scale(self):
        dz, dy, dx = self.V.spacing; return (1.0, dz * self.zx, dy, dx)

    def translate(self):
        """voxel centres: half a voxel up in z, (bin - 1) / 2 pixels in y, x (the particle coordinates are pixel centres)"""
        dz, dy, dx = self.V.spacing; b = self.V.bin; return (0.0, 0.5 * dz * self.zx, 0.5 * (b - 1) / b * dy, 0.5 * (b - 1) / b * dx)

    def default_particle_size(self):
        """display diameter of the Au spheres (nm): the true diameter, but at least 0.8 % of the field of view so they stay visible"""
        V = self.V; return float(max(V.d_part, 0.008 * max(V.ny * V.spacing[1], V.nx * V.spacing[2])))

    def set_particle_size(self, d_nm):
        if 'Au particles' in self.layers: self.layers['Au particles'].size = float(d_nm)

    def _columns(self, pts):
        """(N, 2, 4) napari vectors for particles without a measured depth: from under the top membrane down through the liquid
        (and gas) column at the particle (nm, z not exaggerated)"""
        V = self.V; out = []; b = V.bin
        for t, z, y, x in pts:
            i = int(t); iy = int(min(V.ny - 1, max(0, y // (V.px[1] * b)))); ix = int(min(V.nx - 1, max(0, x // (V.px[0] * b))))
            col = float(V.m2['T'][i][iy, ix] + V.m2['gt'][i][iy, ix]); ztop = V.Zmax - V.t_mem[0]
            out.append([[t, ztop, y, x], [0.0, -max(col, V.dz), 0.0, 0.0]])
        return np.array(out, float)

    def _scaled_columns(self):
        c = self._unmeas.copy(); c[:, 0, 1] *= self.zx; c[:, 1, 1] *= self.zx; return c

    def _build(self, particle_size=None):
        v, V = self.viewer, self.V; sc = self.scale()
        for key, kind in (('cell walls', 'walls'), ('liquid', 'liquid'), ('gas', 'gas'), ('SE contact', 'contact')):
            st = dict(LAYER_STYLE[key]); cm = LAYER_CMAP[key]
            if key == 'SE contact': st['visible'] = self.se_only             # with BSE/STEM thickness the gas layer already shows it
            lay = v.add_image(V.dask(kind), name=key, scale=sc, translate=self.translate(), colormap=_cmap(cm, PALETTE[cm]), **st); self.layers[key] = lay
        pts = V.points()
        if len(pts):
            meas = V.particles['z_measured'].values.astype(bool) if 'z_measured' in V.particles else np.ones(len(pts), bool)
            au = np.array([int(PALETTE['Au'][i:i + 2], 16) / 255 for i in (1, 3, 5)] + [1.0])
            if meas.any():                                               # depth measured: spheres at their depth
                p = pts[meas].copy(); p[:, 1] *= self.zx
                self.layers['Au particles'] = v.add_points(p, name='Au particles (depth measured)', size=float(particle_size or self.default_particle_size()),
                                                            face_color=au, border_width=0, shading='spherical', scale=(1, 1, 1, 1), out_of_slice_display=False,
                                                            blending='translucent_no_depth')        # seen through the liquid
            if (~meas).any():                                            # depth not measured: a vertical line through the liquid column
                self._unmeas = self._columns(pts[~meas])
                self.layers['Au particles, depth not measured'] = v.add_vectors(self._scaled_columns(), name='Au particles, depth not measured',
                                                                                 edge_width=max(V.d_part / 2, 0.3 * self.default_particle_size()), edge_color='#9aa0a6',
                                                                                 vector_style='line', length=1.0, out_of_slice_display=False, blending='translucent_no_depth')
            tr = V.tracks()
            if len(tr) and len(np.unique(tr[:, 0])) < len(tr):
                t = tr.copy(); t[:, 2] *= self.zx; self.layers['particle tracks'] = v.add_tracks(t, name='particle tracks', tail_length=20, tail_width=3, colormap='viridis', visible=False)
        # 2-D maps as thin slabs just below the volume (time, 1, y, x)
        slab_sc = (1.0, V.spacing[0] * self.zx, V.spacing[1], V.spacing[2]); tr_z = (0.0, -3 * V.spacing[0] * self.zx, 0.0, 0.0)
        T = V.map2d('thickness')[:, None]; lo, hi = np.nanpercentile(T, [2, 98]) if np.isfinite(T).any() else (0, 1)
        self.layers['thickness map (nm)'] = v.add_image(np.nan_to_num(T, nan=0.0), name='thickness map (nm)', colormap='viridis', contrast_limits=(float(lo), float(hi)),
                                                          scale=slab_sc, translate=tr_z, visible=False)
        cls = V.classes('icl')
        if cls is not None:
            self.layers['classes (ICL)'] = v.add_labels((cls + 1).astype(np.int32)[:, None], name='classes (ICL)', scale=slab_sc, translate=tr_z, visible=False, opacity=0.7)
        obj = self._objects()
        if obj is not None:
            self.layers['objects'] = v.add_labels(obj[:, None], name='objects (bubbles)', scale=slab_sc, translate=(0.0, (V.nz + 2) * V.spacing[0] * self.zx, 0.0, 0.0), visible=False, opacity=0.6)
        v.dims.axis_labels = ('time', 'z', 'y', 'x')
        try: _overlay(v, 'scale_bar').visible = True
        except Exception: pass
        for lay in self.layers.values():
            try: lay.units = ('s', 'nm', 'nm', 'nm')
            except Exception: pass
        try:
            to = _overlay(v, 'text'); to.visible = True; to.font_size = 10; to.color = 'white'
            try: to.position = 'top_left'
            except Exception: pass
        except Exception: pass
        v.dims.events.current_step.connect(self._on_time); self._on_time()

    def _objects(self):
        files = sorted(glob.glob(os.path.join(self.run_dir, f'{self.V.name}_*_objects.tif')))
        if len(files) != self.V.n: return None
        import tifffile
        from ..volume4d import _bin
        b = self.V.bin; out = []
        for f in files:
            a = tifffile.imread(f); ny, nx = a.shape[0] // b * b, a.shape[1] // b * b
            out.append(a[:ny:b, :nx:b][:self.V.ny, :self.V.nx])
        return np.stack(out).astype(np.int32)

    def frame_index(self):
        return int(self.viewer.dims.current_step[0]) if self.viewer.dims.ndim >= 4 else 0

    def _on_time(self, event=None):
        i = min(self.frame_index(), self.V.n - 1); lab = self.V.time_labels()
        try: self.V.prefetch(i + 1)
        except Exception: pass
        try:
            t = lab[i] if i < len(lab) else ''
            se_t = self.V.se_text(i)
            _overlay(self.viewer, 'text').text = _wrap(f'{self.V.name}   frame {i + 1}/{self.V.n}   t = {t}   z x{self.zx:g}   {self.V.mode or ""}\n'
                                                       f'{self.V.calibration_text()}\n{self.V.dose_text(i)}\n' + (f'{se_t}\n' if se_t else '') +
                                                       'top membrane drawn flat: all relief shows at the bottom membrane (2.5-D layer model)')
        except Exception: pass

    def set_z_exaggeration(self, zx):
        zx = float(zx); f = zx / self.zx; self.zx = zx
        for name, lay in self.layers.items():
            s = list(lay.scale)
            if name in ('Au particles', 'particle tracks', 'Au particles, depth not measured'):
                if name == 'Au particles, depth not measured': lay.data = self._scaled_columns(); continue
                d = lay.data.copy()
                if name == 'Au particles': d[:, 1] *= f
                else: d[:, 2] *= f
                lay.data = d
            else:
                s[1] = s[1] * f; lay.scale = s
                if name in ('liquid', 'gas', 'SE contact', 'cell walls'): lay.translate = self.translate()
                if name in ('thickness map (nm)', 'classes (ICL)'): lay.translate = (0.0, -3 * self.V.spacing[0] * zx, 0.0, 0.0)
                if name == 'objects': lay.translate = (0.0, (self.V.nz + 2) * self.V.spacing[0] * zx, 0.0, 0.0)

    def remove(self):
        try: self.V.close()
        except Exception: pass
        for lay in list(self.layers.values()):
            try: self.viewer.layers.remove(lay)
            except Exception: pass
        try: self.viewer.dims.events.current_step.disconnect(self._on_time)
        except Exception: pass
        self.layers = {}

def content_box(rv):
    """world-coordinate box (2, 3) around what is drawn: from the deepest bottom membrane (95th percentile of the column) to
    the top membrane, over the whole field of view"""
    V = rv.V; m = V.m2; tot = (m['T'] + m['gt'] + m['go'])[m['inside']]
    col = (float(np.percentile(tot, 95)) if tot.size else V.Zmax) + sum(V.t_mem)
    z0 = max(0.0, V.Zmax - col - V.dz) * rv.zx; z1 = V.Zmax * rv.zx
    return np.array([[z0, 0.0, 0.0], [z1, V.ny * V.spacing[1], V.nx * V.spacing[2]]])


def default_view(viewer, rv=None, elevation=35.0, azimuth=-25.0, margin=0.92):
    """oblique view from above and in front (the top membrane up, the image's lower edge towards the viewer), centred and
    zoomed on the drawn content rather than on the full volume box (which is mostly empty below thin liquid)"""
    viewer.dims.ndisplay = 3
    try:
        viewer.reset_view()
        el, az = np.deg2rad(elevation), np.deg2rad(azimuth)
        view = np.array([-np.sin(el), -np.cos(el) * np.cos(az), -np.cos(el) * np.sin(az)])
        up = (0.0, -1.0, 0.0) if elevation >= 89.9 else (1.0, 0.0, 0.0)          # top view: like the SEM image (y down)
        cam = _camera(viewer); cam.set_view_direction(tuple(view), up)
        if rv is not None:
            box = content_box(rv); cam.center = tuple(box.mean(axis=0))
            try:                                                   # napari >= 0.9: fit the content box as seen from this direction
                bb = viewer._calculate_bounding_box(extent=box, view_direction=cam.view_direction, up_direction=cam.up_direction)
                size = np.asarray(viewer.canvas.viewbox_size(viewer.layers), float)
                cam.zoom = float(margin * np.min(size / np.maximum(bb, 1e-9)))
            except Exception: pass
    except Exception as e:
        print('default_view:', e)
    for name in ('liquid', 'gas'):
        if name in viewer.layers: viewer.layers.selection.active = viewer.layers[name]; break
