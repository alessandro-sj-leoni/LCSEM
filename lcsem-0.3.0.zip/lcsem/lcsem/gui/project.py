"""The GUI's settings (a 'project', saved as JSON) and their translation into an lcsem configuration and scans.

This module has no Qt dependency: the same project file runs from a script with
    from lcsem.gui.project import load_project, run_project
    run_project(load_project('my_project.json'))
"""
from __future__ import annotations
import os, json, copy, numpy as np

MODES = ('SE + BSE', 'SE + BSE + STEM', 'BSE only', 'SE only', 'BSE + STEM', 'STEM only', 'SE + STEM')
MODELS = ('Monte Carlo (automatic, cached)', 'Monte Carlo curve file')
# (the analytical forms 1 - exp(-T/L), exp(-T/lambda) were removed from the interface in 0.3.0: they do not follow the Monte
#  Carlo curves of the annular BSE detector - no membrane signal at T = 0, convex rise, saturation - and fail with dark +
#  empty references; lcsem.calib.analytical_curve remains for comparison only)
CAL_MODES = ('auto', 'dark+empty', 'dark+particles', 'empty+particles', 'particles+flat', 'dark+flat', 'manual')
LAYOUTS = ('separate files', 'side by side', 'top / bottom', 'interleaved frames')

DEFAULTS = dict(
    name='series', source='jeol',                                    # 'jeol' | 'movie' | 'run'
    jeol=dict(folder='', prefix='', mag=0.0, time_from='', time_to=''),
    movie=dict(files=dict(SE='', BSE='', STEM=''), layout='separate files', part=dict(SE=0, BSE=1, STEM=2), parts=2,
               frame_time_s=0.0, t0='00:00:00', start=0, stop=0, step=1, window=1, crop=''),
    run_dir='',
    pixel_nm=[0.0, 0.0], kV=15.0, bits=8, mag=0.0, membranes_nm=[30.0, 30.0], channel_nm=500.0, particle_nm=38.0,     # pixel size: must be entered
    frame_edge=False, skip_rows=0,
    mode='SE + BSE', se_signal='UED',
    model=dict(kind=MODELS[0], curve_file='', bse_L_nm=0.0, stem_lambda_nm=0.0, stem_mrad=[0.0, 100.0], depth_curve=''),
    calibration=dict(mode='auto', flat_T_nm=0.0, B0=dict(BSE=0.0, STEM=0.0), g=dict(BSE=0.0, STEM=0.0), use_particles=True),   # flat 0 = no assumed flat field
    references=dict(dark=dict(BSE='', SE='', STEM=''), empty=dict(BSE='', SE='', STEM=''), full=dict(BSE='', SE='', STEM='')),
    denoise=dict(method='nlm', vst=True, strength=1.0, se=True),
    smooth_sigma_px=0.0,
    particles=dict(detect=True, threshold=6.0, sigma_min=1.5, sigma_max=6.0),
    segmentation=dict(enabled=True, criteria=['icl', 'bic'], stability_runs=5, n_fit=80000),
    objects=dict(enabled=True, source='se_contact', min_area_px=100, min_distance_px=10, min_gas_nm=10.0),
    volume=dict(bin=4, dz_nm=10.0, z_exaggeration='auto', T_cap_nm=1500.0),
    registration=dict(method='phase', roi=''),                      # movies: 'phase' (cross-correlation chain) or 'none'; roi 'y0 y1 x0 x1'
    se_min_area_um2=0.01, se_sigma_px=6.0, se_gas_nm=50.0,           # SE contact map: smallest contact region, smoothing; SE-only nominal gas
    beam_current_pA=0.0,                                             # probe current for the dose bookkeeping (0 = unknown)
    out_dir='')

def _merge(a, b):
    for k, v in b.items():
        if isinstance(v, dict) and isinstance(a.get(k), dict): _merge(a[k], v)
        else: a[k] = copy.deepcopy(v)
    return a

def new_project(**kw):
    return _merge(copy.deepcopy(DEFAULTS), kw)

def load_project(path):
    with open(path) as fh: d = json.load(fh)
    p = _merge(copy.deepcopy(DEFAULTS), d); p['_path'] = path
    base = os.path.dirname(os.path.abspath(path))                  # relative paths are relative to the project file
    def rel(f): return os.path.normpath(os.path.join(base, f)) if f and not os.path.isabs(f) else f
    p['jeol']['folder'] = rel(p['jeol']['folder']); p['movie']['files'] = {c: rel(f) for c, f in p['movie']['files'].items()}
    p['run_dir'] = rel(p.get('run_dir', '')); p['out_dir'] = rel(p.get('out_dir', ''))
    for kind in ('dark', 'empty', 'full'): p['references'][kind] = {c: rel(f) for c, f in p['references'][kind].items()}
    for k in ('curve_file', 'depth_curve'): p['model'][k] = rel(p['model'].get(k, ''))
    return p

def save_project(p, path):
    d = {k: v for k, v in p.items() if not k.startswith('_') or k in ('_lcsem_version', '_lcsem_build', '_created')}
    with open(path, 'w') as fh: json.dump(d, fh, indent=1)

def safe_name(name):
    """a run name usable in file names on every system"""
    import re
    return re.sub(r'[^A-Za-z0-9._-]+', '_', str(name or 'series')).strip('._') or 'series'

def channels_of(mode):
    """detectors of a mode such as 'SE + BSE + STEM' or 'BSE only' (tokens, not substrings: 'BSE' does not contain an SE)"""
    tok = {t.strip().upper() for t in mode.replace('only', '').split('+') if t.strip()}
    return dict(SE='SE' in tok, BSE='BSE' in tok, STEM='STEM' in tok)

def _hms_to_s(t):
    try:
        h, m, s = [float(v) for v in str(t).split(':')]; return h * 3600 + m * 60 + s
    except Exception: return 0.0

def to_config(p, out_dir=None):
    """the lcsem configuration of a project (for lcsem.config.load_config)"""
    ch = channels_of(p['mode']); out_dir = out_dir or p['out_dir']
    se_sig = [p.get('se_signal', 'UED')] + [s for s in ('UED', 'LED', 'SEI') if s != p.get('se_signal', 'UED')]
    stem_det = dict(kind='stem', mrad=list(p['model'].get('stem_mrad', [0.0, 100.0])))
    cfg = dict(name=p['name'], folder=(p['jeol']['folder'] if p['source'] == 'jeol' else os.path.dirname(next((f for f in p['movie']['files'].values() if f), out_dir or '.'))) or '.',
               prefix=p['jeol']['prefix'] if p['source'] == 'jeol' else '', pixel_nm=[float(v) for v in p['pixel_nm']], bits=int(p['bits']),
               source='movie' if p['source'] == 'movie' else 'jeol', mode=p['mode'],
               beam=dict(kV=float(p['kV']) or None, current_pA=float(p.get('beam_current_pA') or 0) or None),
               cell=dict(membranes_nm=[float(v) for v in p['membranes_nm']], channel_nm=float(p['channel_nm']) or None),
               channels=dict(BSE=dict(signal='BED_C', role='thickness', detector='BEDC') if ch['BSE'] else None,
                             STEM=dict(signal='STEM', role='thickness', detector=stem_det) if ch['STEM'] else None,
                             SE=dict(signal=se_sig, role='contact') if ch['SE'] else None),
               frame_edge=bool(p.get('frame_edge', False)), skip_rows=int(p.get('skip_rows', 0)),
               particles=dict(sigma_min=float(p['particles']['sigma_min']), sigma_max=float(p['particles']['sigma_max']), threshold=float(p['particles']['threshold']) if p['particles']['detect'] else 1e9),
               references=dict(particles=dict(diameter_nm=float(p['particle_nm']), material='Au'),
                               flat=dict(frames='all', T_nm=float(p['calibration']['flat_T_nm'])) if float(p['calibration'].get('flat_T_nm') or 0) > 0 else None),
               calibration=dict(mode=p['calibration']['mode'], use_particles=bool(p['calibration'].get('use_particles', True))),
               denoise=dict(method=p['denoise']['method'], vst=bool(p['denoise']['vst']), strength=float(p['denoise']['strength']), se=bool(p['denoise'].get('se', True))),
               segmentation=dict(enabled=bool(p['segmentation']['enabled']), criteria=list(p['segmentation']['criteria']), stability_runs=int(p['segmentation']['stability_runs']),
                                 n_fit=int(p['segmentation']['n_fit']), skip_rows=int(p.get('skip_rows', 0))),
               amira=dict(enabled=False), volume=dict(write=False, write_4d=True, T_cap_nm=float(p['volume']['T_cap_nm'])),
               se_only=dict(gas_nm=float(p.get('se_gas_nm', 50.0)), channel_nm=float(p['channel_nm'])),
               se=dict(min_area_um2=float(p.get('se_min_area_um2', 0.01)), sigma_px=float(p.get('se_sigma_px', 6.0))))
    if p['source'] == 'jeol':
        sel = {}
        if p['jeol'].get('mag'): sel['mag'] = float(p['jeol']['mag'])
        if p['jeol'].get('time_from'): sel['time_from'] = p['jeol']['time_from']
        if p['jeol'].get('time_to'): sel['time_to'] = p['jeol']['time_to']
        cfg['select'] = sel
    if float(p.get('smooth_sigma_px') or 0) > 0: cfg['smooth_sigma_px'] = float(p['smooth_sigma_px'])
    if p['calibration']['mode'] == 'manual':
        cfg['calibration']['B0'] = {c: float(v) for c, v in p['calibration']['B0'].items()}; cfg['calibration']['g'] = {c: float(v) for c, v in p['calibration']['g'].items()}
    for kind in ('dark', 'empty', 'full'):
        files = {c: f for c, f in p['references'][kind].items() if f}
        if files:
            if p['source'] == 'jeol': cfg['references'][kind] = dict(files=[os.path.splitext(f)[0] for f in files.values()])
            else:     # movie references are read with the movie's layout (side by side, interleaved ...) and crop
                mv = p['movie']; lay = {'separate files': 'single', 'side by side': 'side_by_side', 'top / bottom': 'top_bottom', 'interleaved frames': 'interleaved'}[mv['layout']]
                cfg['references'][kind] = dict(movie=files, layout=lay, parts=int(mv['parts']), part={c: int(v) for c, v in mv['part'].items()},
                                               crop=str(mv.get('crop') or ''))
    # detector models
    kind = p['model']['kind']; curves = {}
    if kind == MODELS[1] and p['model']['curve_file']:
        for c in ('BSE', 'STEM'):
            if ch[c]:
                from ..mc.curves import detector_label
                spec = 'BEDC' if c == 'BSE' else f"stem:{stem_det['mrad'][0]:g}:{stem_det['mrad'][1]:g}"
                curves[c] = dict(file=p['model']['curve_file'], detector=detector_label(spec))
    elif kind not in MODELS:
        pass                                                           # older projects with the analytical model: Monte Carlo instead
    if curves: cfg['curves'] = curves
    if p['model'].get('depth_curve'): cfg['depth'] = dict(methods=['core_fraction'] + (['channel_ratio'] if ch['BSE'] and ch['STEM'] else []), curve=p['model']['depth_curve'])
    elif ch['BSE'] and ch['STEM']: cfg['depth'] = dict(methods=['core_fraction', 'channel_ratio'])
    if p['source'] == 'movie':
        rg = p.get('registration') or {}; roi = [int(v) for v in str(rg.get('roi') or '').replace(',', ' ').split()] or None
        cfg['registration'] = dict(method=rg.get('method', 'phase') if rg.get('method', 'phase') != 'auto' else 'phase', roi=roi if roi and len(roi) == 4 else None)
        cfg['frame_time'] = dict(fast_s=1.0, slow_s=1.0, sigma_split=1e9)
    return cfg

def calibration_plan(p):
    """what the calibration will be before the run: (mode, assumptions, problems). Mirrors lcsem.calib.solve('auto'):
    dark+empty, dark+particles, empty+particles, particles+flat, dark+flat, manual - the first the references allow."""
    ch = channels_of(p['mode']); cal = p['calibration']; refs = p['references']
    if p.get('source') != 'run' and not all(float(v or 0) > 0 for v in p.get('pixel_nm', [0, 0])):
        return None, [], ['enter the pixel size in nm (Data tab): measure it on a grating or from the scale bar - areas, volumes, particle photometry and depths depend on it']
    if not (ch['BSE'] or ch['STEM']): return 'none (SE only)', ['no thickness is measured: the 3-D model is nominal'], []
    have = set()
    for kind in ('dark', 'empty'):
        if any(refs[kind].get(c) for c in ('BSE', 'STEM') if ch[c]): have.add(kind)
    if p['particles'].get('detect') and cal.get('use_particles', True): have.add('particles')
    if float(cal.get('flat_T_nm') or 0) > 0: have.add('flat')
    if cal['mode'] == 'manual':
        bad = [c for c in ('BSE', 'STEM') if ch[c] and not float(cal['g'].get(c) or 0)]
        return 'manual', ['B0 and gain typed in by the user'], ([f'manual calibration: gain of {", ".join(bad)} is 0'] if bad else [])
    order = [('dark+empty', {'dark', 'empty'}), ('dark+particles', {'dark', 'particles'}), ('empty+particles', {'empty', 'particles'}),
             ('particles+flat', {'particles', 'flat'}), ('dark+flat', {'dark', 'flat'})]
    mode = cal['mode'] if cal['mode'] != 'auto' else next((m for m, need in order if need <= have), None)
    if mode is None:
        return None, [], ['no calibration possible with these references. Best: record a dark frame (beam blanked, same detector '
                          'settings) - with the Au particles it calibrates without assumptions - and if possible an empty cell. '
                          'Otherwise enter an assumed flat-field thickness (Processing > calibration): every thickness then scales '
                          'with that assumption; or type B0 and gain (manual).']
    need = dict(order)[mode] if mode in dict(order) else set()
    miss = sorted(need - have)
    if miss: return mode, [], [f'calibration {mode} needs: {", ".join(miss)}']
    ass = []
    if 'flat' in mode: ass.append(f'ASSUMED: the median of all frames is {float(cal["flat_T_nm"]):.0f} nm of liquid - absolute thickness scales with this assumption')
    if 'particles' in mode: ass.append('Au particles near the top membrane set the gain (Monte Carlo particle model)')
    if mode == 'dark+empty': ass.append('dark + empty cell: instrument calibration, no sample assumption')
    if 'empty' not in mode: ass.append('no empty-cell reference: the detector-model scale is not tested independently (METHODS section 7: +-25-30 %)')
    return mode, ass, []

def acquisition_summary(p):
    """one line with the acquisition values the analysis will use (shown before a run starts: several are prefilled defaults)"""
    ft = float(p['movie'].get('frame_time_s') or 0) if p.get('source') == 'movie' else 0.0
    parts = [f"{float(p['kV']):g} kV", f"pixel {float(p['pixel_nm'][0]):g} x {float(p['pixel_nm'][1]):g} nm",
             f"SiN membranes {float(p['membranes_nm'][0]):g} / {float(p['membranes_nm'][1]):g} nm", f"Au particles {float(p['particle_nm']):g} nm",
             f"{int(p['bits'])}-bit"]
    if p.get('source') == 'movie':
        parts.append(f'frame time {ft:g} s' if ft else 'frame time from the file (or 1 s)')
        mv = p['movie']; parts.append(f"frames {mv['start']}-{mv['stop'] or 'end'} step {mv['step']}" + (f", window {mv['window']}" if int(mv['window']) > 1 else ''))
    parts.append(f"probe current {float(p['beam_current_pA']):g} pA" if float(p.get('beam_current_pA') or 0) > 0 else 'probe current not given (no dose)')
    return 'acquisition: ' + ', '.join(parts) + ' - check these values (Data tab)'

def movie_sources(p):
    from ..io_movie import MovieSource, _Reader
    ch = channels_of(p['mode']); mv = p['movie']; lay = {'separate files': 'single', 'side by side': 'side_by_side', 'top / bottom': 'top_bottom',
                                                       'interleaved frames': 'interleaved'}[mv['layout']]
    crop = tuple(int(v) for v in str(mv.get('crop') or '').replace(',', ' ').split()) or None
    src = {}; shared = {}
    for c in ('SE', 'BSE', 'STEM'):
        if not ch[c]: continue
        f = mv['files'].get(c) or (next((v for v in mv['files'].values() if v), '') if lay != 'single' else '')
        if not f: raise ValueError(f'no movie file for {c}')
        if lay == 'single': src[c] = MovieSource(f, crop=crop)
        else:
            rd = shared.setdefault(f, _Reader(f)); src[c] = MovieSource(f, layout=lay, part=int(mv['part'][c]), parts=int(mv['parts']), crop=crop, reader=rd)
    return src

def memory_estimate(p, src=None):
    """(GB, time points, pixels per time point over all detectors) the analysis of a movie project needs: the pipeline keeps
    about 80 bytes per pixel and time point; series denoising adds the input, output and raw stacks (13 bytes) and the
    denoiser's working set on one block (about 13 x the block)"""
    from .. import denoise as DN
    src = src or movie_sources(p); mv = p['movie']
    n = min(len(s) for s in src.values()); stop = int(mv['stop']) or n; start = int(mv['start']); step = max(1, int(mv['step']))
    npx = sum(int(np.prod(s.get(0).shape)) for s in src.values()); nt = len(range(start, min(stop, n), step))
    gb = 80.0 * npx * nt / 1e9
    if p['denoise']['method'] in DN.STACK_METHODS:
        gb += (13.0 * npx * nt + 13.0 * 8.0 * (npx / len(src)) * min(nt, int(p['denoise'].get('block', 32)))) / 1e9
    return gb, nt, npx

def build_scans(p, log=print, progress=None, work_dir=None, should_abort=None):
    """scans for the pipeline: None for JEOL folders (the pipeline reads cfg['folder']); for movies, io_jeol.Scan objects,
    after registration and stack denoising when a series method (MP-PCA, SVD, temporal) is chosen"""
    if p['source'] != 'movie':
        if p['denoise']['method'] in ('mppca', 'svd_gd', 'temporal_mean', 'temporal_median'):
            log(f'WARNING: {p["denoise"]["method"]} works on movies only; JEOL image series are denoised frame by frame with NLM instead')
            p['denoise']['method'] = 'nlm'
        return None, {}
    from ..io_movie import movie_scans, ArraySource, register_stack
    from .. import denoise as DN
    mv = p['movie']; src = movie_sources(p); extra = {}
    lens = {c: len(s) for c, s in src.items()}
    if len(set(lens.values())) > 1: log(f'WARNING: the movies have different lengths {lens}: only the first {min(lens.values())} frames are used')
    n = min(len(s) for s in src.values()); stop = int(mv['stop']) or n; start = int(mv['start']); step = max(1, int(mv['step']))
    need_gb, nt, npx = memory_estimate(p, src)
    log(f'{nt} time points of {npx / len(src) / 1e6:.2f} Mpx per detector: about {need_gb:.1f} GB of memory for the analysis'
        + (' - use a frame step, a crop or fewer frames if this exceeds the free memory' if need_gb > 4 else ''))
    meth = p['denoise']['method']
    if meth in DN.STACK_METHODS:
        # series denoising in blocks of `block` time points: in each block the frames are aligned by whole pixels (no
        # interpolation, so the noise stays white and independent) on the field common to that block, denoised together and put
        # back in their own geometry; the drift is measured on every raw frame and handed to the pipeline, which keeps the raw
        # frames for particle photometry and noise estimates. Pixels outside a block's common field stay undenoised (flag in
        # the maps: 'denoised'). Blocks keep that field large in long movies (the common field of a whole movie shrinks with
        # all its drift) and bound the memory of the denoiser.
        from ..io_movie import register_movie
        idx = list(range(start, min(stop, n), step)); prim = next(c for c in ('BSE', 'STEM', 'SE') if c in src)
        block = int(p['denoise'].get('block', 32)); halo = int(p['denoise'].get('window', 5)) // 2 if meth.startswith('temporal') else 0
        log(f'series denoising ({DN.describe(meth)}) of {len(idx)} frames in blocks of {block}: drift measured on every frame of {prim}')
        rg = p.get('registration') or {}; roi = [int(v) for v in str(rg.get('roi') or '').replace(',', ' ').split()] or None
        if rg.get('method') != 'none':
            sub = register_movie(src[prim].get, idx, ref=len(idx) - 1, roi=roi if roi and len(roi) == 4 else None, should_abort=should_abort,
                                 progress=(lambda f, m: progress(0.01 * f, m)) if progress else None)
        else: sub = np.zeros((len(idx), 2))
        sh = np.rint(sub).astype(int); extra['drift_shifts'] = sub.tolist()
        new, raw, dmask = {}, {}, {}
        for k, (c, s_) in enumerate(src.items()):
            a = np.stack([s_.get(i) for i in idx]); out = a.copy(); dm = np.zeros(a.shape, bool); T_, H_, W_ = a.shape
            for b0 in range(0, T_, block):
                if should_abort is not None and should_abort():
                    from ..pipeline import Aborted; raise Aborted('aborted by the user')
                if progress: progress(0.02 + 0.2 * (k + b0 / T_) / len(src), f'denoising {c}: frames {b0 + 1}-{min(b0 + block, T_)} of {T_}')
                e0, e1 = max(0, b0 - halo), min(T_, b0 + block + halo); sb = sh[e0:e1]
                y0, x0 = max(0, sb[:, 0].max()), max(0, sb[:, 1].max()); y1, x1 = H_ + min(0, sb[:, 0].min()), W_ + min(0, sb[:, 1].min())
                if y1 - y0 < 16 or x1 - x0 < 16:
                    log(f'  {c} frames {e0}-{e1 - 1}: drift larger than the frame within the block - left undenoised'); continue
                al = np.stack([a[e0 + i, y0 - dy:y1 - dy, x0 - dx:x1 - dx] for i, (dy, dx) in enumerate(sb)])
                dn = DN.denoise_stack(al, meth, vst=bool(p['denoise']['vst']), strength=float(p['denoise']['strength']))
                for i in range(b0, min(b0 + block, T_)):
                    dy, dx = sh[i]; out[i, y0 - dy:y1 - dy, x0 - dx:x1 - dx] = dn[i - e0]; dm[i, y0 - dy:y1 - dy, x0 - dx:x1 - dx] = True
            new[c] = ArraySource(out, fps=None); raw[c] = ArraySource(a, fps=None); dmask[c] = dm
            log(f'  {c}: {100 * dm.mean():.0f} % of the pixels denoised (the rest lies outside the common field of its block)')
        fps = getattr(src[prim], 'fps', None); ft = float(mv['frame_time_s']) or (1.0 / fps if fps else 1.0); st0 = int(mv['step'])
        # frame k of the denoised series is raw frame start + k * step: its end time is t0 + (start + k * step + 1) * ft
        scans = movie_scans(new, frame_time_s=ft * st0, t0_s=_hms_to_s(mv['t0']) + (int(mv['start']) + 1) * ft - ft * st0, mag=float(p.get('mag') or 0),
                            kv=float(p['kV']), start=0, stop=len(idx), step=1, window=1, name=p['name'])
        for k, s_ in enumerate(scans):
            for c, fr in s_.channels.items():
                fr.frame_s = ft; fr.raw_src = raw[c]; fr.movie_index = idx[k]; fr.name = f'f{idx[k]:05d}'   # one raw frame per time point; raw kept
                fr.denoised_mask = dmask[c][k]
        extra['denoise'] = dict(method='none'); extra['series_denoised'] = DN.describe(meth)
        return scans, extra
    ft = float(mv['frame_time_s']) or None
    scans = movie_scans(src, frame_time_s=ft, t0_s=_hms_to_s(mv['t0']), mag=float(p.get('mag') or 0), kv=float(p['kV']),
                        start=start, stop=stop, step=step, window=int(mv['window']), name=p['name'])
    return scans, extra

def run_project(p, out_dir=None, log=print, progress=None, should_abort=None):
    """the whole analysis of a project; returns the run folder"""
    from ..config import load_config
    out_dir = out_dir or p['out_dir']
    if p['source'] == 'run': return p['run_dir']
    if not out_dir: raise ValueError('choose an output folder')
    p['name'] = safe_name(p['name'])
    if os.path.isdir(out_dir) and os.listdir(out_dir):             # never mix two runs in one folder: a new sub-folder per run
        import time as _t
        out_dir = os.path.join(out_dir, f"{p['name']}_{_t.strftime('%Y%m%d-%H%M%S')}"); log(f'output folder not empty: this run goes to {out_dir}')
    os.makedirs(out_dir, exist_ok=True); p = dict(p, out_dir=out_dir)
    p['_lcsem_version'] = __import__('lcsem').__version__; p['_lcsem_build'] = __import__('lcsem').build_id(); p['_created'] = __import__('time').strftime('%Y-%m-%d %H:%M:%S')
    save_project(p, os.path.join(out_dir, 'lcsem_project.json'))
    mode_, ass_, prob_ = calibration_plan(p)
    if prob_: raise ValueError(' / '.join(prob_))
    log(f'calibration: {mode_}' + ''.join(f'\n  - {a}' for a in ass_)); log(acquisition_summary(p))
    scans, extra = build_scans(p, log, progress, out_dir, should_abort=should_abort)
    cfg = to_config(p, out_dir); cfg.update(extra); cfg = load_config(cfg)
    ch = channels_of(p['mode'])
    if not ch['BSE'] and not ch['STEM']:
        from ..se_only import run_se_only
        if scans is None:
            from .. import io_jeol as J
            from ..pipeline import _select
            fr = J.scan_folder_all(cfg['folder'], cfg.get('prefix', '')); series = J.group_scans(fr, {'SE': cfg['channels']['SE']}, cfg['pair_window_s'])
            scans = _select(series, cfg.get('select') or {})
        run_se_only(cfg, scans, out_dir, progress=progress, should_abort=should_abort, log=log)
    else:
        from ..pipeline import run
        run(cfg, out_dir, scans=scans, progress=progress, should_abort=should_abort, log=log)
    if p['objects']['enabled']:
        from ..objects import analyse_run
        try: analyse_run(out_dir, p['objects']['source'], int(p['objects']['min_area_px']), int(p['objects']['min_distance_px']), float(p['objects']['min_gas_nm']), log=log)
        except Exception as e:
            log(f'WARNING: object analysis failed: {type(e).__name__}: {e}')
            if progress: progress(1.0, f'done, but the object analysis failed: {e}')
    return out_dir
