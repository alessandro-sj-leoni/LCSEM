"""Objects in the liquid cell over time: gas bubbles / dry patches (and any other mask), split with the watershed transform,
measured per frame and linked into tracks.

Per frame (drift-corrected canvas coordinates, nm): the object mask is taken from the SE contact map ('se_contact'), from
the gas thickness ('gas', gas at the top + elsewhere > min_gas_nm), from thickness levels ('thin': liquid below
thin_nm), or from a segmentation class; small objects are removed and holes filled; touching objects are split by a
marker-controlled watershed on the distance transform (Beucher & Lantuejoul 1979; Meyer 1994; Soille 2003); every object
is measured (area, equivalent diameter, centroid, perimeter, eccentricity, mean gas and liquid thickness, gas volume,
touches the image border). Objects are linked between consecutive frames by maximum overlap (IoU) with a globally optimal
assignment (Hungarian algorithm, Kuhn 1955); unmatched objects start or end tracks, and one-to-many overlaps are recorded
as split / merge events.

Outputs: objects.csv (one row per object and frame), object_tracks.csv (one row per track: lifetime, growth rate from a
linear fit of area vs time over the frames where it does not touch the border, net speed of the centroid),
object_events.csv (splits / merges: overlap >= half of the smaller object), and per-frame label images
(*_objects.tif, int labels = track id + 1, 0 background) on the canvas.
"""
from __future__ import annotations
import os, glob, json, numpy as np, pandas as pd
from scipy import ndimage as ndi

def _canvas_place(img, shift, H, W, ymin, xmin, fill=0):
    dy, dx = shift; out = np.full((H, W), fill, dtype=np.asarray(img).dtype)
    iy, ix = int(np.floor(dy)) - ymin, int(np.floor(dx)) - xmin
    h, w = min(img.shape[0], H - iy), min(img.shape[1], W - ix)
    out[iy:iy + h, ix:ix + w] = img[:h, :w]; return out

def object_mask(m, source='se_contact', min_gas_nm=10.0, thin_nm=None, seg=None, cls=None):
    valid = m['valid'] | m['au']
    if source == 'se_contact': mk = m['dark'].astype(bool)
    elif source == 'gas': mk = (np.nan_to_num(m['gas_top']) + np.nan_to_num(m['gas_other'])) > min_gas_nm
    elif source == 'thin':
        if thin_nm is None: raise ValueError('object source "thin" needs a thickness limit (thin_nm); a per-frame percentile would fix the area fraction')
        mk = np.nan_to_num(m['T'], nan=1e9) < thin_nm
    elif source == 'class' and seg is not None: mk = np.isin(seg, np.atleast_1d(cls))
    else: raise ValueError(f'unknown object source {source}')
    return mk & valid

def split_objects(mask, min_area_px=100, min_distance_px=10, fill_holes=True, watershed=True, h_px=2.0):
    """labels of the objects in a binary mask: small ones removed, holes filled, touching ones split by a marker-controlled
    watershed of the distance transform. Markers: regional maxima of the distance transform deeper than h_px (h-maxima,
    Soille 2003), at least min_distance_px apart - an elongated object (a single ridge of the distance transform) stays one
    object, two touching discs (two maxima separated by a neck) are split."""
    from skimage.segmentation import watershed as ws
    from skimage.morphology import h_maxima
    mk = ndi.binary_fill_holes(mask) if fill_holes else mask.copy()
    lab, n = ndi.label(mk)
    if n == 0: return lab
    sz = ndi.sum(mk, lab, range(1, n + 1)); mk = np.isin(lab, 1 + np.where(sz >= min_area_px)[0])
    if not watershed: return ndi.label(mk)[0]
    dist = ndi.distance_transform_edt(mk)
    hm = h_maxima(dist, h_px) & mk; ml, nm = ndi.label(hm)
    if nm > 1 and min_distance_px > 0:                                  # merge markers closer than min_distance_px
        c = np.array(ndi.center_of_mass(hm, ml, range(1, nm + 1))); keep = np.ones(nm, bool); order = np.argsort([-dist[tuple(np.round(p).astype(int))] for p in c])
        for a_ in order:
            if not keep[a_]: continue
            d_ = np.hypot(*(c - c[a_]).T); close = (d_ < min_distance_px) & keep; close[a_] = False; keep[close] = False
            for b_ in np.where(close)[0]: ml[ml == b_ + 1] = a_ + 1
    return ws(-dist, ml, mask=mk)

def measure(labels, m, px, shift, canvas_origin, time_s):
    """per object: area, equivalent diameter, centroid (canvas, nm), perimeter, eccentricity, mean gas and liquid thickness
    (measured pixels only), gas volume, border contact, and its time: the mean acquisition time of its rows (raster clock)"""
    from skimage.measure import regionprops
    gas = m['gas_top'] + (m['gas_other'] if 'gas_other' in m else 0.0); T = m['T']; rows = []
    rt = m.get('row_t') if isinstance(m, dict) else None
    ymin, xmin = canvas_origin; dy, dx = shift; pa = px[0] * px[1]; ny, nx = labels.shape
    for r in regionprops(labels):
        sl = labels == r.label; y, x = r.centroid; b = r.bbox
        rows.append(dict(label=int(r.label), area_um2=float(r.area * pa / 1e6), eq_diameter_nm=float(np.sqrt(4 * r.area * pa / np.pi)),
                         x_nm=float((x + dx - xmin) * px[0]), y_nm=float((y + dy - ymin) * px[1]), perimeter_nm=float(r.perimeter * np.sqrt(pa)),
                         eccentricity=float(r.eccentricity), gas_mean_nm=float(np.nanmean(gas[sl])) if np.isfinite(gas[sl]).any() else np.nan,
                         liquid_mean_nm=float(np.nanmean(T[sl])) if np.isfinite(T[sl]).any() else np.nan,
                         gas_volume_um3=float(np.nansum(gas[sl]) * pa / 1e9) if np.isfinite(gas[sl]).any() else np.nan,
                         touches_border=bool(b[0] == 0 or b[1] == 0 or b[2] == ny or b[3] == nx),
                         time_s=float(np.mean(rt[np.nonzero(sl)[0]])) if rt is not None and len(rt) == ny else float(time_s)))
    return rows

def link(prev_lab, cur_lab, min_iou=0.1, min_ios=0.5):
    """assignment of current labels to previous labels by maximum IoU (Hungarian); returns ({cur: prev}, splits, merges).
    Splits and merges: overlaps covering at least min_ios of the smaller object (intersection over the smaller area: a small
    fragment of a large bubble has a small IoU but is entirely inside it)."""
    from scipy.optimize import linear_sum_assignment
    pl = [l for l in np.unique(prev_lab) if l > 0]; cl = [l for l in np.unique(cur_lab) if l > 0]
    if not pl or not cl: return {}, [], []
    both = (prev_lab > 0) & (cur_lab > 0)
    pairs, cnt = np.unique(np.stack([prev_lab[both], cur_lab[both]]), axis=1, return_counts=True)
    ap = dict(zip(*np.unique(prev_lab[prev_lab > 0], return_counts=True))); ac = dict(zip(*np.unique(cur_lab[cur_lab > 0], return_counts=True)))
    iou = np.zeros((len(pl), len(cl))); ios = np.zeros_like(iou); ip = {l: i for i, l in enumerate(pl)}; ic = {l: i for i, l in enumerate(cl)}
    for (a, b), c in zip(pairs.T, cnt): iou[ip[a], ic[b]] = c / (ap[a] + ac[b] - c); ios[ip[a], ic[b]] = c / min(ap[a], ac[b])
    r, c = linear_sum_assignment(-iou); match = {cl[j]: pl[i] for i, j in zip(r, c) if iou[i, j] >= min_iou}
    splits = [(pl[i], [cl[j] for j in np.where(ios[i] >= min_ios)[0]]) for i in range(len(pl)) if (ios[i] >= min_ios).sum() > 1]
    merges = [(cl[j], [pl[i] for i in np.where(ios[:, j] >= min_ios)[0]]) for j in range(len(cl)) if (ios[:, j] >= min_ios).sum() > 1]
    return match, splits, merges

def analyse_run(run_dir, source='se_contact', min_area_px=100, min_distance_px=10, min_gas_nm=10.0, thin_nm=None, min_iou=0.1,
                write_labels=True, log=print, progress=None):
    with open(os.path.join(run_dir, 'run_info.json')) as fh: info = json.load(fh)
    cfg = info['config']; px = tuple(cfg['pixel_nm'])
    H, W, ymin, xmin = [int(v) for v in info['canvas']]; drift = np.array(info['drift']); name = cfg.get('name', 'series')
    files = [os.path.join(run_dir, t + '_maps.npz') for t in info['tags']] if info.get('tags') else sorted(glob.glob(os.path.join(glob.escape(run_dir), f'{glob.escape(name)}_*_maps.npz')))
    if len(files) != len(drift): raise ValueError(f'{run_dir}: {len(files)} map files for {len(drift)} frames - several runs in one folder?')
    S = pd.read_csv(os.path.join(run_dir, 'summary.csv'))
    rows, events, prev = [], [], None; next_id = 0; track_of = {}
    for i, fn in enumerate(files):
        if progress: progress(i / max(len(files), 1), f'objects in frame {i + 1}/{len(files)}')
        m = dict(np.load(fn)); t = float(np.nanmean(m['row_t']))
        if 'se_measured' in m and not bool(m['se_measured']) and source == 'se_contact': prev = None; continue       # no SE: no contact objects
        try: mk = object_mask(m, source, min_gas_nm, thin_nm)
        except KeyError: continue
        lab = split_objects(mk, min_area_px, min_distance_px)
        cl = _canvas_place(lab.astype(np.int32), drift[i], H, W, ymin, xmin)
        cur_track = {}
        if prev is not None:
            match, sp, mg = link(prev[0], cl, min_iou)
            for c_, p_ in match.items(): cur_track[c_] = prev[1][p_]
            for p_, cs in sp: events.append(dict(frame=i, event='split', parent_track=prev[1][p_], n=len(cs)))
            for c_, ps in mg: events.append(dict(frame=i, event='merge', child_label=int(c_), parent_tracks=';'.join(str(prev[1][p]) for p in ps)))
        for l in np.unique(cl):
            if l > 0 and l not in cur_track: cur_track[l] = next_id; next_id += 1
        for r in measure(lab, m, px, drift[i], (ymin, xmin), t):
            r.update(frame=i, time=str(S.loc[i, 'time_end']) if i < len(S) else '', track=int(cur_track.get(r['label'], -1))); rows.append(r)
        if write_labels:
            tl = np.zeros_like(cl)
            for l, tr in cur_track.items(): tl[cl == l] = tr + 1
            import tifffile
            tifffile.imwrite(os.path.join(run_dir, os.path.basename(fn)[:-9] + '_objects.tif'), tl.astype(np.int32), compression='zlib')
        prev = (cl, cur_track)
    O = pd.DataFrame(rows); O.to_csv(os.path.join(run_dir, 'objects.csv'), index=False)
    pd.DataFrame(events).to_csv(os.path.join(run_dir, 'object_events.csv'), index=False)
    rg = cfg.get('registration') or {}
    ref_note = ('drift measured in a static region of interest' if rg.get('roi') else
                'no drift correction' if rg.get('method') == 'none' else
                'drift measured on the whole field: speeds and positions include the registration error (several px over tens of '
                'frames when everything moves; give a static region of interest)')
    tr = []
    for k, g in (O.groupby('track') if len(O) else []):
        g = g.sort_values('time_s'); dt = g['time_s'].iloc[-1] - g['time_s'].iloc[0]; gi = g[~g['touches_border'].astype(bool)]   # cut objects excluded
        rate = float(np.polyfit(gi['time_s'], gi['area_um2'], 1)[0]) if len(gi) >= 3 and gi['time_s'].nunique() > 1 else np.nan
        # speed: net displacement of the centroid over the lifetime (a path length would add the centroid noise of every frame)
        sp = float(np.hypot(g['x_nm'].iloc[-1] - g['x_nm'].iloc[0], g['y_nm'].iloc[-1] - g['y_nm'].iloc[0]) / dt) if dt > 0 else np.nan
        tr.append(dict(track=int(k), first_frame=int(g['frame'].min()), last_frame=int(g['frame'].max()), n_frames=len(g), lifetime_s=float(dt),
                       area_first_um2=float(g['area_um2'].iloc[0]), area_last_um2=float(g['area_um2'].iloc[-1]), growth_um2_per_s=rate,
                       net_speed_nm_per_s=sp, max_gas_volume_um3=float(g['gas_volume_um3'].max()), n_frames_touching_border=int(g['touches_border'].sum()),
                       drift_reference=ref_note))
    pd.DataFrame(tr).to_csv(os.path.join(run_dir, 'object_tracks.csv'), index=False)
    log(f'objects: {len(O)} in {len(files)} frames, {len(tr)} tracks, {len(events)} split/merge events ({source}); {ref_note}')
    return O
