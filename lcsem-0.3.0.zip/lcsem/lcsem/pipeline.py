"""End-to-end pipeline (v0.2): JEOL image series (BSE, optional STEM, optional SE) + optional references
-> calibrated liquid thickness per frame (per channel and fused), gas on the top membrane and gas elsewhere, per-pixel
acquisition time, particles in 3-D with trajectories, dynamics maps, 3-D label volumes per frame and 4-D stacks.

Steps
  1  read the folder, group the images of each scan (io_jeol.group_scans), select the series
  2  references: dark / empty / full cell / probe current (references.py)
  3  per scan and channel: masks (field of view, window edge, particles), noise, clipping correction, optional NLM and
     interference removal, smoothing (imageproc, interference)
  4  drift registration of the scans on a common canvas (particle vote, chained)
  5  Monte Carlo curves for each thickness channel at the scan kV (cached), calibration from the references (calib.solve)
  6  per frame: thickness per channel + inverse-variance fusion (fusion.py), SE contact map, gap map, gas, particles with
     photometry and depth (depth.py), time map, label volume
  7  trajectories (tracking.py), dynamics (dynamics.py), 4-D stacks (volume.py), tables, calibration report, QC figure
"""
from __future__ import annotations
import os, json, time, warnings, numpy as np, pandas as pd
from scipy import ndimage as ndi
from . import io_jeol as J
from .config import load_config
from .imageproc import (register_by_particles, smooth_masked, noise_sigma_censored, unclip_mean, register_translation, shift_image, detect_particles,
                        particle_mask, aperture_excess, frame_edge_columns, frame_edge_fit, edge_term, denoise_nlm)
from .interference import deinterfere
from .calib import ChannelCurve, Calibration, solve, single_particle_excess, single_particle_excess_err
from .analysis import se_contact_map
from .fusion import fuse, smoothed_noise
from .references import load_references, warnings_for
from . import depth as D
from .volume import build_volume, write_label_tiff, write_map_tiff, row_times, write_stack
from . import tracking as TR
from . import dynamics as DY
from . import segment as SG
from . import denoise as DN

tifffile_stack = SG.write_prob_stack          # kept for scripts written against v0.2.0
SG_figure = SG.overview_figure

# --------------------------------------------------------------------------------------------------------------- helpers
def _select(series, sel):
    if not sel: return max(series.values(), key=len)
    out = []
    for (x, y, mag), lst in series.items():
        if 'mag' in sel and abs(mag - sel['mag']) > 0.5: continue
        for s in lst:
            if 'time_from' in sel and s.time_s < J.hms_to_s(sel['time_from']): continue
            if 'time_to' in sel and s.time_s > J.hms_to_s(sel['time_to']): continue
            if 'kV' in sel and abs(s.kv - sel['kV']) > 0.05: continue
            out.append(s)
    out.sort(key=lambda s: s.time_s)
    for i, s in enumerate(out): s.index = i
    return out

def _detector_spec(ch):
    d = ch.get('detector', 'BEDC')
    if isinstance(d, dict) and d.get('kind') == 'stem': return f"stem:{d['mrad'][0]:g}:{d['mrad'][1]:g}"
    if isinstance(d, dict) and d.get('kind') == 'bse': return f"bse:{d['theta'][0]:g}:{d['theta'][1]:g}:{d.get('weight', 'E-2')}"
    return d

class Frame_:
    pass

def _find(p, cfg):
    """relative file names in a configuration: as given, next to the configuration file, or in the package folder"""
    if not isinstance(p, str) or os.path.isabs(p) or os.path.exists(p): return p
    here = os.path.dirname(os.path.abspath(__file__))
    for base in (cfg.get('_config_dir'), os.path.dirname(here)):
        if base and os.path.exists(os.path.join(base, p)): return os.path.join(base, p)
    q = os.path.join(here, 'data', os.path.basename(p))                  # curves shipped inside the package (pip installs)
    return q if os.path.exists(q) else p

# --------------------------------------------------------------------------------------------------------------- main
class Aborted(Exception):
    pass

def run(cfg, out_dir, verbose=True, scans=None, progress=None, should_abort=None, log=None):
    """the full pipeline. scans: a list of io_jeol.Scan (e.g. from lcsem.io_movie.movie_scans) instead of reading
    cfg['folder']; progress(fraction, message) and should_abort() are called from the loops (GUI); log(message)."""
    if isinstance(cfg, str): cfg = load_config(cfg)
    os.makedirs(out_dir, exist_ok=True); t_start = time.time()
    if log is None: log = (lambda *a: print(*a, flush=True)) if verbose else (lambda *a: None)
    prog = progress or (lambda *a: None)
    def check_abort():
        if should_abort is not None and should_abort(): raise Aborted('aborted by the user')
    CH = {k: v for k, v in cfg['channels'].items() if v}
    TH = [k for k, v in CH.items() if v.get('role') == 'thickness']; SEC = [k for k, v in CH.items() if v.get('role') == 'contact']
    px = tuple(cfg['pixel_nm']); pxa = px[0] * px[1]; HI = float(2 ** int(cfg.get('bits', 8)) - 1)
    # ---------------------------------------------------------------- 1. scans
    refs_cfg = cfg.get('references') or {}
    excl = [f for kind in ('dark', 'empty', 'full') for f in ((refs_cfg.get(kind) or {}).get('files') or [])]
    excl = [f if os.path.isabs(f) else os.path.join(cfg['folder'], f if f.endswith('.tif') else f + '.tif') for f in excl]
    if scans is None:
        frames = J.scan_folder_all(cfg['folder'], cfg.get('prefix', ''))
        series = J.group_scans(frames, CH, cfg['pair_window_s'], exclude=excl)
        log('scans found:\n' + J.describe_scans(series))
        scans = _select(series, cfg.get('select') or {})
    else:
        log(f'{len(scans)} scans given (movie or custom source)')
    if not scans: raise ValueError('no scans selected: check the folder, the file prefix, the magnification, the time window and the kV '
                                   '(lcsem list FOLDER shows the series in a folder), or the movie frame range')
    prog(0.01, f'{len(scans)} scans')
    kvs = [s.kv for s in scans]; kv_main = cfg['beam'].get('kV') or max(set(kvs), key=kvs.count)
    if not any(abs(k - kv_main) < 0.05 for k in kvs):
        k2 = max(set(kvs), key=kvs.count); log(f'WARNING: no scan at the configured {kv_main:g} kV; using {k2:g} kV from the image metadata'); kv_main = k2
    main = [s for s in scans if abs(s.kv - kv_main) < 0.05]; aux = [s for s in scans if abs(s.kv - kv_main) >= 0.05]
    for i, s in enumerate(main): s.index = i
    log(f'{len(main)} scans at {kv_main:g} kV selected' + (f'; {len(aux)} scans at other kV kept for energy-ratio depth' if aux else ''))
    prim = main[0].primary
    # ---------------------------------------------------------------- 2. references
    refs = load_references(cfg)
    for w in warnings_for(refs): log('WARNING: ' + w)
    for kind in ('dark', 'empty', 'full'):
        for c, d in (refs.get(kind) or {}).items(): log(f'reference {kind:5s} {c}: {d["mean"]:.2f} +- {d["err"]:.2f} grey ({len(d["frames"])} frames, {100*d["clipped"]:.1f} % clipped)')
    Icur = refs.get('current')
    # ---------------------------------------------------------------- 3. per-scan preprocessing
    P = cfg['particles']; ap, (a0, a1) = P['aperture_px'], P['annulus_px']
    F = []; dn_cfg = cfg.get('denoise') or {}; dn_meth = dn_cfg.get('method')
    for s in main:
        check_abort(); prog(0.02 + 0.38 * s.index / max(len(main), 1), f'preprocessing scan {s.index + 1}/{len(main)}')
        f = Frame_(); f.scan = s; f.ch = {}
        _raw = lambda ch: getattr(ch, 'load_raw', ch.load)()           # undenoised frame (movies denoised as a series keep both)
        base = _raw(s.channels[prim]); ny, nx = base.shape; f.shape = base.shape
        if base.max() > HI * 1.0001:
            raise ValueError(f'grey levels up to {base.max():.0f} exceed the bit depth ({int(HI)}): set the bit depth to 16 (Data tab)')
        valid = np.ones(base.shape, bool); f.outwin = np.zeros(base.shape, bool); f.dist_edge = None
        if cfg['frame_edge'] and 'BSE' in s.channels:
            xe = frame_edge_fit(frame_edge_columns(s.channels['BSE'].load()))
            if xe is not None:
                X = np.arange(nx)[None, :]; f.outwin = X >= (xe[:, None] - cfg['frame_edge_margin_px']); valid &= ~f.outwin; f.dist_edge = (xe[:, None] - X).astype(np.float32)
        # particles from the primary channel (Au is bright in BSE, dark in STEM bright field)
        spec_ = str(_detector_spec(CH[prim]))
        try: inner_ = float(spec_.split(':')[1]) if spec_.startswith('stem:') else 0.0
        except Exception: inner_ = 0.0
        sign = 1.0 if prim == 'BSE' or 'HAADF' in spec_ or 'DF' in spec_.upper() or inner_ > 0 else -1.0     # Au bright in BSE and dark field, dark in bright field
        det_img = base if sign > 0 else (base.max() - base)
        f.blobs = detect_particles(det_img, valid, P['sigma_min'], P['sigma_max'], P['threshold'], sat_level=HI if sign > 0 else 1e30)
        f.au = particle_mask(base.shape, f.blobs, 3.0, P['mask_extra_px']); f.valid = valid & ~f.au
        for c in TH:
            if not s.has(c): continue
            img = base if c == prim else _raw(s.channels[c])
            den = s.channels[c].load() if getattr(s.channels[c], 'raw_src', None) is not None else None     # series-denoised frame
            if c != prim:      # same scan: small offset between detectors; estimate once per frame
                try:
                    hp = lambda a: smooth_masked(a, ~f.valid, 2) - smooth_masked(a, ~f.valid, 12)
                    sh = register_translation(hp(base), hp(img if sign * (1 if c == 'BSE' else -1) > 0 else -img), upsample=10)
                    if np.hypot(*sh) < 20:
                        img = np.nan_to_num(shift_image(img, sh[0], sh[1], fill=np.nan), nan=float(np.median(img)))
                        if den is not None: den = np.nan_to_num(shift_image(den, sh[0], sh[1], fill=np.nan), nan=float(np.median(den)))
                except Exception: pass
            q = dict(raw=img)
            q['clip'] = float(((img <= 0) | (img >= HI))[f.valid].mean())
            q['sigma'] = noise_sigma_censored(img, f.valid, 0.0, HI)
            work = (den if den is not None else img).astype(np.float32); q['notch'] = []
            fs = s.channels[c].__dict__.get('frame_s')
            q['frame_s'] = fs or (cfg['frame_time']['fast_s'] if q['sigma'] > cfg['frame_time']['sigma_split'] else cfg['frame_time']['slow_s'])
            if cfg['deinterfere'] and q['sigma'] <= cfg['frame_time']['sigma_split']: work, q['notch'] = deinterfere(work, f.valid, pmax=cfg['deinterfere_pmax'])
            if dn_meth and dn_meth in DN.FRAME_METHODS and dn_meth != 'none':
                work = DN.denoise_image(work, dn_meth, vst=bool(dn_cfg.get('vst', False)), strength=float(dn_cfg.get('strength', 1.0)), mask=f.valid)
            elif cfg['nlm']: work, _ = denoise_nlm(work, ~f.valid, sigma=q['sigma'], patch=7, distance=11, h_factor=1.0)
            q['work'] = work                                  # de-interfered / denoised, not yet smoothed (used by the segmentation)
            q['denoised'] = den is not None or bool(dn_meth and dn_meth in DN.FRAME_METHODS and dn_meth != 'none') or bool(cfg['nlm'])
            sm = smooth_masked(work, ~f.valid, cfg['smooth_sigma_px']); sm = unclip_mean(sm, max(q['sigma'], 1.0), 0.0, HI) if q['clip'] > 0.002 else sm
            q['edge'] = np.zeros(img.shape, np.float32)
            m = f.valid.copy(); m[:cfg['skip_rows']] = False
            if f.dist_edge is not None and c == 'BSE': q['edge'], q['flat'] = edge_term(sm, f.valid, f.dist_edge, skip_rows=cfg['skip_rows'])
            else: q['flat'] = float(np.median(sm[m]))
            q['grey'] = (sm - q['edge']).astype(np.float32)
            q['sigma_sm'] = smoothed_noise(q['sigma'], cfg['smooth_sigma_px'])
            ex = []
            for (y, x, sg) in f.blobs:
                if x < a1 + 2 or y < a1 + 2 or x > nx - a1 - 2 or y > ny - a1 - 2 or y < cfg['skip_rows']: continue
                e, bg, n = aperture_excess(img, y, x, ap, a0, a1, exclude=f.au & ~particle_mask(img.shape, [(y, x, sg)], 3.0, P['mask_extra_px']))
                if np.isfinite(e): ex.append((e, bg, y, x))
            q['excess'] = np.array(ex) if ex else np.zeros((0, 4))
            f.ch[c] = q
        f.frame_s = f.ch[prim]['frame_s']
        # SE (contact) channels, aligned to the primary
        f.se = {}
        for c in SEC:
            if not s.has(c): continue
            se = s.channels[c].load()
            if dn_meth and dn_meth in DN.FRAME_METHODS and dn_meth != 'none' and dn_cfg.get('se', True):
                se = DN.denoise_image(se, dn_meth, vst=bool(dn_cfg.get('vst', False)), strength=float(dn_cfg.get('strength', 1.0)))
            if (cfg.get('se') or {}).get('align', True):
                try:
                    hp = lambda a: smooth_masked(a, ~f.valid, 2) - smooth_masked(a, ~f.valid, 12)
                    sh = register_translation(hp(base * sign), hp(se), upsample=10)
                    if np.hypot(*sh) <= float((cfg.get('se') or {}).get('max_align_px', 10.0)): se = shift_image(se, sh[0], sh[1], fill=np.nan)
                except Exception: pass
            f.se[c] = se
        log(f'scan {s.index:2d} {s.time_str} {s.kv:g} kV: ' + ', '.join(f'{c} sigma {q["sigma"]:.1f} clip {100*q["clip"]:.1f}%' for c, q in f.ch.items()) + f', particles {len(f.blobs)}, frame {f.frame_s:.1f} s, SE {list(f.se)}')
        F.append(f)
    # ---------------------------------------------------------------- 4. registration
    shifts, H, W, ymin, xmin = _register(F, cfg, log, should_abort)
    def to_canvas(img, i, fill=np.nan):
        dy, dx = shifts[i]; out = np.full((H, W), fill, np.float32)
        s_ = shift_image(np.asarray(img, np.float32), dy - np.floor(dy), dx - np.floor(dx)); iy, ix = int(np.floor(dy)) - ymin, int(np.floor(dx)) - xmin
        out[iy:iy + img.shape[0], ix:ix + img.shape[1]] = s_; return out
    # ---------------------------------------------------------------- 5. curves and calibration
    cells = cfg['cell']; curves = {}; cal = {}; reports = {}; models = {}
    Tmed_guess = cfg['cell'].get('channel_nm') or (cfg['references'].get('flat') or {}).get('T_nm') or 300.0
    for c in TH:
        spec = _detector_spec(CH[c]); src = (cfg.get('curves') or {}).get(c)
        if src:
            from .mc.curves import detector_label
            if isinstance(src, dict): curves[c] = ChannelCurve(_find(src['file'], cfg), src.get('detector'))
            else:
                dd = json.load(open(_find(src, cfg))); lab = detector_label(spec)
                curves[c] = ChannelCurve(dd, lab if dd.get('version', 1) >= 2 and lab in dd.get('detectors', {}) else None)
        else:
            from .mc.curves import cached_curve
            Tl = sorted({float(round(v)) for v in (0.5 * Tmed_guess, Tmed_guess, 2 * Tmed_guess)} | {200.0, 500.0})
            d, fn = cached_curve(cfg['mc'].get('cache_dir'), E0=float(kv_main), detectors=(spec,), t_mem=tuple(cells['membranes_nm']), membrane=cells.get('membrane', 'SiN'),
                                 liquid=cells.get('liquid', 'H2O'), water=tuple(cfg['mc']['water_nm']), n=int(cfg['mc']['n']), particle=float(cfg['references']['particles']['diameter_nm']),
                                 material=cfg['references']['particles'].get('material', 'Au'), particle_T=tuple(Tl), depths=('top', 'f0.25', 'mid', 'f0.75', 'bot'))
            log(f'Monte Carlo curve for {c} ({spec}, {kv_main:g} kV): {fn}'); curves[c] = ChannelCurve(d)
        r = {}
        dk = (refs.get('dark') or {}).get(c); ek = (refs.get('empty') or {}).get(c)
        if dk: r['dark'] = (dk['mean'], dk['err'])
        if ek: r['empty'] = (ek['mean'], ek['err'])
        # particle depth model (Monte Carlo profiles rendered at this pixel size); depth.curve may give a separate file
        dsrc = (cfg['depth'].get('curve') or {}) if isinstance(cfg['depth'].get('curve'), dict) else ({c: cfg['depth']['curve']} if cfg['depth'].get('curve') else {})
        dcurve = curves[c]
        if dsrc.get(c):
            from .mc.curves import detector_label
            dd = json.load(open(_find(dsrc[c], cfg))); lab = detector_label(spec); dcurve = ChannelCurve(dd, lab if lab in dd.get('detectors', {}) else None)
        if dcurve.particle is not None:
            try: models[c] = D.ParticleModel(dcurve.particle, dcurve.detector, px, cfg['depth'].get('pixel_blur_nm', 2.0))
            except Exception as e: log(f'  depth model for {c} not available: {e}')
        A_mc = None
        def particle_gain(Tref, cal0=None):
            """(excess in grey nm^2, its error, Monte Carlo top excess) from the particles in the top quarter of the liquid;
            with a preliminary calibration cal0 every particle is modelled in its own local liquid thickness"""
            sgn = 1.0 if curves[c].sign > 0 else -1.0; meas = []; dP = float(cfg['references']['particles']['diameter_nm']); R_ = dP / 2
            for f in F:
                if c not in f.ch: continue
                for k_, (y, x, sg) in enumerate(f.blobs):
                    nb_ = np.delete(f.blobs[:, :2], k_, axis=0)
                    m = D.measure(f.ch[c]['raw'], y, x, px, dP, sigma_noise=f.ch[c]['sigma'], sign=sgn, lo=0.0, hi=HI, neighbors=nb_)
                    if m is not None and not m['crowded'] and m.get('n_sat', 0) == 0 and np.isfinite(m['CF']) and sgn * m['A'] > 8 * m.get('sA', 0) and m['CF'] < 1.15:
                        Ti = float(cal0.thickness(f.ch[c]['grey'][int(y), int(x)])) if cal0 is not None else Tref
                        meas.append((m['CF'], m.get('sCF', 0.05), abs(m['A']), max(Ti, dP + 20)))
            if not meas: log(f'  {c}: no isolated, unsaturated particle passed the checks for the depth-corrected gain'); return None
            # depth-corrected photometry: each particle's excess is compared with the Monte Carlo excess at the depth its core
            # fraction indicates (a ratio, independent of the gain) in its local thickness; particles in the top quarter are used
            M = np.array(meas); zi = np.zeros(len(M)); Ai = np.zeros(len(M)); top = np.zeros(len(M), bool)
            for j_, (cf_, s_, a_, Ti) in enumerate(M):
                zA, At = models[c].excess(Ti); zi[j_] = models[c].z_from_cf(cf_, s_, Ti)[0]; Ai[j_] = abs(np.interp(zi[j_], zA, At)); top[j_] = zi[j_] <= R_ + 0.25 * (Ti - 2 * R_)
            zA, At = models[c].excess(Tref)
            if top.sum() < 3: log(f'  {c}: only {int(top.sum())} particles near the top membrane: no particle gain'); return None
            ratio = M[top, 2] / Ai[top]; q = float(np.median(ratio)); sq = float(1.2533 * 1.4826 * np.median(np.abs(ratio - q)) / np.sqrt(top.sum()))
            log(f'  {c}: {int(top.sum())} of {len(M)} particles in the top quarter of the liquid (T = {Tref:.0f} nm) -> gain standard')
            A_top = abs(float(At[0])); return q * A_top * pxa, sq * A_top * pxa, A_top
        if cfg['calibration'].get('use_particles', True) and c in models:
            pg = particle_gain(Tmed_guess)
            if pg: r['particles'] = pg[:2]; A_mc = pg[2]
            elif curves[c].legacy_particle is not None: log(f'  {c}: falling back to the aperture photometry of all particles (8-bit saturation or too few particles near the top)')
        if 'particles' not in r and cfg['calibration'].get('use_particles', True) and curves[c].legacy_particle is not None:
            exc = np.concatenate([F[i].ch[c]['excess'][:, 0] for i in range(len(F)) if c in F[i].ch and F[i].ch[c]['excess'].size]) if any(c in f.ch and f.ch[c]['excess'].size for f in F) else np.array([])
            if exc.size >= 3:
                e1 = single_particle_excess(np.abs(exc)); se1 = single_particle_excess_err(np.abs(exc)); r['particles'] = (e1 * pxa, se1 * pxa)
        rf = cfg['references'].get('flat')
        if rf and rf.get('T_nm') is not None:
            idx = list(range(len(F))) if rf.get('frames', 'all') == 'all' else list(rf['frames'])
            fl = [F[i].ch[c]['flat'] for i in idx if c in F[i].ch]
            if fl: r['flat'] = (float(np.median(fl)), float(np.std(fl) / np.sqrt(len(fl)) + 0.05), float(rf['T_nm']))
        mode = cfg['calibration']['mode']
        if mode == 'manual': r['manual'] = (cfg['calibration']['B0'][c], cfg['calibration']['g'][c])
        if mode == 'two_references': r['two'] = tuple(tuple(v) for v in cfg['calibration']['two'][c])
        if 'particles' in mode and 'particles' not in r:
            raise RuntimeError(f'calibration mode {mode} needs the particle standard, but no particle could be used for {c} (all saturated or crowded?). '
                               'Use calibration mode dark+flat / dark+empty, or record 16-bit images.')
        try:
            cal[c], reports[c] = solve(curves[c], r, mode, T_particle=None, aperture_nm=ap * px[0], annulus_nm=(a0 * px[0], a1 * px[0]), A_mc=A_mc)
        except ValueError as ex_:
            if 'not enough references' in str(ex_) and 'particles' not in r and cfg['calibration'].get('use_particles', True):
                have_ = ', '.join(sorted(k for k, v in r.items() if v is not None)) or 'none'
                raise ValueError(f'calibration of {c}: the references given ({have_}) need the Au particles as the gain standard, but no particle '
                                 'near the top membrane could be used (all saturated, crowded, too deep or too few). Record an empty cell '
                                 '(dry K-kit, same settings) or enter an assumed flat-field thickness.') from None
            raise
        if A_mc is not None:      # second pass: particle depths and excesses at the measured thickness
            Tm = float(np.nanmedian(cal[c].thickness(np.array([F[i].ch[c]['flat'] for i in range(len(F)) if c in F[i].ch]))))
            pg = particle_gain(max(Tm, float(cfg['references']['particles']['diameter_nm']) + 20), cal0=cal[c])
            if pg: r['particles'] = pg[:2]; A_mc = pg[2]; cal[c], reports[c] = solve(curves[c], r, mode, aperture_nm=ap * px[0], annulus_nm=(a0 * px[0], a1 * px[0]), A_mc=A_mc)
        # iterate once: particle excess evaluated at the measured median thickness
        if ('particles' in reports[c]['mode'] or 'particles' in r) and A_mc is None:
            Tm = float(np.nanmedian(cal[c].thickness(np.array([F[i].ch[c]['flat'] for i in range(len(F)) if c in F[i].ch]))))
            cal[c], reports[c] = solve(curves[c], r, mode, T_particle=max(Tm, 50.0), aperture_nm=ap * px[0], annulus_nm=(a0 * px[0], a1 * px[0]))
        log(f'calibration {c}: {reports[c]["mode"]}  B0 = {cal[c].B0:.2f} +- {cal[c].sB0:.2f}, g = {cal[c].g:.1f} +- {cal[c].sg:.1f}  ({reports[c]["note"]})')
        for chk in reports[c]['checks']: log(f'   check: {chk["check"]} = {chk["value"]:.3g} +- {chk["err"]:.2g}   ({chk["meaning"]})')
    json.dump({c: {k: (v if not isinstance(v, (np.floating,)) else float(v)) for k, v in rep.items()} for c, rep in reports.items()}, open(os.path.join(out_dir, 'calibration_report.json'), 'w'), indent=1, default=float)
    # ---------------------------------------------------------------- per-frame calibration (contrast changes, probe current)
    I_ref = None
    if Icur: I_ref = float(np.median([Icur(f.scan.time_s) for f in F]))
    for f in F:
        f.cal = {}
        for c in f.ch:
            k = cal[c]; note = ''
            if Icur: fac = Icur(f.scan.time_s) / I_ref; k = Calibration(k.curve, k.B0, k.g * fac, k.note + f'; current x{fac:.3f}', k.sB0, k.sg * fac)
            ex = f.ch[c]['excess']
            if cfg['calibration'].get('per_frame_gain', True) and ex.shape[0] >= 2 and 'particles' in reports[c]['references']:
                e = single_particle_excess(np.abs(ex[:, 0])) if ex.shape[0] >= 8 else float(np.median(np.abs(ex[:, 0])))
                allx = np.abs(np.concatenate([g.ch[c]['excess'][:, 0] for g in F if c in g.ch and g.ch[c]['excess'].size])); e_all = single_particle_excess(allx)
                if np.isfinite(e) and abs(e / e_all - 1) > cfg['calibration']['gain_change_threshold']:
                    Tflat = (cfg['references'].get('flat') or {}).get('T_nm') or float(np.median([cal[c].thickness(g_.ch[c]['flat']) for g_ in F if c in g_.ch and g_ is not f]))
                    g2 = k.g * e / e_all
                    k = Calibration(k.curve, f.ch[c]['flat'] - g2 * float(k.curve.S_of_T(Tflat)), g2, k.note + f'; own gain (particles {e:.0f} vs {e_all:.0f}) and black level (flat = {Tflat:.0f} nm)', k.sB0, k.sg)
                    log(f'  scan {f.scan.index}: {c} contrast differs (particle excess {e:.0f} vs {e_all:.0f}): own gain and black level')
            f.cal[c] = k
    # ---------------------------------------------------------------- gap map from a full-cell reference
    gap_canvas = None; gap_sigma = 0.0
    if refs.get('full') and prim in refs['full']:
        gap_canvas = _gap_map(refs['full'][prim]['frames'], F, cal[prim], cfg, shifts, to_canvas, log)
        if gap_canvas is not None:
            nf = len(refs['full'][prim]['frames']); q0 = F[0].ch[prim]
            gap_sigma = float(np.nanmedian(cal[prim].sigma_T(np.nan_to_num(gap_canvas, nan=np.nanmedian(gap_canvas)), q0['sigma_sm']))) / np.sqrt(max(nf, 1))
    # ---------------------------------------------------------------- 6. per-frame maps
    summary, prow, canv = [], [], []; seg_rows, seg_fig = [], []
    seg_pick = SG.pick_frames(len(F), cfg['segmentation'])
    S_ = cfg['se']; V = cfg['volume']; dpart = float(cfg['references']['particles']['diameter_nm'])
    ndig = max(2, len(str(len(F) - 1))); tags_all = []; qc_warned = False; qc_notes = []
    for i, f in enumerate(F):
        check_abort(); prog(0.45 + 0.45 * i / max(len(F), 1), f'maps and 3-D model of frame {i + 1}/{len(F)}')
        s = f.scan; rt = row_times(s.time_s, f.frame_s, f.shape[0]); tag = f'{cfg["name"]}_{i:0{ndig}d}_{s.frame.name}'; tags_all.append(tag)
        Tm, Sm = {}, {}
        for c, q in f.ch.items():
            T = f.cal[c].thickness(q['grey']); T[~(f.valid | f.au)] = np.nan; T[f.outwin] = np.nan
            Tm[c] = T.astype(np.float32); Sm[c] = f.cal[c].sigma_T(np.nan_to_num(T, nan=0), q['sigma_sm']).astype(np.float32)
        T, sT, chi2, wfrac = fuse(Tm, Sm)
        # sanity check of the thickness map: a map stuck at one value or at the ends of the detector curve means the wrong
        # channel was read as thickness (e.g. SE and BSE swapped in a side-by-side movie) or a wrong black level / gain
        tv = T[f.valid & np.isfinite(T)]
        if tv.size > 1000 and not qc_warned:
            c0_ = next(iter(Tm)); t_hi = float(np.nanmax(f.cal[c0_].curve.T)) if hasattr(f.cal[c0_].curve, 'T') else np.inf
            stuck = float(np.mean(np.abs(tv - np.median(tv)) < 0.5)); ends = float(np.mean((tv <= 0.5) | (tv >= 0.98 * t_hi)))
            if stuck > 0.5 or ends > 0.3:
                qc_warned = True
                log(f'WARNING frame {i}: the thickness map is {"nearly constant" if stuck > 0.5 else "at the ends of the detector curve"} '
                    f'({100 * max(stuck, ends):.0f} % of the field) - unless the cell is dry there, check the detector order and layout (Preview first frame), '
                    'the bit depth and the calibration')
                qc_notes.append(f'frame {i}: thickness map nearly constant or at the curve limits - check detector order, layout, calibration')
        # SE contact: any/all of the SE channels dark
        dark = np.zeros(f.shape, bool); se_ok = bool(f.se)
        min_area_se = int(S_['min_area_px']) if S_.get('min_area_px') else int(round(float(S_.get('min_area_um2', 0.01)) * 1e6 / pxa))
        se_info = {}
        for c, se in f.se.items():     # particle masks are not holes in the contact map (they would notch every bubble rim)
            dk, thr, _, se_info[c] = se_contact_map(se, (f.valid | f.au) & ~f.outwin & np.isfinite(se), S_['sigma_px'], min_area_se, S_['open_iter'], cfg['skip_rows'],
                                                    k_sigma=float(S_.get('k_sigma', 5.0)), min_contrast=float(S_.get('min_contrast', 0.05)), return_info=True)
            dark = (dark | dk) if S_.get('combine', 'any') == 'any' or not dark.any() else (dark & dk)
        # unsupervised multimodal segmentation (PCA + Gaussian mixture on thickness + SE)
        T_seg = None
        if cfg['segmentation'].get('enabled') and se_ok:
            try:
                # thickness for the segmentation: the primary channel denoised (non-local means) and smoothed at the fine scale
                # only, as in the K-kit 1 figure (the thickness above is smoothed at smooth_sigma_px for the calibration)
                c0 = next(c for c in TH if c in f.ch); q0_ = f.ch[c0]
                # (not a second time when the frames were already denoised: NLM tuned to the raw noise would over-smooth them)
                dn_ = denoise_nlm(q0_['work'], ~f.valid, sigma=q0_['sigma'], patch=7, distance=11, h_factor=1.0)[0] \
                    if cfg['segmentation'].get('nlm', True) and not q0_.get('denoised') else q0_['work']
                sg_ = smooth_masked(dn_, ~f.valid, 4.0 if px[0] >= 5.0 else 6.0)
                sg_ = unclip_mean(sg_, max(q0_['sigma'], 1.0), 0.0, HI) if q0_['clip'] > 0.002 else sg_
                T_seg = f.cal[c0].thickness(sg_ - q0_['edge']).astype(np.float32); T_seg[~f.valid] = np.nan
                seg = SG.segment_frame(T_seg, list(f.se.values())[0], f.valid & ~f.au, dark, px[0], cfg['segmentation'], T_ready=True)
            except Exception as ex_: seg = None; log(f'  segmentation failed on frame {i}: {ex_}')
            if seg:
                seg_rows += SG.write_frame(out_dir, tag, seg, px, i, s.time_str)
                if i in seg_pick: seg_fig.append(dict(frame=i, time=s.time_str, seg=seg, dark=dark))
        # gap: full-cell reference (canvas) or wet reference of this frame or configured channel height
        gas_ok = bool(se_ok)
        if gap_canvas is not None:
            dy, dx = shifts[i]; iy, ix = int(np.floor(dy)) - ymin, int(np.floor(dx)) - xmin
            gap = shift_image(gap_canvas, -(dy - np.floor(dy)), -(dx - np.floor(dx)))[iy:iy + f.shape[0], ix:ix + f.shape[1]]; gap_src = 'full-cell reference'
        else:
            # no full-cell reference: the gap under the gas is interpolated from the wet (SE-bright) surroundings with a robust
            # quadratic surface (membrane bulging is smooth), not a single median of the frame
            wet = f.valid & ~dark & np.isfinite(T); wet[:cfg['skip_rows']] = False
            margin = int(np.ceil(2.5 * float(cfg['smooth_sigma_px'])))      # the smoothed thickness leaks across rims: keep away
            if dark.any(): wet &= ~ndi.binary_dilation(dark, iterations=margin)
            cover = float(dark[f.valid].mean()) if f.valid.any() else 0.0
            if dark.any() and (cover > 0.5 or wet.sum() < 0.25 * f.valid.sum()):
                # the gap would be extrapolated from a small wet part over most of the field (real 12k frames: -5.8 um3 of "gas"):
                # no gas measurement without a full-cell reference
                gap = np.full(f.shape, np.nan, np.float32); gas_ok = False
                gap_src = f'none: contact over {100 * cover:.0f} % of the field, wet surroundings too small for the gap (record a full-cell reference)'
                log(f'  frame {i}: gas not measured - {gap_src}')
            elif wet.sum() > 0.05 * f.valid.sum() and dark.any():
                from .analysis import smooth_surface
                gap = smooth_surface(np.where(wet, T, np.nan), wet).astype(np.float32); gap_src = 'wet surroundings (quadratic surface)'
            else:
                g0 = float(np.nanmedian(T[wet])) if wet.sum() > 0.05 * f.valid.sum() else (cfg['cell'].get('channel_nm') or float(np.nanmedian(T[f.valid])))
                gap = np.full(f.shape, g0, np.float32); gap_src = f'wet reference {g0:.0f} nm'
        # for volumes: gap - T summed over the contact region and a margin of 2.5 smoothing lengths, which recovers the gas deficit
        # that the smoothing of T moves across the rim (unbiased for sums: noise both ways); per-pixel display: clipped, in contact
        near = ndi.binary_dilation(dark, iterations=int(np.ceil(2.5 * float(cfg['smooth_sigma_px'])))) & f.valid if dark.any() else dark
        gas_signed = np.where(near, gap - T, 0.0).astype(np.float32)
        gas_tot = np.clip(gap - T, 0, None); gas_top = np.where(dark, gas_tot, 0.0).astype(np.float32); gas_top[~f.valid] = np.nan; gas_signed[~f.valid] = np.nan
        if not gas_ok: gas_top[:] = np.nan; gas_signed[:] = np.nan                # no SE, or no gap: gas at the top not measured
        # uncertainty of the gas volume: the same sum over a region of this size where there is no gas scatters with the
        # residual gap - T of the wet surroundings (noise, smoothing, misfit of the gap surface), spatially correlated
        gas_vol = gas_sd = np.nan
        if gas_ok:
            gas_vol = float(np.nansum(gas_signed)) * pxa / 1e9
            if dark.any():
                from .analysis import sum_sd
                wet_r = f.valid & ~ndi.binary_dilation(near, iterations=int(np.ceil(float(cfg['smooth_sigma_px'])))) & np.isfinite(T) & np.isfinite(gap)
                wet_r[:cfg['skip_rows']] = False
                sd_, _, _ = sum_sd(gap - T, wet_r, near & f.valid); gas_sd = sd_ * pxa / 1e9
            else: gas_sd = 0.0
        if gap_canvas is not None:     # gas not touching the top membrane: gap - T significantly above zero (3 sigma), cleaned
            thr = np.maximum(cfg['gas']['other_threshold_nm'], 3 * np.sqrt(np.nan_to_num(sT, nan=1e3) ** 2 + gap_sigma ** 2))
            mo = ~dark & (gas_tot > thr) & f.valid
            mo = ndi.binary_opening(mo, iterations=2); lab_, nlab_ = ndi.label(mo)
            if nlab_:
                sz_ = ndi.sum(mo, lab_, range(1, nlab_ + 1)); mo = np.isin(lab_, 1 + np.where(sz_ >= min_area_se)[0])
            gas_oth = np.where(mo, gas_tot, 0.0).astype(np.float32)
        else: gas_oth = np.zeros(f.shape, np.float32)
        gas_oth[~f.valid] = np.nan
        # particles: photometry in each channel, depth
        parts = []
        for k, (y, x, sg) in enumerate(f.blobs):
            row = dict(frame=i, time=s.time_str, t_s=float(rt[int(y)]), y_px=float(y), x_px=float(x), x_nm=float((x + shifts[i][1] - xmin) * px[0]), y_nm=float((y + shifts[i][0] - ymin) * px[1]),
                       liquid_here_nm=float(np.nanmedian(T[max(0, int(y) - 3):int(y) + 4, max(0, int(x) - 3):int(x) + 4])) if np.isfinite(T[max(0, int(y) - 3):int(y) + 4, max(0, int(x) - 3):int(x) + 4]).any() else np.nan,
                       top_membrane_dry=bool(dark[int(y), int(x)]) if se_ok else None)
            Tloc = row['liquid_here_nm'] if np.isfinite(row['liquid_here_nm']) else float(np.nanmedian(T))
            gap_here = float(gap[int(y), int(x)]) if np.isfinite(gap[int(y), int(x)]) else Tloc
            # the beam broadens only in the liquid above the particle: model the liquid column (T here) and add any gas on the top membrane
            gtop = 0.0
            if gas_ok:    # the particle itself is masked in the contact map: use the ring around it
                yy_, xx_ = np.ogrid[:f.shape[0], :f.shape[1]]; rr_ = np.hypot(yy_ - y, xx_ - x); rg = f.valid & (rr_ > 3 * sg + P['mask_extra_px']) & (rr_ < 3 * sg + P['mask_extra_px'] + 8)
                if rg.any() and dark[rg].mean() > 0.5: gtop = float(np.nanmedian(np.clip(gap[rg] - T[rg], 0, None)))
            Tmod = max(Tloc, dpart + 2)
            est = []; meas = {}
            for c, q in f.ch.items():
                m = D.measure(q['raw'], y, x, px, dpart, sigma_noise=q['sigma'], sign=1.0 if curves[c].sign > 0 else -1.0, lo=0.0, hi=HI, neighbors=np.delete(f.blobs[:, :2], k, axis=0))
                if m is None: continue
                row[f'sat_{c}'] = m.get('n_sat', 0); row['crowded'] = bool(m['crowded'])
                if m['crowded']: m['CF'] = np.nan; m['sA'] = abs(m['A'])          # a neighbour inside the aperture: no depth, photometry flagged
                if m.get('n_sat', 0) > 0: m['CF'] = np.nan          # clipped core: the core fraction is biased low; no depth from it
                meas[c] = m; row[f'A_{c}'] = m['A'] * pxa / f.cal[c].g; row[f'CF_{c}'] = m['CF']
                if 'core_fraction' in cfg['depth']['methods'] and c in models and np.isfinite(m['CF']) and m['A'] * (1 if curves[c].sign > 0 else -1) > 0:
                    z, sz = models[c].z_from_cf(m['CF'], m['sCF'], Tmod); z += gtop; est.append((z, sz)); row[f'z_cf_{c}_nm'] = z; row[f'sz_cf_{c}_nm'] = sz
            if 'channel_ratio' in cfg['depth']['methods'] and 'BSE' in meas and 'STEM' in meas and 'BSE' in models and 'STEM' in models:
                a1_, a2_ = row['A_BSE'], row['A_STEM']
                if a2_ != 0:
                    Q = a1_ / a2_; sQ = abs(Q) * np.hypot(meas['BSE'].get('sA', 0) / max(abs(meas['BSE']['A']), 1e-9), meas['STEM'].get('sA', 0) / max(abs(meas['STEM']['A']), 1e-9))
                    z, sz = D.z_from_ratio(Q, sQ, models['BSE'], models['STEM'], Tmod); z += gtop; est.append((z, sz)); row['z_ratio_nm'] = z; row['sz_ratio_nm'] = sz
            z, sz = D.combine(est); row['z_nm'] = z; row['sz_nm'] = sz; row['gap_here_nm'] = gap_here; row['gas_top_here_nm'] = gtop
            prow.append(row); parts.append((row['x_nm'], row['y_nm'], (z - dpart / 2) if np.isfinite(z) else 0.0, dpart, 10 + k))
        # outputs
        def _prev(a):                                                    # 2 x 2 binned preview of an input frame (GUI 2-D maps)
            a = np.asarray(a, np.float32); h2, w2 = a.shape[0] // 2 * 2, a.shape[1] // 2 * 2
            return a[:h2, :w2].reshape(h2 // 2, 2, w2 // 2, 2).mean(axis=(1, 3)).astype(np.float16)
        prim_c = next(c for c in TH if c in f.ch)
        previews = {f'prev_{prim_c}': _prev(f.ch[prim_c]['raw'])}
        previews.update({f'prev_{c}': _prev(v) for c, v in f.se.items()})
        dmask_ = getattr(s.channels.get(s.primary), 'denoised_mask', None)
        if dmask_ is not None: previews['denoised'] = np.asarray(dmask_, bool)       # series denoising: pixels inside the block's common field
        np.savez_compressed(os.path.join(out_dir, tag + '_maps.npz'), T=T, sT=sT, chi2=chi2, gas_top=gas_top, gas_other=gas_oth, gas_signed=gas_signed, gap=gap, dark=dark,
                            valid=f.valid, au=f.au, outwin=f.outwin, se_measured=np.array(se_ok), gas_measured=np.array(gas_ok), **({'T_seg': T_seg} if T_seg is not None else {}),
                            row_t=rt, shift=shifts[i], **{f'T_{c}': v for c, v in Tm.items()}, **{f'se_{c}': v for c, v in f.se.items()}, **previews)
        write_map_tiff(os.path.join(out_dir, tag + '_liquid_nm.tif'), T, px, 'liquid thickness (nm), ' + ' + '.join(f.ch) + ' fused')
        write_map_tiff(os.path.join(out_dir, tag + '_liquid_sigma_nm.tif'), sT, px, 'statistical error of the liquid thickness (nm): a lower bound (METHODS section 7)')
        if len(Tm) > 1:
            for c, v in Tm.items(): write_map_tiff(os.path.join(out_dir, tag + f'_liquid_{c}_nm.tif'), v, px, f'liquid thickness from {c} alone (nm)')
            write_map_tiff(os.path.join(out_dir, tag + '_chi2.tif'), chi2, px, 'channel disagreement chi2 (1 dof)')
        if se_ok: write_map_tiff(os.path.join(out_dir, tag + '_gas_top_nm.tif'), gas_top, px, f'gas on the top membrane (nm); gap: {gap_src}')
        if gap_canvas is not None: write_map_tiff(os.path.join(out_dir, tag + '_gas_other_nm.tif'), gas_oth, px, 'gas not touching the top membrane (nm)')
        write_map_tiff(os.path.join(out_dir, tag + '_time_s.tif'), np.broadcast_to(rt[:, None], f.shape).astype(np.float32), px, 'acquisition time of each row, s since midnight')
        fov = np.isfinite(T) | f.au
        Tc = to_canvas(np.where(fov, np.nan_to_num(T, nan=np.nanmedian(T)), np.nan), i); gc = to_canvas(np.where(fov, np.nan_to_num(gas_top), np.nan), i)
        goc = to_canvas(np.where(fov, np.nan_to_num(gas_oth), np.nan), i); dc = to_canvas(dark.astype(np.float32), i) > 0.5
        vc = to_canvas(f.valid.astype(np.float32), i) > 0.5; auc = to_canvas(f.au.astype(np.float32), i) > 0.5; tc = to_canvas(np.broadcast_to(rt[:, None], f.shape), i)
        ow = to_canvas(f.outwin.astype(np.float32), i) > 0.5; fovc = np.isfinite(Tc)
        canv.append(dict(T=Tc, gas=gc, gas_other=goc, dark=dc, valid=vc & np.isfinite(Tc), au=auc, t=tc, se=se_ok, label=s.time_str, t_end=s.time_s, frame_s=f.frame_s, outwin=ow))
        if V['write']:
            film = dc & (np.nan_to_num(gc) <= S_['film_threshold_nm']); nomeas = None if se_ok else fovc.copy()
            vol = build_volume(np.nan_to_num(Tc, nan=0), np.nan_to_num(gc), fovc, px, V['dz_nm'], tuple(cfg['cell']['membranes_nm']), film=film, nomeas=nomeas,
                               outwin=ow if ow.any() else None, particles=[(x_, y_, z_, d_, l_) for (x_, y_, z_, d_, l_) in parts], gas_other=np.nan_to_num(goc), T_cap=V['T_cap_nm'])
            write_label_tiff(os.path.join(out_dir, tag + '_labels.tif'), vol, px, V['dz_nm'], 'labels: 0 vacuum 1 membrane 2 liquid 3 gas at top 4 gas not at top 5 film 7 outside window 255 not imaged/measured 10+ particles')
        m = f.valid.copy(); m[:cfg['skip_rows']] = False
        row = dict(frame=i, file=s.frame.name, time_end=s.time_str, kV=s.kv, frame_s=f.frame_s, channels='+'.join(f.ch), se='+'.join(f.se) or '',
                   liquid_nm_p10=float(np.nanpercentile(T[m], 10)), liquid_nm_median=float(np.nanmedian(T[m])), liquid_nm_p90=float(np.nanpercentile(T[m], 90)),
                   liquid_sigma_nm_median=float(np.nanmedian(sT[m])), se_dark_fraction=float(dark[f.valid].mean()) if se_ok else np.nan, gap_source=gap_src,
                   gas_top_median_nm=float(np.nanmedian(gas_top[dark & f.valid])) if gas_ok and (dark & f.valid).any() else np.nan,
                   gas_other_fraction=float((np.nan_to_num(gas_oth) > 0)[f.valid].mean()), drift_dy=float(shifts[i][0]), drift_dx=float(shifts[i][1]), n_particles=len(f.blobs),
                   gas_top_volume_um3=gas_vol, gas_top_volume_sd_um3=gas_sd)
        if se_ok:
            from .analysis import contact_summary
            row.update(contact_summary(se_info)); row['se_signal'] = '+'.join(str(getattr(s.channels.get(c), 'signal', c)) for c in f.se)
            if row.get('se_contact_flag'): log(f'  frame {i}: {row["se_contact_flag"]} - check the SE contact map')
        for c, q in f.ch.items(): row.update({f'{c}_sigma': q['sigma'], f'{c}_clip': q['clip'], f'{c}_B0': f.cal[c].B0, f'{c}_g': f.cal[c].g, f'{c}_median_nm': float(np.nanmedian(Tm[c][m]))})
        if len(Tm) > 1: row['chi2_median'] = float(np.nanmedian(chi2[m]))
        summary.append(row)
        log(f'  frame {i}: liquid {row["liquid_nm_median"]:.0f} nm (+- {row["liquid_sigma_nm_median"]:.0f})' + (f', SE-dark {100*row["se_dark_fraction"]:.0f} %' if se_ok else '') + (f', gas elsewhere {100*row["gas_other_fraction"]:.0f} %' if gap_canvas is not None else ''))
    # ---------------------------------------------------------------- energy-ratio depth from scans at another kV
    if aux and 'energy_ratio' in cfg['depth']['methods'] and prow:
        _energy_ratio(aux, F, prow, cfg, curves, cal, px, kv_main, log)
    # ---------------------------------------------------------------- 7. tables, trajectories, dynamics, 4-D
    check_abort(); prog(0.91, 'tables, tracks and dynamics')
    dose_info = _add_dose(summary, F, cfg, px, kv_main, log)
    sig_used = sorted({r.get('se_signal') for r in summary if r.get('se_signal')})
    if len(sig_used) > 1: log(f'NOTE: the SE contact comes from different detectors in different frames ({", ".join(sig_used)}; column se_signal): '
                              'their contrasts differ - compare contact areas between frames of the same detector')
    pd.DataFrame(summary).to_csv(os.path.join(out_dir, 'summary.csv'), index=False)
    if seg_rows:
        pd.DataFrame(seg_rows).to_csv(os.path.join(out_dir, 'segmentation_classes.csv'), index=False)
        try: SG.overview_figure(seg_fig, os.path.join(out_dir, 'segmentation_overview.png'))
        except Exception as ex_: log(f'  segmentation figure failed: {ex_}')
    PT = pd.DataFrame(prow)
    if len(PT) and cfg['tracking']['enabled']:
        PT = TR.link(PT, cfg['tracking']['max_disp_nm'], cfg['tracking']['max_gap'])
        TR.track_table(PT).to_csv(os.path.join(out_dir, 'tracks.csv'), index=False)
    PT.to_csv(os.path.join(out_dir, 'particles.csv'), index=False)
    if cfg['dynamics']['enabled'] and len(canv) >= 2:
        DY.run(canv, px, out_dir, cfg['name'], log)
    if V.get('write_4d', True) and canv:
        write_stack(os.path.join(out_dir, f'{cfg["name"]}_4D_liquid_nm.tif'), np.stack([c['T'] for c in canv]), px, 'TYX', 'liquid thickness (nm) on the drift-corrected canvas; T = frame')
        write_stack(os.path.join(out_dir, f'{cfg["name"]}_4D_time_s.tif'), np.stack([c['t'] for c in canv]), px, 'TYX', 'acquisition time of each pixel (s since midnight)')
        if any(c['se'] for c in canv): write_stack(os.path.join(out_dir, f'{cfg["name"]}_4D_gas_top_nm.tif'), np.stack([c['gas'] for c in canv]), px, 'TYX', 'gas on the top membrane (nm)')
    info = dict(config=cfg, kV=kv_main, calibration={c: cal[c].to_dict() for c in cal}, reports=reports, drift=shifts.tolist(), canvas=[int(H), int(W), int(ymin), int(xmin)],
                n_frames=len(F), seconds=round(time.time() - t_start, 1), version=__import__('lcsem').__version__, build=__import__('lcsem').build_id(),
                source=cfg.get('source', 'jeol'), mode=cfg.get('mode', ''), tags=tags_all, dose=dose_info,
                calibration_modes={c: cal[c].note.split(':')[0] for c in cal}, warnings=qc_notes)
    with open(os.path.join(out_dir, 'run_info.json'), 'w') as fh: json.dump(info, fh, indent=1, default=str)
    _qc(F, canv, summary, out_dir, cfg)
    if cfg.get('amira', {}).get('enabled'):
        prog(0.95, 'Amira export')
        from .export_amira import export_run
        export_run(out_dir, os.path.join(out_dir, 'amira'), bin=int(cfg['amira'].get('bin', 4)), dz=float(cfg['amira'].get('dz_nm', 10.0)), t_mem=tuple(cfg['cell']['membranes_nm']), log=log)
    prog(1.0, 'done'); log(f'done in {time.time()-t_start:.0f} s -> {out_dir}')
    return summary

# --------------------------------------------------------------------------------------------------------------- pieces
def _add_dose(summary, F, cfg, px, kv, log):
    """electron dose per time point (lcsem.dose) into the summary rows; returns the run-level record"""
    from . import dose as DS
    I = (cfg.get('beam') or {}).get('current_pA')
    fs = [r.get('frame_s', np.nan) for r in summary]; ny, nx = F[0].shape if F else (0, 0)
    idx = [getattr(f.scan.frame, 'movie_index', getattr(f.scan.frame, 'index', None)) for f in F]
    idx = idx if all(v is not None and v >= 0 for v in idx) and cfg.get('source') == 'movie' else None
    def _w(f):                                                        # raw frames averaged into this time point (temporal window)
        c = f.scan.channels.get(f.scan.primary) or next(iter(f.scan.channels.values()))
        sp, fr = float(getattr(c, 'support_s', 0.0) or 0.0), float(getattr(c, 'frame_s', 0.0) or 0.0)
        return max(1, int(round(sp / fr))) if sp > 0 and fr > 0 else 1
    tb = DS.table(fs, idx, I, ny, nx, px, kv, n_raw=[_w(f) for f in F])
    for k, r in enumerate(summary): r.update({key: float(v[k]) for key, v in tb.items()})
    if I: log(f'dose: {tb["dose_frame_e_nm2"][0]:.3g} e/nm2 per frame at {I:g} pA; cumulative at the last time point {tb["dose_cum_e_nm2"][-1]:.3g} e/nm2 '
              f'(~{tb["dose_cum_MGy"][-1]:.3g} MGy in water, first order)')
    else: log('dose: probe current not given (beam.current_pA / Data tab): no dose bookkeeping')
    return dict(current_pA=I, kV=kv, frame_fluence_e_nm2=[float(v) for v in tb['dose_frame_e_nm2']], cumulative_e_nm2=[float(v) for v in tb['dose_cum_e_nm2']],
                note='first order: fluence over the scanned field; absorbed dose in water at the beam energy (lcsem.dose); exposures outside the recorded frames not included')

def _register(F, cfg, log, should_abort=None):
    P = cfg['particles']; n = len(F); shifts = np.zeros((n, 2)); iref = cfg['reference_frame'] % n
    meth = (cfg.get('registration') or {}).get('method', 'auto')
    if meth == 'auto': meth = 'phase' if cfg.get('source') == 'movie' else 'particles'
    if cfg.get('drift_csv'):
        d = pd.read_csv(cfg['drift_csv']).set_index('frame'); shifts = np.array([[d.loc[i, 'dy'], d.loc[i, 'dx']] for i in range(n)])
    elif meth == 'none':
        pass
    elif meth == 'phase':            # movies: sub-pixel phase correlation chained through neighbouring frames (lcsem.io_movie)
        from .io_movie import register_stack, register_movie
        prim = F[0].scan.primary; rg = cfg.get('registration') or {}
        chs = [f.scan.channels[prim] for f in F]; src0 = getattr(chs[0], 'raw_src', None) or getattr(chs[0], 'src', None)
        mi = [getattr(c, 'index', None) for c in chs]
        same = src0 is not None and all((getattr(c, 'raw_src', None) or getattr(c, 'src', None)) is src0 for c in chs) and all(v is not None for v in mi)
        if cfg.get('drift_shifts') is not None:                  # measured on every raw frame before series denoising (build_scans)
            shifts = np.asarray(cfg['drift_shifts'], float); log('drift: from every frame of the movie (measured before series denoising)')
        elif same and len(mi) > 1 and np.any(np.diff(mi) > 1) and not int(rg.get('refine', 0)):
            # a frame step: the drift is measured on every frame in between and subsampled (shorter links, less scene change)
            shifts = register_movie(src0.get, mi, ref=iref, roi=rg.get('roi') or None, should_abort=should_abort)
            log(f'drift: measured on all {max(mi) - min(mi) + 1} movie frames between the first and the last time point')
        else:
            sh = register_stack([f.ch[prim]['raw'] if prim in f.ch else f.scan.channels[prim].load() for f in F], ref=iref, particles=False,
                                roi=rg.get('roi') or None, refine=int(rg.get('refine', 0)))
            shifts = np.asarray(sh, float)   # same convention as the particle voting: the shift that maps frame i onto the reference
    else:
        for i in list(range(iref - 1, -1, -1)) + list(range(iref + 1, n)):
            j = i + 1 if i < iref else i - 1
            res = register_by_particles(F[j].blobs, F[i].blobs, max_shift=cfg.get('max_drift_px', 600))
            if res is None or res[2] < 2:
                prim = F[i].scan.primary; a = F[i].scan.channels[prim].load(); b = F[j].scan.channels[prim].load()
                try:
                    sh = register_translation(b, a, upsample=10); res = (float(sh[0]), float(sh[1]), 0); log(f'  scan {i}: particle registration failed; phase correlation used')
                except Exception: res = None
            if res is None: shifts[i] = shifts[j]; log(f'  scan {i}: registration failed; shift copied'); continue
            shifts[i] = shifts[j] + np.array(res[:2])
    ymin, xmin = np.floor(shifts.min(axis=0)).astype(int); ymax, xmax = np.ceil(shifts.max(axis=0)).astype(int)
    H = F[iref].shape[0] + (ymax - ymin) + 1; W = F[iref].shape[1] + (xmax - xmin) + 1
    log('drift (dy, dx) px: ' + str(np.round(shifts, 1).tolist()))
    return shifts, H, W, ymin, xmin

def _gap_map(frames, F, cal, cfg, shifts, to_canvas, log):
    """local gap h(x, y) from full-cell frames: registered to scan 0 by particles (or phase correlation), calibrated with the
    same detector calibration; returned on the canvas"""
    P = cfg['particles']; maps = []
    for fr in frames:
        img = fr.load(); blobs = detect_particles(img, None, P['sigma_min'], P['sigma_max'], P['threshold'])
        res = register_by_particles(F[0].blobs, blobs, max_shift=cfg.get('max_drift_px', 600))
        if res is None or res[2] < 2:
            try: sh = register_translation(F[0].scan.channels[F[0].scan.primary].load(), img, upsample=10); res = (sh[0], sh[1], 0)
            except Exception: log('  full-cell reference could not be registered; ignored'); continue
        au = particle_mask(img.shape, blobs, 3.0, P['mask_extra_px'])
        sm = smooth_masked(img.astype(np.float32), au, cfg['smooth_sigma_px'])
        h = cal.thickness(sm).astype(np.float32)
        maps.append(to_canvas(shift_image(h, res[0], res[1]), 0))
    if not maps: return None
    g = np.nanmedian(np.stack(maps), axis=0).astype(np.float32); log(f'gap map from {len(maps)} full-cell frame(s): median {np.nanmedian(g):.0f} nm, p10-p90 {np.nanpercentile(g, 10):.0f}-{np.nanpercentile(g, 90):.0f} nm')
    return g

def _energy_ratio(aux, F, prow, cfg, curves, cal, px, kv_main, log):
    """depth from the ratio of a particle's excess at another kV and at the main kV (curves at the other kV from the MC cache)"""
    from .mc.curves import cached_curve
    P = cfg['particles']; dpart = float(cfg['references']['particles']['diameter_nm']); pxa = px[0] * px[1]; cells = cfg['cell']
    for s in aux:
        img = s.channels[s.primary].load(); blobs = detect_particles(img, None, P['sigma_min'], P['sigma_max'], P['threshold'])
        j = int(np.argmin([abs(f.scan.time_s - s.time_s) for f in F])); res = register_by_particles(F[j].blobs, blobs, max_shift=cfg.get('max_drift_px', 600))
        if res is None: log(f'  {s.kv:g} kV scan {s.time_str}: not registered; skipped'); continue
        spec = _detector_spec(cfg['channels'][s.primary])
        d, fn = cached_curve(cfg['mc'].get('cache_dir'), E0=float(s.kv), detectors=(spec,), t_mem=tuple(cells['membranes_nm']), membrane=cells.get('membrane', 'SiN'), liquid=cells.get('liquid', 'H2O'),
                             water=tuple(cfg['mc']['water_nm']), n=int(cfg['mc']['n']), particle=dpart, material=cfg['references']['particles'].get('material', 'Au'),
                             particle_T=(200.0, 500.0), depths=('top', 'f0.25', 'mid', 'f0.75', 'bot'))
        c_low = ChannelCurve(d); m_low = D.ParticleModel(c_low.particle, c_low.detector, px); m_main = D.ParticleModel(curves[s.primary].particle, curves[s.primary].detector, px)
        # the low-kV gain: from the dark reference and the flat field at the same place (thickness known from the main-kV frame)
        flat_low = float(np.median(smooth_masked(img, particle_mask(img.shape, blobs), cfg['smooth_sigma_px'])))
        Tflat = float(np.nanmedian([r['liquid_here_nm'] for r in prow if r['frame'] == j]))
        B0 = cal[s.primary].B0; g_low = (flat_low - B0) / float(c_low.S_of_T(Tflat))
        for r in [r for r in prow if r['frame'] == j]:
            yy, xx = r['y_px'] - res[0], r['x_px'] - res[1]
            m = D.measure(img, yy, xx, px, dpart, sigma_noise=noise_sigma_censored(img))
            if m is None or not np.isfinite(r.get(f'A_{s.primary}', np.nan)): continue
            Q = (m['A'] * pxa / g_low) / r[f'A_{s.primary}']; sQ = abs(Q) * (m.get('sA', 0) / max(abs(m['A']), 1e-9))
            z, sz = D.z_from_ratio(Q, sQ, m_low, m_main, max(r['gap_here_nm'], dpart + 2)); r['z_energy_nm'] = z; r['sz_energy_nm'] = sz
            zc, szc = D.combine([(r['z_nm'], r['sz_nm']), (z, sz)]); r['z_nm'], r['sz_nm'] = zc, szc
        log(f'  energy-ratio depth from the {s.kv:g} kV scan at {s.time_str} (paired with frame {j})')

def _qc(F, canv, summary, out_dir, cfg):
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    pick = list(range(len(F))) if len(F) <= 12 else sorted(set(np.linspace(0, len(F) - 1, 12).round().astype(int).tolist()))   # at most 12 columns
    n = len(pick); fig, axs = plt.subplots(3, n, figsize=(3.2 * n, 8.4), squeeze=False)
    for i, k in enumerate(pick):
        f = F[k]
        raw = f.ch[f.scan.primary]['raw']; axs[0, i].imshow(ndi.gaussian_filter(raw, 1.5), cmap='gray', vmin=np.percentile(raw, 1), vmax=np.percentile(raw, 99.5)); axs[0, i].set_title(f'{f.scan.time_str} {f.scan.primary}', fontsize=9)
        if f.se:
            se = list(f.se.values())[0]; se = np.where(np.isfinite(se), se, np.nanmedian(se)); axs[1, i].imshow(ndi.gaussian_filter(se, 2), cmap='gray', vmin=np.nanpercentile(se, 1), vmax=np.nanpercentile(se, 99))
        else: axs[1, i].text(0.5, 0.5, 'no SE', ha='center', va='center', transform=axs[1, i].transAxes)
        axs[1, i].set_title('SE', fontsize=9)
        T = canv[k]['T']; axs[2, i].imshow(T, cmap='Blues', vmin=0, vmax=max(400, np.nanpercentile(T, 98))); axs[2, i].set_title(f'frame {k}: liquid nm (median {summary[k]["liquid_nm_median"]:.0f})', fontsize=9)
        for a in axs[:, i]: a.set_xticks([]); a.set_yticks([])
    plt.tight_layout(); fig.savefig(os.path.join(out_dir, 'qc_overview.png'), dpi=70); plt.close(fig)
