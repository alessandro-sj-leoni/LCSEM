"""SE-only processing (no BSE / STEM recorded).

Secondary electrons leave the top few nanometres of the top membrane: they carry no liquid-thickness information, but
their contrast marks where gas touches the top membrane (charging-mediated contact) and, in suitable conditions, graded
SE levels. This mode therefore produces, per frame: the denoised SE, the SE contact map (lcsem.analysis.se_contact_map:
shading-corrected, significance-based, with a two-state background for contact over much of the field), multi-Otsu SE
levels (Liao et al. 2001), bubble objects, drift-corrected canvases and a *nominal* 3-D model: a cell of the configured
channel height (cell.channel_nm) with a gas layer of nominal thickness (se_only.gas_nm) under the top membrane where the
SE says gas touches it. The run files have the same layout as `lcsem.pipeline.run` so the GUI, the exports and the object
analysis work unchanged; run_info.json records mode = 'SE only' and thickness = 'nominal (not measured)'.
"""
from __future__ import annotations
import os, json, time, numpy as np, pandas as pd
from .analysis import se_contact_map, contact_summary
from .volume import row_times, write_map_tiff, write_stack
from . import denoise as DN

def run_se_only(cfg, scans, out_dir, progress=None, should_abort=None, log=print):
    os.makedirs(out_dir, exist_ok=True); t0 = time.time(); prog = progress or (lambda *a: None)
    px = tuple(cfg['pixel_nm']); name = cfg.get('name', 'series'); S_ = cfg['se']; so = cfg.get('se_only') or {}
    H_nom = float(cfg['cell'].get('channel_nm') or so.get('channel_nm') or 500.0); g_nom = float(so.get('gas_nm', 50.0))
    dn = cfg.get('denoise') or {}; meth = dn.get('method') or 'nlm'
    ch = next(c for c in scans[0].channels if c.startswith('SE'))
    frames = []
    for i, s in enumerate(scans):
        if should_abort is not None and should_abort():
            from .pipeline import Aborted; raise Aborted('aborted by the user')
        prog(0.02 + 0.4 * i / len(scans), f'denoising SE frame {i + 1}/{len(scans)}')
        a = s.channels[ch].load()
        frames.append(DN.denoise_image(a, meth, vst=bool(dn.get('vst', True)), strength=float(dn.get('strength', 1.0))) if meth in DN.FRAME_METHODS and meth != 'none' else a)
    from .io_movie import register_stack, register_movie
    rg = cfg.get('registration') or {}; iref = cfg['reference_frame'] % len(frames)
    chs = [s.channels[ch] for s in scans]; src0 = getattr(chs[0], 'raw_src', None) or getattr(chs[0], 'src', None); mi = [getattr(c, 'index', None) for c in chs]
    stepped = (cfg.get('source') == 'movie' and src0 is not None and all(v is not None for v in mi) and len(mi) > 1 and np.any(np.diff(mi) > 1)
               and all((getattr(c, 'raw_src', None) or getattr(c, 'src', None)) is src0 for c in chs) and not int(rg.get('refine', 0)))
    if rg.get('method', 'auto') == 'none': sh = np.zeros((len(frames), 2))
    elif cfg.get('drift_shifts') is not None: sh = np.asarray(cfg['drift_shifts'], float)
    elif stepped:     # a frame step: drift measured on every movie frame in between, then subsampled (shorter links)
        sh = register_movie(src0.get, mi, ref=iref, roi=rg.get('roi') or None, should_abort=should_abort)
        log(f'drift: measured on all {max(mi) - min(mi) + 1} movie frames between the first and the last time point')
    else:
        sh = register_stack(frames, ref=iref, particles=False, roi=rg.get('roi') or None, refine=int(rg.get('refine', 0)))
    ymin, xmin = np.floor(sh.min(axis=0)).astype(int); ymax, xmax = np.ceil(sh.max(axis=0)).astype(int)
    ny, nx = frames[0].shape; Hc, Wc = ny + (ymax - ymin) + 1, nx + (xmax - xmin) + 1
    summary, canv, tags_all = [], [], []; ndig = max(2, len(str(len(frames) - 1)))
    for i, (s, se) in enumerate(zip(scans, frames)):
        prog(0.45 + 0.5 * i / len(scans), f'SE contact map {i + 1}/{len(scans)}')
        valid = np.isfinite(se); fs = s.channels[ch].__dict__.get('frame_s') or 1.0
        min_area_se = int(S_['min_area_px']) if S_.get('min_area_px') else int(round(float(S_.get('min_area_um2', 0.01)) * 1e6 / (px[0] * px[1])))
        dark, thr, sm, inf = se_contact_map(se, valid, S_['sigma_px'], min_area_se, S_['open_iter'], min(cfg.get('skip_rows', 0), ny // 4),
                                            k_sigma=float(S_.get('k_sigma', 5.0)), min_contrast=float(S_.get('min_contrast', 0.05)), return_info=True)
        gas = np.where(dark, g_nom, 0.0).astype(np.float32); T = np.where(valid, H_nom - gas, np.nan).astype(np.float32)
        rt = row_times(s.time_s, fs, ny); tag = f'{name}_{i:0{ndig}d}_{s.frame.name}'; tags_all.append(tag)
        try:
            from skimage.filters import threshold_multiotsu
            lev = np.digitize(sm, threshold_multiotsu(sm[valid], classes=int(so.get('levels', 3)))).astype(np.int16)
        except Exception: lev = dark.astype(np.int16)
        np.savez_compressed(os.path.join(out_dir, tag + '_maps.npz'), T=T, sT=np.full(T.shape, np.nan, np.float32), gas_top=gas, gas_other=np.zeros_like(gas),
                            gap=np.full(T.shape, H_nom, np.float32), dark=dark, valid=valid, au=np.zeros(T.shape, bool), outwin=np.zeros(T.shape, bool),
                            row_t=rt, shift=sh[i], se_SE=se.astype(np.float32), se_levels=lev, se_measured=np.array(True), nominal=np.array(True),
                            prev_SE=se[:ny // 2 * 2, :nx // 2 * 2].reshape(ny // 2, 2, nx // 2, 2).mean(axis=(1, 3)).astype(np.float16))
        write_map_tiff(os.path.join(out_dir, tag + '_se_denoised.tif'), se, px, f'SE denoised ({DN.describe(meth)})')
        write_map_tiff(os.path.join(out_dir, tag + '_se_contact.tif'), dark.astype(np.float32), px, 'SE contact map: 1 = gas touches the top membrane')
        summary.append(dict(frame=i, file=s.frame.name, time_end=s.time_str, kV=s.kv, frame_s=fs, channels='', se=ch, liquid_nm_p10=np.nan,
                            liquid_nm_median=float(np.nanmedian(T)), liquid_nm_p90=np.nan, liquid_sigma_nm_median=np.nan, se_dark_fraction=float(dark[valid].mean()),
                            se_threshold=thr, thickness='nominal (SE only)', se_signal=str(getattr(s.channels[ch], 'signal', ch)), **contact_summary({ch: inf})))
        if summary[-1].get('se_contact_flag'): log(f'  frame {i}: {summary[-1]["se_contact_flag"]} - check the SE contact map')
        dy, dx = sh[i]; iy, ix = int(np.floor(dy)) - ymin, int(np.floor(dx)) - xmin
        c_ = np.full((Hc, Wc), np.nan, np.float32); c_[iy:iy + ny, ix:ix + nx] = dark.astype(np.float32); canv.append(c_)
    from . import dose as DS
    I = (cfg.get('beam') or {}).get('current_pA'); idx = [getattr(s.frame, 'movie_index', getattr(s.frame, 'index', None)) for s in scans]
    nraw = [max(1, int(round(float(getattr(s.channels[ch], 'support_s', 0) or 0) / float(getattr(s.channels[ch], 'frame_s', 0) or 1)))) if getattr(s.channels[ch], 'support_s', 0) else 1 for s in scans]
    tb = DS.table([r['frame_s'] for r in summary], idx if all(v is not None and v >= 0 for v in idx) and cfg.get('source') == 'movie' else None, I, ny, nx, px, scans[0].kv or 15.0, n_raw=nraw)
    for k, r in enumerate(summary): r.update({key: float(v[k]) for key, v in tb.items()})
    dose_info = dict(current_pA=I, frame_fluence_e_nm2=[float(v) for v in tb['dose_frame_e_nm2']], cumulative_e_nm2=[float(v) for v in tb['dose_cum_e_nm2']])
    pd.DataFrame(summary).to_csv(os.path.join(out_dir, 'summary.csv'), index=False)
    pd.DataFrame(columns=['frame', 'time', 't_s', 'x_nm', 'y_nm', 'z_nm']).to_csv(os.path.join(out_dir, 'particles.csv'), index=False)
    write_stack(os.path.join(out_dir, f'{name}_4D_se_contact.tif'), np.stack(canv), px, 'TYX', 'SE contact map on the drift-corrected canvas')
    info = dict(config=cfg, kV=scans[0].kv, calibration={}, reports={}, drift=sh.tolist(), canvas=[int(Hc), int(Wc), int(ymin), int(xmin)], n_frames=len(frames),
                seconds=round(time.time() - t0, 1), version=__import__('lcsem').__version__, build=__import__('lcsem').build_id(), source=cfg.get('source', 'movie'), mode='SE only',
                thickness='nominal (not measured): channel height with a nominal gas layer where the SE shows contact', tags=tags_all, dose=dose_info)
    with open(os.path.join(out_dir, 'run_info.json'), 'w') as fh: json.dump(info, fh, indent=1, default=str)
    prog(1.0, 'done'); log(f'SE-only run: {len(frames)} frames in {time.time() - t0:.0f} s -> {out_dir}')
    return summary
