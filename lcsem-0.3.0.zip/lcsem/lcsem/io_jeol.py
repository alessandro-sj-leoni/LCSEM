"""Reading JEOL SEM image pairs (TIFF + sidecar .txt metadata) and grouping them into time series.

Every JEOL image `NAME.tif` comes with `NAME.txt` containing lines such as
    $CM_TIME 10:25:55
    $CM_MAG 12000
    $CM_SIGNAL BED_C            (BED_C = annular BSE detector; UED / LED = upper / lower SE detectors)
    $CM_STAGE_POS 1.631 -7.221 7.299 0.004 0.000 0.000
    $$SM_PROBE_NO 10
    $CM_ACCEL_VOLT 15.00
The functions here parse these, and pair each BSE frame with the SE frame recorded within a few seconds of it.
For other microscopes, write a `FrameSet` by hand (see the class docstring) - nothing else in the package depends on JEOL.
"""
from __future__ import annotations
import re, glob, os, dataclasses
import numpy as np, tifffile

@dataclasses.dataclass
class Frame:
    """one recorded image"""
    path: str
    time_s: float            # seconds since midnight (CM_TIME)
    signal: str              # 'BED_C', 'UED', 'LED', ...
    mag: float
    stage: tuple             # stage position
    probe: str = ''
    kv: float = 0.0
    name: str = ''
    def load(self) -> np.ndarray:
        return tifffile.imread(self.path).astype(np.float32)

@dataclasses.dataclass
class FramePair:
    """a BSE frame and the SE frame from the same scan (or None)"""
    bse: Frame
    se: Frame | None
    index: int = 0
    @property
    def time_s(self): return self.bse.time_s
    @property
    def time_str(self): return hms(self.bse.time_s)

def hms_to_s(t: str) -> float:
    h, m, s = [float(v) for v in t.split(':')]; return h * 3600 + m * 60 + s

def hms(sec: float) -> str:
    h = int(sec // 3600); m = int((sec % 3600) // 60); s = sec % 60; return f'{h:02d}:{m:02d}:{s:04.1f}'

def read_meta(txt_path: str) -> dict:
    d = {}
    for line in open(txt_path, errors='ignore'):
        m = re.match(r'\$+(\S+)\s*(.*)', line.strip())
        if m: d[m.group(1)] = m.group(2).strip()
    return d

def scan_folder(folder: str, prefix: str = '') -> list[Frame]:
    """all JEOL images in a folder (optionally only files whose name starts with `prefix`, e.g. the date), sorted by time"""
    out = []
    for txt in sorted(glob.glob(os.path.join(folder, prefix + '*.txt'))):
        tif = txt[:-4] + '.tif'
        if not os.path.exists(tif): continue
        m = read_meta(txt)
        if 'CM_TIME' not in m: continue
        st = tuple(float(v) for v in m.get('CM_STAGE_POS', '0 0 0').split()[:3])
        out.append(Frame(path=tif, time_s=hms_to_s(m['CM_TIME']), signal=m.get('CM_SIGNAL', '?'), mag=float(m.get('CM_MAG', 0)), stage=st,
                         probe=m.get('SM_PROBE_NO', ''), kv=float(m.get('CM_ACCEL_VOLT', 0)), name=os.path.basename(tif)[:-4]))
    return sorted(out, key=lambda f: f.time_s)

def group_series(frames: list[Frame], bse_signal='BED_C', se_signals=('UED', 'LED'), pair_window_s=10.0, stage_tol=0.01):
    """split the frames into series of the same stage position and magnification; pair BSE with the nearest SE frame.
    Returns a dict {(stage_xy, mag): [FramePair, ...]}."""
    series = {}
    bse = [f for f in frames if f.signal == bse_signal]
    se = [f for f in frames if f.signal in se_signals]
    for b in bse:
        key = (round(b.stage[0] / stage_tol) * stage_tol, round(b.stage[1] / stage_tol) * stage_tol, b.mag)
        cands = [s for s in se if abs(s.time_s - b.time_s) <= pair_window_s and s.mag == b.mag]
        # prefer the first listed SE signal, then the closest in time
        cands.sort(key=lambda s: (se_signals.index(s.signal), abs(s.time_s - b.time_s)))
        series.setdefault(key, []).append(FramePair(bse=b, se=cands[0] if cands else None))
    for k, lst in series.items():
        lst.sort(key=lambda p: p.time_s)
        for i, p in enumerate(lst): p.index = i
    return series

def describe(series: dict) -> str:
    lines = []
    for (x, y, mag), lst in sorted(series.items(), key=lambda kv: kv[1][0].time_s):
        lines.append(f'stage ({x:.3f}, {y:.3f})  mag {mag:.0f}x  {len(lst)} BSE frames  {hms(lst[0].time_s)} - {hms(lst[-1].time_s)}  SE paired: {sum(p.se is not None for p in lst)}')
    return '\n'.join(lines)

# ----------------------------------------------------------------------------------------------------------- v0.2: scans
@dataclasses.dataclass
class Scan:
    """all detector images recorded in one scan (or within `pair_window_s` of each other): {channel name: Frame}"""
    channels: dict
    primary: str
    index: int = 0
    @property
    def frame(self): return self.channels[self.primary]
    @property
    def time_s(self): return self.frame.time_s
    @property
    def time_str(self): return hms(self.frame.time_s)
    @property
    def kv(self): return self.frame.kv
    @property
    def mag(self): return self.frame.mag
    @property
    def tilt(self): return self.frame.stage[3] if len(self.frame.stage) > 3 else 0.0
    def has(self, ch): return ch in self.channels and self.channels[ch] is not None

def _signals(ch):
    s = ch.get('signal'); return s if isinstance(s, list) else [s]

def scan_folder_all(folder, prefix=''):
    """like scan_folder but keeps the full stage vector (x, y, z, tilt, rotation)"""
    out = []
    for txt in sorted(glob.glob(os.path.join(folder, prefix + '*.txt'))):
        tif = txt[:-4] + '.tif'
        if not os.path.exists(tif): continue
        m = read_meta(txt)
        if 'CM_TIME' not in m: continue
        st = tuple(float(v) for v in m.get('CM_STAGE_POS', '0 0 0 0 0').split())
        out.append(Frame(path=tif, time_s=hms_to_s(m['CM_TIME']), signal=m.get('CM_SIGNAL', '?'), mag=float(m.get('CM_MAG', 0)), stage=st,
                         probe=m.get('SM_PROBE_NO', ''), kv=float(m.get('CM_ACCEL_VOLT', 0)), name=os.path.basename(tif)[:-4]))
    return sorted(out, key=lambda f: f.time_s)

def group_scans(frames, channels: dict, pair_window_s=10.0, stage_tol=0.01, exclude=()):
    """Scans: each frame of the primary thickness channel (BSE if configured, else STEM; SE for SE-only series) with the frames
    of the other channels recorded within pair_window_s at the same magnification and kV (the first listed signal preferred,
    then the closest in time; the detector used is recorded per scan in the run's summary.csv, column se_signal). The
    primary channel uses one detector only: the first of its listed signals present in the folder.
    Returns {(x, y, mag): [Scan, ...]}."""
    key_ = lambda p: os.path.normcase(os.path.splitext(os.path.abspath(p))[0])          # references given with or without .tif
    ex = set(key_(p) for p in exclude)
    frames = [f for f in frames if key_(f.path) not in ex]
    order = [k for k in ('BSE', 'STEM') if channels.get(k)] + [k for k, v in channels.items() if v and k not in ('BSE', 'STEM')]
    if not order: raise ValueError('no channel configured')
    prim = next((k for k in order if channels[k].get('role') == 'thickness'), order[0])      # SE-only series: SE is primary
    sig_of = {k: _signals(channels[k]) for k in order}
    # the primary channel is ONE detector: the first listed signal present (an SE-only series with in-lens and E-T images
    # would otherwise alternate between the two detectors from one time point to the next)
    present = [sg for sg in sig_of[prim] if any(f.signal == sg for f in frames)]
    prim_sig = present[:1]
    series = {}
    for f in frames:
        if f.signal not in prim_sig: continue
        chans = {prim: f}
        for k in order:
            if k == prim: continue
            c = [g for g in frames if g.signal in sig_of[k] and abs(g.time_s - f.time_s) <= pair_window_s and g.mag == f.mag and abs(g.kv - f.kv) < 0.05]
            if c:
                c.sort(key=lambda g: (sig_of[k].index(g.signal), abs(g.time_s - f.time_s))); chans[k] = c[0]
        key = (round(f.stage[0] / stage_tol) * stage_tol, round(f.stage[1] / stage_tol) * stage_tol, f.mag)
        series.setdefault(key, []).append(Scan(channels=chans, primary=prim))
    for lst in series.values():
        lst.sort(key=lambda s: s.time_s)
        for i, s in enumerate(lst): s.index = i
    return series

def describe_scans(series):
    lines = []
    for (x, y, mag), lst in sorted(series.items(), key=lambda kv: kv[1][0].time_s):
        chans = sorted({c for s in lst for c in s.channels}); kvs = sorted({s.kv for s in lst})
        lines.append(f'stage ({x:.3f}, {y:.3f})  mag {mag:.0f}x  {len(lst)} scans  {hms(lst[0].time_s)} - {hms(lst[-1].time_s)}  kV {kvs}  channels {chans}')
    return '\n'.join(lines)
