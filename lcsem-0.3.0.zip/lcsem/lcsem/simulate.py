"""Synthetic K-kit data sets with known ground truth, written exactly like JEOL data (NAME.tif + NAME.txt), for testing
the pipeline and for planning experiments.

Scene (per frame): a window whose membranes bulge (local gap h(x, y)), gas pockets that grow and move (touching the top
membrane, the bottom membrane, or both), Au particles at known (x, y, z) that diffuse in 3-D, stage drift.
Image formation per detector: grey = B0 + g * S_det(T_liquid) + particle excess (Monte Carlo radial profile of that
particle at its depth and local thickness, rendered at the pixel size) + Gaussian detector noise, 8-bit clipping.
SE: bright where liquid touches the top membrane, dark where gas does, with noise.
References: dark (beam blanked), empty cell (T = 0) and full cell (T = h) frames with the same detector settings.
The laterally-uniform S(T) approximation is used for the liquid; the finite-size effects of small gas pockets
(see docs/VALIDATION.md) are therefore not in these data - they test the pipeline, not the physics model.
"""
from __future__ import annotations
import os, json, numpy as np, tifffile
from .calib import ChannelCurve
from .mc.radial import render

BITS = 8
def _write_jeol(folder, name, img, t_s, signal, mag, kv, stage=(0.0, 0.0, 0.0, 0.0, 0.0)):
    hi = 2 ** BITS - 1
    tifffile.imwrite(os.path.join(folder, name + '.tif'), np.clip(np.rint(img), 0, hi).astype(np.uint8 if BITS == 8 else np.uint16))
    h = int(t_s // 3600); m = int((t_s % 3600) // 60); s = t_s % 60
    with open(os.path.join(folder, name + '.txt'), 'w') as f:
        f.write(f'$CM_TIME {h:02d}:{m:02d}:{s:02.0f}\n$CM_MAG {mag:.0f}\n$CM_SIGNAL {signal}\n$CM_ACCEL_VOLT {kv:.2f}\n$CM_STAGE_POS {" ".join(f"{v:.3f}" for v in stage)}\n$$SM_PROBE_NO 10\n')

def _profile_at(rows, T, u, det):
    """radial excess profile at liquid thickness T and normalized depth u = (z - R) / (T - 2R), interpolating linearly between
    the Monte Carlo depths of one thickness and then between the two nearest thicknesses (as lcsem.depth.ParticleModel does)"""
    Ts = sorted({r['T_nm'] for r in rows}); T = float(np.clip(T, Ts[0], Ts[-1])); i = int(np.clip(np.searchsorted(Ts, T), 1, len(Ts) - 1))
    Ta, Tb = Ts[i - 1], Ts[i]; w = 0.0 if Tb == Ta else (T - Ta) / (Tb - Ta)
    def at(Tn):
        rr = sorted([r for r in rows if r['T_nm'] == Tn], key=lambda r: r['z_center_nm']); R = None
        zs = np.array([r['z_center_nm'] for r in rr]); R_ = zs[0] - 0.5; uz = (zs - R_) / max(Tn - 2 * R_, 1.0)
        j = int(np.clip(np.searchsorted(uz, u) - 1, 0, len(rr) - 2)); ww = float(np.clip((u - uz[j]) / max(uz[j + 1] - uz[j], 1e-9), 0, 1))
        return np.asarray(rr[j]['edges']), (1 - ww) * np.asarray(rr[j]['det'][det]['prof']) + ww * np.asarray(rr[j + 1]['det'][det]['prof'])
    ea, pa = at(Ta); eb, pb = at(Tb)
    if len(ea) != len(eb) or not np.allclose(ea, eb): return (ea, pa) if w < 0.5 else (eb, pb)
    return ea, (1 - w) * pa + w * pb

def particle_image(curve: ChannelCurve, T_local, z, shape, y, x, px):
    """excess image (signal per primary) of one particle of the curve's standard at centre depth z (nm below the liquid surface)"""
    rows = curve.particle['profiles']; d = curve.particle['diameter_nm']; R = d / 2
    u = float(np.clip((z - R) / max(T_local - 2 * R, 1.0), 0, 1))
    e, prof = _profile_at(rows, T_local, u, curve.detector); rc = 0.5 * (e[1:] + e[:-1])
    half = min(2.3 * (R + 60) + 16, e[-1]); img = render(rc, prof, px, half, center=((x - int(x) + 0.5) * px[0], (y - int(y) + 0.5) * px[1]), ss=3)
    out = np.zeros(shape, np.float32); hy, hx = img.shape[0] // 2, img.shape[1] // 2; iy, ix = int(y), int(x)
    y0, y1, x0, x1 = iy - hy, iy - hy + img.shape[0], ix - hx, ix - hx + img.shape[1]
    sy0, sx0 = max(0, -y0), max(0, -x0); y0c, x0c = max(0, y0), max(0, x0); y1c, x1c = min(shape[0], y1), min(shape[1], x1)
    if y1c > y0c and x1c > x0c: out[y0c:y1c, x0c:x1c] = img[sy0:sy0 + (y1c - y0c), sx0:sx0 + (x1c - x0c)]
    return out

def scene(n_frames=8, shape=(480, 640), px=(8.0, 8.0), channel_nm=500.0, bulge_nm=300.0, n_particles=20, d_nm=60.0, seed=0, pockets=None,
          drift_per_frame=(4.0, -6.0), step_px=3.0, step_u=0.05, growth=1.0, jitter_px=0.5):
    """ground truth per frame: h (gap), gas_top, gas_bot (nm), particles (x_px, y_px, z_nm), drift (dy, dx px).
    growth scales how much the gas pockets grow or shrink over the series (0 = static pockets); jitter_px is the random part
    of the drift (0 with an integer drift_per_frame gives integer shifts, so registration needs no interpolation)."""
    rng = np.random.default_rng(seed); ny, nx = shape; Y, X = np.mgrid[0:ny, 0:nx]
    # membranes bulge across the (short) window width: parabolic profile in y, plus a gentle x trend
    yy = (Y - ny / 2) / (ny / 2); h = channel_nm + bulge_nm * (1 - yy ** 2) + 30 * (X / nx - 0.5)
    pockets = pockets or [dict(cx=0.30, cy=0.45, r0=40, r1=95, height=0.9, where='top'),          # grows, touches the top membrane
                          dict(cx=0.72, cy=0.55, r0=30, r1=70, height=0.45, where='bot'),         # gas on the bottom membrane
                          dict(cx=0.55, cy=0.20, r0=55, r1=20, height=0.6, where='top')]         # shrinks
    parts = [dict(x=rng.uniform(40, nx - 40), y=rng.uniform(40, ny - 40), u=rng.uniform(0, 1)) for _ in range(n_particles)]
    frames = []
    for k in range(n_frames):
        tfrac = k / max(n_frames - 1, 1); gt = np.zeros(shape, np.float32); gb = np.zeros(shape, np.float32)
        for p in pockets:
            r = p['r0'] + (p['r1'] - p['r0']) * tfrac * growth; m = (X - p['cx'] * nx) ** 2 + (Y - p['cy'] * ny) ** 2 < r * r
            (gt if p['where'] == 'top' else gb)[m] = (p['height'] * h)[m]
        T = np.clip(h - gt - gb, 0, None)
        P = []
        for q in parts:
            q['x'] += rng.normal(0, step_px); q['y'] += rng.normal(0, step_px); q['u'] = float(np.clip(q['u'] + rng.normal(0, step_u), 0, 1))
            yi, xi = int(np.clip(q['y'], 0, ny - 1)), int(np.clip(q['x'], 0, nx - 1)); Tl = float(T[yi, xi]); R = d_nm / 2
            g_ = float(gt[yi, xi]); z = R + q['u'] * max(Tl - 2 * R, 0) + g_          # below a top gas layer the particle sits lower
            P.append((q['x'], q['y'], z, Tl, g_))
        drift = (k * drift_per_frame[0] + rng.normal(0, jitter_px), k * drift_per_frame[1] + rng.normal(0, jitter_px))
        frames.append(dict(h=h.astype(np.float32), gas_top=gt, gas_bot=gb, T=T.astype(np.float32), particles=P, drift=drift))
    return frames

def make_dataset(folder, curves: dict, n_frames=8, shape=(480, 640), px=(8.0, 8.0), mag=12000, kv=15.0, t0_s=36000.0, frame_s=3.2, dt_s=40.0,
                 channel_nm=500.0, bulge_nm=300.0, n_particles=20, seed=0,
                 detectors=None, references=('dark', 'empty', 'full'), n_ref=2, se=True, true_curves=None, bits=8):
    """curves: {'BSE': ChannelCurve, 'STEM': ChannelCurve} used for the images (true_curves overrides them to simulate a
    detector-model error). Returns the path of the ground-truth file."""
    global BITS; BITS = bits
    os.makedirs(folder, exist_ok=True); rng = np.random.default_rng(seed + 1)
    det = dict(BSE=dict(B0=30.0, g=600.0, sigma=35.0, signal='BED_C'), STEM=dict(B0=15.0, g=220.0, sigma=12.0, signal='STEM'),
               SE=dict(wet=150.0, dry=70.0, sigma=25.0, signal='UED'))
    for k, v in (detectors or {}).items(): det[k].update(v)
    img_curves = true_curves or curves
    d_nm = curves[list(curves)[0]].particle['diameter_nm'] if curves[list(curves)[0]].particle else 60.0
    S = scene(n_frames, shape, px, channel_nm, bulge_nm, n_particles, d_nm, seed)
    names = []; t = t0_s
    def shifted(a, dy, dx):
        from scipy.ndimage import shift as sh
        return sh(a, (-dy, -dx), order=1, mode='nearest')
    def form(c, T, parts, drift):
        C = img_curves[c]; g = det[c]['g']; img = shifted(det[c]['B0'] + g * C.S_of_T(T), *drift)     # smooth fields: interpolated shift
        for (x, y, z, Tl, g_) in parts:        # particles rendered directly at their drifted position (no interpolation blur);
            if C.particle is not None:          # the beam only broadens in the liquid above the particle: depth below the liquid surface
                img = img + g * particle_image(C, Tl, z - g_, T.shape, y - drift[0], x - drift[1], px)
        return img + rng.normal(0, det[c]['sigma'], img.shape)
    # references first
    if 'dark' in references:
        for j in range(n_ref):
            for c in curves: nm = f'dark_{c}_{j}'; _write_jeol(folder, nm, det[c]['B0'] + rng.normal(0, det[c]['sigma'], shape), t, det[c]['signal'], mag, kv); t += 2
    if 'empty' in references:
        for j in range(n_ref):
            for c in curves: nm = f'empty_{c}_{j}'; _write_jeol(folder, nm, det[c]['B0'] + det[c]['g'] * img_curves[c].S_of_T(np.zeros(shape)) + rng.normal(0, det[c]['sigma'], shape), t, det[c]['signal'], mag, kv); t += 2
    if 'full' in references:
        for j in range(n_ref):
            h = S[0]['h']; parts0 = list(S[0]['particles'])
            for c in curves: nm = f'full_{c}_{j}'; _write_jeol(folder, nm, form(c, h, parts0, S[0]['drift']), t, det[c]['signal'], mag, kv)
            t += 2
    t += 60; truth = dict(px=px, frames=[], detectors=det, curves={c: curves[c].meta.get('description', '') for c in curves})
    for k, fr in enumerate(S):
        t += dt_s; base = f'2026090{1}{int(t // 3600):02d}{int((t % 3600) // 60):02d}{int(t % 60):02d}'
        for c in curves:
            _write_jeol(folder, f'{base}_{c}', form(c, fr['T'], fr['particles'], fr['drift']), t, det[c]['signal'], mag, kv)
        if se:
            s_img = np.where(fr['gas_top'] > 0, det['SE']['dry'], det['SE']['wet']).astype(np.float32)
            _write_jeol(folder, f'{base}_SE', shifted(s_img, *fr['drift']) + rng.normal(0, det['SE']['sigma'], shape), t, det['SE']['signal'], mag, kv)
        truth['frames'].append(dict(time_s=t, drift=fr['drift'], particles=[dict(x_px=x, y_px=y, z_nm=z, T_nm=Tl, gas_top_nm=g_) for (x, y, z, Tl, g_) in fr['particles']]))
        np.savez_compressed(os.path.join(folder, f'truth_{k:02d}.npz'), h=fr['h'], T=fr['T'], gas_top=fr['gas_top'], gas_bot=fr['gas_bot'])
    json.dump(truth, open(os.path.join(folder, 'truth.json'), 'w'), indent=1, default=float)
    return os.path.join(folder, 'truth.json')

def config_for(folder, px, channels=('BSE', 'STEM', 'SE'), references=('dark', 'empty', 'full'), name='synthetic', mode='auto', curves=None, n_ref=2, depth=('core_fraction',), d_nm=60.0, extra=None, bits=8):
    """an lcsem configuration for a synthetic data set with a chosen subset of channels and references"""
    ch = {}
    if 'BSE' in channels: ch['BSE'] = dict(signal='BED_C', role='thickness', detector='BEDC')
    else: ch['BSE'] = None
    ch['STEM'] = dict(signal='STEM', role='thickness', detector=dict(kind='stem', mrad=[0, 100])) if 'STEM' in channels else None
    ch['SE'] = dict(signal=['UED'], role='contact') if 'SE' in channels else None
    refs = {}
    for r in ('dark', 'empty', 'full'):
        refs[r] = dict(files=[f'{r}_{c}_{j}' for c in ('BSE', 'STEM') if c in channels for j in range(n_ref)]) if r in references else None
    refs['flat'] = dict(frames='all', T_nm=None) if 'flat' not in references else dict(frames='all', T_nm=references['flat'] if isinstance(references, dict) else 500.0)
    refs['particles'] = dict(diameter_nm=d_nm, material='Au') if 'particles' in references else dict(diameter_nm=d_nm, material='Au')
    cfg = dict(name=name, folder=folder, prefix='2026', pixel_nm=list(px), bits=bits, channels=ch, references=refs, calibration=dict(mode=mode),
               particles=dict(sigma_min=1.5, sigma_max=5.0, threshold=5.0, aperture_px=12, annulus_px=[16, 28], mask_extra_px=6),
               smooth_sigma_px=6, skip_rows=0, depth=dict(methods=list(depth)), se=dict(sigma_px=3, min_area_px=200, open_iter=1), frame_time=dict(fast_s=3.2, slow_s=3.2, sigma_split=1e9),
               curves=curves or {}, gas=dict(other_threshold_nm=40.0))
    if 'particles' not in references: cfg['calibration']['use_particles'] = False
    if extra: cfg.update(extra)
    return cfg


def make_movie(folder, curves: dict, n_frames=60, shape=(360, 480), px=(8.0, 8.0), frame_s=0.5, t0_s=36000.0, dose_e_px=200.0,
               channels=('SE', 'BSE'), channel_nm=500.0, bulge_nm=300.0, n_particles=12, seed=0, bits=8, mp4=True, read_sigma=4.0,
               drift_per_frame=(0.3, -0.45), step_px=1.0, step_u=0.02, growth=1.0, jitter_px=0.5, references=True, n_ref=5):
    """A synthetic SE + BSE (+ STEM) movie with ground truth, as tomorrow's real movies will come: one multi-frame TIFF per
    detector (movie_SE.tif, movie_BSE.tif, movie_STEM.tif), optionally an MP4 with SE | BSE side by side (lossy, 8-bit),
    and truth_movie.npz (liquid thickness, gas at the top per frame; particles in truth_movie.json).
    Noise is Poisson-Gaussian: grey = B0 + (g / dose) Poisson(dose S) + N(0, read_sigma^2), so var = (g / dose)(grey - B0) +
    read_sigma^2; values clipped to the bit depth. dose_e_px sets the noise level (Poisson quanta per pixel per unit of
    signal S); it is NOT the incident electron dose (the detected signal per primary differs between detectors and the
    single-electron response is not modelled). Not modelled either: charging and SE drift, beam effects (radiolysis,
    bubble nucleation, particle motion caused by the beam), row-by-row acquisition within a frame, detector bandwidth
    (noise correlated along the scan), drift of B0 and g, scan distortions, membrane deflection changing with pressure.
    drift_per_frame (px), step_px (particle random-walk step, px) and step_u (gas growth per frame) set how the scene changes;
    step_px = step_u = growth = 0 gives a static scene that only drifts.
    references: also write reference movies of n_ref frames per detector, as they would be recorded before the movie with the
    same settings: ref_dark_<c>.tif (beam blanked: black level and read noise), ref_empty_<c>.tif (an empty, dry cell: T = 0;
    thickness channels only) and ref_full_<c>.tif (this cell filled before any gas: the local gap at the drift of frame 0;
    thickness channels only; no particles)."""
    import imageio.v2 as iio
    os.makedirs(folder, exist_ok=True); rng = np.random.default_rng(seed + 7); hi = 2 ** bits - 1
    det = dict(BSE=dict(B0=30.0, g=600.0), STEM=dict(B0=15.0, g=220.0), SE=dict(wet=150.0, dry=70.0, B0=10.0))
    d_nm = curves[list(curves)[0]].particle['diameter_nm'] if curves[list(curves)[0]].particle else 60.0
    S = scene(n_frames, shape, px, channel_nm, bulge_nm, n_particles, d_nm, seed, drift_per_frame=drift_per_frame, step_px=step_px, step_u=step_u,
              growth=growth, jitter_px=jitter_px)
    def shifted(a, dy, dx):
        from scipy.ndimage import shift as sh
        return sh(a, (-dy, -dx), order=1, mode='nearest')
    def noisy(mean, B0, g):
        # Poisson counts of dose_e_px quanta per unit of signal S = (mean - B0) / g, scaled back to grey, plus read noise
        lam = np.clip(dose_e_px * (mean - B0) / g, 0, None)
        return np.clip(np.rint(B0 + g / dose_e_px * rng.poisson(lam) + rng.normal(0, read_sigma, mean.shape)), 0, hi)
    stacks = {c: [] for c in channels}; clean = {c: [] for c in channels}; truth = dict(px=px, frame_s=frame_s, t0_s=t0_s, dose_e_px=dose_e_px, frames=[])
    for k, fr in enumerate(S):
        for c in channels:
            if c == 'SE':
                m = shifted(np.where(fr['gas_top'] > 0, det['SE']['dry'], det['SE']['wet']).astype(np.float32), *fr['drift'])
                clean[c].append(m.astype(np.float32)); stacks[c].append(noisy(m, det['SE']['B0'], 40.0)); continue
            C = curves[c]; g = det[c]['g']; img = shifted(det[c]['B0'] + g * C.S_of_T(fr['T']), *fr['drift'])
            for (x, y, z, Tl, g_) in fr['particles']:
                if C.particle is not None: img = img + g * particle_image(C, Tl, z - g_, fr['T'].shape, y - fr['drift'][0], x - fr['drift'][1], px)
            clean[c].append(img.astype(np.float32)); stacks[c].append(noisy(img, det[c]['B0'], g))
        truth['frames'].append(dict(time_s=t0_s + (k + 1) * frame_s, drift=fr['drift'],
                                    particles=[dict(x_px=x, y_px=y, z_nm=z, T_nm=Tl, gas_top_nm=g_) for (x, y, z, Tl, g_) in fr['particles']]))
    dt = np.uint8 if bits == 8 else np.uint16
    for c in channels:
        tifffile.imwrite(os.path.join(folder, f'movie_{c}.tif'), np.stack(stacks[c]).astype(dt), imagej=True,
                         resolution=(1 / px[0], 1 / px[1]), metadata={'axes': 'TYX', 'finterval': frame_s, 'unit': 'nm'})
    if references:
        wr = lambda nm, fr: tifffile.imwrite(os.path.join(folder, nm), np.stack(fr).astype(dt), imagej=True, resolution=(1 / px[0], 1 / px[1]),
                                             metadata={'axes': 'TYX', 'finterval': frame_s, 'unit': 'nm'})
        for c in channels:
            B0 = det[c]['B0']
            wr(f'ref_dark_{c}.tif', [noisy(np.full(shape, B0, np.float32), B0, 1.0) for _ in range(n_ref)])
            if c == 'SE': continue
            C = curves[c]; g = det[c]['g']
            wr(f'ref_empty_{c}.tif', [noisy(np.full(shape, B0 + g * float(C.S_of_T(0.0)), np.float32), B0, g) for _ in range(n_ref)])
            full = shifted(B0 + g * C.S_of_T(S[0]['h']), *S[0]['drift']).astype(np.float32)
            wr(f'ref_full_{c}.tif', [noisy(full, B0, g) for _ in range(n_ref)])
    if mp4 and 'SE' in channels and 'BSE' in channels:
        w = iio.get_writer(os.path.join(folder, 'movie_SE_BSE_side_by_side.mp4'), fps=1.0 / frame_s, codec='libx264', quality=8, macro_block_size=2)   # no rescaling
        for a, b in zip(stacks['SE'], stacks['BSE']): w.append_data(np.concatenate([a, b], axis=1).astype(np.uint8))
        w.close()
    np.savez_compressed(os.path.join(folder, 'truth_movie.npz'), T=np.stack([f['T'] for f in S]).astype(np.float16), gas_top=np.stack([f['gas_top'] for f in S]).astype(np.float16),
                        h=S[0]['h'].astype(np.float32), drift=np.array([f['drift'] for f in S]), **{f'clean_{c}': np.stack(clean[c]).astype(np.float32) for c in channels})
    json.dump(truth, open(os.path.join(folder, 'truth_movie.json'), 'w'), indent=1, default=float)
    return folder
