"""Monte Carlo sub-package: `engine` (numba single-scattering MC) and `curves` (BSE-vs-thickness and particle calibration curves)."""
