"""Detector models: the signal each detector records from one primary electron, computed from its exit state
(columns of engine output: flag, E, ux, uy, uz, x, y, hit, zmax).

BSE detectors
  BEDC         annular solid-state BSE detector under the pole piece (JEOL BED-C): BSE leaving the top surface 15-65 deg from
               the normal, signal proportional to the energy deposited above a ~2 keV dead layer (E - 2 keV).
  BSE_axial    BSE travelling up the column (0-15 deg): what a through-the-lens (in-lens) detector records in BSE mode.
  BSE_grazing  BSE leaving at 65-88 deg from the normal (low take-off): the direct-BSE part of an Everhart-Thornley (E-T)
               or low-angle BSE detector; surface sensitive.
Secondary electrons (SE) - only the part that carries sub-surface information is modelled:
  SE2          SE generated where BSE cross the top surface. Yield per BSE = delta(E) / cos(theta) with the universal
               yield curve delta(E) = 1.28 dm (E/Em)^-0.67 [1 - exp(-1.614 (E/Em)^1.67)]  [Lin & Joy, Surf. Interface Anal.
               37, 895 (2005)], dm = 2, Em = 0.6 keV (insulator); in-lens and E-T SE detectors both record SE2.
  SE3          SE produced when BSE hit the pole piece / chamber (E-T only): delta(E) summed over all BSE.
  SE1 (from the primary beam at the entrance surface) is the same everywhere and is omitted; so is charging (voltage
  contrast), which dominates the SE images of this system and is treated as a contact map, not modelled here.
Transmission (STEM-in-SEM, detector below the cell), counting detectors, semi-angles in mrad
  STEM_BF50, STEM_BF100, STEM_ADF (100-400), STEM_HAADF (400-1200), STEM_all.
An E-T image is roughly SE1 + SE2 + a SE3 + b BSE_grazing, with a, b set by the grid bias and chamber geometry.
"""
import numpy as np

def se_yield(E, dm=2.0, Em=0.6):
    x = np.maximum(E, 1e-3) / Em
    return 1.28 * dm * x ** -0.67 * (1 - np.exp(-1.614 * x ** 1.67))

def _theta_top(o):
    return np.degrees(np.arccos(np.clip(-o[:, 4], -1, 1)))          # BSE polar angle from the surface normal

def _theta_trans(o):
    return np.arccos(np.clip(o[:, 4], -1, 1)) * 1000.0             # transmitted polar angle, mrad

def bse(o, tmin, tmax, weight='E-2', threshold=2.0):
    b = (o[:, 0] == 1); th = _theta_top(o); sel = b & (th >= tmin) & (th < tmax)
    if weight == 'E-2': w = np.clip(o[:, 1] - threshold, 0, None)
    elif weight == 'E': w = o[:, 1]
    else: w = np.ones(len(o))
    return np.where(sel, w, 0.0)

def se2(o, dm=2.0, Em=0.6):
    b = (o[:, 0] == 1); ct = np.clip(-o[:, 4], 0.1, 1.0)
    return np.where(b, se_yield(o[:, 1], dm, Em) / ct, 0.0)

def se3(o, dm=2.0, Em=0.6):
    return np.where(o[:, 0] == 1, se_yield(o[:, 1], dm, Em), 0.0)

def stem(o, mmin, mmax):
    t = (o[:, 0] == 2); th = _theta_trans(o)
    return (t & (th >= mmin) & (th < mmax)).astype(float)

DETECTORS = {
    'BEDC':        lambda o: bse(o, 15, 65, 'E-2'),
    'BSE_axial':   lambda o: bse(o, 0, 15, 'E'),
    'BSE_grazing': lambda o: bse(o, 65, 88, 'E'),
    'SE2':         se2,
    'SE3':         se3,
    'STEM_BF50':   lambda o: stem(o, 0, 50),
    'STEM_BF100':  lambda o: stem(o, 0, 100),
    'STEM_ADF':    lambda o: stem(o, 100, 400),
    'STEM_HAADF':  lambda o: stem(o, 400, 1200),
    'STEM_all':    lambda o: stem(o, 0, 1571),
}
LABELS = {'BEDC': 'BSE (BED-C, 15-65°)', 'BSE_axial': 'in-lens BSE (0-15°)', 'BSE_grazing': 'grazing BSE (E-T part)', 'SE2': 'SE2 (in-lens / E-T SE)',
          'SE3': 'SE3 (E-T only)', 'STEM_BF50': 'STEM BF <50 mrad', 'STEM_BF100': 'STEM BF <100 mrad', 'STEM_ADF': 'STEM ADF 100-400 mrad',
          'STEM_HAADF': 'STEM HAADF 400-1200 mrad', 'STEM_all': 'STEM all transmitted'}

def signals(o, names=None):
    names = names or list(DETECTORS)
    return {k: DETECTORS[k](o) for k in names}

def custom(kind, a, b, **kw):
    """custom detector: custom('bse', 20, 70, weight='E') or custom('stem', 30, 250)"""
    if kind == 'bse': return lambda o: bse(o, a, b, **kw)
    if kind == 'stem': return lambda o: stem(o, a, b)
    raise ValueError(kind)
