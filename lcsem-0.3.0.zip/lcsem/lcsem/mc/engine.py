"""
Electron Monte Carlo for SEM imaging of liquid cells (single elastic scattering + continuous slowing down).

Physics
  * elastic scattering: Mott (Dirac partial-wave) differential and total cross sections from ELSEPA
    [Salvat, Jablonski & Powell, Comput. Phys. Commun. 165, 157 (2005)] for free atoms (Dirac-Fock density, Fermi nucleus,
    Furness-McCarthy exchange), 0.5-32 keV (the tables of lcsem/mc/elsepa_mott_tables.npz); compounds and mixtures by the independent-atom sum.
    Elements in the tables: H C N O Na Al Si P S Cl Cu Au.
  * energy loss: continuous slowing down with the Joy-Luo modified Bethe stopping power [Joy & Luo, Scanning 11, 176 (1989)],
    Bragg additivity, ICRU mean excitation energies.
  This is the model class of CASINO [Drouin et al., Scanning 29, 92 (2007)] and the NIST DTSA-II single-scattering codes.

Geometry (z positive DOWN, beam enters at z = 0 travelling +z)
  * planar layers zb[0] < zb[1] < ... with materials lmat; outside [zb[0], zb[-1]] is vacuum
  * objects, tested in list order (the first object that contains the point wins, so nested shells are listed inside-out):
      sphere    [0, x, y, z, R, 0, mat]
      cylinder  [1, x, y, z0, z1, R, mat]   (axis parallel to the beam)
      rod       [2, x, z, R, y0, y1, mat]   (horizontal cylinder along y, e.g. a bacterium lying on a membrane)
    The legacy form sph=[[x, y, z, R, mat], ...] is still accepted.

Transport: the optical depth of each free flight, tau = -ln(u), is sampled once and consumed across material boundaries
(exact for piecewise-constant media). Every flight uses one random number and every collision four, whatever the geometry,
so two runs with the same seeds but slightly different materials stay synchronized and their trajectories differ only
smoothly: correlated sampling then gives low-variance image differences even for weak-contrast objects (proteins, viruses)
[Spanier & Gelbard, Monte Carlo Principles and Neutron Transport Problems (1969), ch. 4; Rief, Ann. Nucl. Energy 11, 455 (1984)].

Output per primary (columns): 0 flag (1 = left through the top surface, 2 = transmitted through the bottom, 0 = absorbed),
1 E (keV), 2-4 direction (ux, uy, uz), 5-6 exit x, y (nm), 7 entered an object (0/1), 8 deepest z reached (nm).
Units: nm, keV, g/cm3.
"""
import numpy as np, os
from numba import njit, prange

NA = 6.02214076e23
_T = np.load(os.path.join(os.path.dirname(__file__), 'elsepa_mott_tables.npz'))
ZLIST = sorted({int(k.split('_')[1]) for k in _T.files})
ZIDX = {z: i for i, z in enumerate(ZLIST)}
AW = {1: 1.008, 6: 12.011, 7: 14.007, 8: 15.999, 11: 22.990, 13: 26.982, 14: 28.086, 15: 30.974, 16: 32.06, 17: 35.45, 29: 63.546, 79: 196.967}
JJ = {1: 0.0192, 6: 0.078, 7: 0.082, 8: 0.095, 11: 0.149, 13: 0.166, 14: 0.173, 15: 0.173, 16: 0.180, 17: 0.174, 29: 0.322, 79: 0.790}  # keV (ICRU 37)
SYMBOL = {1: 'H', 6: 'C', 7: 'N', 8: 'O', 11: 'Na', 13: 'Al', 14: 'Si', 15: 'P', 16: 'S', 17: 'Cl', 29: 'Cu', 79: 'Au'}
ZOF = {v: k for k, v in SYMBOL.items()}

# ---------------- tables ----------------
NE = len(_T[f'E_{ZLIST[0]}']); NMU = _T[f'mu_{ZLIST[0]}'].shape[1]
LOGE = np.log(_T[f'E_{ZLIST[0]}'] / 1000.0)                               # ln(E/keV)
LSIG = np.zeros((len(ZLIST), NE))                                          # ln(sigma / nm^2)
CDF = np.zeros((len(ZLIST), NE, NMU)); MU = np.zeros((len(ZLIST), NE, NMU))
for zi, z in enumerate(ZLIST):
    LSIG[zi] = np.log(_T[f'tcs_{z}'] * 1e14)
    for k in range(NE):
        mu = _T[f'mu_{z}'][k]; f = 4 * np.pi * _T[f'dcs_{z}'][k]
        c = np.concatenate([[0], np.cumsum(0.5 * (f[1:] + f[:-1]) * np.diff(mu))])
        CDF[zi, k] = c / c[-1]; MU[zi, k] = mu

# ---------------- materials ----------------
def formula(**counts):
    """mass fractions of a chemical formula, e.g. formula(H=2, O=1)"""
    m = {ZOF[s]: n * AW[ZOF[s]] for s, n in counts.items()}; tot = sum(m.values())
    return {z: v / tot for z, v in m.items()}

# name -> (mass fractions {Z: w}, density g/cm3) ; None = vacuum / gas
MATDEF = {
    'vac': None,
    'SiN': (formula(Si=3, N=4), 3.10),
    'H2O': (formula(H=2, O=1), 1.00),
    'Au': (formula(Au=1), 19.32),
    'Si': (formula(Si=1), 2.33),
    'C': (formula(C=1), 2.00),
    'Al': (formula(Al=1), 2.70),
    'Cu': (formula(Cu=1), 8.96),
    # average protein (C4.94 H7.76 N1.36 O1.48 S0.04 per residue), density from the partial specific volume 0.73 cm3/g
    'protein': (formula(C=4.94, H=7.76, N=1.36, O=1.48, S=0.04), 1 / 0.73),
    # RNA, average nucleotide residue C9.5 H11.25 N3.75 O7 P, density from a partial specific volume of 0.55 cm3/g
    'RNA': (formula(C=9.5, H=11.25, N=3.75, O=7, P=1), 1 / 0.55),
    # phospholipid (phosphatidylethanolamine-like, C39H76NO8P), partial specific volume 0.98 cm3/g
    'lipid': (formula(C=39, H=76, N=1, O=8, P=1), 1 / 0.98),
    # DNA, average deoxynucleotide residue C9.75 H12.25 N3.75 O6 P, partial specific volume 0.55 cm3/g
    'DNA': (formula(C=9.75, H=12.25, N=3.75, O=6, P=1), 1 / 0.55),
    'saline': ({**{k: v * (1 - 0.0088) for k, v in formula(H=2, O=1).items()}, 11: 0.0088 * 0.3934, 17: 0.0088 * 0.6066}, 1.005),  # 0.15 M NaCl
}

def mix(parts, name=None):
    """volume-fraction mixture of library materials, e.g. mix({'protein': 0.4, 'H2O': 0.6}); returns (mass fractions, density)"""
    rho = 0.0; mass = {}
    for nm, phi in parts.items():
        d = MATDEF[nm]
        if d is None or phi <= 0: continue
        w, r = d; rho += phi * r
        for z, f in w.items(): mass[z] = mass.get(z, 0.0) + phi * r * f
    tot = sum(mass.values())
    out = ({z: v / tot for z, v in mass.items()}, rho)
    if name: MATDEF[name] = out
    return out

def build_materials(names):
    nm = len(names); nz = len(ZLIST)
    ndens = np.zeros((nm, nz)); stopw = np.zeros((nm, nz)); isvac = np.zeros(nm, np.int64)
    for m, nmn in enumerate(names):
        d = MATDEF[nmn] if isinstance(nmn, str) else nmn
        if d is None: isvac[m] = 1; continue
        w, rho = d
        for z, f in w.items():
            ndens[m, ZIDX[z]] = rho * f * NA / AW[z] * 1e-21          # atoms / nm^3
            stopw[m, ZIDX[z]] = rho * f * z / AW[z]
    Jarr = np.array([JJ[z] for z in ZLIST])
    elist = np.full((nm, nz), -1, np.int64); ecount = np.zeros(nm, np.int64)
    for m in range(nm):
        idx = np.where(ndens[m] > 0)[0]; elist[m, :len(idx)] = idx; ecount[m] = len(idx)
    return ndens, stopw, isvac, Jarr, elist, ecount

# ---------------- RNG ----------------
@njit(inline='always')
def splitmix(x):
    x = (x + np.uint64(0x9E3779B97F4A7C15)); z = x
    z = (z ^ (z >> np.uint64(30))) * np.uint64(0xBF58476D1CE4E5B9)
    z = (z ^ (z >> np.uint64(27))) * np.uint64(0x94D049BB133111EB)
    return z ^ (z >> np.uint64(31))

@njit(inline='always')
def rnd(state):
    x = state[0]
    x ^= x >> np.uint64(12); x ^= x << np.uint64(25); x ^= x >> np.uint64(27)
    state[0] = x
    r = (x * np.uint64(2685821657736338717)) >> np.uint64(11)
    return (np.float64(r) + 0.5) / 9007199254740992.0

# ---------------- physics ----------------
@njit(inline='always')
def e_index(E, loge):
    le = np.log(E)
    if le <= loge[0]: return 0, 0.0
    if le >= loge[-1]: return len(loge) - 2, 1.0
    k = np.searchsorted(loge, le) - 1
    return k, (le - loge[k]) / (loge[k + 1] - loge[k])

@njit(inline='always')
def sigma_tot(m, k, f, ndens, lsig, elist, ecount):
    tot = 0.0
    for j in range(ecount[m]):
        zi = elist[m, j]
        tot += ndens[m, zi] * np.exp((1 - f) * lsig[zi, k] + f * lsig[zi, k + 1])
    return tot

@njit(inline='always')
def pick_element(m, k, f, ndens, lsig, elist, ecount, u):
    tot = sigma_tot(m, k, f, ndens, lsig, elist, ecount); acc = 0.0; target = u * tot; last = elist[m, 0]
    for j in range(ecount[m]):                    # elements in Z order, so small composition changes swap neighbours
        zi = elist[m, j]; last = zi
        acc += ndens[m, zi] * np.exp((1 - f) * lsig[zi, k] + f * lsig[zi, k + 1])
        if acc >= target: return zi
    return last

@njit(inline='always')
def sample_mu(zi, k, f, cdf, mu, u1, u2):
    kk = k + 1 if u1 < f else k
    c = cdf[zi, kk]; j = np.searchsorted(c, u2)
    if j <= 0: return mu[zi, kk, 0]
    if j >= c.shape[0]: return mu[zi, kk, -1]
    c0 = c[j - 1]; c1 = c[j]; t = (u2 - c0) / (c1 - c0) if c1 > c0 else 0.0
    return mu[zi, kk, j - 1] + t * (mu[zi, kk, j] - mu[zi, kk, j - 1])

@njit(inline='always')
def stopping(m, E, stopw, Jarr, elist, ecount):
    """keV per nm"""
    s = 0.0
    for j in range(ecount[m]):
        zi = elist[m, j]
        s += stopw[m, zi] * np.log(1.166 * (E + 0.85 * Jarr[zi]) / Jarr[zi])
    return 7.85e4 * s / E * 1e-7

@njit(inline='always')
def rotate(ux, uy, uz, ct, phi):
    st = np.sqrt(max(0.0, 1 - ct * ct)); cp = np.cos(phi); sp = np.sin(phi)
    if abs(uz) > 0.99999:
        sgn = 1.0 if uz > 0 else -1.0
        return st * cp, st * sp, sgn * ct
    d = np.sqrt(1 - uz * uz)
    nx = ux * ct + st * (ux * uz * cp - uy * sp) / d
    ny = uy * ct + st * (uy * uz * cp + ux * sp) / d
    nz = uz * ct - st * d * cp
    n = np.sqrt(nx * nx + ny * ny + nz * nz)
    return nx / n, ny / n, nz / n

# ---------------- geometry ----------------
@njit(inline='always')
def inside(o, x, y, z):
    if o[0] == 0:
        dx = x - o[1]; dy = y - o[2]; dz = z - o[3]
        return dx * dx + dy * dy + dz * dz < o[4] * o[4]
    if o[0] == 2:                              # horizontal cylinder along y: [2, x0, z0, R, y0, y1, mat]
        dx = x - o[1]; dz = z - o[2]
        return (y > o[4]) and (y < o[5]) and (dx * dx + dz * dz < o[3] * o[3])
    dx = x - o[1]; dy = y - o[2]
    return (z > o[3]) and (z < o[4]) and (dx * dx + dy * dy < o[5] * o[5])

@njit(inline='always')
def region(x, y, z, zb, lmat, obj, nobj):
    for i in range(nobj):
        if inside(obj[i], x, y, z): return int(obj[i, 6]), i
    if z < zb[0] or z > zb[-1]: return -1, -1
    for j in range(zb.shape[0] - 1):
        if z < zb[j + 1]: return int(lmat[j]), -1
    return int(lmat[-1]), -1

@njit(inline='always')
def _quad(ox, oy, oz, ux, uy, uz, R, d, planar):
    """nearest positive root of |o + t u|^2 = R^2 (planar: only x, y components)"""
    if planar:
        a = ux * ux + uy * uy
        if a < 1e-14: return d
        b = (ox * ux + oy * uy) / a; c = (ox * ox + oy * oy - R * R) / a
    else:
        b = ox * ux + oy * uy + oz * uz; c = ox * ox + oy * oy + oz * oz - R * R
    disc = b * b - c
    if disc > 0:
        sq = np.sqrt(disc); t1 = -b - sq; t2 = -b + sq
        if t1 > 1e-9 and t1 < d: return t1
        if t2 > 1e-9 and t2 < d: return t2
    return d

@njit(inline='always')
def dist_boundary(x, y, z, ux, uy, uz, zb, obj, nobj):
    d = 1e30
    if uz != 0:
        for j in range(zb.shape[0]):
            t = (zb[j] - z) / uz
            if t > 1e-9 and t < d: d = t
    for i in range(nobj):
        o = obj[i]
        if o[0] == 0:
            d = _quad(x - o[1], y - o[2], z - o[3], ux, uy, uz, o[4], d, False)
        elif o[0] == 2:
            d = _quad(x - o[1], z - o[2], 0.0, ux, uz, 0.0, o[3], d, True)
            if uy != 0:
                for yy in (o[4], o[5]):
                    t = (yy - y) / uy
                    if t > 1e-9 and t < d: d = t
        else:
            d = _quad(x - o[1], y - o[2], 0.0, ux, uy, uz, o[5], d, True)
            if uz != 0:
                for zz in (o[3], o[4]):
                    t = (zz - z) / uz
                    if t > 1e-9 and t < d: d = t
    return d

@njit
def track(x, y, E0, Ecut, state, zb, lmat, obj, nobj, ndens, lsig, cdf, mu, loge, stopw, Jarr, isvac, elist, ecount):
    z = 1e-7; ux = 0.0; uy = 0.0; uz = 1.0; E = E0; hit = 0; zmax = 0.0
    tau = -np.log(rnd(state))
    for it in range(400000):
        m, oi = region(x, y, z, zb, lmat, obj, nobj)
        if oi >= 0: hit = 1
        if z > zmax: zmax = z
        if m < 0 or isvac[m] == 1:
            if z <= zb[0] and uz < 0: return 1, E, ux, uy, uz, x, y, hit, zmax
            if z >= zb[-1] and uz > 0: return 2, E, ux, uy, uz, x, y, hit, zmax
            d = dist_boundary(x, y, z, ux, uy, uz, zb, obj, nobj)
            if d > 1e29: return (1 if uz < 0 else 2), E, ux, uy, uz, x, y, hit, zmax
            x += ux * (d + 1e-6); y += uy * (d + 1e-6); z += uz * (d + 1e-6)
            continue
        k, f = e_index(E, loge)
        lam = sigma_tot(m, k, f, ndens, lsig, elist, ecount)
        s = tau / lam
        d = dist_boundary(x, y, z, ux, uy, uz, zb, obj, nobj)
        if s >= d:
            step = d + 1e-6
            E -= stopping(m, E, stopw, Jarr, elist, ecount) * step
            tau = max(tau - lam * step, 1e-12)
            x += ux * step; y += uy * step; z += uz * step
            if E < Ecut: return 0, E, ux, uy, uz, x, y, hit, zmax
            continue
        E -= stopping(m, E, stopw, Jarr, elist, ecount) * s
        x += ux * s; y += uy * s; z += uz * s
        if z > zmax: zmax = z
        if E < Ecut: return 0, E, ux, uy, uz, x, y, hit, zmax
        k, f = e_index(E, loge)
        zi = pick_element(m, k, f, ndens, lsig, elist, ecount, rnd(state))
        u1 = rnd(state); u2 = rnd(state)
        ct = 1 - 2 * sample_mu(zi, k, f, cdf, mu, u1, u2)
        ux, uy, uz = rotate(ux, uy, uz, ct, 2 * np.pi * rnd(state))
        tau = -np.log(rnd(state))
    return 0, E, ux, uy, uz, x, y, hit, zmax

@njit(parallel=True)
def run(bx, by, seeds, E0, Ecut, zb, lmat, obj, nobj, ndens, lsig, cdf, mu, loge, stopw, Jarr, isvac, elist, ecount):
    n = bx.shape[0]; out = np.zeros((n, 9))
    for i in prange(n):
        st = np.zeros(1, np.uint64); st[0] = splitmix(np.uint64(seeds[i]))
        if st[0] == 0: st[0] = np.uint64(88172645463325252)
        fl, E, ux, uy, uz, x, y, h, zm = track(bx[i], by[i], E0, Ecut, st, zb, lmat, obj, nobj, ndens, lsig, cdf, mu, loge, stopw, Jarr, isvac, elist, ecount)
        out[i, 0] = fl; out[i, 1] = E; out[i, 2] = ux; out[i, 3] = uy; out[i, 4] = uz
        out[i, 5] = x; out[i, 6] = y; out[i, 7] = h; out[i, 8] = zm
    return out

def sphere(x, y, z, R, mat): return [0, x, y, z, R, 0, mat]
def cylinder(x, y, z0, z1, R, mat): return [1, x, y, z0, z1, R, mat]
def rod(x, z, R, y0, y1, mat): return [2, x, z, R, y0, y1, mat]

class Sim:
    """Sim(['vac', 'SiN', 'H2O', 'Au']) ; materials may also be given as (mass-fraction dict, density) tuples via add()"""
    def __init__(self, names):
        self.names = list(names); self._build()
    def _build(self):
        self.ndens, self.stopw, self.isvac, self.Jarr, self.elist, self.ecount = build_materials(self.names)
    def add(self, name, spec=None):
        if spec is not None: MATDEF[name] = spec
        if name not in self.names: self.names.append(name); self._build()
        return self.names.index(name)
    def m(self, name): return self.names.index(name)
    def go(self, bx, by, seeds, E0, zb, lmat, sph=None, objects=None, Ecut=0.2):
        objs = []
        if sph is not None:
            for s in sph: objs.append(list(s) if len(s) == 7 else [0, s[0], s[1], s[2], s[3], 0, s[4]])
        if objects is not None: objs += [list(o) for o in objects]
        obj = np.array(objs, float) if objs else np.zeros((1, 7))
        return run(np.asarray(bx, float), np.asarray(by, float), np.asarray(seeds, np.int64), float(E0), float(Ecut),
                   np.asarray(zb, float), np.asarray(lmat, float), obj, len(objs),
                   self.ndens, LSIG, CDF, MU, LOGE, self.stopw, self.Jarr, self.isvac, self.elist, self.ecount)

def stack(S, layers, t_mem=(30.0, 30.0), membrane='SiN'):
    """zb, lmat for membrane | layers... | membrane ; layers = [(thickness_nm, material), ...]"""
    zb = [0.0, t_mem[0]]; lm = [S.m(membrane)]; z = t_mem[0]
    for t, m in layers:
        if t <= 0: continue
        z += t; zb.append(z); lm.append(S.m(m))
    z += t_mem[1]; zb.append(z); lm.append(S.m(membrane))
    return zb, lm
