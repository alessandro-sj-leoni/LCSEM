"""Monte Carlo calibration data for any detector: signal vs liquid thickness S(T), and radial excess profiles of a
particle standard at several depths and thicknesses (for gain calibration, photometry and particle depth).

    lcsem mc-curve --E0 15 --detector BEDC --out bse15.json
    lcsem mc-curve --E0 20 --detector stem:0:100 --membrane 30 30 --particle 60 --out stem20.json

Detector specifications (strings or dicts):
    BEDC | BSE_axial | BSE_grazing | SE2 | SE3 | STEM_BF50 | STEM_BF100 | STEM_ADF | STEM_HAADF | STEM_all   (see detectors.py)
    bse:TMIN:TMAX[:WEIGHT]      BSE between TMIN and TMAX degrees from the normal, WEIGHT = E-2 (default), E or N
    stem:MMIN:MMAX              transmitted electrons between MMIN and MMAX mrad
"""
from __future__ import annotations
import numpy as np, json, argparse, time, os, hashlib
from .engine import Sim, stack, sphere, MATDEF
from . import detectors as DET
from . import radial

def parse_detector(spec):
    if isinstance(spec, dict): return spec
    s = str(spec)
    if s in DET.DETECTORS: return dict(name=s)
    p = s.split(':')
    if p[0] == 'bse': return dict(kind='bse', theta=[float(p[1]), float(p[2])], weight=p[3] if len(p) > 3 else 'E-2')
    if p[0] == 'stem': return dict(kind='stem', mrad=[float(p[1]), float(p[2])])
    raise ValueError(f'unknown detector {spec}')

def detector_function(spec):
    d = parse_detector(spec)
    if 'name' in d: return DET.DETECTORS[d['name']]
    if d['kind'] == 'bse': return lambda o: DET.bse(o, d['theta'][0], d['theta'][1], d.get('weight', 'E-2'), d.get('threshold', 2.0))
    if d['kind'] == 'stem': return lambda o: DET.stem(o, d['mrad'][0], d['mrad'][1])
    if d['kind'] == 'se2': return DET.se2
    raise ValueError(d)

def detector_label(spec):
    d = parse_detector(spec)
    if 'name' in d: return d['name']
    return f"{d['kind']}_{'_'.join(str(int(v)) for v in d.get('theta', d.get('mrad', [])))}"

def _sim(liquid, membrane, material='Au'):
    names = ['vac', membrane, liquid] + ([material] if material not in (membrane, liquid) else [])
    return Sim(names)

def water_curve(E0, detectors, t_mem=(30.0, 30.0), membrane='SiN', liquid='H2O', water=(0, 50, 100, 200, 300, 500, 1000), n=300000, seed=1, verbose=True):
    S = _sim(liquid, membrane); fns = {detector_label(d): detector_function(d) for d in detectors}; out = {k: dict(S=[], m2=[], err=[]) for k in fns}
    for T in water:
        zb, lm = stack(S, [(T, liquid)], t_mem, membrane); t0 = time.time()
        o = S.go(np.zeros(n), np.zeros(n), np.arange(n) + seed, E0, zb, lm)
        for k, f in fns.items():
            v = f(o); out[k]['S'].append(float(v.mean())); out[k]['m2'].append(float((v * v).mean())); out[k]['err'].append(float(v.std() / np.sqrt(n)))
        if verbose: print(f'  {liquid} {T:6.0f} nm: ' + '  '.join(f'{k} {out[k]["S"][-1]:.4f}' for k in fns) + f'  [{time.time()-t0:.1f} s]', flush=True)
    return out

def particle_profiles(E0, detectors, d=38.0, material='Au', T_list=(200.0, 500.0), depths=('top', 'mid', 'bot'), t_mem=(30.0, 30.0), membrane='SiN', liquid='H2O',
                      n=(500000, 250000, 80000), seed=11, verbose=True):
    """radial excess profiles of one particle at each (T, depth); depth 'top' = touching the top membrane, 'bot' = touching the bottom one"""
    from .scenes import z_of
    S = _sim(liquid, membrane, material); fns = {detector_label(x): detector_function(x) for x in detectors}
    R = d / 2; res = []
    for T in T_list:
        zb, lm = stack(S, [(T, liquid)], t_mem, membrane)
        for dep in depths:
            if R * 2 + 1 > T: continue
            zc = z_of(dep, R, T, t_mem[0]); zones = radial.zones_for(R, extra=(40, 150, 400), n=n)
            r = radial.profiles(S, zb, lm, [sphere(0, 0, zc, R, S.m(material))], E0, zones, detectors=fns, seed=seed + int(T) + int(zc))
            row = dict(T_nm=float(T), depth=dep if isinstance(dep, str) else float(dep), z_center_nm=float(zc - t_mem[0]), edges=r['edges'].tolist(), det={})
            for k in fns:
                q = r['det'][k]; row['det'][k] = dict(prof=q['prof'].tolist(), prof_err=q['prof_err'].tolist(), integral=float(q['integral']), err=float(q['err']))
            res.append(row)
            if verbose: print(f'  {material} d={d:.0f} nm, T={T:.0f}, {dep}: ' + '  '.join(f'{k} {row["det"][k]["integral"]:.0f}' for k in fns), flush=True)
    return dict(diameter_nm=d, material=material, profiles=res)

def make_curve(E0=15.0, detectors=('BEDC',), t_mem=(30.0, 30.0), membrane='SiN', liquid='H2O', water=(0, 25, 50, 100, 150, 200, 300, 400, 500, 700, 1000, 1500),
               n=300000, particle=38.0, material='Au', particle_T=(200.0, 500.0), depths=('top', 'mid', 'bot'), verbose=True):
    t0 = time.time()
    wc = water_curve(E0, detectors, t_mem, membrane, liquid, water, n, verbose=verbose)
    res = dict(version=2, E0_keV=E0, membranes_nm=list(t_mem), membrane=membrane, liquid=liquid, water_nm=list(map(float, water)),
               detectors={detector_label(d): dict(spec=parse_detector(d), S=wc[detector_label(d)]['S'], m2=wc[detector_label(d)]['m2'], S_err=wc[detector_label(d)]['err']) for d in detectors})
    if particle:
        res['particle'] = particle_profiles(E0, detectors, particle, material, particle_T, depths, t_mem, membrane, liquid, verbose=verbose)
    res['description'] = f'{E0:g} kV, {membrane} {t_mem[0]:g}/{t_mem[1]:g} nm, {liquid}; detectors ' + ', '.join(res['detectors']) + (f'; standard {material} {particle:g} nm' if particle else '')
    res['mc_seconds'] = round(time.time() - t0, 1)
    return res

def cache_key(**kw):
    return hashlib.sha1(json.dumps(kw, sort_keys=True, default=str).encode()).hexdigest()[:12]

def cached_curve(cache_dir=None, **kw):
    cache_dir = cache_dir or os.path.join(os.path.expanduser('~'), '.lcsem', 'curves'); os.makedirs(cache_dir, exist_ok=True)
    fn = os.path.join(cache_dir, f'curve_{cache_key(**kw)}.json')
    if os.path.exists(fn): return json.load(open(fn)), fn
    res = make_curve(**kw); json.dump(res, open(fn, 'w')); return res, fn

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--E0', type=float, default=15.0); ap.add_argument('--membrane', type=float, nargs=2, default=[30.0, 30.0])
    ap.add_argument('--membrane-material', default='SiN'); ap.add_argument('--liquid', default='H2O')
    ap.add_argument('--detector', nargs='+', default=['BEDC'])
    ap.add_argument('--water', type=float, nargs='+', default=[0, 25, 50, 100, 150, 200, 300, 400, 500, 700, 1000, 1500])
    ap.add_argument('--particle', type=float, default=38.0, help='particle standard diameter (nm); 0 = none')
    ap.add_argument('--material', default='Au'); ap.add_argument('--particle-T', type=float, nargs='+', default=[200.0, 500.0])
    ap.add_argument('--n', type=int, default=300000); ap.add_argument('--out', default='curve.json')
    a = ap.parse_args()
    res = make_curve(a.E0, a.detector, tuple(a.membrane), a.membrane_material, a.liquid, a.water, a.n, a.particle, a.material, a.particle_T)
    json.dump(res, open(a.out, 'w')); print('wrote', a.out, f'({res["mc_seconds"]} s)')

if __name__ == '__main__':
    main()
