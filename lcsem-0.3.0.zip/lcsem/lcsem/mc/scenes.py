"""Scene library for the Monte Carlo: liquid-cell stacks and the objects placed in them.

Rotavirus model (group A, SA11-like), spherically averaged layers; every number is from the literature except where
marked 'assumed':
  radii            core (VP2 outer) 25.5 nm, DLP (VP6 outer) 35.25 nm, TLP without spikes ~38.25 nm, TLP with VP4 spikes ~50 nm
                   [ICTV report, Sedoreoviridae: Rotavirus; Li et al., J. Virol. 83, 1754 (2009), 'Rotavirus architecture at
                   subnanometer resolution': 60 VP4 spikes, 12 nm long]. VP2 inner radius 22.5 nm (assumed: ~3 nm VP2 shell).
  stoichiometry    VP1 12 x 125.0 kDa, VP2 120 x 102.4, VP3 12 x 98.1, VP4 180 x 86.8, VP6 780 x 44.8, VP7 780 x 37.4 [ICTV]
  genome           11 dsRNA segments, 18,555 bp (SA11) [ICTV]; 642 Da per bp (average nucleotide residue)
  volumes          partial specific volume 0.73 cm3/g for protein, 0.55 cm3/g for RNA (standard values); the rest of each
                   layer is water. 20 % of VP4 is placed in the VP6 layer (spike foot; assumed), 80 % in the spike layer.
Check: mean density of the TLP body (dry mass / (dry volume)) 1.41 g/cm3, vs buoyant density 1.36 g/cm3 in CsCl [ICTV].
"""
import numpy as np
from .engine import MATDEF, mix, sphere, cylinder, stack, rod

DA_TO_NM3 = 1.66054e-3       # nm^3 per Da per (cm^3/g)

ROTAVIRUS = dict(r_vp2_in=22.5, r_vp2=25.5, r_vp6=35.25, r_vp7=38.25, r_spike=50.0,
                 vp1=(12, 125.0), vp2=(120, 102.4), vp3=(12, 98.1), vp4=(180, 86.8), vp6=(780, 44.8), vp7=(780, 37.4),
                 genome_bp=18555, da_per_bp=642.0, vbar_protein=0.73, vbar_rna=0.55, vp4_in_vp6=0.2)

def _shell_vol(r0, r1): return 4 / 3 * np.pi * (r1 ** 3 - r0 ** 3)

def rotavirus_layers(kind='TLP', p=ROTAVIRUS):
    """[(r_outer_nm, phi_protein, phi_rna, label), ...] inside-out"""
    kda = lambda k: p[k][0] * p[k][1] * 1e3           # Da
    vprot = lambda m: m * DA_TO_NM3 * p['vbar_protein']
    rna_v = p['genome_bp'] * p['da_per_bp'] * DA_TO_NM3 * p['vbar_rna']
    L = []
    v = _shell_vol(0, p['r_vp2_in']); L.append((p['r_vp2_in'], vprot(kda('vp1') + kda('vp3')) / v, rna_v / v, 'core (dsRNA + VP1/VP3)'))
    v = _shell_vol(p['r_vp2_in'], p['r_vp2']); L.append((p['r_vp2'], vprot(kda('vp2')) / v, 0.0, 'VP2 shell'))
    if kind == 'SLP': return L
    v = _shell_vol(p['r_vp2'], p['r_vp6']); foot = p['vp4_in_vp6'] * kda('vp4') if kind == 'TLP' else 0.0
    L.append((p['r_vp6'], vprot(kda('vp6') + foot) / v, 0.0, 'VP6 layer'))
    if kind == 'DLP': return L
    v = _shell_vol(p['r_vp6'], p['r_vp7']); L.append((p['r_vp7'], vprot(kda('vp7')) / v, 0.0, 'VP7 layer'))
    v = _shell_vol(p['r_vp7'], p['r_spike']); L.append((p['r_spike'], vprot((1 - p['vp4_in_vp6']) * kda('vp4')) / v, 0.0, 'VP4 spike layer'))
    return L

def rotavirus_mass(kind='TLP', p=ROTAVIRUS):
    m = {'SLP': ['vp1', 'vp2', 'vp3'], 'DLP': ['vp1', 'vp2', 'vp3', 'vp6'], 'TLP': ['vp1', 'vp2', 'vp3', 'vp4', 'vp6', 'vp7']}[kind]
    prot = sum(p[k][0] * p[k][1] * 1e3 for k in m); rna = p['genome_bp'] * p['da_per_bp']
    return prot, rna

def rotavirus_objects(S, kind='TLP', zc=0.0, x=0.0, y=0.0, p=ROTAVIRUS):
    """register the layer materials in the Sim and return the nested-sphere object list (inside-out) and the outer radius"""
    objs = []
    for i, (r, fp, fr, lab) in enumerate(rotavirus_layers(kind, p)):
        name = f'rv_{kind}_{i}'
        spec = mix({'protein': fp, 'RNA': fr, 'H2O': max(0.0, 1 - fp - fr)})
        m = S.add(name, spec)
        objs.append(sphere(x, y, zc, r, m))
    return objs, rotavirus_layers(kind, p)[-1][0]

def cell(S, T, t_mem=(30.0, 30.0), liquid='H2O'):
    return stack(S, [(T, liquid)], t_mem)

def z_of(position, R, T, t_top=30.0, clearance=0.5):
    """centre depth (engine z) of an object of radius R: 'top' touching the top membrane, 'bot' the bottom one, 'mid', or a number = centre depth below the top membrane"""
    if position == 'top': return t_top + R + clearance
    if position == 'bot': return t_top + T - R - clearance
    if position == 'mid': return t_top + T / 2
    if isinstance(position, str) and position.startswith('f'):          # fraction of the free range: f0 = top, f1 = bottom
        return t_top + R + clearance + float(position[1:]) * (T - 2 * R - 2 * clearance)
    return t_top + float(position)

def gas_pocket(S, R, h, where, T, t_top=30.0):
    """vertical gas cylinder of radius R and height h touching the top ('top') or bottom ('bot') membrane, or centred ('mid')"""
    z0 = {'top': t_top, 'bot': t_top + T - h, 'mid': t_top + (T - h) / 2}[where]
    return [cylinder(0, 0, z0 + (1e-3 if where == 'top' else 0.0), z0 + h - (1e-3 if where == 'bot' else 0.0), R, S.m('vac'))]


# ---------------------------------------------------------------------------------------------------------------- E. coli
# Spherocylinder (capsule) lying along y. Sources: BioNumbers (Milo & Phillips, Cell Biology by the Numbers): diameter ~1 um,
# length ~2 um, volume ~1.3 um^3, ~70 % water; dry mass ~55 % protein, ~20 % RNA, ~10 % lipid, ~3 % DNA, rest polysaccharides,
# metabolites, ions (Neidhardt et al., Physiology of the Bacterial Cell, 1990; BNID 104954). Envelope (Matias et al.,
# J. Bacteriol. 185, 6112 (2003), frozen-hydrated sections, E. coli K-12): outer membrane 6.9 nm, periplasm 21.0 nm
# (peptidoglycan 6.4 nm), inner membrane 5.8 nm -> 33.7 nm. Assumed: dry mass 30 % by weight (0.325 g/cm3 of cell volume);
# all lipid, LPS + peptidoglycan and 20 % of the protein in the envelope; the nucleoid (radius 250 nm, straight part) holds
# the DNA (partial specific volume 0.55) with 30 % of the average ribosomal RNA; partial specific volumes protein 0.73,
# RNA 0.55, lipid 0.98 cm3/g.
ECOLI = dict(radius=500.0, length=2000.0, envelope=33.7, nucleoid_radius=250.0, dry_g_cm3=0.325,
             f_protein=0.55, f_rna=0.20, f_lipid=0.10, f_dna=0.03, f_other=0.12, protein_in_envelope=0.20, rna_in_nucleoid=0.30)

def ecoli_compartments(p=ECOLI):
    """volume fractions (protein, RNA, DNA, lipid) of envelope, cytoplasm and nucleoid"""
    R = p['radius']; L = p['length']; h = L / 2 - R; e = p['envelope']
    V = np.pi * R ** 2 * 2 * h + 4 / 3 * np.pi * R ** 3; A = 2 * np.pi * R * 2 * h + 4 * np.pi * R ** 2
    Venv = A * e; Vcyt = V - Venv; Vnuc = np.pi * p['nucleoid_radius'] ** 2 * 2 * h
    dry = p['dry_g_cm3'] * V                                     # g/cm3 x nm^3 (only ratios matter)
    prot, rna, lip, dna, oth = (p[k] * dry for k in ('f_protein', 'f_rna', 'f_lipid', 'f_dna', 'f_other'))
    env_prot = p['protein_in_envelope'] * prot + 0.5 * oth       # LPS + peptidoglycan counted as protein-like
    cyt_prot = prot + oth - env_prot
    c_rna = rna / (Vcyt - Vnuc * (1 - p['rna_in_nucleoid']))    # RNA concentration outside the nucleoid
    out = dict(
        envelope=dict(protein=env_prot / Venv * 0.73, lipid=lip / Venv * 0.98, RNA=0.0, DNA=0.0),
        cytoplasm=dict(protein=cyt_prot / Vcyt * 0.73, RNA=c_rna * 0.55, DNA=0.0, lipid=0.0),
        nucleoid=dict(protein=cyt_prot / Vcyt * 0.73, RNA=c_rna * p['rna_in_nucleoid'] * 0.55, DNA=dna / Vnuc * 0.55, lipid=0.0))
    return out, dict(volume_um3=V / 1e9, envelope_um3=Venv / 1e9, nucleoid_um3=Vnuc / 1e9, half_straight_nm=h)

def ecoli_objects(S, zc, geometry='rod', p=ECOLI):
    """nested objects (inside-out) for the infinite-rod ('rod', straight part) or the sphere ('cap') approximation"""
    comp, g = ecoli_compartments(p); objs = []; R = p['radius']; e = p['envelope']
    def mat(name):
        c = comp[name]; return S.add(f'ecoli_{name}', mix({'protein': c['protein'], 'RNA': c['RNA'], 'DNA': c['DNA'], 'lipid': c['lipid'],
                                                             'H2O': max(0.0, 1 - sum(c.values()))}))
    if geometry == 'rod':
        objs.append(rod(0, zc, p['nucleoid_radius'], -1e5, 1e5, mat('nucleoid')))
        objs.append(rod(0, zc, R - e, -1e5, 1e5, mat('cytoplasm')))
        objs.append(rod(0, zc, R, -1e5, 1e5, mat('envelope')))
    else:
        objs.append(sphere(0, 0, zc, R - e, mat('cytoplasm'))); objs.append(sphere(0, 0, zc, R, mat('envelope')))
    return objs
