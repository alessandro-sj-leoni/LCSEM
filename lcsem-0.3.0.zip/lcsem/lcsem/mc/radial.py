"""Images of axisymmetric objects (spheres, nested shells, vertical cylinders centred on x = y = 0) for many detectors at once,
by correlated sampling: the same primaries are tracked with and without the object, at beam positions spread over concentric
zones around the axis. Returns, per detector, the radial excess profile ds(r) (signal per primary), its error, the
integrated excess and the background mean/variance per primary, from which images at any dose and noise model follow.
"""
import numpy as np, time
from .engine import Sim
from .detectors import DETECTORS

def zones_for(R, extra=(40.0, 150.0, 400.0), n=(600000, 300000, 100000), bins=(1.0, 4.0, 10.0)):
    r1, r2, r3 = R + extra[0], R + extra[1], R + extra[2]
    return [(0.0, r1, n[0], bins[0]), (r1, r2, n[1], bins[1]), (r2, r3, n[2], bins[2])]

def profiles(S, zb, lm, objects, E0, zones, detectors=None, seed=1, Ecut=0.2, verbose=False):
    fns = detectors if isinstance(detectors, dict) else {k: DETECTORS[k] for k in (detectors or list(DETECTORS))}
    dets = list(fns)
    edges = np.unique(np.concatenate([np.arange(a, b + 1e-9, w) for a, b, _, w in zones] + [[z[1] for z in zones]]))
    nb = len(edges) - 1; rng = np.random.default_rng(seed); t0 = time.time()
    acc = {k: np.zeros((4, nb)) for k in dets}; cnt = np.zeros(nb)
    integ = {k: 0.0 for k in dets}; ivar = {k: 0.0 for k in dets}; bg = {k: np.zeros(3) for k in dets}
    for zi, (a, b, n, _) in enumerate(zones):
        r = np.sqrt(a * a + (b * b - a * a) * rng.random(n)); ph = 2 * np.pi * rng.random(n)
        bx, by = r * np.cos(ph), r * np.sin(ph); seeds = np.arange(n, dtype=np.int64) + seed * 100_000_000 + zi * 10_000_000
        o1 = S.go(bx, by, seeds, E0, zb, lm, objects=objects, Ecut=Ecut)
        o0 = o1.copy(); hit = o1[:, 7] > 0
        if hit.any(): o0[hit] = S.go(bx[hit], by[hit], seeds[hit], E0, zb, lm, objects=None, Ecut=Ecut)
        idx = np.clip(np.searchsorted(edges, r, side='right') - 1, 0, nb - 1); cnt += np.bincount(idx, minlength=nb)
        area = np.pi * (b * b - a * a)
        for k in dets:
            s1 = fns[k](o1); s0 = fns[k](o0); d = s1 - s0
            integ[k] += area * d.mean(); ivar[k] += area ** 2 * d.var() / n
            acc[k][0] += np.bincount(idx, d, nb); acc[k][1] += np.bincount(idx, d * d, nb)
            acc[k][2] += np.bincount(idx, s1, nb); acc[k][3] += np.bincount(idx, s1 * s1, nb)
            bg[k] += (s0.sum(), (s0 * s0).sum(), n)
    out = dict(E0=E0, edges=edges, rc=0.5 * (edges[1:] + edges[:-1]), cnt=cnt, sec=time.time() - t0, det={})
    c = np.maximum(cnt, 1)
    for k in dets:
        m = acc[k][0] / c; v = np.maximum(acc[k][1] / c - m * m, 0)
        w1 = acc[k][2] / c; w1v = np.maximum(acc[k][3] / c - w1 * w1, 0)
        bm = bg[k][0] / bg[k][2]; bv = bg[k][1] / bg[k][2] - bm * bm
        out['det'][k] = dict(prof=m, prof_err=np.sqrt(v / c), with_mean=w1, with_var=w1v, integral=integ[k], err=np.sqrt(ivar[k]), bg_mean=bm, bg_var=bv)
    if verbose: print(f'  profiles done in {out["sec"]:.0f} s', flush=True)
    return out

def smooth_profile(rc, prof, err=None, width_nm=2.0):
    """Gaussian kernel smoothing in r (Nadaraya-Watson), each bin weighted by its width (reduces MC noise; keeps the shape).
    Inverse-variance weights are deliberately not used: bins outside an object have almost no Monte Carlo variance (most
    trajectories never reach it) and would dominate the kernel at the object's edge, pulling the profile to zero there."""
    rc = np.asarray(rc, float); prof = np.asarray(prof, float); wb = np.abs(np.gradient(rc)) if len(rc) > 1 else np.ones(1)
    ok = np.isfinite(prof); out = np.empty_like(prof)
    for i, r in enumerate(rc):
        g = np.exp(-0.5 * ((rc - r) / width_nm) ** 2) * wb * ok
        out[i] = (g * np.nan_to_num(prof)).sum() / g.sum() if g.sum() > 0 else prof[i]
    return out

def render(rc, prof, px_nm=(2.0, 2.0), half_nm=150.0, center=(0.0, 0.0), ss=4):
    """pixel-averaged 2-D image (signal per primary) of the radial profile"""
    px, py = px_nm; nx = int(np.ceil(half_nm / px)); ny = int(np.ceil(half_nm / py))
    xs = (np.arange(-nx * ss, nx * ss) + 0.5) * (px / ss); ys = (np.arange(-ny * ss, ny * ss) + 0.5) * (py / ss)
    X, Y = np.meshgrid(xs - center[0], ys - center[1]); rr = np.hypot(X, Y)
    img = np.interp(rr, rc, prof, right=0.0)
    return img.reshape(2 * ny, ss, 2 * nx, ss).mean(axis=(1, 3))

def noisy_image(delta_img, bg_mean, bg_var, dose_e_per_nm2, px_area_nm2, rng, detector_sigma=0.0, gain=1.0, offset=0.0, bits=None):
    """expected signal = N (bg + delta), with N primaries per pixel; shot noise from the per-primary signal variance
    (compound Poisson), plus additive detector noise (in output units), gain, offset and optional clipping."""
    N = dose_e_per_nm2 * px_area_nm2
    mean = N * (bg_mean + delta_img)
    shot = np.sqrt(np.maximum(N * (bg_var + bg_mean ** 2), 0))                 # variance of a compound Poisson sum
    img = offset + gain * (mean + rng.normal(0, 1, mean.shape) * shot) + rng.normal(0, detector_sigma, mean.shape)
    if bits: img = np.clip(np.round(img), 0, 2 ** bits - 1)
    return img

def excess_snr_per_electron(res, det, R_ap):
    """photometric SNR^2 per primary per nm^2 of dose for an aperture of radius R_ap (shot-noise limit):
    SNR = sqrt(dose) * A / sqrt(area * var)"""
    d = res['det'][det]; e = res['edges']; ann = np.pi * (e[1:] ** 2 - e[:-1] ** 2)
    m = res['rc'] < R_ap; A = (d['prof'][m] * ann[m]).sum(); var = d['bg_var'] + d['bg_mean'] ** 2
    return A, A / np.sqrt(np.pi * R_ap ** 2 * var)

def transverse_profiles(S, zb, lm, objects, E0, zones, detectors=None, seed=1, Ecut=0.2):
    """Like profiles(), for objects invariant along y (rods lying along y): beam positions x in zones (|x|), y = 0.
    Returns per detector the transverse excess profile ds(x) and its integral per unit length (signal per primary x nm)."""
    fns = detectors if isinstance(detectors, dict) else {k: DETECTORS[k] for k in (detectors or list(DETECTORS))}
    dets = list(fns)
    edges = np.unique(np.concatenate([np.arange(a, b + 1e-9, w) for a, b, _, w in zones] + [[z[1] for z in zones]]))
    nb = len(edges) - 1; rng = np.random.default_rng(seed); t0 = time.time()
    acc = {k: np.zeros(4 * nb).reshape(4, nb) for k in dets}; cnt = np.zeros(nb)
    integ = {k: 0.0 for k in dets}; ivar = {k: 0.0 for k in dets}; bg = {k: np.zeros(3) for k in dets}
    for zi, (a, b, n, _) in enumerate(zones):
        ax = a + (b - a) * rng.random(n); sgn = np.where(rng.random(n) < 0.5, -1.0, 1.0)
        bx, by = sgn * ax, np.zeros(n); seeds = np.arange(n, dtype=np.int64) + seed * 100_000_000 + zi * 10_000_000
        o1 = S.go(bx, by, seeds, E0, zb, lm, objects=objects, Ecut=Ecut)
        o0 = o1.copy(); hit = o1[:, 7] > 0
        if hit.any(): o0[hit] = S.go(bx[hit], by[hit], seeds[hit], E0, zb, lm, objects=None, Ecut=Ecut)
        idx = np.clip(np.searchsorted(edges, ax, side='right') - 1, 0, nb - 1); cnt += np.bincount(idx, minlength=nb)
        width = 2 * (b - a)
        for k in dets:
            s1 = fns[k](o1); s0 = fns[k](o0); d = s1 - s0
            integ[k] += width * d.mean(); ivar[k] += width ** 2 * d.var() / n
            acc[k][0] += np.bincount(idx, d, nb); acc[k][1] += np.bincount(idx, d * d, nb)
            acc[k][2] += np.bincount(idx, s1, nb); acc[k][3] += np.bincount(idx, s1 * s1, nb)
            bg[k] += (s0.sum(), (s0 * s0).sum(), n)
    out = dict(E0=E0, edges=edges, xc=0.5 * (edges[1:] + edges[:-1]), cnt=cnt, sec=time.time() - t0, det={})
    c = np.maximum(cnt, 1)
    for k in dets:
        m = acc[k][0] / c; v = np.maximum(acc[k][1] / c - m * m, 0)
        bm = bg[k][0] / bg[k][2]; bv = bg[k][1] / bg[k][2] - bm * bm
        out['det'][k] = dict(prof=m, prof_err=np.sqrt(v / c), integral=integ[k], err=np.sqrt(ivar[k]), bg_mean=bm, bg_var=bv)
    return out

def render_capsule(xc_t, prof_t, rc_s, prof_s, half_len, px_nm=(20.0, 20.0), field=(3000.0, 4000.0), ss=2):
    """2-D image of a capsule (rod along y with hemispherical caps, straight part from -half_len to +half_len): the transverse
    profile of the infinite rod where the pixel projects onto the straight part, the radial profile of the sphere (same radius
    and depth) around the cap centres elsewhere"""
    px, py = px_nm; nx = int(np.ceil(field[0] / 2 / px)); ny = int(np.ceil(field[1] / 2 / py))
    xs = (np.arange(-nx * ss, nx * ss) + 0.5) * (px / ss); ys = (np.arange(-ny * ss, ny * ss) + 0.5) * (py / ss)
    X, Y = np.meshgrid(xs, ys)
    straight = np.abs(Y) <= half_len
    img = np.where(straight, np.interp(np.abs(X), xc_t, prof_t, right=0.0),
                   np.interp(np.hypot(X, np.abs(Y) - half_len), rc_s, prof_s, right=0.0))
    return img.reshape(2 * ny, ss, 2 * nx, ss).mean(axis=(1, 3))
