"""Per-frame layered 3-D label volumes and quantitative maps, written as ImageJ-compatible TIFFs.

Column model (top to bottom): vacuum | top membrane | gas layer (SE-dark; thickness = liquid deficit) | liquid (BSE) | bottom membrane | vacuum.
Labels: 0 vacuum, 1 membrane, 2 liquid, 3 gas layer on the top membrane (SE-dark), 4 gas not touching the top membrane (needs a gap
map; drawn against the bottom membrane - its vertical position is not measured), 5 dry membrane with a film below resolution,
7 outside the window, 255 not imaged / not measured, 10+ particles (spheres at their measured depth).
"""
from __future__ import annotations
import numpy as np, tifffile

L_VAC, L_MEM, L_LIQ, L_GAS, L_GAS_OTHER, L_FILM, L_OUTWIN, L_NOIMG = 0, 1, 2, 3, 4, 5, 7, 255

def build_volume(T, gas, fov, px, dz=5.0, t_mem=(30.0, 30.0), t_vac=5.0, film=None, nomeas=None, outwin=None, particles=(), film_nm=10.0, nomeas_nm=10.0, T_cap=1500.0, gas_other=None):
    """T: liquid thickness (nm, 2-D); gas: gas-layer thickness on the top membrane (nm, 2-D, 0 where wet); fov: imaged pixels;
    particles: iterable of (x_nm, y_nm, z_top_below_membrane_nm, diameter_nm, label)."""
    ny, nx = T.shape
    Tn = np.nan_to_num(np.clip(T, 0, T_cap)); gn = np.nan_to_num(np.clip(gas, 0, T_cap))
    ng = np.rint(gn / dz).astype(int); nl = np.rint(Tn / dz).astype(int)
    no = np.rint(np.nan_to_num(np.clip(gas_other, 0, T_cap)) / dz).astype(int) if gas_other is not None else np.zeros_like(nl)
    if film is not None: ng[film] = int(film_nm / dz)
    nvac = int(round(t_vac / dz)); nt = int(round(t_mem[0] / dz)); nb = int(round(t_mem[1] / dz))
    nz = nvac + nt + int((ng + nl + no).max()) + nb + 3
    vol = np.zeros((nz, ny, nx), np.uint8); vol[nvac:nvac + nt] = L_MEM
    k0 = nvac + nt; Z = np.arange(nz)[:, None, None]
    end_gas = k0 + ng[None]; end_liq = end_gas + nl[None]; end_oth = end_liq + no[None]; end_mem = end_oth + nb
    vol[(Z >= k0) & (Z < end_gas)] = L_GAS; vol[(Z >= end_gas) & (Z < end_liq)] = L_LIQ; vol[(Z >= end_liq) & (Z < end_oth)] = L_GAS_OTHER
    vol[(Z >= end_oth) & (Z < end_mem)] = L_MEM
    if film is not None and film.any(): vol[(Z >= k0) & (Z < end_gas) & film[None]] = L_FILM
    if nomeas is not None and nomeas.any():
        nm_ = int(nomeas_nm / dz); vol[(Z >= end_gas) & (Z < end_gas + nm_) & (Z < end_liq) & nomeas[None]] = L_NOIMG
    Y, X = np.mgrid[0:ny, 0:nx]; zch = (np.arange(nz) + 0.5) * dz - (t_vac + t_mem[0])
    for (xn, yn, zt, d, lab) in particles:
        R = d / 2; zc = zt + R; cx, cy = xn / px[0], yn / px[1]; rx, ry = R / px[0] + 1, R / px[1] + 1
        y0, y1 = int(max(0, cy - ry)), int(min(ny, cy + ry + 1)); x0, x1 = int(max(0, cx - rx)), int(min(nx, cx + rx + 1))
        if y1 <= y0 or x1 <= x0: continue
        dxy2 = (X[y0:y1, x0:x1] * px[0] - xn) ** 2 + (Y[y0:y1, x0:x1] * px[1] - yn) ** 2
        for k in range(nz):
            dzz = zch[k] - zc
            if abs(dzz) > R: continue
            inside = dxy2 + dzz ** 2 <= R ** 2
            if inside.any():
                sl = vol[k, y0:y1, x0:x1]; ok = inside & (sl != L_MEM) & (sl != L_VAC); sl[ok] = lab
    if outwin is not None: vol[:, outwin] = L_OUTWIN
    vol[:, ~fov] = L_NOIMG
    return vol

def write_label_tiff(fn, vol, px, dz, info=''):
    kw = dict(imagej=True, resolution=(1.0 / px[0], 1.0 / px[1]), metadata={'spacing': dz, 'unit': 'nm', 'axes': 'ZYX', 'Info': info})
    try: tifffile.imwrite(fn, vol, compression='zlib', **kw)
    except Exception: tifffile.imwrite(fn, vol, **kw)

def write_map_tiff(fn, arr, px, info=''):
    tifffile.imwrite(fn, np.asarray(arr, np.float32), imagej=True, resolution=(1.0 / px[0], 1.0 / px[1]), metadata={'unit': 'nm', 'Info': info}, compression='zlib')

def row_times(t_end_s, frame_s, n_rows=960):
    """acquisition time of every row: the raster is a clock"""
    return t_end_s - frame_s + np.arange(n_rows) * frame_s / n_rows

def write_stack(fn, arr, px, axes='TYX', info='', dz=None):
    """ImageJ hyperstack (float32), e.g. T x Y x X maps or T x Z x Y x X label volumes"""
    md = {'unit': 'nm', 'axes': axes, 'Info': info}
    if dz: md['spacing'] = dz
    a = np.asarray(arr); a = a.astype(np.float32) if a.dtype != np.uint8 else a
    tifffile.imwrite(fn, a, imagej=True, resolution=(1.0 / px[0], 1.0 / px[1]), metadata=md, compression='zlib')
