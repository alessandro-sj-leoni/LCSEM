"""Denoising of single SEM frames and of movies / image series, with the peer-reviewed methods that suit scanned-beam data.

Noise model. SEM pixel values are Poisson-Gaussian: x = B0 + a p + n, p ~ Poisson (detected electrons), n ~ N(0, s^2)
(detector/amplifier noise), so var(x) = a E[x] + b. `estimate_noise_model` fits (a, b) from the local mean-variance relation
of flat image regions (Foi et al. 2008 [1]). The generalized Anscombe transform (GAT [2]) makes the noise approximately
Gaussian with unit variance, so the Gaussian denoisers below work at the right strength everywhere; the closed-form
approximation of the exact unbiased inverse [3] maps the result back without bias.

Per frame:  'gaussian' smoothing; 'nlm' non-local means [4]; 'bm3d' block matching and 3-D filtering [5] (bm3d package,
            free for non-commercial use); 'tv' total variation [6, 7].
Series:     'mppca' Marchenko-Pastur PCA [8] over local patches x frames (random-matrix threshold of the PCA spectrum; the
            implementation follows DIPY's localpca [9]); 'svd_gd' optimal hard threshold of singular values for unknown noise
            [10] on overlapping tiles x frames; 'temporal_mean' / 'temporal_median' sliding windows (baselines).
Series methods need registered frames (lcsem.io_movie.register_stack) - drift destroys the low rank they exploit.

[1] A. Foi, M. Trimeche, V. Katkovnik, K. Egiazarian, IEEE Trans. Image Process. 17, 1737-1754 (2008).
[2] F. J. Anscombe, Biometrika 35, 246-254 (1948); J.-L. Starck, F. Murtagh, A. Bijaoui, Image Processing and Data Analysis,
    Cambridge University Press (1998).
[3] M. Makitalo, A. Foi, IEEE Trans. Image Process. 20, 2697-2698 (2011); 22, 91-103 (2013).
[4] A. Buades, B. Coll, J.-M. Morel, Multiscale Model. Simul. 4, 490-530 (2005).
[5] K. Dabov, A. Foi, V. Katkovnik, K. Egiazarian, IEEE Trans. Image Process. 16, 2080-2095 (2007); Y. Maekinen, L. Azzari,
    A. Foi, IEEE Trans. Image Process. 29, 8339-8354 (2020).
[6] L. I. Rudin, S. Osher, E. Fatemi, Physica D 60, 259-268 (1992).  [7] A. Chambolle, J. Math. Imaging Vis. 20, 89-97 (2004).
[8] J. Veraart, D. S. Novikov, D. Christiaens, B. Ades-Aron, J. Sijbers, E. Fieremans, NeuroImage 142, 394-406 (2016).
[9] E. Garyfallidis et al., Front. Neuroinform. 8, 8 (2014) (DIPY).
[10] M. Gavish, D. L. Donoho, IEEE Trans. Inf. Theory 60, 5040-5053 (2014).
"""
from __future__ import annotations
import numpy as np
from scipy import ndimage as ndi

FRAME_METHODS = ('none', 'gaussian', 'nlm', 'bm3d', 'tv')
STACK_METHODS = ('mppca', 'svd_gd', 'temporal_mean', 'temporal_median')
METHODS = FRAME_METHODS + STACK_METHODS

# ------------------------------------------------------------------------------------------------ noise model and GAT
def estimate_noise_model(img, mask=None, win=7, lo=None, hi=None, nbins=16):
    """(a, b) of var = a * mean + b from local statistics of the flattest windows (robust: median variance per mean bin,
    weighted least squares); clipped values (at lo / hi) are left out. a < 0 is clipped to 0 (pure Gaussian noise)."""
    x = np.asarray(img, np.float64)
    m = ndi.uniform_filter(x, win); v = ndi.uniform_filter(x * x, win) - m * m; v *= win * win / (win * win - 1.0)
    gy, gx = np.gradient(ndi.gaussian_filter(x, 2.0)); g = np.hypot(gy, gx)
    ok = np.isfinite(v) if mask is None else (mask & np.isfinite(v))
    lo = np.min(x) if lo is None else lo; hi = np.max(x) if hi is None else hi
    clip = ndi.maximum_filter((x <= lo) | (x >= hi), win); ok &= ~clip
    ok &= g <= np.percentile(g[ok], 30) if ok.any() else ok
    if ok.sum() < 50: return 0.0, float(np.var(x))
    mm, vv = m[ok], v[ok]; edges = np.unique(np.percentile(mm, np.linspace(0, 100, nbins + 1)))
    xs, ys, ws = [], [], []
    for a_, b_ in zip(edges[:-1], edges[1:]):
        s = (mm >= a_) & (mm <= b_)
        k = win * win - 1.0                                   # median of a variance estimate with k d.o.f. = (1 - 2 / 9k)^3 x its mean
        if s.sum() >= 20: xs.append(np.median(mm[s])); ys.append(np.median(vv[s]) / (1 - 2 / (9 * k)) ** 3); ws.append(s.sum())
    if len(xs) < 2: return 0.0, float(np.median(vv) / 0.7)
    X = np.vstack([xs, np.ones(len(xs))]).T; W = np.sqrt(ws)
    a, b = np.linalg.lstsq(X * W[:, None], np.array(ys) * W, rcond=None)[0]
    if a < 0: a, b = 0.0, float(np.average(ys, weights=ws))
    return float(a), float(b)

def gat(x, a, b):
    """generalized Anscombe transform for var(x) = a x + b: unit-variance, approximately Gaussian noise"""
    if a <= 1e-12: return (np.asarray(x, np.float64)) / np.sqrt(max(b, 1e-12))           # Gaussian noise only: plain scaling
    return 2.0 / a * np.sqrt(np.clip(a * np.asarray(x, np.float64) + 0.375 * a * a + b, 0, None))

def igat(D, a, b):
    """closed-form approximation of the exact unbiased inverse of the GAT (Makitalo & Foi 2011, 2013)"""
    D = np.asarray(D, np.float64)
    if a <= 1e-12: return D * np.sqrt(max(b, 1e-12))
    Dc = np.maximum(D, 0.8); r = np.sqrt(1.5)
    I = 0.25 * Dc ** 2 + 0.25 * r / Dc - 11.0 / 8.0 / Dc ** 2 + 0.625 * r / Dc ** 3 - 0.125
    return a * np.maximum(I, 0.0) - b / a

# ------------------------------------------------------------------------------------------------ single frames
def _sigma_mad(x):
    """robust noise sigma from differences of neighbours along x and y (MAD), at least the quantisation noise of integer data"""
    d = np.concatenate([np.diff(x, axis=1).ravel(), np.diff(x, axis=0).ravel()])
    return max(float(1.4826 * np.median(np.abs(d - np.median(d))) / np.sqrt(2)), 1.0 / np.sqrt(12))

def denoise_image(img, method='nlm', vst=False, noise=None, strength=1.0, mask=None, **kw):
    """one frame. vst: use the generalized Anscombe transform with the noise model `noise` = (a, b) (estimated if None).
    strength scales the method's smoothing (1 = the noise-matched default)."""
    x = np.asarray(img, np.float32)
    if method in (None, 'none'): return x.copy()
    if vst:
        a, b = noise if noise is not None else estimate_noise_model(x, mask)
        y = gat(x, a, b); sig = 1.0
    else:
        y = x.astype(np.float64); sig = _sigma_mad(y)
    if method == 'gaussian': z = ndi.gaussian_filter(y, kw.get('sigma_px', 1.5 * strength))
    elif method == 'nlm':
        from skimage.restoration import denoise_nl_means
        z = denoise_nl_means(y, h=kw.get('h_factor', 0.9) * strength * sig, sigma=sig, patch_size=kw.get('patch', 5), patch_distance=kw.get('distance', 9),
                             fast_mode=True, preserve_range=True)
    elif method == 'bm3d':
        import bm3d
        z = bm3d.bm3d(y, sigma_psd=sig * strength)
    elif method == 'tv':
        from skimage.restoration import denoise_tv_chambolle
        z = denoise_tv_chambolle(y, weight=kw.get('weight', 1.0) * strength * sig)
    else:
        raise ValueError(f'{method} is not a single-frame method (use denoise_stack)')
    return (igat(z, a, b) if vst else z).astype(np.float32)

# ------------------------------------------------------------------------------------------------ series
def _pca_classifier(L, nvox):
    """Marchenko-Pastur classification of eigenvalues L (ascending) of a covariance from nvox samples: returns the noise
    variance and the number of noise components (Veraart et al. 2016, as implemented in DIPY)"""
    if L.size > nvox - 1: L = L[-(nvox - 1):]
    var = np.mean(L); c = L.size - 1
    r = L[c] - L[0] - 4 * np.sqrt((c + 1.0) / nvox) * var
    while r > 0 and c > 0:
        var = np.mean(L[:c]); c -= 1
        r = L[c] - L[0] - 4 * np.sqrt((c + 1.0) / nvox) * var
    return var, c + 1

def mppca(stack, patch=None, stride=None, tblock=32, return_sigma=False):
    """Marchenko-Pastur PCA denoising of a registered series (T, Y, X): every patch x patch window is a matrix of
    (pixels x frames); its PCA eigenvalues below the Marchenko-Pastur edge are noise and are removed; overlapping patches are
    averaged with the weights 1 / (1 + number of kept components) (DIPY). Long series are processed in overlapping blocks of
    `tblock` frames."""
    A = np.asarray(stack, np.float64); T, ny, nx = A.shape
    if T < 3: return A.astype(np.float32)
    if T > tblock:                                              # overlapping temporal blocks, linear cross-fade
        out = np.zeros_like(A); wsum = np.zeros(T); step = tblock // 2; starts = list(range(0, T - tblock + 1, step))
        if starts[-1] != T - tblock: starts.append(T - tblock)
        for s in starts:
            w = np.minimum(np.arange(1, tblock + 1), np.arange(tblock, 0, -1)).astype(float)
            out[s:s + tblock] += mppca(A[s:s + tblock], patch, stride, tblock) * w[:, None, None]; wsum[s:s + tblock] += w
        return (out / wsum[:, None, None]).astype(np.float32)
    p = patch or max(7, int(np.ceil(2 * np.sqrt(T))) | 1)       # odd p with p^2 >= 4 T pixels per patch (13 x 13 for 32 frames)
    st = stride or max(1, p // 2); ys = list(range(0, ny - p + 1, st)); xs = list(range(0, nx - p + 1, st))
    if ys[-1] != ny - p: ys.append(ny - p)
    if xs[-1] != nx - p: xs.append(nx - p)
    acc = np.zeros((T, ny, nx)); wacc = np.zeros((ny, nx)); sig = []
    for y0 in ys:
        blk = np.stack([A[:, y0:y0 + p, x0:x0 + p].reshape(T, -1).T for x0 in xs])    # (nx_patches, p*p samples, T dims)
        mu = blk.mean(axis=1, keepdims=True); Xc = blk - mu
        C = np.einsum('kni,knj->kij', Xc, Xc) / Xc.shape[1]; d, W = np.linalg.eigh(C)
        for j, x0 in enumerate(xs):
            var, ncomp = _pca_classifier(d[j], Xc.shape[1]); tau = (1 + np.sqrt(T / Xc.shape[1])) ** 2 * var
            keep = d[j] >= tau; Wk = W[j][:, keep]; Xe = Xc[j] @ Wk @ Wk.T + mu[j]
            th = 1.0 / (1.0 + keep.sum()); acc[:, y0:y0 + p, x0:x0 + p] += th * Xe.T.reshape(T, p, p); wacc[y0:y0 + p, x0:x0 + p] += th
            sig.append(np.sqrt(max(var, 0)))
    out = (acc / np.maximum(wacc, 1e-12)).astype(np.float32)
    return (out, float(np.median(sig))) if return_sigma else out

def _gd_omega(beta):
    return 0.56 * beta ** 3 - 0.95 * beta ** 2 + 1.82 * beta + 1.43

def _gd_lambda(beta):
    """optimal hard-threshold coefficient for known noise (Gavish & Donoho 2014, eq. 11)"""
    return np.sqrt(2 * (beta + 1) + 8 * beta / ((beta + 1) + np.sqrt(beta ** 2 + 14 * beta + 1)))

def svd_gd(stack, tile=48, return_rank=False, sigma=None):
    """optimal hard threshold of singular values (Gavish & Donoho 2014): overlapping tiles x frames; with known noise sigma
    (e.g. 1 after variance stabilisation) the threshold lambda*(beta) sqrt(n) sigma, otherwise omega(beta) times the median
    singular value (the null singular value left by removing the temporal mean is excluded); Hann-weighted blending"""
    A = np.asarray(stack, np.float64); T, ny, nx = A.shape; t = min(tile, ny, nx); st = max(1, t // 2)
    ys = list(range(0, ny - t + 1, st)); xs = list(range(0, nx - t + 1, st))
    if ys[-1] != ny - t: ys.append(ny - t)
    if xs[-1] != nx - t: xs.append(nx - t)
    w1 = np.hanning(t + 2)[1:-1]; w2 = np.outer(w1, w1) + 1e-3
    acc = np.zeros((T, ny, nx)); wacc = np.zeros((ny, nx)); ranks = []
    for y0 in ys:
        for x0 in xs:
            Y = A[:, y0:y0 + t, x0:x0 + t].reshape(T, -1).T            # (pixels, frames)
            mu = Y.mean(axis=1, keepdims=True); U, s, Vt = np.linalg.svd(Y - mu, full_matrices=False)
            n, m = Y.shape; mm = min(n, m) - 1; beta = mm / max(n, m)            # centring removes one dimension
            tau = _gd_lambda(beta) * np.sqrt(max(n, m)) * sigma if sigma else _gd_omega(beta) * np.median(s[:mm])
            k = int((s > tau).sum()); ranks.append(k)
            Ye = (U[:, :k] * s[:k]) @ Vt[:k] + mu
            acc[:, y0:y0 + t, x0:x0 + t] += Ye.T.reshape(T, t, t) * w2; wacc[y0:y0 + t, x0:x0 + t] += w2
    out = (acc / np.maximum(wacc, 1e-12)).astype(np.float32)
    return (out, float(np.median(ranks))) if return_rank else out

def denoise_stack(stack, method='mppca', vst=False, noise=None, strength=1.0, window=5, **kw):
    """a series (T, Y, X): series methods act across frames; frame methods are applied to every frame. With vst the
    noise model is estimated on the whole series (median of the per-frame fits) unless given."""
    A = np.asarray(stack, np.float32)
    if method in (None, 'none'): return A.copy()
    if method in FRAME_METHODS:
        nm = noise if (noise is not None or not vst) else _series_noise(A)
        return np.stack([denoise_image(f, method, vst=vst, noise=nm, strength=strength, **kw) for f in A])
    if vst:
        a, b = noise if noise is not None else _series_noise(A); Y = gat(A, a, b)
    else: Y = A.astype(np.float64)
    if method == 'mppca': Z = mppca(Y, kw.get('patch'), kw.get('stride'), kw.get('tblock', 32))
    elif method == 'svd_gd': Z = svd_gd(Y, kw.get('tile', 48), sigma=1.0 if vst else None)
    elif method == 'temporal_mean': Z = ndi.uniform_filter1d(Y, size=int(window), axis=0, mode='nearest')
    elif method == 'temporal_median': Z = ndi.median_filter(Y, size=(int(window), 1, 1), mode='nearest')
    else: raise ValueError(f'unknown method {method}')
    return (igat(Z, a, b) if vst else Z).astype(np.float32)

def _series_noise(A, max_frames=8):
    idx = np.linspace(0, len(A) - 1, min(max_frames, len(A))).astype(int)
    ab = np.array([estimate_noise_model(A[i]) for i in idx]); return float(np.median(ab[:, 0])), float(np.median(ab[:, 1]))

def describe(method):
    return {'none': 'no denoising', 'gaussian': 'Gaussian smoothing', 'nlm': 'non-local means (Buades et al. 2005)',
            'bm3d': 'BM3D (Dabov et al. 2007)', 'tv': 'total variation (Rudin, Osher & Fatemi 1992; Chambolle 2004)',
            'mppca': 'Marchenko-Pastur PCA (Veraart et al. 2016)', 'svd_gd': 'optimal SVD hard threshold (Gavish & Donoho 2014)',
            'temporal_mean': 'sliding temporal mean', 'temporal_median': 'sliding temporal median'}.get(method, method)
