"""Depth (z) of particles inside the liquid from the images, calibrated by Monte Carlo profiles.

Two physical cues, both computed for the actual cell, detector, beam energy, particle size and pixel size:
  core fraction (one detector, one kV)  The beam spreads laterally as it goes down through the liquid (beam broadening),
      so a particle just under the top membrane gives a sharp image and a deeper one a blurred image with the same
      integrated excess spread into a halo. CF = excess inside R + 10 nm / excess inside R + 60 nm decreases with depth.
      (The scanning analogue of the 'top-bottom effect' of liquid-cell STEM.)
  signal ratio (two detectors, or two kV)  The integrated excess of a particle depends on depth differently for different
      detectors (BSE vs STEM of the same scan) or beam energies (e.g. 8 vs 15 kV), so Q = A1 / A2 is a depth gauge.
Photometry uses the same pixel apertures on the data as on the rendered Monte Carlo profile, so pixelation and the probe
blur enter both identically. Errors: pixel noise propagated to CF and Q, divided by the local slope of the model curve.
"""
from __future__ import annotations
import numpy as np
from .mc.radial import render

def _measure_on(img, y, x, px, R, core_extra, flux_extra, sigma_noise=None, neighbors=None):
    """aperture sums around (y, x) (pixels) on img; radii in nm; returns dict with A (flux excess, grey px^2), Ac (core), CF, sCF, sA.
    neighbors: (y, x) of other particles; their surroundings (R + flux_extra) are removed from the background annulus, and the
    measurement is flagged 'crowded' if one lies inside 2 (R + flux_extra) (then the aperture itself is contaminated)."""
    ny, nx = img.shape; ra = R + flux_extra; rc = R + core_extra; rin, rout = 1.33 * ra, 2.2 * ra
    hy, hx = int(np.ceil(rout / px[1])) + 1, int(np.ceil(rout / px[0])) + 1
    y0, y1, x0, x1 = int(y) - hy, int(y) + hy + 1, int(x) - hx, int(x) + hx + 1
    if y0 < 0 or x0 < 0 or y1 > ny or x1 > nx: return None
    sub = img[y0:y1, x0:x1]; Y, X = np.mgrid[y0:y1, x0:x1]; r = np.hypot((X - x) * px[0], (Y - y) * px[1])
    ok = np.isfinite(sub); crowded = False
    if neighbors is not None and len(neighbors):
        for (yn, xn) in neighbors:
            dn = np.hypot((xn - x) * px[0], (yn - y) * px[1])
            if dn < 1e-6 or dn > rout + ra: continue
            if dn < 2 * ra: crowded = True
            ok &= np.hypot((X - xn) * px[0], (Y - yn) * px[1]) >= ra
    bgm = (r >= rin) & (r < rout) & ok
    if bgm.sum() < 10: return None
    # background: plane fitted to the annulus with iterative 3-sigma clipping (robust to gradients, e.g. membrane bulging)
    dX, dY = (X - x)[bgm], (Y - y)[bgm]; v = sub[bgm]; G = np.c_[np.ones(v.size), dX, dY]; keep = np.ones(v.size, bool)
    for _ in range(3):
        coef, *_ = np.linalg.lstsq(G[keep], v[keep], rcond=None); res = v - G @ coef; s_ = 1.4826 * np.median(np.abs(res[keep])) + 1e-9
        keep = np.abs(res) < 3 * s_
    plane = coef[0] + coef[1] * (X - x) + coef[2] * (Y - y); bg = float(coef[0])
    c = (r < rc) & ok; f = (r < ra) & ok
    Ac = float((sub[c] - plane[c]).sum()); A = float((sub[f] - plane[f]).sum()); nc, nf, nb = int(c.sum()), int(f.sum()), int(keep.sum())
    out = dict(A=A, Ac=Ac, CF=Ac / A if A != 0 else np.nan, n_core=nc, n_flux=nf, bg=bg, crowded=crowded)
    if sigma_noise is not None:
        s2 = sigma_noise ** 2; Ah = A - Ac; nh = nf - nc
        sbg = sigma_noise / np.sqrt(nb)                                 # error of the fitted background level
        out['sA'] = float(np.sqrt(s2 * nf + (nf * sbg) ** 2))
        out['sCF'] = float(np.sqrt((Ah ** 2 * s2 * nc + Ac ** 2 * s2 * nh) / A ** 4)) if A != 0 else np.nan
    return out

def refine_center(img, y, x, px, R, core_extra=10.0, n_iter=4):
    """sub-pixel centre: iterated first moment of the background-subtracted signal inside R + core_extra
    (a centring error of a fraction of a pixel lowers the measured core fraction, so this matters at low magnification)"""
    ny, nx = img.shape; rc = R + core_extra; ra = R + 60.0; rin, rout = 1.33 * ra, 2.2 * ra
    hy, hx = int(np.ceil(rout / px[1])) + 1, int(np.ceil(rout / px[0])) + 1
    for _ in range(n_iter):
        y0, y1, x0, x1 = int(round(y)) - hy, int(round(y)) + hy + 1, int(round(x)) - hx, int(round(x)) + hx + 1
        if y0 < 0 or x0 < 0 or y1 > ny or x1 > nx: return y, x
        sub = img[y0:y1, x0:x1]; Y, X = np.mgrid[y0:y1, x0:x1]; r = np.hypot((X - x) * px[0], (Y - y) * px[1])
        ok = np.isfinite(sub); bgm = (r >= rin) & (r < rout) & ok
        if bgm.sum() < 10: return y, x
        w = np.clip(sub - np.median(sub[bgm]), 0, None) * ((r < rc) & ok)
        if w.sum() <= 0: return y, x
        yn, xn = float((w * Y).sum() / w.sum()), float((w * X).sum() / w.sum())
        if abs(yn - y) < 0.01 and abs(xn - x) < 0.01: return yn, xn
        y, x = yn, xn
    return y, x

def measure(img, y, x, px_nm, d_nm, core_extra=10.0, flux_extra=60.0, sigma_noise=None, refine=True, sign=1.0, lo=None, hi=None, neighbors=None):
    """photometry of one particle; sign = -1 for particles that appear dark (STEM bright field)"""
    if refine:
        yy, xx = refine_center(sign * img, y, x, px_nm, d_nm / 2, core_extra)
        if np.hypot(yy - y, xx - x) < 3: y, x = yy, xx
    m = _measure_on(img, y, x, px_nm, d_nm / 2, core_extra, flux_extra, sigma_noise, neighbors)
    if m is not None:
        m['y'], m['x'] = y, x
        if lo is not None or hi is not None:     # clipped pixels in the core, on the side the particle is (bright: hi, dark: lo)
            rc = d_nm / 2 + core_extra; hy, hx = int(np.ceil(rc / px_nm[1])) + 1, int(np.ceil(rc / px_nm[0])) + 1
            y0, x0 = max(0, int(round(y)) - hy), max(0, int(round(x)) - hx); sub = img[y0:int(round(y)) + hy + 1, x0:int(round(x)) + hx + 1]
            Y, X = np.mgrid[y0:y0 + sub.shape[0], x0:x0 + sub.shape[1]]; core = np.hypot((X - x) * px_nm[0], (Y - y) * px_nm[1]) < rc
            clipped = (sub >= hi) if (sign > 0 and hi is not None) else ((sub <= lo) if (sign < 0 and lo is not None) else np.zeros(sub.shape, bool))
            m['n_sat'] = int((clipped & core).sum())
    return m

class ParticleModel:
    """CF(z, T) and integrated excess A(z, T) of one particle size for one detector, from Monte Carlo profiles
    (lcsem.mc.curves.particle_profiles output), measured on rendered pixel images exactly like the data."""
    def __init__(self, particle: dict, detector: str, px_nm, probe_nm=2.0, core_extra=10.0, flux_extra=60.0, offsets=((0, 0), (0.37, 0.21))):
        self.d = float(particle['diameter_nm']); R = self.d / 2; self.detector = detector; self.px = tuple(px_nm)
        rows = {}
        for p in particle['profiles']:
            e = np.asarray(p['edges']); rc = 0.5 * (e[1:] + e[:-1]); prof = np.asarray(p['det'][detector]['prof'])
            if probe_nm > 0:      # probe blur: Gaussian smoothing in r of the 1-nm bins
                from scipy.ndimage import gaussian_filter1d
                fine = np.diff(e) < 1.5; q = prof.copy(); q[fine] = gaussian_filter1d(prof[fine], probe_nm / 1.0, mode='nearest'); prof = q
            cfs, As = [], []
            for oy, ox in offsets:
                half = 2.3 * (R + flux_extra) + 3 * max(self.px)
                img = render(rc, prof, self.px, half, center=(ox * self.px[0], oy * self.px[1]))
                cy, cx = img.shape[0] / 2 - 0.5 + oy, img.shape[1] / 2 - 0.5 + ox
                m = _measure_on(img, cy, cx, self.px, R, core_extra, flux_extra)
                cfs.append(m['CF']); As.append(m['A'] * self.px[0] * self.px[1])       # signal per primary x nm^2
            rows.setdefault(p['T_nm'], []).append((p['z_center_nm'], float(np.mean(cfs)), float(np.mean(As))))
        self.T = np.array(sorted(rows)); self.tab = {T: np.array(sorted(rows[T])) for T in self.T}
    def _at(self, T, col):
        T = float(np.clip(T, self.T[0], self.T[-1])); i = np.searchsorted(self.T, T)
        if i == 0 or self.T[i] == T or i == len(self.T): Tk = self.T[min(i, len(self.T) - 1)]; t = self.tab[Tk]; return t[:, 0], t[:, col]
        # interpolate in T on a normalized depth coordinate u = (z - R) / (T - 2R)
        R = self.d / 2; a, b = self.tab[self.T[i - 1]], self.tab[self.T[i]]; w = (T - self.T[i - 1]) / (self.T[i] - self.T[i - 1])
        ua = (a[:, 0] - R) / (self.T[i - 1] - 2 * R); ub = (b[:, 0] - R) / (self.T[i] - 2 * R); u = np.linspace(0, 1, 9)
        v = (1 - w) * np.interp(u, ua, a[:, col]) + w * np.interp(u, ub, b[:, col])
        return R + u * (T - 2 * R), v
    def cf(self, T): return self._at(T, 1)
    def excess(self, T): return self._at(T, 2)
    def z_from_cf(self, cf, scf, T):
        z, c = self.cf(T); return _invert(z, c, cf, scf)

def _invert(z, v, val, sval):
    """z where the model curve v(z) equals val; error = sval / |dv/dz| (smoothed slope); a value outside the model range
    returns the nearest end with an error of at least a third of the range"""
    zz = np.linspace(z[0], z[-1], 400); vv = np.interp(zz, z, v); i = int(np.argmin(np.abs(vv - val)))
    sl = np.gradient(vv, zz); sl = np.convolve(sl, np.ones(21) / 21, mode='same')[i]
    s = abs(sval / sl) if sl != 0 else np.inf
    lo, hi = vv.min(), vv.max()
    if (val < lo - sval) or (val > hi + sval): s = max(s, (zz[-1] - zz[0]) / 3)
    return float(zz[i]), float(s)

def z_from_ratio(Q, sQ, m1: ParticleModel, m2: ParticleModel, T):
    """depth from the ratio of integrated excesses A1/A2 (both in signal-per-primary x nm^2 units)"""
    z1, a1 = m1.excess(T); z2, a2 = m2.excess(T); zz = np.linspace(max(z1[0], z2[0]), min(z1[-1], z2[-1]), 50)
    q = np.interp(zz, z1, a1) / np.interp(zz, z2, a2)
    return _invert(zz, q, Q, sQ)

def combine(estimates):
    """inverse-variance combination of (z, sz) pairs, ignoring non-finite ones"""
    e = [(z, s) for z, s in estimates if np.isfinite(z) and np.isfinite(s) and s > 0]
    if not e: return np.nan, np.nan
    w = np.array([1 / s ** 2 for _, s in e]); z = np.array([z for z, _ in e]); return float((w * z).sum() / w.sum()), float(1 / np.sqrt(w.sum()))
