"""Dynamics maps on the drift-corrected canvas.

  dT/dt      rate of change of the liquid thickness between consecutive frames, using each pixel pair's own acquisition times
             (the raster is a clock), NaN where not imaged in both frames
  dry state  per frame: 0 wet, 1 dry (SE-dark), 255 not imaged / no SE; occupancy, first / last dry time, wet<->dry transitions
  boundary   normal displacement of the dry-region boundary between consecutive SE frames (signed distance transform of the
             later boundary sampled on the earlier one; + = the dry region advanced), per-interval table
"""
from __future__ import annotations
import os, numpy as np, pandas as pd, tifffile
from scipy import ndimage as ndi

def _write(fn, arr, px, info, axes=None):
    md = {'unit': 'nm', 'Info': info}
    if axes: md['axes'] = axes
    tifffile.imwrite(fn, np.asarray(arr, np.float32), imagej=True, resolution=(1 / px[0], 1 / px[1]), metadata=md, compression='zlib')

def run(C, px, out_dir, name='series', log=print):
    n = len(C); H, W = C[0]['T'].shape; t0 = min(c['t_end'] - c['frame_s'] for c in C)
    dT = np.full((n - 1, H, W), np.nan, np.float32); dTdt = np.full((n - 1, H, W), np.nan, np.float32); rows = []
    for i in range(n - 1):
        a, b = C[i], C[i + 1]; ok = a['valid'] & b['valid'] & ~a['au'] & ~b['au']; dt = b['t'] - a['t']
        dT[i][ok] = (b['T'] - a['T'])[ok]; dTdt[i][ok] = (dT[i] / np.where(dt > 0, dt, np.nan))[ok]
        rows.append(dict(interval=f"{a['label']}->{b['label']}", dt_s_median=float(np.nanmedian(dt[ok])) if ok.any() else np.nan,
                         dT_median_nm=float(np.nanmedian(dT[i][ok])) if ok.any() else np.nan, frac_thinning_50nm=float((dT[i][ok] < -50).mean()) if ok.any() else np.nan,
                         frac_thickening_50nm=float((dT[i][ok] > 50).mean()) if ok.any() else np.nan))
    _write(os.path.join(out_dir, f'{name}_dT_nm.tif'), dT, px, 'liquid thickness change between consecutive frames (nm)', 'TYX')
    _write(os.path.join(out_dir, f'{name}_dTdt_nm_per_s.tif'), dTdt, px, 'rate of change of the liquid thickness (nm/s), per-pixel times', 'TYX')
    has = [i for i, c in enumerate(C) if c['se']]
    if len(has) >= 2:
        dry = np.full((n, H, W), 255, np.uint8)
        for i in has: dry[i][C[i]['valid']] = C[i]['dark'][C[i]['valid']].astype(np.uint8)
        tifffile.imwrite(os.path.join(out_dir, f'{name}_dry_state.tif'), dry, imagej=True, resolution=(1 / px[0], 1 / px[1]),
                         metadata={'unit': 'nm', 'axes': 'TYX', 'Info': '0 wet, 1 dry (SE-dark), 255 not imaged / no SE'}, compression='zlib')
        S = np.stack([dry[i] for i in has]).astype(np.float32); S[S == 255] = np.nan
        occ = np.nanmean(S, axis=0); nobs = np.sum(np.isfinite(S), axis=0); tf = np.array([C[i]['t_end'] - t0 for i in has], np.float32)
        first = np.full((H, W), np.nan, np.float32); last = np.full((H, W), np.nan, np.float32); trans = np.zeros((H, W), np.float32)
        for k in range(len(has)):
            m = S[k] == 1; first = np.where(np.isnan(first) & m, tf[k], first); last = np.where(m, tf[k], last)
            if k: trans += np.abs(np.nan_to_num(S[k] - S[k - 1]))
        occ[nobs < 2] = np.nan; trans[nobs < 2] = np.nan
        _write(os.path.join(out_dir, f'{name}_dry_occupancy.tif'), occ, px, 'fraction of SE frames with a dry top membrane')
        _write(os.path.join(out_dir, f'{name}_dry_first_s.tif'), first, px, f'time of the first dry frame (s after {t0:.0f} s since midnight)')
        _write(os.path.join(out_dir, f'{name}_dry_last_s.tif'), last, px, 'time of the last dry frame (s)')
        _write(os.path.join(out_dir, f'{name}_dry_transitions.tif'), trans, px, 'number of wet<->dry transitions')
        disp = np.full((n - 1, H, W), np.nan, np.float32); brow = []
        from scipy.spatial import cKDTree
        for i in range(n - 1):
            a, b = C[i], C[i + 1]
            if not (a['se'] and b['se']): continue
            va = a['valid'] & b['valid']; da = a['dark'] & va; db = b['dark'] & va
            if da.sum() < 100 or db.sum() < 100: continue
            sd = np.where(db, ndi.distance_transform_edt(db), -ndi.distance_transform_edt(~db)) * px[0]
            edge = da & ~ndi.binary_erosion(da, iterations=1) & ndi.binary_erosion(va, iterations=12)
            if not edge.any(): continue
            vals = sd[edge]; idx = np.argwhere(edge); dl = ndi.binary_dilation(edge, iterations=2); ys, xs = np.nonzero(dl)
            _, j = cKDTree(idx).query(np.c_[ys, xs]); disp[i][ys, xs] = vals[j]
            dt = float(np.nanmedian((b['t'] - a['t'])[edge]))
            brow.append(dict(interval=f"{a['label']}->{b['label']}", dt_s=dt, boundary_px=int(edge.sum()), median_normal_disp_nm=float(np.median(vals)),
                             p10_nm=float(np.percentile(vals, 10)), p90_nm=float(np.percentile(vals, 90)), median_speed_nm_s=float(np.median(vals) / dt) if dt > 0 else np.nan,
                             dry_area_um2_a=float(da.sum() * px[0] * px[1] / 1e6), dry_area_um2_b=float(db.sum() * px[0] * px[1] / 1e6)))
        _write(os.path.join(out_dir, f'{name}_dry_boundary_disp_nm.tif'), disp, px, 'normal displacement of the dry boundary of frame i to frame i+1 (nm; + = dry region advanced)', 'TYX')
        pd.DataFrame(brow).to_csv(os.path.join(out_dir, f'{name}_boundary_motion.csv'), index=False)
    pd.DataFrame(rows).to_csv(os.path.join(out_dir, f'{name}_thickness_change.csv'), index=False)
    log(f'dynamics maps written ({n - 1} intervals)')
