"""Image-processing primitives: masked smoothing, denoising, clipping (censoring) correction, registration, particle masks.

References (see METHODS.md for the full list)
  normalized convolution        Knutsson & Westin, CVPR 1993
  non-local means               Buades, Coll & Morel, SIAM MMS 4, 490 (2005); implementation: scikit-image
  robust noise estimate         Donoho & Johnstone, Biometrika 81, 425 (1994) (MAD of first differences)
  censored-normal mean          Cohen, Technometrics 1, 217 (1959); we invert E[clip(X,0,255)] numerically
  phase correlation             Guizar-Sicairos, Thurman & Fienup, Opt. Lett. 33, 156 (2008); implementation: scikit-image
  particle detection            matched filter + noise threshold, Bertin & Arnouts, A&AS 117, 393 (1996)
  aperture photometry           Howell, PASP 101, 616 (1989)
"""
from __future__ import annotations
import numpy as np
from scipy import ndimage as ndi
from scipy.stats import norm
from skimage.restoration import denoise_nl_means
from skimage.registration import phase_cross_correlation

# ----------------------------------------------------------------- smoothing with missing data
def smooth_masked(img, invalid, sigma):
    """Gaussian smoothing that ignores `invalid` pixels (normalized convolution)."""
    w = (~invalid).astype(np.float32)
    a = ndi.gaussian_filter(np.where(invalid, 0, img).astype(np.float32), sigma)
    b = ndi.gaussian_filter(w, sigma)
    return a / np.maximum(b, 1e-3)

def fill_masked(img, invalid, sigma=6):
    """replace invalid pixels by the local mean of the valid ones"""
    out = img.astype(np.float32).copy(); f = smooth_masked(img, invalid, sigma); out[invalid] = f[invalid]; return out

# ----------------------------------------------------------------- noise and denoising
def noise_sigma_censored(img, valid=None, lo=0.0, hi=255.0, n_max=200000, seed=0):
    """Gaussian noise sigma of an 8-bit image with clipping, by maximum likelihood on the pixel values of a locally flat region
    (censored normal, Cohen 1959): the local mean is removed with a 25-px normalized smoothing, then (mu, sigma) are fitted
    with censoring at lo/hi. Use when more than ~2 % of the pixels are clipped (the MAD estimate is then biased low)."""
    from scipy.special import log_ndtr
    from scipy.optimize import minimize
    a = img.astype(np.float32); m = np.ones(a.shape, bool) if valid is None else valid
    loc = smooth_masked(a, ~m, 25); r = (a - loc)[m]; c = np.clip(a, lo, hi)[m]; lo_r = (lo - loc)[m]; hi_r = (hi - loc)[m]
    rng = np.random.default_rng(seed); i = rng.choice(r.size, min(n_max, r.size), replace=False); r, lo_r, hi_r = r[i], lo_r[i], hi_r[i]
    is_lo = c[i] <= lo; is_hi = c[i] >= hi; mid = ~(is_lo | is_hi)
    def nll(p):
        mu, s = p[0], abs(p[1]) + 1e-3
        v = 0.5 * np.sum(((r[mid] - mu) / s) ** 2) + mid.sum() * np.log(s)
        if is_lo.any(): v -= np.sum(log_ndtr((lo_r[is_lo] - mu) / s))
        if is_hi.any(): v -= np.sum(log_ndtr((mu - hi_r[is_hi]) / s))
        return v
    res = minimize(nll, [0.0, max(noise_sigma_mad(img, valid), 5.0)], method='Nelder-Mead', options=dict(xatol=0.01, fatol=0.1))
    return float(abs(res.x[1]))

def noise_sigma_mad(img, valid=None):
    """robust per-pixel noise: MAD of horizontal first differences / sqrt(2) (Donoho & Johnstone 1994)"""
    a = img.astype(np.float32)
    d = a[:, 1:] - a[:, :-1]
    if valid is not None: d = d[valid[:, 1:] & valid[:, :-1]]
    d = d.ravel(); return float(1.4826 * np.median(np.abs(d - np.median(d))) / np.sqrt(2))

def denoise_nlm(img, invalid=None, sigma=None, patch=5, distance=9, h_factor=0.9):
    """non-local means (Buades 2005). Invalid pixels are filled with the local mean before denoising."""
    a = img.astype(np.float32).copy()
    if invalid is not None and invalid.any(): a = fill_masked(a, invalid)
    if sigma is None: sigma = noise_sigma_mad(a, None if invalid is None else ~invalid)
    return denoise_nl_means(a, h=h_factor * sigma, sigma=sigma, patch_size=patch, patch_distance=distance, fast_mode=True, preserve_range=True).astype(np.float32), sigma

# ----------------------------------------------------------------- 8-bit clipping (censoring) correction
def _clip_table(sigma, lo=0.0, hi=255.0):
    mu = np.arange(lo - 3 * sigma, hi + 3 * sigma, 0.5)
    z0 = (lo - mu) / sigma; z1 = (hi - mu) / sigma
    E = mu * (norm.cdf(z1) - norm.cdf(z0)) + sigma * (norm.pdf(z0) - norm.pdf(z1)) + lo * norm.cdf(z0) + hi * (1 - norm.cdf(z1))
    return mu, E

def unclip_mean(clipped_mean, sigma, lo=0.0, hi=255.0):
    """Given the mean of values that were clipped to [lo, hi] and the (unclipped) Gaussian noise sigma, return the
    underlying mean (inverse of the censored-normal expectation; Cohen 1959). Works on arrays."""
    mu, E = _clip_table(sigma, lo, hi)
    return np.interp(clipped_mean, E, mu)

# ----------------------------------------------------------------- registration
def register_by_particles(pts_ref, pts_mov, max_shift=600, bin_px=10, refine_px=30):
    """translation (dy, dx) from two coordinate lists (y, x): the mode of all pairwise displacement vectors
    (Groth, Astron. J. 91, 1244 (1986)-style voting), refined by the median of the matched pairs. `refine_px` should exceed the
    relative scan-geometry distortion between frames (a few % of the image at different scan speeds). Returns (dy, dx, n_matched)."""
    if len(pts_ref) < 2 or len(pts_mov) < 2: return None
    d = (np.asarray(pts_ref)[:, None, :2] - np.asarray(pts_mov)[None, :, :2]).reshape(-1, 2)
    d = d[(np.abs(d[:, 0]) < max_shift) & (np.abs(d[:, 1]) < max_shift)]
    if len(d) == 0: return None
    H, ye, xe = np.histogram2d(d[:, 0], d[:, 1], bins=[np.arange(-max_shift, max_shift + bin_px, bin_px)] * 2)
    # the ten most-voted bins are candidates; for each, votes within +-refine_px of its centre are counted (so that votes split
    # between neighbouring bins add up) and the centre is re-estimated; the candidate with most votes wins, ties go to the
    # smallest displacement (drift between consecutive frames is usually small)
    flat = np.argsort(H.ravel())[::-1][:10]; best = None
    for f in flat:
        if H.ravel()[f] < 1: break
        iy, ix = np.unravel_index(f, H.shape); cy, cx = ye[iy] + bin_px / 2, xe[ix] + bin_px / 2
        for _ in range(2):
            sel = (np.abs(d[:, 0] - cy) <= refine_px) & (np.abs(d[:, 1] - cx) <= refine_px)
            if sel.sum() < 2: break
            cy, cx = np.median(d[sel, 0]), np.median(d[sel, 1])
        n = int(sel.sum())
        if n < 2: continue
        key = (-n, np.hypot(cy, cx))
        if best is None or key < best[0]: best = (key, sel)
    if best is None: return None
    sel = best[1]
    return float(np.median(d[sel, 0])), float(np.median(d[sel, 1])), int(sel.sum())

def register_translation(ref, mov, ref_valid=None, mov_valid=None, sigma=2.0, upsample=10):
    """translation (dy, dx) that maps `mov` onto `ref` by masked phase correlation on lightly smoothed images"""
    a = smooth_masked(ref, ~ref_valid if ref_valid is not None else np.zeros(ref.shape, bool), sigma)
    b = smooth_masked(mov, ~mov_valid if mov_valid is not None else np.zeros(mov.shape, bool), sigma)
    a = a - np.nanmean(a[ref_valid] if ref_valid is not None else a); b = b - np.nanmean(b[mov_valid] if mov_valid is not None else b)
    if ref_valid is not None or mov_valid is not None:
        shift = phase_cross_correlation(a, b, reference_mask=ref_valid, moving_mask=mov_valid)
        shift = shift[0] if isinstance(shift, tuple) else shift
    else:
        shift, err, _ = phase_cross_correlation(a, b, upsample_factor=upsample)
    return np.asarray(shift, float)

def shift_image(img, dy, dx, fill=np.nan):
    """sub-pixel shift with NaN fill outside"""
    a = np.nan_to_num(img, nan=0.0).astype(np.float32); m = np.isfinite(img).astype(np.float32)
    s = ndi.shift(a, (dy, dx), order=1, mode='constant', cval=0.0); w = ndi.shift(m, (dy, dx), order=1, mode='constant', cval=0.0)
    out = np.where(w > 0.99, s, fill); return out

# ----------------------------------------------------------------- particles
def detect_particles(img, valid=None, sigma_min=1.5, sigma_max=6.0, threshold=5.0, smooth=1.0, bg_sigma=8.0, sat_level=255.0, edge_ratio=10.0, isolation=0.5,
                     rings=(1.0, 1.5, 2.0)):
    """bright particles by matched filtering (Gaussian kernel minus local background, SExtractor-style detection:
    Bertin & Arnouts, A&AS 117, 393 (1996)). `threshold` is in units of the noise of the filtered image (robust MAD estimate).
    Sigma candidates between sigma_min and sigma_max are tried and the best response kept. Edge-like responses (the bright
    side of a bubble rim or any thickness step) are rejected with the Hessian test of Lowe (IJCV 60, 91, 2004): a peak is kept
    only if both principal curvatures of the filtered image are negative and their ratio is below edge_ratio (0 = no test),
    and if, on a ring of radius max(2.5 sigma, 3 px) around it, the filtered image reaches `isolation` x the peak only on
    one side (`_ring_isolated`: a ridge - bubble rim, bright side of a step - crosses the ring on opposite sides; a
    neighbouring particle or a nearby step only on one). Validation: docs/VALIDATION.md (rims, pairs, steps).
    Returns rows (y, x, sigma)."""
    a = img.astype(np.float32)
    if valid is not None: a = fill_masked(a, ~valid)
    sat = ndi.uniform_filter((img >= sat_level).astype(np.float32), max(15, int(6 * sigma_max + 1))) > 0.25
    b = int(2 * sigma_max + 2); out = []; taken = np.zeros(a.shape, bool)
    # fine scales first: a peak found at a scale is kept there, and coarser scales only add peaks away from it. Near a
    # thickness step the coarse responses merge the particle with the step (shifted peak, a ridge through it); at the finest
    # scale the particle is still a separate peak.
    for s in np.geomspace(sigma_min, sigma_max, 4):
        f = ndi.gaussian_filter(a, s) - ndi.gaussian_filter(a, max(bg_sigma, 3 * s))
        fv = f[valid] if valid is not None else f.ravel(); f = f / (1.4826 * np.median(np.abs(fv - np.median(fv))) + 1e-9)
        peaks = (f == ndi.maximum_filter(f, size=int(2 * s + 1) | 1)) & (f > threshold) & ~sat & ~taken
        if valid is not None: peaks &= valid
        peaks[:b] = peaks[-b:] = False; peaks[:, :b] = peaks[:, -b:] = False
        ys, xs = np.nonzero(peaks)
        if edge_ratio and len(ys):
            g = ndi.gaussian_filter(f, 1.0); gy, gx = np.gradient(g); gyy, gyx = np.gradient(gy); gxy, gxx = np.gradient(gx)
            tr = gxx[ys, xs] + gyy[ys, xs]; det = gxx[ys, xs] * gyy[ys, xs] - gyx[ys, xs] * gxy[ys, xs]
            keep = (tr < 0) & (det > 0) & (tr ** 2 < (edge_ratio + 1) ** 2 / edge_ratio * det)
            ys, xs = ys[keep], xs[keep]
        if isolation and len(ys):
            th = np.linspace(0, 2 * np.pi, 36, endpoint=False); R0 = max(2.5 * s, 3.0)
            keep = [all(_ring_isolated(ndi.map_coordinates(f, [y + R * np.sin(th), x + R * np.cos(th)], order=1, mode='nearest') >= isolation * f[y, x])
                        for R in (R0 * r_ for r_ in rings)) for y, x in zip(ys, xs)]
            keep = np.array(keep, bool); ys, xs = ys[keep], xs[keep]
        for y, x in zip(ys, xs):
            out.append((y, x, s)); r = int(np.ceil(2.5 * s)) + 1
            y0, y1, x0, x1 = max(0, y - r), min(a.shape[0], y + r + 1), max(0, x - r), min(a.shape[1], x + r + 1)
            yy, xx = np.ogrid[y0:y1, x0:x1]; taken[y0:y1, x0:x1] |= (yy - y) ** 2 + (xx - x) ** 2 <= r * r
    return np.array(out, float).reshape(-1, 3)

def _ring_isolated(high, max_frac=0.34, opposite_deg=135.0):
    """sector test on the ring around a peak (high = ring samples at >= `isolation` x the peak). Kept: the ring stays low, or
    is high in sectors on one side only (a neighbouring particle - dimers, aggregates - or a thickness step touching the
    ring). Rejected: a long high arc (over a third of the ring) or high sectors on opposite sides (> opposite_deg apart:
    a ridge such as a bubble rim or the bright side of a step running through the peak)."""
    high = np.asarray(high, bool); n = high.size
    if not high.any(): return True
    if high.mean() > max_frac: return False
    h = np.roll(high, -int(np.flatnonzero(~high)[0])); off = int(np.flatnonzero(~high)[0]); centres = []; i = 0
    while i < n:
        if h[i]:
            j = i
            while j < n and h[j]: j += 1
            centres.append(((i + j - 1) / 2.0 + off) % n * 360.0 / n); i = j
        else: i += 1
    if len(centres) < 2: return True
    a = np.array(centres); d = np.abs(a[:, None] - a[None, :]); d = np.minimum(d, 360.0 - d)
    return bool(d.max() < opposite_deg)

def particle_mask(shape, blobs, radius_factor=3.0, extra=4):
    m = np.zeros(shape, bool); yy, xx = np.mgrid[:shape[0], :shape[1]]
    for y, x, s in blobs:
        r = radius_factor * s + extra
        y0, y1 = int(max(0, y - r - 1)), int(min(shape[0], y + r + 2)); x0, x1 = int(max(0, x - r - 1)), int(min(shape[1], x + r + 2))
        m[y0:y1, x0:x1] |= (yy[y0:y1, x0:x1] - y) ** 2 + (xx[y0:y1, x0:x1] - x) ** 2 <= r * r
    return m

def aperture_excess(img, y, x, r_ap, r_bg0, r_bg1, exclude=None):
    """sum of (pixel - local background) in a circular aperture; background = mean of an annulus (Howell 1989).
    Returns (excess, background, n_aperture)."""
    y0, y1 = int(max(0, y - r_bg1 - 1)), int(min(img.shape[0], y + r_bg1 + 2)); x0, x1 = int(max(0, x - r_bg1 - 1)), int(min(img.shape[1], x + r_bg1 + 2))
    sub = img[y0:y1, x0:x1]; yy, xx = np.mgrid[y0:y1, x0:x1]; rr = np.hypot(xx - x, yy - y)
    bgm = (rr >= r_bg0) & (rr < r_bg1); ap = rr < r_ap
    if exclude is not None: bgm &= ~exclude[y0:y1, x0:x1]
    if bgm.sum() < 20: return np.nan, np.nan, int(ap.sum())
    bg = float(sub[bgm].mean()); return float((sub[ap] - bg).sum()), bg, int(ap.sum())

# ----------------------------------------------------------------- window edge (Si frame) term
def frame_edge_columns(bse, sat=250.0, lo_cols=None, smooth=2.0):
    """per-row x position where the image crosses half-way to a saturated Si-frame region on the right; NaN if none"""
    s = ndi.gaussian_filter(bse.astype(np.float32), smooth); ny, nx = s.shape; xe = np.full(ny, np.nan)
    lo_cols = lo_cols or nx // 2
    for yy in range(ny):
        r = s[yy]; lvl = np.median(r[:lo_cols]); thr = lvl + 0.5 * (sat - lvl)
        idx = np.where(r > thr)[0]; idx = idx[idx > lo_cols]
        if len(idx) == 0: continue
        x0 = idx[0]
        xe[yy] = x0 - 1 + (thr - r[x0 - 1]) / (r[x0] - r[x0 - 1]) if (x0 > 0 and r[x0] != r[x0 - 1]) else x0
    return xe

def frame_edge_fit(xe, deg=2, k=3.0):
    """robust polynomial fit of the edge position vs row"""
    yy = np.arange(len(xe)); ok = np.isfinite(xe)
    if ok.sum() < 20: return None
    p = np.polyfit(yy[ok], xe[ok], deg)
    for _ in range(5):
        r = xe - np.polyval(p, yy); s = 1.4826 * np.nanmedian(np.abs(r[ok])); ok = np.isfinite(xe) & (np.abs(r) < k * max(s, 0.3)); p = np.polyfit(yy[ok], xe[ok], deg)
    return np.polyval(p, yy)

def edge_term(sm, valid, dist_to_edge, flat_min=350, bin_px=25, skip_rows=250):
    """extra BSE (grey) as a function of distance to the Si-frame edge, from the median profile of the flat rows; 0 far away"""
    ok = valid.copy(); ok[:skip_rows] = False; ok &= dist_to_edge > 12
    bins = np.arange(12, dist_to_edge[ok].max() + bin_px, bin_px); idx = np.digitize(dist_to_edge[ok], bins)
    prof = np.array([np.median(sm[ok][idx == i]) if np.sum(idx == i) > 300 else np.nan for i in range(len(bins) + 1)])
    cen = np.r_[bins[0] - bin_px / 2, 0.5 * (bins[1:] + bins[:-1]), bins[-1] + bin_px / 2]; good = np.isfinite(prof)
    flat = float(np.nanmedian(sm[ok & (dist_to_edge > flat_min)]))
    e = np.interp(dist_to_edge, cen[good], prof[good]) - flat; e[dist_to_edge > flat_min + 50] = 0.0
    return np.clip(e, 0, None).astype(np.float32), flat
