"""Export of a finished run (its time-resolved 3-D volumes, 2-D maps and tables) for the common analysis and
visualisation programs. Every export is written from the same `lcsem.volume4d.Volume4D` model (voxel fractions for liquid
and gas, 1 for the cell walls and the Au particles, SE contact under the top membrane), so all programs show the same data.

    lcsem export run_dir --formats tiff ome-zarr imaris vtk nrrd mrc mesh matlab hdf5 csv --out export_dir

format        files                                              open with
amira         *.am, *.surf, *.landmarkAscii (per frame)           Amira / Avizo (Open Time Series Data)
tiff          *_TZCYX.tif (ImageJ hyperstack, calibrated)        Fiji / ImageJ, Icy, napari
ome-tiff      *.ome.tif (TCZYX, physical sizes)                   Fiji (Bio-Formats), QuPath, Imaris, Arivis, Dragonfly, napari
ome-zarr      *.ome.zarr (NGFF 0.4, TCZYX, scales)                napari (napari-ome-zarr), Fiji (MoBIE / N5), Neuroglancer, vizarr
imaris        *.ims (Imaris 5.5 HDF5, all frames and channels)     Imaris (and Imaris Viewer), Fiji (Bio-Formats), Arivis
vtk           frame_*.vti + *.pvd time collection, particles.vtp  ParaView, VisIt, PyVista, 3D Slicer (vti)
nrrd          *.seq.nrrd (4-D sequence) + per-frame label maps    3D Slicer (Sequences), ITK-SNAP, MITK
nifti         *.nii.gz (4-D, micrometres, seconds)                3D Slicer, ITK-SNAP, FSLeyes, MRIcroGL
mrc           *_liquid.mrc etc. per frame, 8-bit percent (voxel in A)  UCSF ChimeraX / Chimera (vseries), IMOD, Dragonfly
mesh          *.stl and a coloured *.glb scene per frame (marching cubes) Blender, MeshLab, ParaView, CAD programs, 3-D printing
matlab        *.mat (v5, or v7.3 HDF5 when large)                 MATLAB, Octave, Python (scipy.io)
hdf5          *.h5 (volumes, maps, tables, metadata)              Python / MATLAB / R / HDFView, Dragonfly
csv           *.csv and one *.xlsx workbook                       Excel, Origin, Prism, R, pandas
trackmate     *_trackmate_spots.csv (TrackMate column names)      Fiji TrackMate (CSV importer), napari
"""
from __future__ import annotations
import os, json, shutil, numpy as np, pandas as pd
from .volume4d import Volume4D, KINDS

FORMATS = ('amira', 'tiff', 'ome-tiff', 'ome-zarr', 'imaris', 'vtk', 'nrrd', 'nifti', 'mrc', 'mesh', 'matlab', 'hdf5', 'csv', 'trackmate')
COLORS = dict(liquid=(0.16, 0.47, 0.84), gas=(0.92, 0.41, 0.20), contact=(0.91, 0.48, 0.64), walls=(0.55, 0.55, 0.53), au=(0.93, 0.66, 0.0))
OPEN_WITH = {       # explicit (not parsed from the docstring, which python -OO removes)
    'amira': 'Amira / Avizo (File > Open Time Series Data)',
    'tiff': 'Fiji / ImageJ, Icy, napari (ImageJ hyperstack TZCYX, calibrated)',
    'ome-tiff': 'Fiji (Bio-Formats), QuPath, Imaris, arivis, Dragonfly, napari',
    'ome-zarr': 'napari (napari-ome-zarr plugin), Fiji (MoBIE / N5), Neuroglancer, vizarr',
    'imaris': 'Imaris, Imaris Viewer (free), Fiji (Bio-Formats), arivis',
    'vtk': 'ParaView (open the .pvd), VisIt, PyVista',
    'nrrd': '3D Slicer (Sequences), ITK-SNAP, MITK',
    'nifti': '3D Slicer, ITK-SNAP, FSLeyes, MRIcroGL',
    'mrc': 'UCSF ChimeraX / Chimera (vseries), IMOD, Dragonfly',
    'mesh': 'Blender (glTF .glb), MeshLab, ParaView, CAD, 3-D printing (STL)',
    'matlab': 'MATLAB, Octave, Python (scipy.io)',
    'hdf5': 'Python / MATLAB / R, HDFView, Dragonfly',
    'csv': 'Excel, Origin, Prism, R, pandas',
    'trackmate': 'Fiji TrackMate (CSV importer), napari'}

def _frames(V, kinds=KINDS, log=None, what=''):
    """(i, volumes of frame i); through the model's frame cache, so several formats in one export compute each frame once
    when the run fits in the cache (LCSEM_CACHE_MB)"""
    for i in range(V.n):
        if log and (i % max(1, V.n // 10) == 0): log(f'  {what}: frame {i + 1}/{V.n}')
        yield i, V.cached(i)

def _times(V):
    t = np.asarray(V.times, float); return t - t[0] if len(t) else t

# ------------------------------------------------------------------------------------------------------------------ writers
def export_tiff(V, out, log=print):
    import tifffile
    fn = os.path.join(out, f'{V.name}_TZCYX.tif'); dt = float(np.median(np.diff(_times(V)))) if V.n > 1 else 1.0
    shape = (V.n, V.nz, len(KINDS), V.ny, V.nx)
    def gen():
        for i, f in _frames(V, log=log, what='tiff'):
            for k in range(V.nz):
                for kind in KINDS: yield (f[kind][k] * (255 if kind in ('walls', 'au') else 1)).astype(np.uint8)
    with tifffile.TiffWriter(fn, imagej=True) as tw:
        tw.write(gen(), shape=shape, dtype=np.uint8, resolution=(1 / V.spacing[2], 1 / V.spacing[1]), compression='zlib',
                 metadata={'axes': 'TZCYX', 'spacing': V.spacing[0], 'unit': 'nm', 'finterval': dt, 'Labels': [f'{k}' for k in KINDS] * (V.n * V.nz),
                           'mode': 'composite', 'Info': 'lcsem: liquid/gas/contact = voxel fraction x 255, walls/au = 255'})
    return [fn]

def export_ome_tiff(V, out, log=print):
    import tifffile
    fn = os.path.join(out, f'{V.name}.ome.tif'); dt = float(np.median(np.diff(_times(V)))) if V.n > 1 else 1.0
    def gen():
        for i, f in _frames(V, log=log, what='ome-tiff'):
            for kind in KINDS:
                for k in range(V.nz): yield (f[kind][k] * (255 if kind in ('walls', 'au') else 1)).astype(np.uint8)
    md = {'axes': 'TCZYX', 'PhysicalSizeX': V.spacing[2], 'PhysicalSizeXUnit': 'nm', 'PhysicalSizeY': V.spacing[1], 'PhysicalSizeYUnit': 'nm',
          'PhysicalSizeZ': V.spacing[0], 'PhysicalSizeZUnit': 'nm', 'TimeIncrement': dt, 'TimeIncrementUnit': 's', 'Channel': {'Name': list(KINDS)}}
    with tifffile.TiffWriter(fn, ome=True, bigtiff=True) as tw:
        tw.write(gen(), shape=(V.n, len(KINDS), V.nz, V.ny, V.nx), dtype=np.uint8, compression='zlib', metadata=md, tile=None)
    return [fn]

def export_ome_zarr(V, out, log=print):
    import zarr
    fn = os.path.join(out, f'{V.name}.ome.zarr')
    if os.path.exists(fn): shutil.rmtree(fn)
    root = zarr.open_group(fn, mode='w', zarr_format=2)
    dt = float(np.median(np.diff(_times(V)))) if V.n > 1 else 1.0
    arr = root.create_array('0', shape=(V.n, len(KINDS), V.nz, V.ny, V.nx), chunks=(1, 1, V.nz, min(V.ny, 256), min(V.nx, 256)), dtype='uint8',
                            chunk_key_encoding={'name': 'v2', 'separator': '/'})
    for i, f in _frames(V, log=log, what='ome-zarr'):
        for c, kind in enumerate(KINDS): arr[i, c] = (f[kind] * (255 if kind in ('walls', 'au') else 1)).astype(np.uint8)
    root.attrs['multiscales'] = [{'version': '0.4', 'name': V.name,
                                  'axes': [{'name': 't', 'type': 'time', 'unit': 'second'}, {'name': 'c', 'type': 'channel'},
                                           {'name': 'z', 'type': 'space', 'unit': 'nanometer'}, {'name': 'y', 'type': 'space', 'unit': 'nanometer'},
                                           {'name': 'x', 'type': 'space', 'unit': 'nanometer'}],
                                  'datasets': [{'path': '0', 'coordinateTransformations': [{'type': 'scale', 'scale': [dt, 1.0, V.spacing[0], V.spacing[1], V.spacing[2]]},
                                                                                             {'type': 'translation', 'translation': [0.0, 0.0, *V.origin_nm]}]}],
                                  'type': 'none', 'metadata': {'description': 'lcsem 4-D model: liquid/gas/contact = voxel fraction x 255, walls/au = 255'}}]
    root.attrs['omero'] = {'channels': [{'label': k, 'color': ''.join(f'{int(255 * c):02X}' for c in COLORS[k]), 'window': {'start': 0, 'end': 255, 'min': 0, 'max': 255},
                                         'active': True} for k in KINDS], 'rdefs': {'model': 'color'}}
    return [fn]

def _a(s):
    return np.array(list(str(s)), dtype='S1')

def export_imaris(V, out, log=print):
    """Imaris 5.5 file (HDF5): one resolution level, all time points and channels, sizes and extents in micrometres"""
    import h5py
    fn = os.path.join(out, f'{V.name}.ims'); dz, dy, dx = [s / 1000.0 for s in V.spacing]
    with h5py.File(fn, 'w') as f:
        for k, v in (('DataSetDirectoryName', 'DataSet'), ('DataSetInfoDirectoryName', 'DataSetInfo'), ('ImarisDataSet', 'ImarisDataSet'),
                     ('ImarisVersion', '5.5.0'), ('ThumbnailDirectoryName', 'Thumbnail')): f.attrs[k] = _a(v)
        f.attrs['NumberOfDataSets'] = np.array([1], dtype=np.uint32)
        info = f.create_group('DataSetInfo'); im = info.create_group('Imaris'); im.attrs['Version'] = _a('8.0')
        g = info.create_group('Image')
        e0 = [V.origin_nm[2] / 1000 - dx / 2, V.origin_nm[1] / 1000 - dy / 2, V.origin_nm[0] / 1000 - dz / 2]       # extents = voxel edges
        for k, v in (('X', V.nx), ('Y', V.ny), ('Z', V.nz), ('Unit', 'um'), ('Noc', len(KINDS)), ('ExtMin0', f'{e0[0]:.6f}'), ('ExtMin1', f'{e0[1]:.6f}'), ('ExtMin2', f'{e0[2]:.6f}'),
                     ('ExtMax0', f'{e0[0] + V.nx * dx:.6f}'), ('ExtMax1', f'{e0[1] + V.ny * dy:.6f}'), ('ExtMax2', f'{e0[2] + V.nz * dz:.6f}'), ('Name', V.name),
                     ('Description', 'lcsem 4-D model: liquid, gas, SE contact (voxel fraction x 255), cell walls and Au particles (255)')):
            g.attrs[k] = _a(v)
        for c, kind in enumerate(KINDS):
            ch = info.create_group(f'Channel {c}'); col = COLORS[kind]
            for k, v in (('Name', kind), ('Color', f'{col[0]:.3f} {col[1]:.3f} {col[2]:.3f}'), ('ColorMode', 'BaseColor'), ('ColorOpacity', '1.000'),
                         ('ColorRange', '0.000 255.000'), ('GammaCorrection', '1.000'), ('Description', '')): ch.attrs[k] = _a(v)
        ti = info.create_group('TimeInfo'); ti.attrs['DatasetTimePoints'] = _a(V.n); ti.attrs['FileTimePoints'] = _a(V.n)
        import re
        m_ = re.search(r'(20\d\d)(\d\d)(\d\d)', ' '.join(V.tags)); day = f'{m_.group(1)}-{m_.group(2)}-{m_.group(3)}' if m_ else '2000-01-01'   # date from JEOL names, else a placeholder
        for i, t in enumerate(V.times):
            h = int(t // 3600); m = int((t % 3600) // 60); s = t % 60; ti.attrs[f'TimePoint{i + 1}'] = _a(f'{day} {h:02d}:{m:02d}:{s:06.3f}')
        ds = f.create_group('DataSet').create_group('ResolutionLevel 0')
        chunks = (min(V.nz, 16), min(V.ny, 128), min(V.nx, 128))
        for i, fr in _frames(V, log=log, what='imaris'):
            tp = ds.create_group(f'TimePoint {i}')
            for c, kind in enumerate(KINDS):
                a = (fr[kind] * (255 if kind in ('walls', 'au') else 1)).astype(np.uint8); cg = tp.create_group(f'Channel {c}')
                cg.create_dataset('Data', data=a, chunks=chunks, compression='gzip', compression_opts=2)
                cg.create_dataset('Histogram', data=np.bincount(a.ravel(), minlength=256).astype(np.uint64))
                for k, v in (('ImageSizeX', V.nx), ('ImageSizeY', V.ny), ('ImageSizeZ', V.nz), ('HistogramMin', '0.000'), ('HistogramMax', '255.000')): cg.attrs[k] = _a(v)
        th = f.create_group('Thumbnail'); tn = np.zeros((256, 256 * len(KINDS)), np.uint8)
        fr0 = V.frame(0)
        for c, kind in enumerate(KINDS):
            mip = fr0[kind].max(axis=0).astype(float); mip = mip * (255 if kind in ('walls', 'au') else 1)
            from skimage.transform import resize
            tn[:, 256 * c:256 * (c + 1)] = np.clip(resize(mip, (256, 256), preserve_range=True), 0, 255).astype(np.uint8)
        th.create_dataset('Data', data=tn)
    return [fn]

def export_vtk(V, out, log=print, z_exaggeration=1.0):
    import vtk
    from vtk.util import numpy_support as ns
    files = []; pvd = ['<?xml version="1.0"?>', '<VTKFile type="Collection" version="0.1" byte_order="LittleEndian">', '  <Collection>']
    t = _times(V)
    for i, fr in _frames(V, log=log, what='vtk'):
        img = vtk.vtkImageData(); img.SetDimensions(V.nx, V.ny, V.nz); img.SetSpacing(V.spacing[2], V.spacing[1], V.spacing[0] * z_exaggeration)
        img.SetOrigin(V.origin_nm[2], V.origin_nm[1], V.origin_nm[0] * z_exaggeration)
        for kind in KINDS:
            arr = ns.numpy_to_vtk((fr[kind] * (255 if kind in ('walls', 'au') else 1)).astype(np.uint8).ravel(order='C'), deep=True, array_type=vtk.VTK_UNSIGNED_CHAR)
            arr.SetName(kind); img.GetPointData().AddArray(arr)
        img.GetPointData().SetActiveScalars('liquid')
        fn = os.path.join(out, f'{V.tags[i]}.vti'); w = vtk.vtkXMLImageDataWriter(); w.SetFileName(fn); w.SetInputData(img)
        w.SetDataModeToAppended(); w.SetCompressorTypeToZLib(); w.EncodeAppendedDataOff(); w.Write(); files.append(fn)
        pvd.append(f'    <DataSet timestep="{t[i]:.4f}" group="" part="0" file="{os.path.basename(fn)}"/>')
    pvd += ['  </Collection>', '</VTKFile>']; pf = os.path.join(out, f'{V.name}.pvd'); open(pf, 'w').write('\n'.join(pvd)); files.append(pf)
    P = V.particles
    if len(P):                                                                    # particles: points with frame, time, radius, track
        pts = vtk.vtkPoints(); verts = vtk.vtkCellArray(); arrs = {k: [] for k in ('frame', 'time_s', 'radius_nm', 'track', 'z_measured')}
        for _, r in P.iterrows():
            pid = pts.InsertNextPoint(float(r['x_nm']), float(r['y_nm']), float(V.Zmax - r['depth_nm']) * z_exaggeration); verts.InsertNextCell(1); verts.InsertCellPoint(pid)
            arrs['frame'].append(int(r['frame'])); arrs['time_s'].append(float(t[int(r['frame'])]) if int(r['frame']) < len(t) else np.nan)
            arrs['radius_nm'].append(V.d_part / 2); arrs['track'].append(int(r.get('track', -1)) if np.isfinite(r.get('track', np.nan)) else -1); arrs['z_measured'].append(int(bool(r['z_measured'])))
        pd_ = vtk.vtkPolyData(); pd_.SetPoints(pts); pd_.SetVerts(verts)
        for k, v in arrs.items():
            a = ns.numpy_to_vtk(np.asarray(v, float), deep=True); a.SetName(k); pd_.GetPointData().AddArray(a)
        fn = os.path.join(out, f'{V.name}_particles.vtp'); w = vtk.vtkXMLPolyDataWriter(); w.SetFileName(fn); w.SetInputData(pd_); w.Write(); files.append(fn)
        tr = V.tracks()
        if len(tr):
            pts = vtk.vtkPoints(); lines = vtk.vtkCellArray(); tid = []
            for k in np.unique(tr[:, 0]):
                q = tr[tr[:, 0] == k]
                if len(q) < 2: continue
                ids = [pts.InsertNextPoint(x, y, z * z_exaggeration) for (_, _, z, y, x) in q]
                pl = vtk.vtkPolyLine(); pl.GetPointIds().SetNumberOfIds(len(ids))
                for j, p in enumerate(ids): pl.GetPointIds().SetId(j, p)
                lines.InsertNextCell(pl); tid.append(k)
            pd2 = vtk.vtkPolyData(); pd2.SetPoints(pts); pd2.SetLines(lines); a = ns.numpy_to_vtk(np.asarray(tid, float), deep=True); a.SetName('track'); pd2.GetCellData().AddArray(a)
            fn = os.path.join(out, f'{V.name}_tracks.vtp'); w = vtk.vtkXMLPolyDataWriter(); w.SetFileName(fn); w.SetInputData(pd2); w.Write(); files.append(fn)
    return files

def _labels(fr):
    """one label map per frame: 0 empty, 1 liquid, 2 gas, 3 SE contact, 4 cell wall, 5 Au (majority rules for fractions)"""
    lab = np.zeros(fr['liquid'].shape, np.uint8); lab[fr['liquid'] >= 128] = 1; lab[fr['gas'] >= 128] = 2; lab[fr['contact'] >= 128] = 3
    lab[fr['walls'] > 0] = 4; lab[fr['au'] > 0] = 5; return lab

def export_nrrd(V, out, log=print):
    import nrrd
    files = []; um = [s / 1000.0 for s in V.spacing]; t = _times(V)
    liq = np.stack([V.frame(i, ('liquid',))['liquid'].transpose(2, 1, 0) for i in range(V.n)])        # (t, x, y, z)
    org = [o / 1000.0 for o in V.origin_nm[::-1]]                                                   # (x, y, z) um
    hdr = {'type': 'uint8', 'dimension': 4, 'kinds': ['list', 'domain', 'domain', 'domain'], 'space': 'left-posterior-superior',
           'space directions': [[np.nan] * 3, [um[2], 0, 0], [0, um[1], 0], [0, 0, um[0]]], 'space origin': org,
           'space units': ['mm', 'mm', 'mm'], 'encoding': 'gzip',
           'axis 0 index type': 'numeric', 'axis 0 index values': ' '.join(f'{v:.4f}' for v in t), 'axis 0 quantity': 'time', 'axis 0 unit': 's',
           'DataNodeClassName': 'vtkMRMLScalarVolumeNode'}
    fn = os.path.join(out, f'{V.name}_liquid_fraction.seq.nrrd'); nrrd.write(fn, liq, hdr, custom_field_map={}); files.append(fn)
    for i, fr in _frames(V, log=log, what='nrrd labels'):
        h = {'type': 'uint8', 'dimension': 3, 'space': 'left-posterior-superior', 'space directions': [[um[2], 0, 0], [0, um[1], 0], [0, 0, um[0]]],
             'space origin': org, 'kinds': ['domain'] * 3, 'encoding': 'gzip',
             'labels (0 empty, 1 liquid, 2 gas, 3 SE contact, 4 wall, 5 Au)': 'see README'}
        fn = os.path.join(out, f'{V.tags[i]}_labels.nrrd'); nrrd.write(fn, _labels(fr).transpose(2, 1, 0), h); files.append(fn)
    open(os.path.join(out, 'NRRD_README.txt'), 'w').write('Spacing and origin are written in micrometres labelled as mm (1 "mm" in 3D Slicer / ITK-SNAP = 1 um), '
                                                          'as in the NIfTI export; space LPS with identity directions, so ITK tools show the image as the SEM does.\n'
                                                          'Label maps: 0 empty, 1 liquid, 2 gas, 3 SE contact, 4 cell wall (membranes, window frame), 5 Au particle.\n'
                                                          'The .seq.nrrd file is the liquid fraction (0-255) of all frames; open it with the Sequences module.\n')
    return files

def export_nifti(V, out, log=print):
    import nibabel as nib
    um = [s / 1000.0 for s in V.spacing]; t = _times(V); dt = float(np.median(np.diff(t))) if V.n > 1 else 1.0; files = []
    for kind in ('liquid', 'gas'):
        a = np.stack([V.frame(i, (kind,))[kind].transpose(2, 1, 0) for i in range(V.n)], axis=-1)       # (x, y, z, t)
        # NIfTI affines are RAS; the NRRD export is LPS with identity directions. x and y are flipped here so that both land on
        # the same physical grid in ITK-based tools (3D Slicer, ITK-SNAP), which convert NIfTI to LPS: origin and spacing then
        # read back identical to the NRRD files. Micrometre values labelled mm (as the NRRD export): tools that convert units
        # would otherwise shrink the volume 1000x.
        org = [o / 1000.0 for o in V.origin_nm[::-1]]                                               # (x, y, z) um
        aff = np.diag([-um[2], -um[1], um[0], 1.0]); aff[:3, 3] = [-org[0], -org[1], org[2]]
        img = nib.Nifti1Image(a, aff); img.set_sform(aff, code=1); img.set_qform(aff, code=1)
        img.header.set_xyzt_units('mm', 'sec'); img.header['pixdim'][4] = dt
        img.header['descrip'] = f'lcsem {kind} fraction x255'.encode()[:79]
        fn = os.path.join(out, f'{V.name}_{kind}_fraction.nii.gz'); nib.save(img, fn); files.append(fn)
    return files

def export_mrc(V, out, log=print):
    """MRC2014, mode 0 (8-bit): liquid and gas as percent of the voxel filled (0-100), Au particles 1; voxel size in angstrom"""
    import mrcfile
    files = []; ang = [s * 10.0 for s in V.spacing]
    for i, fr in _frames(V, ('liquid', 'gas', 'au'), log=log, what='mrc'):
        for kind in ('liquid', 'gas', 'au'):
            fn = os.path.join(out, f'{V.tags[i]}_{kind}.mrc')
            a = fr[kind].astype(np.int8) if kind == 'au' else np.rint(fr[kind] * (100.0 / 255.0)).astype(np.int8)
            with mrcfile.new(fn, overwrite=True) as m:
                m.set_data(a); m.voxel_size = (ang[2], ang[1], ang[0])
                m.header.origin.x, m.header.origin.y, m.header.origin.z = V.origin_nm[2] * 10, V.origin_nm[1] * 10, V.origin_nm[0] * 10
                m.header.label[0] = f'lcsem {kind} {"(1 = particle)" if kind == "au" else "percent"}, frame {i}, t = {V.times[i]:.2f} s'.encode()[:80]; m.header.nlabl = 1
            files.append(fn)
    return files

def export_mesh(V, out, log=print, formats=('stl', 'glb'), z_exaggeration=1.0, step_size=2):
    """surfaces per frame: binary STL per object kind and one coloured glTF scene (.glb); 'ply' and 'obj' on request.
    step_size: marching-cubes step in voxels (2 = about 4x fewer triangles than 1, at the voxel scale of the data)"""
    import trimesh
    from skimage.measure import marching_cubes
    from .export_amira import icosphere
    files = []; sc = (V.spacing[0] * z_exaggeration, V.spacing[1], V.spacing[2]); V0, F0 = icosphere(2)
    for i, fr in _frames(V, ('liquid', 'gas'), log=log, what='mesh'):
        meshes = {}
        for kind in ('liquid', 'gas'):
            vol = np.pad(fr[kind].astype(np.float32), 1)
            if vol.max() < 128: continue
            v, f, _, _ = marching_cubes(vol, 127.5, spacing=sc, step_size=int(step_size))
            v = v - np.array(sc) + np.array([V.origin_nm[0] * z_exaggeration, V.origin_nm[1], V.origin_nm[2]])   # undo the padding; voxel-centre origin
            meshes[kind] = trimesh.Trimesh(vertices=v[:, ::-1], faces=f[:, ::-1], process=False)   # (x, y, z)
        P = V.particles
        if len(P):
            q = P[P['frame'] == i]; sph = []
            for _, r in q.iterrows():
                c = np.array([r['x_nm'], r['y_nm'], (V.Zmax - r['depth_nm']) * z_exaggeration]); sph.append(trimesh.Trimesh(V0 * (V.d_part / 2) * np.array([1, 1, z_exaggeration]) + c, F0, process=False))
            if sph: meshes['au'] = trimesh.util.concatenate(sph)
        for kind, m in meshes.items():
            m.visual.face_colors = np.array(list(COLORS[kind]) + [1.0]) * 255
            for fmt in formats:
                if fmt == 'glb': continue
                fn = os.path.join(out, f'{V.tags[i]}_{kind}.{fmt}'); m.export(fn); files.append(fn)
        if 'glb' in formats and meshes:
            fn = os.path.join(out, f'{V.tags[i]}_scene.glb'); trimesh.Scene({k: m for k, m in meshes.items()}).export(fn); files.append(fn)
    open(os.path.join(out, 'MESH_README.txt'), 'w').write(f'Surfaces by marching cubes (Lorensen & Cline 1987) at half filling of the voxels; units nm; '
                                                          f'z exaggeration {z_exaggeration:g}; Au particles as spheres of {V.d_part:g} nm.\n'
                                                          'Blender: File > Import > glTF (.glb keeps the colours) or STL/PLY/OBJ.\n')
    return files

def export_matlab(V, out, log=print, v73_above_bytes=1.8e9):
    from scipy.io import savemat
    vols = {k: np.stack([V.cached(i)[k] for i in range(V.n)]) for k in KINDS}
    d = dict(spacing_nm_zyx=np.array(V.spacing), time_s=np.asarray(V.times), frame_names=np.array(V.tags, dtype=object),
             thickness_nm=V.map2d('thickness'), contact_map=V.map2d('contact'), description='lcsem 4-D model: (t, z, y, x); liquid/gas/contact = fraction x 255, walls/au = 1',
             **vols)
    num = lambda D: {c: np.asarray(D[c].values, float) for c in D.columns if pd.api.types.is_numeric_dtype(D[c]) or pd.api.types.is_bool_dtype(D[c])}
    if len(V.particles): d['particles'] = num(V.particles)
    S = V.series(); d['volumes_vs_time'] = num(S); d['calibration'] = V.calibration_text(); d['frame_names'] = np.array(V.tags, dtype=object)
    fn = os.path.join(out, f'{V.name}.mat'); size = sum(v.nbytes for v in vols.values())
    if size < v73_above_bytes: savemat(fn, d, do_compression=True)
    else:
        import hdf5storage; hdf5storage.savemat(fn, d, format='7.3', matlab_compatible=True)
    return [fn]

def export_hdf5(V, out, log=print):
    import h5py
    fn = os.path.join(out, f'{V.name}.h5')
    with h5py.File(fn, 'w') as f:
        f.attrs['description'] = 'lcsem 4-D model of a liquid-cell SEM series'; f.attrs['spacing_nm_zyx'] = V.spacing; f.attrs['units'] = 'nm, s'
        f.attrs['run_info'] = json.dumps({k: v for k, v in V.info.items() if k != 'config'}, default=str); f.attrs['config'] = json.dumps(V.cfg, default=str)
        f.create_dataset('time_s', data=np.asarray(V.times)); f.create_dataset('frame_names', data=np.array(V.tags, dtype='S'))
        g = f.create_group('volumes')
        ds = {k: g.create_dataset(k, shape=(V.n, V.nz, V.ny, V.nx), dtype='uint8', chunks=(1, V.nz, min(V.ny, 128), min(V.nx, 128)), compression='gzip', compression_opts=3) for k in KINDS}
        for k in KINDS: ds[k].attrs['meaning'] = 'fraction x 255' if k in ('liquid', 'gas', 'contact') else '1 inside'
        for i, fr in _frames(V, log=log, what='hdf5'):
            for k in KINDS: ds[k][i] = fr[k]
        m = f.create_group('maps')
        for k in ('thickness', 'sigma', 'gas_top', 'gas_other', 'contact', 'time'): m.create_dataset(k, data=V.map2d(k), compression='gzip')
        tb = f.create_group('tables')
        for name, D in _tables(V).items(): tb.create_dataset(name, data=D.to_csv(index=False))
    return [fn]

def _tables(V):
    out = {'volumes_vs_time': V.series()}
    for nm in ('summary', 'particles', 'tracks', 'objects', 'object_tracks', 'segmentation_classes', 'calibration'):
        fn = os.path.join(V.run_dir, f'{nm}.csv')
        if os.path.exists(fn):
            try: out[nm] = pd.read_csv(fn)
            except Exception: pass
    return out

def export_csv(V, out, log=print):
    files = []; T = _tables(V)
    for nm, D in T.items():
        fn = os.path.join(out, f'{V.name}_{nm}.csv'); D.to_csv(fn, index=False); files.append(fn)
    fn = os.path.join(out, f'{V.name}_tables.xlsx')
    with pd.ExcelWriter(fn, engine='openpyxl') as xw:
        for nm, D in T.items(): D.to_excel(xw, sheet_name=nm[:31], index=False)
    files.append(fn); return files

def export_trackmate(V, out, log=print):
    P = V.particles; fn = os.path.join(out, f'{V.name}_trackmate_spots.csv')
    if not len(P): pd.DataFrame(columns=['ID', 'TRACK_ID', 'QUALITY', 'POSITION_X', 'POSITION_Y', 'POSITION_Z', 'POSITION_T', 'FRAME', 'RADIUS']).to_csv(fn, index=False); return [fn]
    t = _times(V)
    D = pd.DataFrame(dict(ID=np.arange(len(P)), TRACK_ID=P['track'].fillna(-1).astype(int) if 'track' in P else -1, QUALITY=1.0,
                          POSITION_X=P['x_nm'], POSITION_Y=P['y_nm'], POSITION_Z=V.Zmax - P['depth_nm'], POSITION_T=[t[int(f)] for f in P['frame']],
                          FRAME=P['frame'].astype(int), RADIUS=V.d_part / 2, Z_MEASURED=P['z_measured'].astype(int)))
    D.to_csv(fn, index=False); return [fn]

def export_amira(V, out, log=print):
    from .export_amira import export_run
    export_run(V.run_dir, out, volume=V, log=lambda *a: None)
    return sorted(os.path.join(out, f) for f in os.listdir(out))

WRITERS = {'amira': export_amira, 'tiff': export_tiff, 'ome-tiff': export_ome_tiff, 'ome-zarr': export_ome_zarr, 'imaris': export_imaris,
           'vtk': export_vtk, 'nrrd': export_nrrd, 'nifti': export_nifti, 'mrc': export_mrc, 'mesh': export_mesh, 'matlab': export_matlab,
           'hdf5': export_hdf5, 'csv': export_csv, 'trackmate': export_trackmate}

# ------------------------------------------------------------------------------------------------------------------ verification
def verify(fmt, files, V):
    """read the exported files back (with an independent reader where one exists) and compare them with the model: every layer
    of the first, middle and last frame (voxel by voxel, in the encoding of the format), the frame count and the voxel size
    where the format stores it. Returns dict(format, ok, reader, checked)."""
    import importlib.util
    frames = sorted({0, V.n // 2, V.n - 1}); sc = {k: (255 if k in ('walls', 'au') else 1) for k in KINDS}
    enc = lambda i, k: (V.cached(i)[k] * sc[k]).astype(np.uint8)
    readers = {'ome-zarr': 'zarr', 'imaris': 'imaris_ims_file_reader', 'vtk': 'vtk', 'nrrd': 'SimpleITK', 'nifti': 'SimpleITK', 'mesh': 'meshio', 'matlab': 'scipy', 'hdf5': 'h5py', 'csv': 'openpyxl', 'tiff': 'tifffile', 'ome-tiff': 'tifffile'}
    if fmt in readers and importlib.util.find_spec(readers[fmt]) is None:
        return dict(format=fmt, ok=None, reader=f'not checked: {readers[fmt]} not installed', checked='')
    def same(get, kinds=KINDS):
        return all(np.array_equal(np.asarray(get(i, k)), enc(i, k)) for i in frames for k in kinds)
    what = f'frames {frames}, layers ' + '/'.join(KINDS); sp_ok = True
    try:
        if fmt == 'tiff':
            import tifffile
            with tifffile.TiffFile(files[0]) as tf:
                a = tf.asarray(); ij = tf.imagej_metadata or {}; xr = tf.pages[0].tags['XResolution'].value
            ok = a.shape == (V.n, V.nz, len(KINDS), V.ny, V.nx) and same(lambda i, k: a[i, :, KINDS.index(k)])
            sp_ok = abs(float(ij.get('spacing', 0)) - V.spacing[0]) < 1e-6 and abs(xr[1] / xr[0] - V.spacing[2]) < 1e-3; rd = 'tifffile'
        elif fmt == 'ome-tiff':
            import tifffile, re
            with tifffile.TiffFile(files[0]) as tf: a = tf.series[0].asarray(); ome = tf.ome_metadata
            ok = a.shape == (V.n, len(KINDS), V.nz, V.ny, V.nx) and same(lambda i, k: a[i, KINDS.index(k)])
            px = re.search(r'PhysicalSizeX="([0-9.eE+-]+)"', ome); sp_ok = px is not None and abs(float(px.group(1)) - V.spacing[2]) < 1e-3; rd = 'tifffile (OME-XML)'
        elif fmt == 'ome-zarr':
            import zarr; g = zarr.open_group(files[0], mode='r'); a = g['0']
            ok = a.shape == (V.n, len(KINDS), V.nz, V.ny, V.nx) and same(lambda i, k: a[i, KINDS.index(k)]) and 'multiscales' in g.attrs
            scale = g.attrs['multiscales'][0]['datasets'][0]['coordinateTransformations'][0]['scale']; sp_ok = np.allclose(scale[2:], V.spacing, rtol=1e-6)
            try:
                from ome_zarr.io import parse_url; from ome_zarr.reader import Reader; from ome_zarr.format import FormatV04
                nodes = list(Reader(parse_url(files[0], fmt=FormatV04()))()); ok = ok and len(nodes) > 0; rd = 'zarr + ome-zarr Reader'
            except Exception: rd = 'zarr'
        elif fmt == 'imaris':
            from imaris_ims_file_reader.ims import ims
            r = ims(files[0]); ok = r.shape[:3] == (V.n, len(KINDS), V.nz) and same(lambda i, k: r[i, KINDS.index(k), :, :, :]); rd = 'imaris-ims-file-reader'
        elif fmt == 'vtk':
            import xml.etree.ElementTree as ET, vtk
            from vtk.util import numpy_support as ns
            vti = [f for f in files if f.endswith('.vti')]; imgs = {}
            for i in frames:
                rr = vtk.vtkXMLImageDataReader(); rr.SetFileName(vti[i]); rr.Update(); imgs[i] = rr.GetOutput()
            ok = len(vti) == V.n and same(lambda i, k: ns.vtk_to_numpy(imgs[i].GetPointData().GetArray(k)).reshape(V.nz, V.ny, V.nx))
            pvd = ET.parse([f for f in files if f.endswith('.pvd')][0]); ok = ok and len(pvd.getroot()[0]) == V.n
            sp_ok = np.allclose(imgs[0].GetSpacing(), V.spacing[::-1]) and np.allclose(imgs[0].GetOrigin(), V.origin_nm[::-1]); rd = 'VTK XML reader + ElementTree (pvd)'
        elif fmt == 'nrrd':
            import SimpleITK as sitk
            lab = [f for f in files if f.endswith('_labels.nrrd')]; ims_ = {i: sitk.ReadImage(lab[i]) for i in frames}
            ok = len(lab) == V.n and all(np.array_equal(sitk.GetArrayFromImage(ims_[i]), _labels(V.cached(i))) for i in frames)
            sp_ok = np.allclose(ims_[0].GetSpacing(), [s / 1000 for s in V.spacing[::-1]]) and np.allclose(ims_[0].GetOrigin(), [o / 1000 for o in V.origin_nm[::-1]])
            rd = 'SimpleITK (ITK)'; what = f'label maps of frames {frames}'
        elif fmt == 'nifti':
            import SimpleITK as sitk
            ims_ = {k: sitk.ReadImage([f for f in files if f.endswith(f'_{k}_fraction.nii.gz')][0]) for k in ('liquid', 'gas')}
            arr = {k: sitk.GetArrayFromImage(v) for k, v in ims_.items()}                     # (t, z, y, x)
            ok = arr['liquid'].shape == (V.n, V.nz, V.ny, V.nx) and same(lambda i, k: arr[k][i], ('liquid', 'gas'))
            d3 = np.array(ims_['liquid'].GetDirection()).reshape(4, 4)[:3, :3]
            sp_ok = (np.allclose(ims_['liquid'].GetSpacing()[:3], [s / 1000 for s in V.spacing[::-1]]) and np.allclose(ims_['liquid'].GetOrigin()[:3], [o / 1000 for o in V.origin_nm[::-1]])
                     and np.allclose(d3, np.eye(3)))                                              # the same LPS grid as the NRRD export
            rd = 'SimpleITK (ITK)'; what = f'frames {frames}, liquid/gas'
        elif fmt == 'mrc':
            def rd_mrc(fn):
                with open(fn, 'rb') as fh: hdr = np.frombuffer(fh.read(1024), np.int32); hf = np.frombuffer(hdr.tobytes(), np.float32)
                nx, ny, nz, mode = hdr[:4]; raw = np.fromfile(fn, dtype=np.int8, offset=1024 + int(hdr[23]))[:nx * ny * nz].reshape(nz, ny, nx)
                return raw, (nx, ny, nz, mode), hf[10] / nx                                      # cell a / mx = voxel size x (A)
            ok = True
            for i in frames:
                for k in ('liquid', 'gas', 'au'):
                    raw, (nx, ny, nz, mode), vx = rd_mrc([f for f in files if f.endswith(f'{V.tags[i]}_{k}.mrc')][0])
                    ref = V.cached(i)[k].astype(np.int8) if k == 'au' else np.rint(V.cached(i)[k] * (100.0 / 255.0)).astype(np.int8)
                    ok = ok and (nx, ny, nz) == (V.nx, V.ny, V.nz) and mode == 0 and np.array_equal(raw, ref); sp_ok = sp_ok and abs(vx - V.spacing[2] * 10) < 1e-3
            rd = 'raw MRC2014 header parse (numpy)'; what = f'frames {frames}, liquid/gas/au'
        elif fmt == 'mesh':
            stl = [f for f in files if f.endswith('.stl')]
            if not stl: return dict(format=fmt, ok=None, reader='no surfaces (no voxel at half filling)', checked='')
            import meshio
            ok = all(len(meshio.read(f).points) > 0 for f in stl[:3]); rd = 'meshio'
            gl = [f for f in files if f.endswith('.glb')]
            if gl and importlib.util.find_spec('trimesh'):
                import trimesh; s_ = trimesh.load(gl[0]); ok = ok and len(s_.geometry) >= 1; rd += ' + trimesh (glb)'
            what = 'surfaces readable (vertices > 0)'
        elif fmt == 'matlab':
            try:
                from scipy.io import loadmat; d = loadmat(files[0]); get = lambda i, k: d[k][i]; rd = 'scipy.io.loadmat'; n_ = d['liquid'].shape
            except NotImplementedError:
                import h5py; f5 = h5py.File(files[0], 'r'); get = lambda i, k: np.asarray(f5[k]).transpose()[i]; rd = 'h5py (v7.3)'; n_ = np.asarray(f5['liquid']).transpose().shape
            ok = n_ == (V.n, V.nz, V.ny, V.nx) and all(np.array_equal(get(i, k), V.cached(i)[k]) for i in frames for k in KINDS)
        elif fmt == 'hdf5':
            import h5py
            with h5py.File(files[0], 'r') as f:
                ok = all(np.array_equal(f[f'volumes/{k}'][i], V.cached(i)[k]) for i in frames for k in KINDS) and 'maps/thickness' in f
                sp_ok = np.allclose(f.attrs['spacing_nm_zyx'], V.spacing)
            rd = 'h5py'
        elif fmt == 'csv':
            xl = [f for f in files if f.endswith('.xlsx')][0]; x = pd.read_excel(xl, sheet_name=None); ok = 'volumes_vs_time' in x and len(x['volumes_vs_time']) == V.n
            rd = 'openpyxl (pandas)'; what = 'workbook sheets and rows'
        elif fmt == 'trackmate':
            D = pd.read_csv(files[0]); ok = {'POSITION_X', 'POSITION_Y', 'POSITION_Z', 'POSITION_T', 'FRAME', 'TRACK_ID'} <= set(D.columns) and len(D) == len(V.particles)
            rd = 'pandas'; what = 'columns and rows'
        elif fmt == 'amira':
            from .export_amira import read_am
            names = {'liquid': 'liquid_fraction', 'gas': 'gas_fraction', 'walls': 'cell_walls', 'au': 'au_nps', 'contact': 'top_contact'}
            ok = all(np.array_equal(read_am([f for f in files if f.endswith(f'{V.tags[i]}_{names[k]}.am')][0])[0], V.cached(i)[k]) for i in frames for k in KINDS)
            rd = 'AmiraMesh parser (header + HxZip/zlib)'
        else: return dict(format=fmt, ok=None, reader='-', checked='')
        return dict(format=fmt, ok=bool(ok and sp_ok), reader=rd + ('' if sp_ok else ' - VOXEL SIZE / ORIGIN MISMATCH'), checked=what + ('; voxel size' if fmt not in ('csv', 'trackmate', 'mesh', 'amira', 'imaris', 'matlab') else ''))
    except Exception as e:
        return dict(format=fmt, ok=False, reader=f'error: {type(e).__name__}: {e}', checked='')

NEEDS = {'amira': [], 'tiff': ['tifffile'], 'ome-tiff': ['tifffile'], 'ome-zarr': ['zarr'], 'imaris': ['h5py'], 'vtk': ['vtk'], 'nrrd': ['nrrd'],
         'nifti': ['nibabel'], 'mrc': ['mrcfile'], 'mesh': ['trimesh', 'skimage'], 'matlab': ['scipy'], 'hdf5': ['h5py'], 'csv': ['openpyxl'], 'trackmate': []}
PIP = {'nrrd': 'pynrrd', 'skimage': 'scikit-image'}


def available(fmt):
    """(True, '') if the libraries a format needs are installed, else (False, 'pip install ...')"""
    import importlib.util
    miss = [m for m in NEEDS.get(fmt, []) if importlib.util.find_spec(m) is None]
    return (not miss, '' if not miss else 'pip install ' + ' '.join(PIP.get(m, m) for m in miss))


def provenance(V):
    """what the exported numbers are and are not: written into README_EXPORT.txt and shown in the GUI"""
    S = V.summary; gap = sorted(set(S['gap_source'].astype(str))) if 'gap_source' in S else []
    I = (V.info.get('dose') or {}).get('current_pA')
    unmeas = int((~V.particles['z_measured'].astype(bool)).sum()) if len(V.particles) and 'z_measured' in V.particles else 0
    lines = [f'lcsem {V.info.get("version", "")} export of {V.run_dir}',
             f'mode: {V.mode or "?"}; {V.calibration_text()}',
             f'volume model (2.5-D layer model): {V.n} frames, {V.nz} x {V.ny} x {V.nx} voxels of {V.spacing[0]:g} x {V.spacing[1]:.2f} x {V.spacing[2]:.2f} nm (z, y, x); '
             f'voxel (0,0,0) centred at {V.origin_nm[0]:.2f}, {V.origin_nm[1]:.2f}, {V.origin_nm[2]:.2f} nm (z, y, x)',
             'layers: liquid, gas, contact = fraction of the voxel x 255 (not binary); walls (membranes, window frame) and au (Au particles) = 1 (255 in 8-bit files)',
             'conventions (not measurements): z = height above the bottom of the volume, beam from +z; the top membrane is drawn FLAT and every change of the',
             '  column (liquid + gas) appears at the bottom membrane; gas not touching the top membrane (if any) is drawn on the bottom membrane - its height',
             f'  in the column is not measured; liquid thicker than {V.T_cap:.0f} nm is drawn at {V.T_cap:.0f} nm',
             f'particles: {len(V.particles)} positions, {unmeas} without a measured depth (drawn just under the top membrane in the au volumes; z_measured = 0 in the tables)',
             'gas under the SE contact: ' + ('; '.join(gap) if gap else 'n/a'),
             'dose: ' + (f'{I:g} pA; per frame {V.summary["dose_frame_e_nm2"].iloc[0]:.3g} e/nm2 (lcsem.dose, first order)' if I and 'dose_frame_e_nm2' in V.summary else 'probe current not given'),
             'thickness errors: statistical errors in the maps are too small after denoising (docs/VALIDATION.md); detector-model scale +-25-30 % without an empty-cell reference']
    if 'SE only' in (V.mode or ''): lines.insert(2, 'SE ONLY: no thickness was measured; liquid and gas volumes are NOMINAL (channel height, assumed gas layer)')
    return '\n'.join(lines)

def export_all(run_dir, out_dir, formats=FORMATS, bin=4, dz=10.0, check=True, log=print, progress=None, volume=None, should_abort=None):
    """write every requested format (one sub-folder each), read each back, and write export_manifest.csv + README_EXPORT.txt.
    A format whose library is missing, or whose writer fails, is reported in the manifest and the others are still written."""
    V = volume or Volume4D(run_dir, bin=bin, dz=dz); os.makedirs(out_dir, exist_ok=True); manifest = []
    bad = [f for f in formats if f not in WRITERS]
    if bad: raise ValueError(f'unknown export format(s) {bad}; known: {", ".join(FORMATS)}')
    for n, fmt in enumerate(formats):
        if should_abort is not None and should_abort():
            from .pipeline import Aborted
            raise Aborted('aborted by the user')
        if progress: progress(n / len(formats), f'export {fmt}')
        sub = os.path.join(out_dir, fmt); os.makedirs(sub, exist_ok=True); log(f'export {fmt} -> {sub}')
        ok_lib, hint = available(fmt)
        try:
            if not ok_lib: raise ImportError(hint)
            files = WRITERS[fmt](V, sub, log=log)
        except Exception as e:
            log(f'  {fmt}: NOT written ({type(e).__name__}: {e})')
            manifest.append(dict(format=fmt, n_files=0, size_mb=0.0, folder=os.path.relpath(sub, out_dir), open_with=OPEN_WITH.get(fmt, ''),
                                 read_back=False, reader=f'not written: {type(e).__name__}: {e}'))
            continue
        ver = verify(fmt, files, V) if check else dict(format=fmt, ok=None, reader='not checked', checked='')
        manifest.append(dict(format=fmt, n_files=len(files), size_mb=round(sum(os.path.getsize(f) if os.path.isfile(f) else _du(f) for f in files) / 1e6, 2),
                             folder=os.path.relpath(sub, out_dir), open_with=OPEN_WITH.get(fmt, ''), read_back=ver['ok'], reader=ver['reader'], checked=ver.get('checked', '')))
        log(f'  {fmt}: {len(files)} files, read back: {ver["ok"]} ({ver["reader"]})')
    M = pd.DataFrame(manifest); M.to_csv(os.path.join(out_dir, 'export_manifest.csv'), index=False)
    with open(os.path.join(out_dir, 'README_EXPORT.txt'), 'w', encoding='utf-8') as f:
        f.write(provenance(V) + '\n\n' + M.drop(columns=['open_with']).to_string(index=False) + '\n')
    if progress: progress(1.0, 'export done')
    return M

def _du(path):
    return sum(os.path.getsize(os.path.join(r, f)) for r, _, fs in os.walk(path) for f in fs)
