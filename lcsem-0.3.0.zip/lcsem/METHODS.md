# Methods: quantitative, time-resolved 3-D liquid-cell SEM with `lcsem` (v0.3)

`lcsem` turns a time series of SEM images of a membrane liquid cell (BSE, optionally STEM-in-SEM and SE, recorded in the
same scans) plus optional reference acquisitions into, per frame: (i) the liquid thickness in the column, per detector and
fused; (ii) where gas touches the top membrane; (iii) gas that does not touch it (with a gap map); (iv) the acquisition
time of every pixel; (v) particle positions in x, y and z with errors, linked into trajectories; (vi) layered 3-D label
volumes, 4-D stacks and dynamics maps. Every step is a published method; references are numbered [n] and listed at the end.
Options and what each needs: `docs/OPTIONS.md`. Validation: `docs/VALIDATION.md` and `docs/VALIDATION_DENOISING.md`.
Movies, denoising, objects, the 4-D model, the graphical interface and the exports (v0.3): section 8; `docs/GUI.md`,
`docs/EXPORT_FORMATS.md`.

## 1. Physical model

**Monte Carlo engine** (`lcsem.mc.engine`). Single elastic scattering with Mott cross sections computed with ELSEPA [1]
(free atoms, Dirac-Fock density, Fermi nucleus, Furness-McCarthy exchange; H C N O Na Al Si P S Cl Cu Au; 0.5-32 keV),
continuous slowing down with the Joy-Luo stopping power [2] (Bragg additivity, ICRU mean excitation energies), compounds
and mixtures by the independent-atom sum - the model class of CASINO [3] and DTSA-II [4]. Geometry: planar layers
(membranes, liquid, gas) plus spheres and vertical cylinders (nested shells for layered objects such as viruses, gas
pockets). The optical depth of each free flight is sampled once and consumed across material boundaries, so every flight
uses one random number and every collision four whatever the geometry; two runs with the same seeds and slightly different
materials therefore stay synchronized, and correlated sampling [5, 6] gives low-variance image differences also for
weak-contrast objects (a 44-fold variance reduction for a protein sphere in water).

**Detector models** (`lcsem.mc.detectors`): annular solid-state BSE (15-65 deg from the normal, signal proportional to
E - 2 keV, JEOL BED-C); axial BSE (0-15 deg, through-the-lens); grazing BSE (65-88 deg, the direct-BSE part of an E-T
detector, surface sensitive); SE2 generated where BSE cross the top surface, yield delta(E)/cos(theta) with the universal
yield curve [7]; SE3 (chamber); transmission detectors with any semi-angle range (bright field, ADF, HAADF). SE1 and
charging (voltage contrast) are not modelled: the SE images of this system are dominated by charging and are used as
contact maps.

**What the signals measure.** BSE and transmission signals depend on the total liquid in the column; the vertical position
of a laterally uniform gas layer is exactly invisible to both (vacuum layers only translate trajectories; checked by Monte
Carlo, 0.0 %). For sub-micrometre gas pockets, particles and edges it is not: the beam broadens as it goes down through the
liquid, so features near the top membrane are imaged sharply and deeper ones blurred - the scanning analogue of the
top-bottom effect of liquid-cell STEM [8] - and grazing BSE respond mainly to the top ~100-200 nm. The information per
electron that each detector carries about thickness and depth is computed as a Fisher information [9, 10] (per primary,
shot-noise limit, SE counts Poisson with the SE1 background included); see `examples/four_signals/`.

## 2. Calibration (`lcsem.calib`, `lcsem.references`)

Per thickness channel, grey = B0 + g S(T) with S(T) from the Monte Carlo for that detector, beam energy and cell. B0 and g
are taken from the references recorded, in order of preference: dark + empty cell (instrument calibration, B0 = blanked
level, g from the empty-cell signal S(0)); dark + particle standard; empty + particles; particles + flat field of assumed
thickness (v0.1); dark + flat; two references; manual. Every reference present but not used becomes a consistency check,
e.g. particle excess measured / predicted (the scale error of the detector model itself). Reference levels of 8-bit data
are corrected for clipping with the censored-normal mean [11]. Probe-current logs rescale g frame by frame; a frame
recorded at another contrast setting (recognized by its own particle excess) gets its own gain and black level.

**Particle standard.** Aperture photometry [12] with a background plane fitted to an annulus (iterative 3-sigma clipping),
neighbouring particles excluded from the annulus and crowded particles flagged. In thick liquid a deep particle spreads
part of its excess into a halo that no finite aperture separates from the background, so its measured excess depends on
depth; the gain is therefore taken from particles in the top quarter of the liquid, each compared with the Monte Carlo
excess at the depth its core fraction indicates (a ratio, independent of the gain) in its own local thickness (two passes).
Saturated particle cores are excluded.

**Gap map.** Frames of the cell completely filled (before gas forms) give h(x, y), the local gap including membrane bulging,
registered to the series by particle voting. Gas in the column = h - T; SE-dark pixels are gas on the top membrane; SE-bright
pixels with h - T significantly above zero (3 sigma of the combined thickness errors, morphologically cleaned) are gas that
does not touch the top membrane (label 4; its vertical position is not measured).

## 3. Image processing (`lcsem.imageproc`, `lcsem.interference`, `lcsem.fusion`)

* Particle detection by matched filtering and a robust noise threshold [13]; saturated patches rejected; sub-pixel centres by
  iterated first moments.
* Drift registration: mode of pairwise displacement vectors between particle lists (coordinate voting [14]), chained; phase
  correlation [15] as a fallback and for aligning the channels of one scan.
* Normalized convolution for all smoothing with masked pixels [16]; censoring (8-bit clipping) corrected by maximum
  likelihood on the censored normal [11]; optional non-local means [17]; scan-synchronous interference removed with narrow
  Fourier notches [18], long periods only when stationary; window-edge (Si frame) BSE halo measured and subtracted.
* Thickness per channel with its statistical error (pixel noise after smoothing divided by |g dS/dT|); channels fused by
  inverse-variance weighting, with a chi-squared map of their disagreement (a local test of the detector models).
* SE contact map: section 8 (significance-based detection on a shading-corrected SE, with a two-state background when the
  contact covers much of the field; v0.2 used an Otsu threshold [19]); discrete SE levels by multi-Otsu [20].
* Unsupervised multimodal segmentation (`lcsem.segment`, `lcsem.multimodal`): per pixel, the thickness of the primary
  channel (non-local means [17], smoothed at the fine scale only) and the NLM-denoised SE, each at two scales, and |grad T|;
  z-scored; PCA [21]; Gaussian mixture (EM [22]) in PC space with the number of classes by ICL [23] (well-separated phases)
  and BIC [24] (finer levels); posteriors smoothed, classes ordered by thickness and given plain-language tags against the
  SE contact map. The choice of the number of classes is repeated on independent random subsamples of the pixels (of the same
  size as the final fit, since ICL and BIC depend on the number of points), and the most frequent k is used and reported with
  its frequency (subsampling stability [31, 32]).
* Amira export (`lcsem.export_amira`): per frame, the layer model of every column (top membrane, gas at the top, liquid, gas
  elsewhere, bottom membrane) is converted into voxel fractions (exact overlap of each layer with each voxel), so liquid and
  gas surfaces are partial-volume isosurfaces; the membranes, the window frame and the particles are binary (1).

## 4. Particles in 3-D (`lcsem.depth`, `lcsem.tracking`)

Monte Carlo radial profiles of the particle standard at five depths and several thicknesses are rendered at the data's
pixel size (with the probe blur) and measured with the same apertures as the data. Depth estimators: **core fraction**
CF = excess within R + 10 nm / excess within R + 60 nm (one detector, one beam energy); **channel ratio** A_BSE / A_STEM of the
same scan; **energy ratio** A(E1) / A(E2) for frames at two beam energies. Each is inverted on the model curve for the
particle's local liquid column (liquid above the particle; gas on the top membrane added); errors from the pixel noise
divided by the local slope; estimates combined by inverse variance. Trajectories: frame-to-frame minimum-cost assignment
(Hungarian algorithm [25]) with a distance gate and gap closing [26]; every point keeps its own scan time; MSDs with the
localization error subtracted [27].

## 5. Time and dynamics (`lcsem.volume`, `lcsem.dynamics`)

A raster image is a clock: row r of a frame of duration t_f ends at t_end - t_f + r t_f / N_rows; all channels of a scan share
it. On the drift-corrected canvas: dT/dt with each pixel pair's own times; dry-state stack, occupancy, first/last dry time,
wet-dry transitions; normal displacement of the dry boundary between frames (signed distance transform). Outputs: per-frame
TIFFs, label volumes (0 vacuum, 1 membrane, 2 liquid, 3 gas at the top, 4 gas not at the top, 5 film, 7 outside window, 255 not
imaged/measured, 10+ particles at their depth), ImageJ hyperstacks (TYX) of thickness, time and gas.

## 6. Validation (`lcsem.simulate`, `lcsem.validate`)

Synthetic K-kit series with ground truth (bulging membranes, growing/shrinking gas pockets at the top and bottom membranes,
diffusing Au particles at known depth, drift, detector offsets, gains and noise, dark/empty/full references), written as
JEOL files and analysed with every option set; a second data set is formed with a different BSE detector acceptance than
the analysis assumes. The synthetic images use the laterally-uniform S(T) approximation for the liquid (the finite-size
effects of sub-micrometre gas pockets are quantified separately by Monte Carlo, section 1).

## 7. Uncertainties and limits

* Detector-model scale: +-25-30 % without references; tested on every data set when dark + empty + particles are recorded.
* Absolute level: set by the dark (or flat/second) reference.
* Particle depth: errors from pixel noise are reported; validation shows the reported errors are 2-3x too small at 8 nm
  pixels (model-rendering and centring errors) - use the validated spread (docs/VALIDATION.md) for planning.
* Gas that does not touch the top membrane is detected only with a gap map; its vertical position (bottom or middle) is not
  measured by BSE/STEM except near edges (beam-broadening blur) and in sub-micrometre pockets (grazing BSE).
* Freely diffusing nanoparticles move hundreds of nm during one scan line and are not imaged as spots; tracked particles are
  adsorbed or strongly hindered.
* The statistical thickness errors (`sT`) propagate the raw pixel noise through the smoothing but not through a denoiser, and
  include no systematic error: on the synthetic movies 51-53 % of the errors fall within 1.96 sT (robust sd of error / sT
  2.2-2.35, with or without a denoiser; internal review, round 2). They are lower bounds, about 2.3x too small; the maps, the
  viewer and the exports say so.
* The SE contact is detected only where the SE is at least max(5 sigma_r, 5 %) darker than the wet background: contact with a
  weaker contrast (about 3 % in the 60k series of K-kit 1) is not detected, and wet-region SE texture beyond 5 % is taken for
  contact. With contact over more than half of the field the background rests on the remaining wet part: such frames are
  flagged (summary.csv `se_contact_flag`, the view); with less than 5 % of the field wet no background can be found.
* Drift correction follows whatever moves: without a static region, positions, trajectories and object speeds include the
  registration error (2-6 px over 40 frames on the synthetic movies in which everything moves).
* The PCA + GMM segmentation is fitted frame by frame: in a movie the number of classes and their tags can change between
  frames. Compare frames with care; a series-wide model is planned.
* Gas volumes without a full-cell reference rest on a gap interpolated from the wet surroundings (section 8).
* The SE contact map assumes that SE-dark means gas on the top membrane (section 8); drifting or inverting SE contrast
  (charging) violates it.

## 8. Movies, denoising, objects and the 4-D model (v0.3)

**Movies** (`lcsem.io_movie`). SE, BSE and STEM movies are read as multi-frame TIFF (frame interval from the ImageJ
`finterval` or the OME `TimeIncrement`), video files (AVI, MP4, MOV, MKV via FFmpeg; RGB converted to grey; decoded on
demand) or folders of images in natural order; one detector per file, or several in one file side by side, top/bottom or in
interleaved frames (a TCYX hyperstack is the interleaved layout). A crop is applied to the whole frame before it is split.
Each time point is one frame or the mean of W consecutive frames; every row of an averaged time point is dated at its mean
acquisition time (one frame duration, ending (W - 1)/2 frames before the last one), so the per-row clock of section 5
holds. The raw data type sets the bit depth, and data above it stop the run. Lossy video (MP4) is accepted, but
compression alters grey levels and noise; lossless TIFF is preferred and references must go through the same path.

**Drift** (`register_stack`, `register_movie`). Chained cross-correlation of neighbouring frames, band-passed (difference of
Gaussians, 2-20 px) and Tukey-windowed, refined to 1/20 px (`skimage.registration.phase_cross_correlation` without
normalisation, i.e. plain cross-correlation [15]); particle voting [14] only when a step is implausibly large. The chain is
measured on every frame of the movie, also when only every n-th frame is analysed, and subsampled afterwards: a chain over the
analysed frames alone spans more scene change per link (at a step of 4 its error was 1.8-4.3 times that at a step of 1 on
the synthetic movies; internal review, round 2). Optional: longer baselines combined by least squares [42] where consistent
with the chain, a median-template refinement, and a region of interest. Registration needs static features: a chain follows
whatever moves, and on the synthetic movies in which everything changes it accumulated 2-3 px (BSE) and 3-6 px (SE) over
40 frames (`docs/VALIDATION.md`); give a static region (window edge, stuck particles) or choose none for a stable stage. The
template refinement made that case worse and is off by default.

**Noise model and variance stabilisation** (`lcsem.denoise`). Detector signals are modelled as Poisson-Gaussian, var(x) =
a x + b (a = gain times the excess-noise factor of the single-electron response; b = read noise minus a times the offset).
a and b are fitted per frame (per series for the series methods) from the local variance against the local mean in the
flattest 30 % of 7 x 7 windows (median per intensity bin, corrected for the bias of the median of a chi-squared variance), a
simplified form of the method of Foi et al. [33]; it assumes white noise. On the benchmark's own true-Poisson data the fitted
slope a is 0.86-0.89 of the true value and the offset b is also off (internal review, round 2); the resulting error after the
inverse transform is below 0.4 grey levels, but the model has not been checked on real data (do so with the temporal mean
and variance of a static region). The generalized Anscombe transform [34, 35] makes
the noise approximately unit-variance Gaussian; after denoising, the closed-form approximation of the exact unbiased
inverse [36, 37] (the Poisson inverse applied with the read-noise term) returns to grey levels.

**Denoisers.** Per frame: non-local means [17, 60] (default), BM3D [38], total variation [39, 40], Gaussian (baseline).
Per series (movies; in blocks of 32 time points, each block's frames aligned by whole pixels on the field common to the
block so that the noise stays white and independent, denoised, and put back in their own geometry; pixels outside that field
stay undenoised and are flagged in the maps; the drift comes from every raw frame and the raw frames are kept for particle
photometry and noise estimates): Marchenko-Pastur PCA (MP-PCA) [41, 43] with the classifier of DIPY [44] and the overlap
weights of Manjon et al. [61] on p x p patches, p the smallest odd integer with p^2 >= 4 T; the optimal singular-value hard
threshold of Gavish and Donoho [45] (known noise after the transform); temporal mean and median. The segmentation does not
denoise frames a second time.
On synthetic movies with ground truth (`docs/VALIDATION_DENOISING.md`): BM3D + VST is best for changing scenes, NLM + VST
within 5-25 % of it and 20x faster; MP-PCA + VST is best for static scenes; the series methods blur a changing scene. At the
default 15-px smoothing of the thickness maps the choice changes the thickness bias by at most 2 nm and the mean error by
less than 1 nm, and leaves the SE contact, the particles and the gas volumes unchanged; NLM + VST (the default) removes most
of the thickness bias that noise causes through the non-linear calibration at low signal.

**SE contact map** (`lcsem.analysis.se_contact_map`). The SE is smoothed (normalised convolution [16], 6 px) and divided by
its smooth background B at the level of the wet (SE-bright) surface. B is found in one of two ways. If the distribution of
the smoothed SE is bimodal (two peaks at least twice the detection floor apart, separated by a valley below 0.6 of the lower
peak, each side holding at least 5 % of the pixels), the field has two surface states: s = B (1 + c g), with one smooth
quadratic B for both states (multiplicative shading acts on both, so B is fitted to the whole field and not extrapolated
from the wet part), g the state (contact below half of the fitted contrast c) re-assigned until stable, fitted in log space
with outliers dropped - a bias-field model with two classes [68]; the brighter state is the background, since contact
darkens the SE. Otherwise B is a robust quadratic fitted from the brighter half, dropping pixels more than 3 sd below it
(contact) or 4 sd above it (bright structure such as thicker liquid). Pixels darker than max(5 sigma_r, 5 %) are then
detected, sigma_r being the noise of the smoothed relative SE propagated from the pixel noise; each detected region is grown
to half of its own core contrast (so the area does not depend on the detection threshold), cleaned morphologically and kept
above a minimum area (0.01 um2 by default). A frame without gas therefore has no contact region, instead of the half of the
field a per-frame Otsu split of noise gives [19]; contact over most of the field is still found (discs covering up to 80 %
and drying fronts up to 90 % of the field: 0.97-0.99 of the true area, 12k-like contrast and noise with 5 % shading), and
frames with contact over half of the field are flagged. The detection floor (5 %) is written in the view and in summary.csv. The SE contrast of the dry top membrane comes from SE2 and charging (voltage contrast; Cazaux [62],
Reimer [63]); it can drift and invert with dose rate and scan speed, and its interpretation as gas contact should be
checked on each system (for example a partially filled cell with a gap map). Particle masks do not cut the contact map.

**Particles** (`lcsem.imageproc.detect_particles`). Matched filtering as in section 3, scale by scale from the finest: a
peak found at a scale is kept there and coarser scales only add peaks away from it (at coarse scales a particle next to a
thickness step merges with the step). Two tests reject edge-like responses (the bright side of a bubble rim or any
thickness step): the Hessian ratio test of Lowe [64] (both principal curvatures negative, ratio below 10) and a sector test
on rings of radius 1, 1.5 and 2 times max(2.5 sigma, 3 px): the peak is rejected when, on any ring, the filtered image reaches
half of the peak on a long arc (over a third of the ring) or on opposite sides (a ridge through the peak), and kept when it
does so on one side only (a neighbouring particle, a step nearby). Synthetic tests: pairs 6-14 px apart 0.98-1.00 recall
(5 px: 0.6), particles 3-20 px from a 25-grey step 1.00, bubble rims without particles 0 false detections per image (141
without the tests); on the synthetic movie (20 frames) recall 0.89 with 2 false detections (`docs/VALIDATION.md`).

**Gas at the top without a gap map.** The gap under the SE contact is interpolated from the wet surroundings with a robust
quadratic surface (membrane bulging is smooth), fitted to wet pixels more than 2.5 smoothing lengths from the contact; the
gas volume is the unclipped sum of (gap - thickness) over the contact region and that margin (unbiased by noise, and it
recovers the gas deficit that the smoothing moves across the rim); per-pixel gas maps are clipped at 0 for display. Its
statistical standard deviation is that of the same sum where there is no gas: the residual gap - thickness of the wet
surroundings (noise, smoothing, misfit of the gap surface) is treated as a stationary field, and Var = sum over lags of its
covariance times the number of pixel pairs of the summed region at that lag (the variance of a spatial sum [69]; within
6 % of simulation for smoothed and white fields); the charts show +-2 sd and mark frames consistent with no gas. It does not
include the bias of the gap interpolation below. Frames without SE have no gas measurement (NaN), and neither have frames
in which the contact covers more than half of the field or the wet surroundings used for the gap are less than a quarter of
it: the gap would be extrapolated from a small part over most of the field (on the real 12k series this gave -5.8 um3 of
"gas" in a frame with 66 % contact); a full-cell reference is needed there. Validation: 0.93-0.98 of the true volume while the contact covers < 17 % of the
field, 0.63-0.70 when a large bubble covers the thickest part of the bulge (`docs/VALIDATION.md`): record a full-cell
reference for gas volumes.

**SE-only series** (`lcsem.se_only`). Without BSE or STEM the thickness is not measured. The SE contact map is computed per
frame (with the method above; multi-Otsu levels [20] of the smoothed SE are stored as well); the 3-D model is nominal - the
channel height given by the user, with a gas layer of assumed height where the SE shows contact - and the volumes are
reported as not measured. The areas, shapes and dynamics of the contact regions are measured.

**Objects** (`lcsem.objects`). Contact regions (or gas thicker than a limit, or liquid thinner than a limit, or a
segmentation class) per frame: holes filled, touching objects separated by the watershed of the distance transform [46]
with h-maxima markers [65] (an elongated object stays one object; two touching discs are split), small objects removed.
Per object: area, equivalent diameter, perimeter, eccentricity, centroid on the drift-corrected canvas, mean gas and
liquid thickness, gas volume, border contact, and its time (the mean acquisition time of its rows). Linking between frames
by maximum overlap (IoU, Hungarian assignment [25]); splits and merges when an overlap covers at least half of the smaller
object; per track: growth rate (linear fit over the frames where the object does not touch the border) and net speed.

**Electron dose** (`lcsem.dose`). With the probe current: fluence per frame I t_f / (e A) over the scanned field (e/nm^2),
the cumulative fluence (all frames scanned up to the end of each time point, also those skipped by a frame step; a time
point averaging W frames carries W frame fluences), the frame-averaged dose rate, and the absorbed dose in water to first order (collision stopping power at the beam energy [2]; about 0.26 MGy
per e/nm^2 at 15 keV). At movie doses radiolysis can itself nucleate bubbles [66, 67]: report the dose with every result.

**4-D model** (`lcsem.volume4d`). All displays and exports are made from one 2.5-D layer model: the per-pixel layer maps
of every frame (top membrane, gas at the top, liquid, gas elsewhere, bottom membrane) placed on the drift-corrected canvas,
binned laterally (default 4 x 4) and converted into voxels of height dz (default 10 nm): liquid and gas as the exact
fraction of each voxel they fill (partial volumes, 0-255), the membranes and the window frame as 1, the Au particles as
spheres of their true diameter at their measured depth (1; particles without a measured depth are placed under the top
membrane in the voxel volumes and flagged in every table, and the viewer draws them as vertical lines through their
column), and the SE contact as a fraction in the voxel layer under the top membrane. Conventions, not measurements: the top
membrane is drawn flat and every change of the column shows at the bottom membrane; gas not touching the top membrane is
drawn on the bottom membrane; liquid thicker than a cap (1500 nm) is drawn at the cap. The lateral resolution of the
thickness is set by the calibration smoothing (15 px: about 120 nm at 8 nm pixels), coarser than the SE footprint. Time
series are summed over the field imaged in every frame. Voxel (0, 0, 0) is centred at (dz/2, (b - 1) p_y / 2, (b - 1) p_x
/ 2) in every export and in the viewer.

**Graphical interface** (`lcsem.gui`). A napari viewer [47] with time as the first axis (slider at the bottom) and the 4-D
model as image layers (isosurfaces at half filling), points and lines (particles), tracks, 2-D map layers, a charts dock
(volumes, thickness histogram, particle depth, objects, SE contact, dose) and a 2-D maps dock (thickness with a colour bar,
SE contact over the SE frame, the input frames with the detected particles), both following the time slider. The view
states the calibration used (and any assumption), the dose and the layer-model convention. Long computations run in a
worker thread (one at a time) with progress and abort; a running job is listed in napari's close dialog and is aborted
(and waited for) only when the close is accepted. Before a run, the calibration that the references allow and the
acquisition values are shown, and a run that would rest on a hidden assumption, lacks the pixel size or would not fit in
memory is refused. A project (all settings)
is saved as JSON with the run and runs without the interface (`lcsem project`).

**Exports** (`lcsem.export_formats`). From the same 4-D model: Amira/Avizo [55] (AmiraMesh, zlib-compressed), ImageJ/Fiji
hyperstacks [49, 50], OME-TIFF [48] and OME-Zarr (NGFF) [51], Imaris (.ims), VTK image data with a time collection and
particle/track poly-data for ParaView [52], NRRD and NIfTI for 3D Slicer [53] and ITK-SNAP (on the same physical grid), MRC2014 [54] for ChimeraX [56]
and IMOD [57], surface meshes by marching cubes [58] (STL and coloured glTF), MATLAB, HDF5, CSV/Excel and TrackMate spot
tables [59]. Every export is read back with an independent reader where one exists and compared with the model voxel by
voxel for every layer of the first, middle and last frame, with the voxel size where the format stores it
(`export_manifest.csv`); a README states the conventions, the calibration and the dose.

## References

1. F. Salvat, A. Jablonski, C. J. Powell, *ELSEPA - Dirac partial-wave calculation of elastic scattering of electrons and positrons by atoms, positive ions and molecules*, Comput. Phys. Commun. 165, 157-190 (2005).
2. D. C. Joy, S. Luo, *An empirical stopping power relationship for low-energy electrons*, Scanning 11, 176-180 (1989).
3. D. Drouin et al., *CASINO V2.42 - a fast and easy-to-use modeling tool for scanning electron microscopy and microanalysis users*, Scanning 29, 92-101 (2007).
4. N. W. M. Ritchie, *Spectrum simulation in DTSA-II*, Microsc. Microanal. 15, 454-468 (2009).
5. J. Spanier, E. M. Gelbard, *Monte Carlo Principles and Neutron Transport Problems*, Addison-Wesley (1969).
6. H. Rief, *Generalized Monte Carlo perturbation algorithms for correlated sampling and a second-order Taylor series approach*, Ann. Nucl. Energy 11, 455-476 (1984).
7. Y. Lin, D. C. Joy, *A new examination of secondary electron yield data*, Surf. Interface Anal. 37, 895-900 (2005).
8. N. de Jonge, F. M. Ross, *Electron microscopy of specimens in liquid*, Nat. Nanotechnol. 6, 695-704 (2011).
9. H. Cramer, *Mathematical Methods of Statistics*, Princeton University Press (1946).
10. C. R. Rao, *Information and the accuracy attainable in the estimation of statistical parameters*, Bull. Calcutta Math. Soc. 37, 81-91 (1945).
11. A. C. Cohen, *Simplified estimators for the normal distribution when samples are singly censored or truncated*, Technometrics 1, 217-237 (1959).
12. S. B. Howell, *Two-dimensional aperture photometry: signal-to-noise ratio of point-source observations and optimal data-extraction techniques*, Publ. Astron. Soc. Pac. 101, 616-622 (1989).
13. E. Bertin, S. Arnouts, *SExtractor: software for source extraction*, Astron. Astrophys. Suppl. Ser. 117, 393-404 (1996).
14. E. J. Groth, *A pattern-matching algorithm for two-dimensional coordinate lists*, Astron. J. 91, 1244-1248 (1986).
15. M. Guizar-Sicairos, S. T. Thurman, J. R. Fienup, *Efficient subpixel image registration algorithms*, Opt. Lett. 33, 156-158 (2008).
16. H. Knutsson, C.-F. Westin, *Normalized and differential convolution*, Proc. IEEE CVPR, 515-523 (1993).
17. A. Buades, B. Coll, J.-M. Morel, *A review of image denoising algorithms, with a new one*, Multiscale Model. Simul. 4, 490-530 (2005).
18. R. C. Gonzalez, R. E. Woods, *Digital Image Processing*, 4th ed., Pearson (2018), ch. 5.
19. N. Otsu, *A threshold selection method from gray-level histograms*, IEEE Trans. Syst. Man Cybern. 9, 62-66 (1979).
20. P.-S. Liao, T.-S. Chen, P.-C. Chung, *A fast algorithm for multilevel thresholding*, J. Inf. Sci. Eng. 17, 713-727 (2001).
21. K. Pearson, Philos. Mag. 2, 559-572 (1901); H. Hotelling, J. Educ. Psychol. 24, 417-441 (1933); I. T. Jolliffe, *Principal Component Analysis*, 2nd ed., Springer (2002).
22. A. P. Dempster, N. M. Laird, D. B. Rubin, *Maximum likelihood from incomplete data via the EM algorithm*, J. R. Stat. Soc. B 39, 1-38 (1977).
23. C. Biernacki, G. Celeux, G. Govaert, *Assessing a mixture model for clustering with the integrated completed likelihood*, IEEE Trans. Pattern Anal. Mach. Intell. 22, 719-725 (2000).
24. G. Schwarz, *Estimating the dimension of a model*, Ann. Stat. 6, 461-464 (1978).
25. H. W. Kuhn, *The Hungarian method for the assignment problem*, Nav. Res. Logist. Q. 2, 83-97 (1955).
26. K. Jaqaman et al., *Robust single-particle tracking in live-cell time-lapse sequences*, Nat. Methods 5, 695-702 (2008).
27. X. Michalet, *Mean square displacement analysis of single-particle trajectories with localization error: Brownian motion in an isotropic medium*, Phys. Rev. E 82, 041914 (2010).
28. H. R. Kuensch, *The jackknife and the bootstrap for general stationary observations*, Ann. Stat. 17, 1217-1241 (1989).
29. R. E. Barlow et al., *Statistical Inference under Order Restrictions*, Wiley (1972).
30. S. van der Walt et al., *scikit-image: image processing in Python*, PeerJ 2, e453 (2014); F. Pedregosa et al., *Scikit-learn: machine learning in Python*, J. Mach. Learn. Res. 12, 2825-2830 (2011).
31. N. Meinshausen, P. Buehlmann, *Stability selection*, J. R. Stat. Soc. B 72, 417-473 (2010).
32. T. Lange, V. Roth, M. L. Braun, J. M. Buhmann, *Stability-based validation of clustering solutions*, Neural Comput. 16, 1299-1323 (2004).
33. A. Foi, M. Trimeche, V. Katkovnik, K. Egiazarian, *Practical Poissonian-Gaussian noise modeling and fitting for single-image raw-data*, IEEE Trans. Image Process. 17, 1737-1754 (2008).
34. F. J. Anscombe, *The transformation of Poisson, binomial and negative-binomial data*, Biometrika 35, 246-254 (1948).
35. F. Murtagh, J.-L. Starck, A. Bijaoui, *Image restoration with noise suppression using a multiresolution support*, Astron. Astrophys. Suppl. Ser. 112, 179-189 (1995).
36. M. Makitalo, A. Foi, *A closed-form approximation of the exact unbiased inverse of the Anscombe variance-stabilizing transformation*, IEEE Trans. Image Process. 20, 2697-2698 (2011).
37. M. Makitalo, A. Foi, *Optimal inversion of the generalized Anscombe transformation for Poisson-Gaussian noise*, IEEE Trans. Image Process. 22, 91-103 (2013).
38. K. Dabov, A. Foi, V. Katkovnik, K. Egiazarian, *Image denoising by sparse 3-D transform-domain collaborative filtering*, IEEE Trans. Image Process. 16, 2080-2095 (2007).
39. L. I. Rudin, S. Osher, E. Fatemi, *Nonlinear total variation based noise removal algorithms*, Physica D 60, 259-268 (1992).
40. A. Chambolle, *An algorithm for total variation minimization and applications*, J. Math. Imaging Vis. 20, 89-97 (2004).
41. J. Veraart, D. S. Novikov, D. Christiaens, B. Ades-Aron, J. Sijbers, E. Fieremans, *Denoising of diffusion MRI using random matrix theory*, NeuroImage 142, 394-406 (2016).
42. X. Li et al., *Electron counting and beam-induced motion correction enable near-atomic-resolution single-particle cryo-EM*, Nat. Methods 10, 584-590 (2013).
43. V. A. Marchenko, L. A. Pastur, *Distribution of eigenvalues for some sets of random matrices*, Math. USSR Sb. 1, 457-483 (1967).
44. E. Garyfallidis et al., *Dipy, a library for the analysis of diffusion MRI data*, Front. Neuroinform. 8, 8 (2014).
45. M. Gavish, D. L. Donoho, *The optimal hard threshold for singular values is 4/sqrt(3)*, IEEE Trans. Inf. Theory 60, 5040-5053 (2014).
46. F. Meyer, S. Beucher, *Morphological segmentation*, J. Vis. Commun. Image Represent. 1, 21-46 (1990).
47. napari contributors, *napari: a multi-dimensional image viewer for Python*, Zenodo, doi:10.5281/zenodo.3555620.
48. I. G. Goldberg et al., *The Open Microscopy Environment (OME) Data Model and XML file: open tools for informatics and quantitative analysis in biological imaging*, Genome Biol. 6, R47 (2005).
49. C. A. Schneider, W. S. Rasband, K. W. Eliceiri, *NIH Image to ImageJ: 25 years of image analysis*, Nat. Methods 9, 671-675 (2012).
50. J. Schindelin et al., *Fiji: an open-source platform for biological-image analysis*, Nat. Methods 9, 676-682 (2012).
51. J. Moore et al., *OME-NGFF: a next-generation file format for expanding bioimaging data-access strategies*, Nat. Methods 18, 1496-1498 (2021).
52. J. Ahrens, B. Geveci, C. Law, *ParaView: an end-user tool for large data visualization*, in *The Visualization Handbook*, Elsevier, 717-731 (2005).
53. A. Fedorov et al., *3D Slicer as an image computing platform for the Quantitative Imaging Network*, Magn. Reson. Imaging 30, 1323-1341 (2012).
54. A. Cheng et al., *MRC2014: extensions to the MRC format header for electron cryo-microscopy and tomography*, J. Struct. Biol. 192, 146-150 (2015).
55. D. Stalling, M. Westerhoff, H.-C. Hege, *Amira: a highly interactive system for visual data analysis*, in *The Visualization Handbook*, Elsevier, 749-767 (2005).
56. E. F. Pettersen et al., *UCSF ChimeraX: structure visualization for researchers, educators, and developers*, Protein Sci. 30, 70-82 (2021).
57. J. R. Kremer, D. N. Mastronarde, J. R. McIntosh, *Computer visualization of three-dimensional image data using IMOD*, J. Struct. Biol. 116, 71-76 (1996).
58. W. E. Lorensen, H. E. Cline, *Marching cubes: a high resolution 3D surface construction algorithm*, Comput. Graph. 21, 163-169 (1987).
59. J.-Y. Tinevez et al., *TrackMate: an open and extensible platform for single-particle tracking*, Methods 115, 80-90 (2017).
60. J. Darbon, A. Cunha, T. F. Chan, S. Osher, G. J. Jensen, *Fast nonlocal filtering applied to electron cryomicroscopy*, Proc. IEEE ISBI, 1331-1334 (2008).
61. J. V. Manjon et al., *Diffusion weighted image denoising using overcomplete local PCA*, PLoS ONE 8, e73021 (2013).
62. J. Cazaux, *Charging in scanning electron microscopy "from inside and outside"*, Scanning 26, 181-203 (2004).
63. L. Reimer, *Scanning Electron Microscopy: Physics of Image Formation and Microanalysis*, 2nd ed., Springer (1998).
64. D. G. Lowe, *Distinctive image features from scale-invariant keypoints*, Int. J. Comput. Vis. 60, 91-110 (2004).
65. P. Soille, *Morphological Image Analysis: Principles and Applications*, 2nd ed., Springer (2003).
66. N. M. Schneider et al., *Electron-water interactions and implications for liquid cell electron microscopy*, J. Phys. Chem. C 118, 22373-22382 (2014).
67. J. M. Grogan, N. M. Schneider, F. M. Ross, H. H. Bau, *Bubble and pattern formation in liquid induced by an electron beam*, Nano Lett. 14, 359-364 (2014).
68. W. M. Wells III, W. E. L. Grimson, R. Kikinis, F. A. Jolesz, *Adaptive segmentation of MRI data*, IEEE Trans. Med. Imaging 15, 429-442 (1996).
69. N. A. C. Cressie, *Statistics for Spatial Data*, revised ed., Wiley (1993).
