"""Do the SE grey levels rank the liquid thickness?  Feature-by-feature test on the maps written by `lcsem run`.

    python examples/se_levels_example.py out_12k 3            # frame 3 of that run

For the frame: denoise the SE (non-local means), split the SE-dark region into levels (multi-Otsu), and report the
liquid thickness (BSE) under each level with a 95 % block-bootstrap confidence interval, plus the wet reference.
Also fits a monotone SE -> thickness relation (isotonic regression) and prints Spearman's rho, so that you can see
whether a graded SE -> thickness mapping is justified for that frame."""
import sys, glob, os, numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from lcsem.imageproc import denoise_nlm, smooth_masked
from lcsem.analysis import se_levels, region_table, monotone_fit

out_dir, frame = sys.argv[1], int(sys.argv[2]); n_levels = int(sys.argv[3]) if len(sys.argv) > 3 else 3
fn = sorted(glob.glob(os.path.join(out_dir, f'*_{frame:02d}_*_maps.npz')))[0]; d = np.load(fn)
T, dark, valid, au = d['T'], d['dark'], d['valid'], d['au']; se = d['se']
if se.size == 0: raise SystemExit('no SE image for this frame')
ok = valid & np.isfinite(se) & np.isfinite(T); ok[:200] = False          # skip the frame-start transient
se_dn, sigma = denoise_nlm(se, ~ok, patch=5, distance=9)
regions = {}
lev, thr = se_levels(se_dn, dark & ok, n_levels)
for k in range(n_levels): regions[f'SE-dark level {k} (SE {se_dn[(lev == k)].mean():.0f})'] = (lev == k)
regions['SE-bright (wet reference)'] = ok & ~dark
rows = region_table(T, regions, se_dn)
wet = [r for r in rows if r['region'].startswith('SE-bright')][0]['liquid_nm']
print(f'{os.path.basename(fn)}   NLM noise sigma {sigma:.1f}')
for r in rows:
    print(f"  {r['region']:<40s} liquid {r['liquid_nm']:6.0f} nm  (95 % CI {r['ci95_lo']:.0f}-{r['ci95_hi']:.0f}, n={r['n_px']//1000}k px)   gas gap {max(wet - r['liquid_nm'], 0):5.0f} nm")
x = smooth_masked(se_dn, ~ok, 20)[ok]; y = smooth_masked(np.nan_to_num(T, nan=np.nanmedian(T)), ~ok, 5)[ok]
pred, rho, p = monotone_fit(x, y)
print(f'  monotone SE -> thickness fit: Spearman rho = {rho:+.2f} (p = {p:.1e}); ' + ('graded mapping justified for this frame' if rho > 0.3 else 'weak or inverted relation: use SE only as a contact map, BSE for thickness'))
