"""E. coli (capsule, 1 um x 2 um) in a K-kit with a 2 um channel and 30 nm SiN windows: per-detector images vs beam energy
and position (on the bottom membrane, on the top membrane, mid-channel). Straight part = infinite rod (transverse profile),
caps = sphere of the same radius and depth (radial profile); composed into 2-D images in ec_figure.py."""
import numpy as np, sys, time, pickle, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
from lcsem.mc.engine import Sim, stack
from lcsem.mc import radial, scenes

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out'); os.makedirs(OUT, exist_ok=True)
S = Sim(['vac', 'SiN', 'H2O', 'protein', 'RNA', 'lipid', 'DNA'])
T = float(sys.argv[1]) if len(sys.argv) > 1 else 2000.0
Es = [float(e) for e in sys.argv[2].split(',')] if len(sys.argv) > 2 else [25.0, 15.0, 20.0, 30.0]
poss = sys.argv[3].split(',') if len(sys.argv) > 3 else ['bot', 'top', 'mid']
scale = float(sys.argv[4]) if len(sys.argv) > 4 else 1.0
DET = ['BEDC', 'BSE_grazing', 'SE2', 'STEM_BF50', 'STEM_BF100', 'STEM_ADF', 'STEM_HAADF', 'STEM_all']
zb, lm = stack(S, [(T, 'H2O')]); R = scenes.ECOLI['radius']; t00 = time.time()
for E in Es:
    for pos in poss:
        zc = scenes.z_of(pos, R, T)
        n = lambda a: int(a * scale)
        zt = [(0.0, 700.0, n(1500000), 10.0), (700.0, 1500.0, n(500000), 25.0), (1500.0, 3000.0, n(200000), 50.0)]
        rt = radial.transverse_profiles(S, zb, lm, scenes.ecoli_objects(S, zc, 'rod'), E, zt, detectors=DET, seed=int(E * 10 + len(pos)))
        zs = [(0.0, 700.0, n(1500000), 10.0), (700.0, 1500.0, n(500000), 25.0), (1500.0, 3000.0, n(200000), 50.0)]
        rs = radial.profiles(S, zb, lm, scenes.ecoli_objects(S, zc, 'cap'), E, zs, detectors=DET, seed=int(E * 10 + len(pos) + 7))
        res = dict(E=E, pos=pos, zc=zc, T=T, rod=rt, cap=rs, model=scenes.ECOLI, compartments=scenes.ecoli_compartments()[0])
        pickle.dump(res, open(f'{OUT}/EC_T{int(T)}_E{int(E)}_{pos}.pkl', 'wb'))
        d = rt['det']
        print(f'T{T:.0f} E{E:.0f} {pos}: rod excess per length  BEDC {d["BEDC"]["integral"]:9.2f}+-{d["BEDC"]["err"]:.2f}  BF100 {d["STEM_BF100"]["integral"]:8.2f}+-{d["STEM_BF100"]["err"]:.2f}  '
              f'ADF {d["STEM_ADF"]["integral"]:8.2f}  HAADF {d["STEM_HAADF"]["integral"]:8.2f}   [{rt["sec"] + rs["sec"]:.0f}s, {time.time()-t00:.0f}s]', flush=True)
print('done', flush=True)
