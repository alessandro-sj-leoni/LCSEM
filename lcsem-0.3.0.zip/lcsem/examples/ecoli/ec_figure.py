"""E. coli in a K-kit with a 2 um channel and 30 nm SiN windows: the model, noise-free and noisy images for every signal
(BSE, E-T in BSE mode, in-lens SE, STEM BF/ADF/HAADF) at three depths, the depth cues and the doses. Calibrated TIFFs.
Monte Carlo: lcsem.mc (ELSEPA Mott cross sections, Joy-Luo CSDA); straight part = infinite rod (transverse profile),
caps = sphere of the same radius at the same depth (radial profile)."""
import numpy as np, pickle, glob, sys, os, zipfile, tifffile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, '..', '..')); sys.path.insert(0, HERE)
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Circle, Rectangle, FancyBboxPatch
from matplotlib.lines import Line2D
from scipy.ndimage import gaussian_filter
from lcsem.mc.radial import smooth_profile, render_capsule
from lcsem.mc import scenes
from lcsem.mc.engine import mix
from lcsem.mc.detectors import se_yield
import ec_analyse as EA

OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'figures'); os.makedirs(OUT, exist_ok=True)
EBEST = int(sys.argv[2]) if len(sys.argv) > 2 else 25
INK, INK2, GRID = '#0b0b0b', '#52514e', '#e4e3df'
C6 = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300']
BLUES = LinearSegmentedColormap.from_list('seq', ['#fcfcfb', '#cde2fb', '#9ec5f4', '#6da7ec', '#3987e5', '#256abf', '#184f95', '#0d366b'])
plt.rcParams.update({'font.size': 9, 'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'xtick.color': INK2, 'ytick.color': INK2,
                     'axes.titlesize': 10, 'axes.titleweight': 'bold'})
P = scenes.ECOLI; R = P['radius']; HL = P['length'] / 2 - R; ENV = P['envelope']; RN = P['nucleoid_radius']; TCH = 2000.0
POS = ('top', 'mid', 'bot'); PNAME = {'top': 'touching the top membrane', 'mid': 'mid-channel', 'bot': 'on the bottom membrane'}
SHOW = [('BEDC', 'BSE (BED-C)'), ('BSE_grazing', 'E-T, BSE mode (grazing)'), ('SE2', 'in-lens SE (SE1 + SE2)'),
        ('STEM_BF100', 'STEM BF <100 mrad'), ('STEM_ADF', 'STEM ADF 100-400 mrad'), ('STEM_HAADF', 'STEM HAADF >400 mrad')]
SMOOTH = {'BEDC': 50.0, 'BSE_grazing': 70.0, 'SE2': 60.0, 'STEM_BF100': 40.0, 'STEM_BF50': 50.0, 'STEM_ADF': 25.0, 'STEM_HAADF': 25.0, 'STEM_all': 30.0}

def S_rho(E_keV, ZA=0.5551, I_eV=75.0):
    """collision stopping power of water (MeV cm2/g), Bethe formula for electrons (Rohrlich-Carlson / ICRU 37)"""
    t = E_keV / 511.0; g = 1 + t; b2 = 1 - 1 / g ** 2; Ir = I_eV / 511e3
    F = 1 - b2 + (t * t / 8 - (2 * t + 1) * np.log(2)) / (t + 1) ** 2
    return 0.1535 * ZA / b2 * (np.log(t * t * (t + 2) / (2 * Ir * Ir)) + F)
def gray_per_e_nm2(E): return 1e14 * S_rho(E) * 1.602e-13 * 1e3

def merge(rods):
    out = dict(rods[0]); out['det'] = {}
    for k in rods[0]['det']:
        Pm = np.array([r['det'][k]['prof'] for r in rods]); Em = np.array([np.maximum(r['det'][k]['prof_err'], 1e-12) for r in rods])
        w = 1 / Em ** 2; wi = np.array([1 / max(r['det'][k]['err'], 1e-12) ** 2 for r in rods]); nn = np.array([r['cnt'].sum() for r in rods])
        out['det'][k] = dict(prof=(w * Pm).sum(0) / w.sum(0), prof_err=1 / np.sqrt(w.sum(0)),
                             integral=float((wi * np.array([r['det'][k]['integral'] for r in rods])).sum() / wi.sum()), err=float(1 / np.sqrt(wi.sum())),
                             bg_mean=float((nn * np.array([r['det'][k]['bg_mean'] for r in rods])).sum() / nn.sum()),
                             bg_var=float((nn * np.array([r['det'][k]['bg_var'] for r in rods])).sum() / nn.sum()))
    out['cnt'] = np.sum([r['cnt'] for r in rods], axis=0); return out

D = EA.load()
for (E, pos), r in D.items():
    hi = sorted(glob.glob(os.path.join(HERE, 'out', f'ECHI_T2000_E{E}_{pos}_*.pkl')))
    if hi: r['rod'] = merge([r['rod']] + [pickle.load(open(f, 'rb'))['rod'] for f in hi]); r['n_hi'] = len(hi)
ES = sorted({e for e, _ in D})

def bg_tot(r, k):
    """mean and second moment of the per-primary signal of the background (SE: SE1 + SE2, Poisson counts)"""
    d = r['rod']['det'][k]; m = d['bg_mean']; m2 = d['bg_var'] + m * m
    if k == 'SE2':
        s1 = float(se_yield(np.array([float(r['E'])]))[0]); m2 = m2 + 2 * m * s1 + s1 * s1 + m + s1; m = m + s1
    return m, m2

def profiles(r, k):
    t = r['rod']['det'][k]; c = r['cap']['det'][k]; w = SMOOTH.get(k, 20.0)
    pt = smooth_profile(r['rod']['xc'], t['prof'], np.maximum(t['prof_err'], 1e-12), w)
    pc = smooth_profile(r['cap']['rc'], c['prof'], np.maximum(c['prof_err'], 1e-12), w)
    return r['rod']['xc'], pt, r['cap']['rc'], pc

PX = (20.0, 20.0); FIELD = (2400.0, 3200.0)
def image(r, k, ss=2):
    """capsule image from the transverse profile of the straight part: a pixel over a cap is given the profile value at its
    distance from the cap centre, i.e. at the same chord length through the cell (continuous at the junction; the sphere
    Monte Carlo of the caps is used as a check of this approximation in ecoli_table.csv)"""
    xc, pt, rc, pc = profiles(r, k); px, py = PX; nx = int(np.ceil(FIELD[0] / 2 / px)); ny = int(np.ceil(FIELD[1] / 2 / py))
    xs = (np.arange(-nx * ss, nx * ss) + 0.5) * (px / ss); ys = (np.arange(-ny * ss, ny * ss) + 0.5) * (py / ss); X, Y = np.meshgrid(xs, ys)
    rho = np.where(np.abs(Y) <= HL, np.abs(X), np.hypot(X, np.abs(Y) - HL))
    img = np.interp(rho, xc, pt, right=0.0)
    return img.reshape(2 * ny, ss, 2 * nx, ss).mean(axis=(1, 3))

def outline(ax, color=INK2, lw=0.8, ls=':'):
    th = np.linspace(0, np.pi, 60)
    xs = np.concatenate([R * np.cos(th), -R * np.ones(2), R * np.cos(th + np.pi), R * np.ones(2)])
    ys = np.concatenate([HL + R * np.sin(th), [HL, -HL], -HL + R * np.sin(th + np.pi), [-HL, HL]])
    ax.plot(xs, ys, color=color, lw=lw, ls=ls)

def scalebar(ax, color='white'):
    x1 = FIELD[0] / 2 - 150; ax.plot([x1 - 500, x1], [-FIELD[1] / 2 + 150] * 2, color=color, lw=2.5, solid_capstyle='butt')
    ax.text(x1 - 250, -FIELD[1] / 2 + 230, '500 nm', color=color, fontsize=7.5, ha='center', va='bottom')

# ------------------------------------------------------------------ 1. the model
comp, geo = scenes.ecoli_compartments()
rho = {k: mix({**v, 'H2O': max(0.0, 1 - sum(v.values()))})[1] for k, v in comp.items()}
fig = plt.figure(figsize=(13.0, 10.2)); gs = fig.add_gridspec(2, 2, hspace=0.22, wspace=0.36, width_ratios=[1, 1.15], top=0.93)
ax = fig.add_subplot(gs[0, 0]); px = 5.0
x = np.arange(-800, 800, px) + px / 2; y = np.arange(-1300, 1300, px) + px / 2; X, Y = np.meshgrid(x, y)
dcap = np.hypot(X, np.maximum(np.abs(Y) - HL, 0)); M = np.full(X.shape, 1.0)
M[dcap < R] = rho['envelope']; M[dcap < R - ENV] = rho['cytoplasm']; M[(np.abs(X) < RN) & (np.abs(Y) <= HL)] = rho['nucleoid']
im = ax.imshow(np.where(M > 1.0, M, np.nan), cmap=BLUES, vmin=1.088, vmax=1.098, extent=[x[0], x[-1], y[0], y[-1]], origin='lower')
ax.set_facecolor('#f4f4f2')
cb = fig.colorbar(im, ax=ax, fraction=0.05, pad=0.03, extend='both'); cb.set_label('density (g/cm$^3$); water = grey')
ax.annotate('envelope (OM + PG + IM, %.0f nm)' % ENV, xy=(R - 15, 650), xytext=(-760, 1180), fontsize=8, color=INK, arrowprops=dict(arrowstyle='-', color=INK2, lw=0.7))
ax.text(0, 0, 'nucleoid\n(DNA)', ha='center', va='center', fontsize=8, color='white'); ax.text(0, -760, 'cytoplasm', ha='center', va='center', fontsize=8, color=INK)
ax.set_xlabel('nm'); ax.set_ylabel('nm'); ax.set_title('a  Section through the cell axis (1 x 2 um capsule)')

# b: composition
ax = fig.add_subplot(gs[0, 1]); names = ['envelope', 'cytoplasm', 'nucleoid']; cols = {'protein': C6[0], 'RNA': C6[1], 'DNA': C6[3], 'lipid': C6[4], 'water': GRID}
for i, nm in enumerate(names):
    b = 0.0; v = dict(comp[nm]); v['water'] = 1 - sum(comp[nm].values())
    for part in ('protein', 'RNA', 'DNA', 'lipid', 'water'):
        ax.bar(i, v[part], bottom=b, color=cols[part], width=0.6, edgecolor='white', lw=0.8); b += v[part]
    ax.text(i, 1.02, f'{rho[nm]:.3f} g/cm$^3$', ha='center', fontsize=8.5, color=INK)
ax.set_xticks(range(3)); ax.set_xticklabels(names); ax.set_ylim(0, 1.1); ax.set_ylabel('volume fraction'); [ax.spines[s_].set_visible(False) for s_ in ('top', 'right')]
ax.legend(handles=[Rectangle((0, 0), 1, 1, color=cols[p]) for p in cols], labels=list(cols), frameon=False, fontsize=8, loc='center left', bbox_to_anchor=(1.0, 0.5))
ax.set_title('b  Composition per compartment (water 1.000 g/cm$^3$)')
# c: cell in the K-kit, to scale
ax = fig.add_subplot(gs[1, 0]); W = 4200
ax.add_patch(Rectangle((-W / 2, 0), W, 30, color='#8f8e89')); ax.add_patch(Rectangle((-W / 2, 30), W, TCH, color='#d8e8fb')); ax.add_patch(Rectangle((-W / 2, 30 + TCH), W, 30, color='#8f8e89'))
for x0, pos in ((-1300, 'top'), (0, 'mid'), (1300, 'bot')):
    zc = scenes.z_of(pos, R, TCH); ax.add_patch(Circle((x0, zc), R, color=C6[0], alpha=0.85)); ax.add_patch(Circle((x0, zc), R - ENV, color='#6da7ec'))
    ax.add_patch(Circle((x0, zc), RN, color='#256abf'))
    ax.text(x0, TCH + 330, {'top': 'touching the\ntop membrane', 'mid': 'mid-channel', 'bot': 'on the bottom\nmembrane'}[pos], ha='center', va='top', fontsize=8, color=INK)
ax.annotate('', xy=(-1950, 25), xytext=(-1950, -420), arrowprops=dict(arrowstyle='->', color=INK, lw=1.5)); ax.text(-1990, -250, 'e$^-$', fontsize=9, color=INK, ha='right')
ax.text(W / 2 + 40, 15, '30 nm SiN', fontsize=7.5, va='center', color=INK2); ax.text(W / 2 + 40, 1030, '2 um\nwater', fontsize=7.5, va='center', color=INK2)
ax.text(W / 2 + 40, 2045, '30 nm SiN', fontsize=7.5, va='center', color=INK2)
ax.text(0, -330, 'BSE, E-T and in-lens detectors (above)', ha='center', fontsize=7.5, color=INK2); ax.text(0, TCH + 690, 'STEM detector (below)', ha='center', fontsize=7.5, color=INK2)
ax.set_xlim(-W / 2 - 150, W / 2 + 650); ax.set_ylim(TCH + 760, -480); ax.set_aspect('equal'); ax.axis('off')
ax.set_title('c  Cross-sections in a 2 um K-kit at the three depths simulated')
# d: text
ax = fig.add_subplot(gs[1, 1]); ax.axis('off'); ax.set_title('d  Model and sources', loc='left')
lines = [('Cell', f'capsule, radius {R:.0f} nm, length {P["length"]:.0f} nm (1.3 um$^3$, exponential growth, rich medium)'),
         ('Dry mass', f'{P["dry_g_cm3"]:.3f} g per cm$^3$ of cell; 55 % protein, 20 % RNA, 10 % lipid, 3 % DNA, 12 % other'),
         ('Envelope', f'{ENV:.1f} nm (outer membrane, periplasm with peptidoglycan, inner membrane); all lipid and 20 % of the protein'),
         ('Nucleoid', f'central cylinder of radius {RN:.0f} nm in the straight part: all DNA, 30 % of the local RNA concentration'),
         ('Partial specific volumes', 'protein 0.73, nucleic acid 0.55, lipid 0.98 cm$^3$/g'),
         ('Geometry in the Monte Carlo', 'straight part = infinite rod (transverse profile); caps drawn from it by equal chord; sphere run as a check'),
         ('K-kit', '2 um channel, 2 x 30 nm SiN (a 1 um thick cell does not fit the 0.5 um channel)'),
         ('Sources', 'Neidhardt et al. 1990 (composition); BioNumbers (volume, dry mass); Matias et al. 2003 J Bacteriol 185:6112 (envelope)')]
yy = 0.95
for a_, b_ in lines:
    ax.text(0.0, yy, a_, fontsize=8.5, fontweight='bold', color=INK, transform=ax.transAxes, va='top')
    ax.text(0.0, yy - 0.045, b_, fontsize=8, color=INK2, transform=ax.transAxes, va='top', wrap=True); yy -= 0.118
fig.suptitle(f'E. coli model used in the Monte Carlo ({geo["volume_um3"]:.2f} um$^3$; all compartments ~1.09 g/cm$^3$, so the nucleoid has almost no contrast)', fontsize=11.5, fontweight='bold', color=INK, y=0.985)
fig.savefig(os.path.join(OUT, '1_ecoli_model.png'), dpi=160, bbox_inches='tight'); plt.close(fig)

# ------------------------------------------------------------------ 2. noise-free images, all signals, one scan at EBEST
tifs = {}
fig, axs = plt.subplots(len(SHOW), 3, figsize=(8.6, 3.0 * len(SHOW)), gridspec_kw=dict(hspace=0.10, wspace=0.05, top=0.95))
ext = [-FIELD[0] / 2, FIELD[0] / 2, -FIELD[1] / 2, FIELD[1] / 2]
for i, (k, lab) in enumerate(SHOW):
    imgs = []
    for p in POS:
        r = D[(EBEST, p)]; m, _ = bg_tot(r, k); imgs.append(100 * image(r, k) / m)
    v = max(np.percentile(np.abs(im), 99.5) for im in imgs); v = max(v, 0.2)
    for j, (p, im) in enumerate(zip(POS, imgs)):
        ax = axs[i, j]; h = ax.imshow(im, cmap='RdBu_r', vmin=-v, vmax=v, extent=ext, origin='lower'); ax.set_xticks([]); ax.set_yticks([])
        outline(ax); c0 = im[im.shape[0] // 2 - 5:im.shape[0] // 2 + 5, im.shape[1] // 2 - 5:im.shape[1] // 2 + 5].mean()
        ax.text(-FIELD[0] / 2 + 80, -FIELD[1] / 2 + 100, f'centre {c0:+.1f} %', fontsize=8, color=INK)
        if i == 0: ax.set_title(PNAME[p], fontsize=9.5)
        if j == 0: ax.set_ylabel(lab, fontsize=9)
        tifs[f'noise_free_{k}_{EBEST}kV_{p}_contrast_percent.tif'] = im.astype(np.float32)
    cb = fig.colorbar(h, ax=axs[i, :].tolist(), fraction=0.025, pad=0.02); cb.set_label('signal change (%)', fontsize=8)
fig.suptitle(f'Simulated E. coli, {EBEST} kV, all signals from the same scan, no noise\n(2 um water + 2 x 30 nm SiN; 20 nm pixels; dotted = true outline)',
             fontsize=10.5, fontweight='bold', color=INK, y=0.985)
fig.savefig(os.path.join(OUT, '2_ecoli_images_noise_free.png'), dpi=140, bbox_inches='tight'); plt.close(fig)

# ------------------------------------------------------------------ 3. what the microscope records (same scan, one dose)
DOSES = (2.0, 20.0)
rng = np.random.default_rng(11)
fig, axs = plt.subplots(len(SHOW), 6, figsize=(15.5, 2.95 * len(SHOW)), gridspec_kw=dict(hspace=0.10, wspace=0.04, top=0.95))
for i, (k, lab) in enumerate(SHOW):
    for jd, dose in enumerate(DOSES):
        for j, p in enumerate(POS):
            r = D[(EBEST, p)]; m, m2 = bg_tot(r, k); base = image(r, k); N = dose * PX[0] * PX[1]
            im = N * (m + base) + rng.normal(0, 1, base.shape) * np.sqrt(N * m2)
            tifs[f'noisy_{k}_{EBEST}kV_{p}_{int(dose)}e_per_nm2.tif'] = im.astype(np.float32)
            ims = gaussian_filter(im, 1.0); lo, hi = np.percentile(ims, [1, 99]); ax = axs[i, 3 * jd + j]
            ax.imshow(ims, cmap='gray', vmin=lo, vmax=hi, extent=ext, origin='lower'); ax.set_xticks([]); ax.set_yticks([])
            outline(ax, color=C6[3], lw=0.9)
            if i == 0: ax.set_title(f'{PNAME[p]}\n{dose:g} e/nm$^2$', fontsize=8.5)
            if j == 0 and jd == 0: ax.set_ylabel(lab, fontsize=8.5)
            if i == len(SHOW) - 1 and j == 2: scalebar(ax)
fig.suptitle(f'What the microscope would record: one E. coli, {EBEST} kV, all signals from one scan at 2 and 20 e/nm$^2$ '
             f'({gray_per_e_nm2(EBEST) * 2 / 1e6:.1f} and {gray_per_e_nm2(EBEST) * 20 / 1e6:.0f} MGy); 1 px display smoothing; orange = true outline',
             fontsize=10.5, fontweight='bold', color=INK, y=0.985)
fig.savefig(os.path.join(OUT, '3_ecoli_images_with_noise.png'), dpi=120, bbox_inches='tight'); plt.close(fig)

# ------------------------------------------------------------------ 4. depth cues and doses vs beam energy
import pandas as pd
rows = EA.summary(D); df = pd.DataFrame(rows)
# check of the equal-chord caps: sphere Monte Carlo vs rod profile at the cap centre
for q in rows:
    r = D[(q['E'], q['pos'])]; c = r['cap']['det'][q['det']]; core = r['cap']['rc'] < 150
    q['cap_centre_contrast_pct'] = float(100 * np.average(c['prof'][core], weights=1 / np.maximum(c['prof_err'][core], 1e-12) ** 2) / bg_tot(r, q['det'])[0])
df = pd.DataFrame(rows); df['gray_per_e_nm2'] = [gray_per_e_nm2(E) for E in df['E']]
df.to_csv(os.path.join(OUT, 'ecoli_table.csv'), index=False)
fig, axs = plt.subplots(2, 2, figsize=(12.5, 9.8), gridspec_kw=dict(hspace=0.38, wspace=0.30, top=0.92))
zpos = {p: scenes.z_of(p, R, TCH) - 30 for p in POS}; xs = np.array([zpos[p] for p in POS]); KV = dict(zip(ES, C6))
def kv_legend(ax, loc):
    return ax.legend(handles=[Line2D([], [], color=KV[E], lw=2) for E in ES], labels=[f'{E} kV' for E in ES], fontsize=8, frameon=False, loc=loc, title='beam energy', title_fontsize=8)
ax = axs[0, 0]
for E in ES:
    q = df[(df.E == E) & (df.det == 'BEDC')].set_index('pos').loc[list(POS)]
    ax.errorbar(xs, q['contrast_pct'], q['contrast_err_pct'], color=KV[E], marker='o', lw=2, capsize=3)
    q = df[(df.E == E) & (df.det == 'STEM_ADF')].set_index('pos').loc[list(POS)]
    ax.plot(xs, q['contrast_pct'], color=KV[E], marker='s', lw=1.3, ls='--')
ax.axhline(0, color=INK2, lw=0.6); ax.set_xlabel('cell centre depth below the top membrane (nm)'); ax.set_ylabel('contrast of the cell body (% of background)')
l1 = kv_legend(ax, 'upper right'); ax.add_artist(l1)
ax.legend(handles=[Line2D([], [], color=INK2, marker='o', lw=2), Line2D([], [], color=INK2, marker='s', lw=1.3, ls='--')], labels=['BSE (BED-C)', 'STEM ADF'],
          fontsize=8, frameon=False, loc='center right')
ax.set_ylim(-4.5, 7.5); ax.set_title('a  BSE falls with depth, STEM does not: depth from one scan')
[ax.spines[s_].set_visible(False) for s_ in ('top', 'right')]; ax.grid(color=GRID, lw=0.6)
ax = axs[0, 1]
for E in [e for e in ES if e >= 20]:
    for k, mk, ls, dx in (('STEM_ADF', 's', '--', -10), ('STEM_HAADF', '^', '-', 10)):
        q = df[(df.E == E) & (df.det == k)].set_index('pos').loc[list(POS)]
        ok = (np.isfinite(q['fit_ssig']) & (q['fit_ssig'] > 0) & (q['fit_ssig'] < 0.8 * q['fit_sig']) & (q['fit_sig'] < 590)).values
        ax.errorbar(xs[ok] + dx + 4 * (E - 25), q['fit_sig'].values[ok], q['fit_ssig'].values[ok], color=KV[E], marker=mk, ls=ls, lw=1.6, capsize=3)
ax.set_xlabel('cell centre depth below the top membrane (nm)'); ax.set_ylabel('edge blur sigma (nm), fit to the STEM profile'); ax.set_ylim(0, 300)
l1 = ax.legend(handles=[Line2D([], [], color=KV[E], lw=2) for E in ES if E >= 20], labels=[f'{E} kV' for E in ES if E >= 20], fontsize=8, frameon=False, loc='upper left', title='beam energy', title_fontsize=8)
ax.add_artist(l1)
ax.legend(handles=[Line2D([], [], color=INK2, marker='s', ls='--'), Line2D([], [], color=INK2, marker='^', ls='-')], labels=['STEM ADF', 'STEM HAADF'], fontsize=8, frameon=False, loc='upper center')
ax.set_title('b  STEM edges blur with depth (beam broadening)'); [ax.spines[s_].set_visible(False) for s_ in ('top', 'right')]; ax.grid(color=GRID, lw=0.6)
ax = axs[1, 0]; dets = [('BEDC', 'BSE (BED-C)'), ('STEM_BF100', 'STEM BF'), ('STEM_ADF', 'STEM ADF'), ('STEM_HAADF', 'STEM HAADF')]; DC = dict(zip([d for d, _ in dets], [C6[0], C6[1], C6[2], C6[3]]))
for k, lab in dets:
    q = df[(df.det == k) & (df.pos == 'top')].sort_values('E'); ax.plot(q['E'], q['rose50_e_nm2'], color=DC[k], marker='o', lw=2, label=lab)
    q = df[(df.det == k) & (df.pos == 'bot')].sort_values('E'); ax.plot(q['E'], q['rose50_e_nm2'], color=DC[k], marker='o', lw=1.2, ls=':', mfc='white')
ax.axhline(30, color=INK2, lw=1, ls='--'); ax.text(ES[0], 22, '0.3 e/A$^2$ per image: disputed live-cell\nSTEM dose (Kennedy 2016; de Jonge 2016)', fontsize=7.5, color=INK2, va='top')
ax.set_yscale('log'); ax.set_ylim(5, 3e5); ax.set_xlabel('beam energy (kV)'); ax.set_ylabel('dose for SNR 5 in a 50 x 50 nm element (e/nm$^2$)'); ax.set_xticks(ES)
h_, l_ = ax.get_legend_handles_labels(); h_ += [Line2D([], [], color=INK2, lw=2, marker='o'), Line2D([], [], color=INK2, lw=1.2, ls=':', marker='o', mfc='white')]
l_ += ['cell at the top', 'cell at the bottom']; ax.legend(h_, l_, fontsize=8, frameon=False, ncol=2, loc='upper right')
ax.set_title('c  Dose to see 50 nm detail of the cell body'); [ax.spines[s_].set_visible(False) for s_ in ('top', 'right')]; ax.grid(color=GRID, lw=0.6, which='both')
ax = axs[1, 1]
for k, lab in dets:
    q = df[(df.det == k) & (df.pos == 'top')].sort_values('E'); ax.plot(q['E'], q['dose_whole_cell_e_nm2'], color=DC[k], marker='o', lw=2, label=lab)
Eg = np.linspace(min(ES), max(ES), 50); lo_, hi_ = 200.0 / gray_per_e_nm2(Eg), 800.0 / gray_per_e_nm2(Eg)
ax.fill_between(Eg, lo_, hi_, color=GRID, lw=0); ax.plot(Eg, 350.0 / gray_per_e_nm2(Eg), color=INK2, lw=1, ls='--')
ax.text(Eg[2], hi_[2] * 1.5, 'lethal dose: D$_{10}$ of E. coli 0.35 kGy (dashed;\nTrampuz 2006), band 0.2-0.8 kGy', fontsize=8, color=INK2)
ax.set_yscale('log'); ax.set_ylim(5e-4, 20); ax.set_xlabel('beam energy (kV)'); ax.set_ylabel('dose to detect the whole cell, SNR 5 (e/nm$^2$)'); ax.set_xticks(ES)
ax.legend(fontsize=8, frameon=False, ncol=2, loc='upper left'); ax.set_title('d  Dose to detect the cell vs the lethal dose')
[ax.spines[s_].set_visible(False) for s_ in ('top', 'right')]; ax.grid(color=GRID, lw=0.6, which='both')
fig.suptitle('E. coli in a 2 um K-kit: depth cues and doses (Monte Carlo, shot-noise limit)', fontsize=11.5, fontweight='bold', color=INK, y=0.985)
fig.savefig(os.path.join(OUT, '4_ecoli_depth_and_dose.png'), dpi=150, bbox_inches='tight'); plt.close(fig)

# ------------------------------------------------------------------ 5. calibrated TIFFs for Fiji / Amira
zf = os.path.join(OUT, '5_ecoli_images_tiff.zip'); tmp = '/tmp/claude-0' if os.path.isdir('/tmp/claude-0') else '.'
with zipfile.ZipFile(zf, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, a in tifs.items():
        fn = os.path.join(tmp, name)
        tifffile.imwrite(fn, a, imagej=True, resolution=(1 / PX[0], 1 / PX[1]), metadata={'unit': 'nm', 'Info': name}); z.write(fn, name); os.remove(fn)
    z.write(os.path.join(OUT, 'ecoli_table.csv'), 'ecoli_table.csv')
print('written', sorted(os.listdir(OUT)))
print('Gy per e/nm2:', {E: f'{gray_per_e_nm2(E):.3g}' for E in ES})
