"""E. coli in a 2 um K-kit: per beam energy, position and detector -> background, central contrast of the cell body,
Rose dose (SNR 5 in a 50 x 50 nm element of the cell body), dose to detect the whole cell (SNR 5 over its projected area),
and the edge blur sigma (fit of a Gaussian-blurred projected cylinder to the transverse profile) as a depth cue."""
import numpy as np, pickle, glob, sys, json, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '..'))
from scipy.optimize import least_squares
from scipy.ndimage import gaussian_filter1d
from lcsem.mc.detectors import se_yield

DETS = ['BEDC', 'BSE_grazing', 'SE2', 'STEM_BF50', 'STEM_BF100', 'STEM_ADF', 'STEM_HAADF', 'STEM_all']
R0 = 500.0

def load():
    D = {}
    for f in glob.glob(os.path.join(HERE, 'out', 'EC_T2000_E*_*.pkl')):
        r = pickle.load(open(f, 'rb')); D[(int(r['E']), r['pos'])] = r
    return D

def m2_of(det, E, k):
    m2 = det['bg_var'] + det['bg_mean'] ** 2
    if k == 'SE2':
        s1 = float(se_yield(np.array([float(E)]))[0]); m2 = m2 + det['bg_mean'] + s1 * (1 + s1)
    return m2

def model(x, A, Ra, sig, c):
    """Gaussian-blurred chord length of a cylinder of radius Ra (the projected thickness), amplitude A, plus a constant c"""
    xf = np.linspace(-3000, 3000, 6001); ch = 2 * np.sqrt(np.clip(Ra ** 2 - xf ** 2, 0, None)) / (2 * Ra)
    ch = gaussian_filter1d(ch, max(sig, 0.5), mode='constant')
    return A * np.interp(np.abs(x), xf[3000:], ch[3000:]) + c

def fit_edge(r, k):
    t = r['rod']; d = t['det'][k]; x = t['xc']; p = d['prof']; e = np.maximum(d['prof_err'], 1e-12)
    m = x < 1500
    def res(q): return (model(x[m], *q) - p[m]) / e[m]
    A0 = p[x < 100].mean()
    try:
        o = least_squares(res, [A0, R0, 60.0, 0.0], bounds=([-np.inf, 300, 2.0, -np.inf], [np.inf, 800, 600, np.inf]), diff_step=1e-2)   # finite steps: the Gaussian kernel is not smooth in sigma at 1e-8
        J = np.asarray(o.jac, float); nrm = np.linalg.norm(J, axis=0); nrm[nrm == 0] = 1.0; Js = J / nrm       # column scaling: the parameters differ by 1e6 in scale
        cov = np.linalg.pinv(Js.T @ Js, rcond=1e-12) / np.outer(nrm, nrm) * max(1.0, (o.fun ** 2).sum() / max(1, m.sum() - 4))
        return dict(A=o.x[0], Ra=o.x[1], sig=o.x[2], c=o.x[3], sA=np.sqrt(cov[0, 0]), sRa=np.sqrt(cov[1, 1]), ssig=np.sqrt(cov[2, 2]),
                    chi2=float((o.fun ** 2).sum() / max(1, m.sum() - 4)))
    except Exception as ex:
        return dict(A=np.nan, Ra=np.nan, sig=np.nan, c=np.nan, sA=np.nan, sRa=np.nan, ssig=np.nan, chi2=np.nan)

def summary(D):
    rows = []
    for (E, pos), r in sorted(D.items()):
        for k in DETS:
            t = r['rod']['det'][k]; x = r['rod']['xc']; m2 = m2_of(t, E, k)
            bg = t['bg_mean'] + (float(se_yield(np.array([float(E)]))[0]) if k == 'SE2' else 0.0)   # SE: contrast against SE1 + SE2
            core = x < 150; dc = float(np.average(t['prof'][core], weights=1 / np.maximum(t['prof_err'][core], 1e-12) ** 2))
            edc = float(1 / np.sqrt((1 / np.maximum(t['prof_err'][core], 1e-12) ** 2).sum()))
            C = dc / bg if bg > 0 else np.nan
            rose50 = 25 * m2 / (dc ** 2 * 50 ** 2) if dc != 0 else np.inf                     # e/nm^2 for SNR 5 in 50 x 50 nm^2
            # whole cell: matched filter over the projected area (straight part: integral per length x 1000 nm; caps: sphere integral)
            L = 1000.0; sig_int = t['integral'] * L + r['cap']['det'][k]['integral']      # summed excess (signal per primary x nm^2)
            # matched-filter SNR^2 per unit dose = sum(delta^2)/m2 over the image; approximated from the profiles
            e = r['rod']['edges']; w = np.diff(e); I_rod = (t['prof'] ** 2 * w).sum() * 2 * L         # both sides of the axis
            ec = r['cap']['edges']; ann = np.pi * (ec[1:] ** 2 - ec[:-1] ** 2); I_cap = (r['cap']['det'][k]['prof'] ** 2 * ann).sum()
            snr2_per_dose = (I_rod + I_cap) / m2
            dose_cell = 25 / snr2_per_dose if snr2_per_dose > 0 else np.inf
            fe = fit_edge(r, k)
            rows.append(dict(E=E, pos=pos, det=k, bg_mean=bg, m2=m2, delta_centre=dc, delta_centre_err=edc, contrast_pct=100 * C,
                             contrast_err_pct=100 * edc / bg if bg > 0 else np.nan, rose50_e_nm2=rose50, dose_whole_cell_e_nm2=dose_cell,
                             integral_per_len=t['integral'], integral_err=t['err'], **{f'fit_{a}': b for a, b in fe.items()}))
    return rows

if __name__ == '__main__':
    D = load(); rows = summary(D)
    import pandas as pd
    df = pd.DataFrame(rows); df.to_csv(os.path.join(HERE, 'ecoli_table.csv'), index=False)
    pd.set_option('display.width', 250); pd.set_option('display.max_rows', 400)
    print(df[['E', 'pos', 'det', 'bg_mean', 'contrast_pct', 'contrast_err_pct', 'rose50_e_nm2', 'dose_whole_cell_e_nm2', 'fit_sig', 'fit_ssig', 'fit_Ra', 'fit_chi2']].round(4).to_string())
