"""Higher statistics for the straight part (transverse rod profiles) at one beam energy, in chunks with independent seeds;
merged with the first run in ec_figure.py (inverse-variance weighting). Usage: python3 ec_hi.py E pos1,pos2 nchunks"""
import numpy as np, sys, time, pickle, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
from lcsem.mc.engine import Sim, stack
from lcsem.mc import radial, scenes

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out')
S = Sim(['vac', 'SiN', 'H2O', 'protein', 'RNA', 'lipid', 'DNA'])
E = float(sys.argv[1]); poss = sys.argv[2].split(','); nch = int(sys.argv[3]); T = 2000.0
DET = ['BEDC', 'BSE_grazing', 'SE2', 'STEM_BF50', 'STEM_BF100', 'STEM_ADF', 'STEM_HAADF', 'STEM_all']
zb, lm = stack(S, [(T, 'H2O')]); R = scenes.ECOLI['radius']; t00 = time.time()
for pos in poss:
    zc = scenes.z_of(pos, R, T)
    for c in range(nch):
        fn = f'{OUT}/ECHI_T2000_E{int(E)}_{pos}_{c}.pkl'
        if os.path.exists(fn): continue
        zt = [(0.0, 700.0, 1500000, 10.0), (700.0, 1500.0, 400000, 25.0), (1500.0, 3000.0, 100000, 50.0)]
        rt = radial.transverse_profiles(S, zb, lm, scenes.ecoli_objects(S, zc, 'rod'), E, zt, detectors=DET, seed=int(9000 + E * 10 + 100 * c + len(pos)))
        pickle.dump(dict(E=E, pos=pos, zc=zc, T=T, rod=rt), open(fn, 'wb'))
        print(f'hi E{E:.0f} {pos} chunk {c}: BEDC {rt["det"]["BEDC"]["integral"]:.2f}+-{rt["det"]["BEDC"]["err"]:.2f} [{rt["sec"]:.0f}s, {time.time()-t00:.0f}s]', flush=True)
print('done', flush=True)
