# E. coli in a K-kit - Monte Carlo simulation (lcsem 0.2.1, `examples/ecoli`)

**Cell:** capsule 1 x 2 um (1.31 um3); envelope 33.7 nm (all lipid + 20 % of the protein), cytoplasm, nucleoid (all DNA).
Composition from Neidhardt et al. 1990 / BioNumbers; envelope thickness from Matias et al. 2003. All compartments are
1.09-1.10 g/cm3 (water 1.00), so the nucleoid has almost no contrast against the cytoplasm.

**K-kit:** a 1 um thick cell does not fit the 0.5 um channel, so a 2 um channel with 2 x 30 nm SiN was simulated, with the
cell touching the top membrane, mid-channel, or on the bottom membrane; 15, 20, 25 and 30 kV; all detectors from the same scan.

| file | content |
|---|---|
| 1_ecoli_model.png | the model: section, composition per compartment, the cell in the K-kit, parameters and sources |
| 2_ecoli_images_noise_free.png | 25 kV, six signals x three depths, contrast in % of the background |
| 3_ecoli_images_with_noise.png | what the microscope records at 2 and 20 e/nm2 (0.4 and 4 MGy) |
| 4_ecoli_depth_and_dose.png | depth cues (BSE vs STEM contrast, STEM edge blur) and doses vs kV, with the lethal dose |
| 5_ecoli_images_tiff.zip | all images as 32-bit TIFFs with nm calibration (Fiji / Amira) + table |
| ecoli_table.csv | per kV, depth and detector: background, contrast, dose for SNR 5 (50 nm detail / whole cell), edge-blur fit |

**Main numbers (25 kV):** BSE +5.0 % (top) -> +2.4 % (bottom); STEM BF -4 %, ADF -2.4 %, HAADF +2.3 % at every depth;
in-lens SE +0.3 % (useless without charging). STEM edge blur sigma 36-51 nm (top) -> 161-209 nm (bottom).
Dose for 50 nm detail (SNR 5): 37-43 e/nm2 (STEM ADF/HAADF), 230-950 e/nm2 (BSE). Dose to detect the whole cell: 0.1 e/nm2 (STEM).
1 e/nm2 at 25 keV deposits about 0.18 MGy in water; the D10 of E. coli is 0.35 kGy (0.002 e/nm2) - every useful image is
lethal, in line with de Jonge & Peckys, ACS Nano 10, 9061 (2016).

Rerun: `python ec_run.py 2000 25,15,20,30 bot,top,mid 1.0; python ec_hi.py 25 top,mid,bot 4; python ec_figure.py out_dir 25`
