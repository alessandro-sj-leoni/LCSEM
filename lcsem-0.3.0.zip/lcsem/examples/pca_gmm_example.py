"""Unsupervised multimodal segmentation of one frame of a finished `lcsem run`:
    python examples/pca_gmm_example.py out_12k 3 [icl|bic]
PCA of (thickness at two scales, SE at two scales, |grad T|), Gaussian mixture in PC space, number of classes by ICL
(separated phases; default) or BIC (finer levels). Prints the class table and writes <run>/<frame>_pca_classes.tif."""
import sys, glob, os, numpy as np, tifffile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from lcsem.multimodal import feature_stack, pca_gmm_segment, class_table, interpret
from lcsem.imageproc import denoise_nlm
out_dir, frame = sys.argv[1], int(sys.argv[2]); crit = sys.argv[3] if len(sys.argv) > 3 else 'icl'
fn = sorted(glob.glob(os.path.join(out_dir, f'*_{frame:02d}_*_maps.npz')))[0]; d = np.load(fn)
T, dark, valid, au, se = d['T'], d['dark'], d['valid'], d['au'], d['se']
if se.size == 0: raise SystemExit('no SE image for this frame')
ok = valid & np.isfinite(se) & np.isfinite(T)
se_dn, _ = denoise_nlm(se, ~ok)
X, names, maps = feature_stack(T, se_dn, ok)
out = pca_gmm_segment(X, ok, criterion=crit)
rows, lab = class_table(out['labels'], maps['T_fine'], maps['SE_fine'], maps['gradT'], ok); rows = interpret(rows)
print(f'{os.path.basename(fn)}: {out["ncomp"]} PCs explain {100*sum(out["explained"]):.0f} %; k = {out["k"]} by {crit.upper()}')
for k, ld in enumerate(out['loadings']): print(f'  PC{k+1} loadings: ' + ', '.join(f'{n} {l:+.2f}' for n, l in zip(names, ld)))
for r in rows:
    r['otsu_dark_frac'] = float(dark[(lab == r['cls']) & ok].mean())
    print(f"  class {r['cls']}: {100*r['area_frac']:5.1f} %  SE {r['se_mean']:6.1f}  T {r['T_median']:5.0f} nm (IQR {r['T_p25']:.0f}-{r['T_p75']:.0f})  |gradT| {r['grad_median']:.2f}  SE-dark(Otsu) {r['otsu_dark_frac']:.2f}  -> {r['tag']}")
tifffile.imwrite(os.path.join(out_dir, f'frame{frame:02d}_pca_classes_{crit}.tif'), lab.astype(np.int16), imagej=True, metadata={'Info': 'PCA+GMM classes ordered by thickness; -1 outside'})
