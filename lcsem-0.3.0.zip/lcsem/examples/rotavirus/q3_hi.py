"""High-statistics rotavirus profiles for the key configurations (chunks of 3 M primaries in the inner zone, merged)."""
import os
import numpy as np, sys, time, pickle, os
OUT = os.environ.get('LCSEM_EXAMPLE_OUT', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out')); os.makedirs(OUT, exist_ok=True)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
from lcsem.mc.engine import Sim, stack
from lcsem.mc import radial, scenes

S = Sim(['vac', 'SiN', 'H2O', 'Au', 'protein', 'RNA']); T = 500.0; zb, lm = stack(S, [(T, 'H2O')])
cases = [(15.0, 'TLP', 'top'), (15.0, 'TLP', 'mid'), (15.0, 'TLP', 'bot'), (25.0, 'TLP', 'top'), (25.0, 'TLP', 'mid'), (25.0, 'TLP', 'bot'),
         (15.0, 'DLP', 'top'), (25.0, 'DLP', 'top')]
nchunk = int(sys.argv[1]) if len(sys.argv) > 1 else 8; t00 = time.time()
for E, kind, pos in cases:
    Rout = scenes.rotavirus_layers(kind)[-1][0]; zc = scenes.z_of(pos, Rout, T); objs, _ = scenes.rotavirus_objects(S, kind, zc)
    zones = radial.zones_for(Rout, extra=(30, 150, 400), n=(3000000, 300000, 50000), bins=(2.0, 5.0, 10.0))
    acc = None
    for c in range(nchunk):
        r = radial.profiles(S, zb, lm, objs, E, zones, seed=int(900000 + E * 1000 + len(kind) * 100 + {'top': 0, 'mid': 1, 'bot': 2}[pos] * 10 + c))
        if acc is None: acc = r; W = {k: r['cnt'].copy() for k in r['det']}; continue
        for k, d in r['det'].items():
            a = acc['det'][k]; c0, c1 = acc['cnt'], r['cnt']; tot = np.maximum(c0 + c1, 1)
            a['prof_err'] = np.sqrt((c0 ** 2 * a['prof_err'] ** 2 + c1 ** 2 * d['prof_err'] ** 2)) / tot
            a['prof'] = (c0 * a['prof'] + c1 * d['prof']) / tot
            a['with_mean'] = (c0 * a['with_mean'] + c1 * d['with_mean']) / tot
            a['integral'] = (a['integral'] * (c) + d['integral']) / (c + 1); a['err'] = np.sqrt(a['err'] ** 2 * c ** 2 + d['err'] ** 2) / (c + 1)
            a['bg_mean'] = (a['bg_mean'] * c + d['bg_mean']) / (c + 1); a['bg_var'] = (a['bg_var'] * c + d['bg_var']) / (c + 1)
        acc['cnt'] = acc['cnt'] + r['cnt']
    acc.update(E=E, kind=kind, pos=pos, zc=zc, T=T, Rout=Rout, layers=scenes.rotavirus_layers(kind), nchunk=nchunk)
    pickle.dump(acc, open(OUT + f'/HI_T500_E{int(E)}_{kind}_{pos}.pkl', 'wb'))
    print(f'E{E:.0f} {kind} {pos} done [{time.time()-t00:.0f}s]', flush=True)
print('done', flush=True)
