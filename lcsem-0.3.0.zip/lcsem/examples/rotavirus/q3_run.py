"""Q3: rotavirus (TLP, DLP) in a K-kit with a 0.5 um channel and 30 nm SiN windows: per-detector images vs beam energy
and position (adsorbed on the top membrane, mid-channel, on the bottom membrane). Correlated sampling (same primaries with
and without the virus) gives the excess profiles; images at any dose follow in q3_images.py."""
import os
import numpy as np, sys, time, pickle, os
OUT = os.environ.get('LCSEM_EXAMPLE_OUT', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out')); os.makedirs(OUT, exist_ok=True)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
from lcsem.mc.engine import Sim, stack
from lcsem.mc import radial, scenes

os.makedirs(OUT, exist_ok=True)
S = Sim(['vac', 'SiN', 'H2O', 'Au', 'protein', 'RNA'])
T = float(sys.argv[1]) if len(sys.argv) > 1 else 500.0
Es = [float(e) for e in sys.argv[2].split(',')] if len(sys.argv) > 2 else [15.0, 20.0, 25.0, 30.0, 12.0]
kinds = sys.argv[3].split(',') if len(sys.argv) > 3 else ['TLP', 'DLP']
poss = sys.argv[4].split(',') if len(sys.argv) > 4 else ['top', 'mid', 'bot']
zb, lm = stack(S, [(T, 'H2O')]); t00 = time.time()
for E in Es:
    for kind in kinds:
        for pos in poss:
            Rout = scenes.rotavirus_layers(kind)[-1][0]
            zc = scenes.z_of(pos, Rout, T)
            objs, _ = scenes.rotavirus_objects(S, kind, zc)
            zones = radial.zones_for(Rout, extra=(30, 150, 400), n=(3000000, 600000, 150000), bins=(2.0, 5.0, 10.0))
            r = radial.profiles(S, zb, lm, objs, E, zones, seed=int(E * 100 + len(kind) * 7 + {'top': 0, 'mid': 1, 'bot': 2}[pos]))
            r.update(E=E, kind=kind, pos=pos, zc=zc, T=T, Rout=Rout, layers=scenes.rotavirus_layers(kind))
            pickle.dump(r, open(OUT + f'/V_T{int(T)}_E{int(E)}_{kind}_{pos}.pkl', 'wb'))
            d = r['det']
            print(f'T{T:.0f} E{E:.0f} {kind} {pos}: BEDC {d["BEDC"]["integral"]:8.1f}+-{d["BEDC"]["err"]:5.1f}  BF100 {d["STEM_BF100"]["integral"]:8.1f}+-{d["STEM_BF100"]["err"]:4.1f}  '
                  f'ADF {d["STEM_ADF"]["integral"]:8.1f}  HAADF {d["STEM_HAADF"]["integral"]:8.1f}  SE2 {d["SE2"]["integral"]:7.2f}  [{r["sec"]:.0f}s, {time.time()-t00:.0f}s]', flush=True)
print('done', flush=True)
