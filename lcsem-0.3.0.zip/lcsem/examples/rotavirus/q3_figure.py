"""Rotavirus (TLP / DLP) in a 0.5 um K-kit with 30 nm SiN windows: what BSE and STEM-in-SEM would show."""
import os
import numpy as np, pickle, glob, sys, json
OUT = os.environ.get('LCSEM_EXAMPLE_OUT', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out')); os.makedirs(OUT, exist_ok=True)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from lcsem.mc.radial import smooth_profile, render
from lcsem.mc import scenes
from q3_analyse import m2_bg

INK, INK2, GRID = '#0b0b0b', '#52514e', '#e4e3df'
COL = {'BEDC': '#2a78d6', 'STEM_BF100': '#eb6834', 'STEM_ADF': '#1baf7a', 'STEM_HAADF': '#eda100', 'SE2': '#e87ba4'}
LAB = {'BEDC': 'BSE (BED-C)', 'STEM_BF100': 'STEM BF <100 mrad', 'STEM_ADF': 'STEM ADF 100-400', 'STEM_HAADF': 'STEM HAADF >400', 'SE2': 'SE2'}
plt.rcParams.update({'font.size': 8.5, 'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'xtick.color': INK2, 'ytick.color': INK2, 'axes.titlesize': 9.5, 'axes.titleweight': 'bold'})
def style(ax):
    ax.grid(True, color=GRID, lw=0.6); ax.set_axisbelow(True)
    for s in ('top', 'right'): ax.spines[s].set_visible(False)

H = {}
for f in glob.glob(OUT + '/HI_T500_E*_*.pkl'):
    r = pickle.load(open(f, 'rb')); H[(int(r['E']), r['kind'], r['pos'])] = r
def prof(r, k, w=3.0):
    d = r['det'][k]; return smooth_profile(r['rc'], d['prof'], np.maximum(d['prof_err'], 1e-9), w)
def snr2(r, k, rmax=None):
    e = r['edges']; ann = np.pi * (e[1:] ** 2 - e[:-1] ** 2); p = prof(r, k); m = r['rc'] < (rmax or r['Rout'] + 30)
    return float((p[m] ** 2 * ann[m]).sum() / m2_bg(r, k))
def mc_quality(r, k):
    d = r['det'][k]; m = r['rc'] < r['Rout']; p = prof(r, k); return float(np.sqrt(np.mean((p[m] / np.maximum(d['prof_err'][m], 1e-12)) ** 2)))

rng = np.random.default_rng(3); PX = (2.0, 2.0); HALF = 110.0
def noisy(r, k, dose, detector_sigma=None, gain=None):
    """image of the virus on its background at a dose (e/nm^2): shot noise (compound Poisson), or the detector-limited noise
    of the K-kit 1 60k series (sigma 20.6 grey, gain 64.1 grey per keV/primary, at that series' pixel size)"""
    d = r['det'][k]; img = render(r['rc'], prof(r, k), PX, HALF); N = dose * PX[0] * PX[1]
    if detector_sigma is not None:     # detector-limited: signal in grey = gain * (bg + delta); noise sigma per 1.6 nm pixel, rescaled to 2 nm pixels
        s = detector_sigma * (1.6 / PX[0]); return gain * (d['bg_mean'] + img) + rng.normal(0, s, img.shape), gain * d['bg_mean']
    mean = N * (d['bg_mean'] + img); sd = np.sqrt(N * (d['bg_var'] + d['bg_mean'] ** 2))
    return mean + rng.normal(0, 1, img.shape) * sd, N * d['bg_mean']

fig = plt.figure(figsize=(14.0, 10.6)); gs = fig.add_gridspec(4, 6, height_ratios=[1.0, 1.0, 1.0, 1.05], hspace=0.55, wspace=0.35)
# a: layer model
ax = fig.add_subplot(gs[0, 0:2])
for kind, ls in (('TLP', '-'), ('DLP', '--')):
    L = scenes.rotavirus_layers(kind); r0 = 0.0; xs, pp, rn = [], [], []
    for (r1, fp, fr, lab) in L: xs += [r0, r1]; pp += [fp, fp]; rn += [fr, fr]; r0 = r1
    ax.plot(xs, pp, color='#2a78d6', ls=ls, lw=2, label=f'{kind} protein'); ax.plot(xs, rn, color='#eb6834', ls=ls, lw=2, label=f'{kind} dsRNA')
for (r1, fp, fr, lab) in scenes.rotavirus_layers('TLP'): ax.axvline(r1, color=GRID, lw=0.8)
ax.text(11, 0.27, 'core\n(RNA)', fontsize=7, color=INK2, ha='center'); ax.text(24, 0.72, 'VP2', fontsize=7, color=INK2, ha='center'); ax.text(30.5, 0.44, 'VP6', fontsize=7, color=INK2, ha='center')
ax.text(36.8, 0.72, 'VP7', fontsize=7, color=INK2, ha='center'); ax.text(44, 0.09, 'VP4 spikes', fontsize=7, color=INK2, ha='center')
ax.set_xlim(0, 52); ax.set_ylim(0, 0.9); ax.set_xlabel('radius (nm)'); ax.set_ylabel('volume fraction (rest: water)')
ax.set_title('a  Rotavirus model (SA11 stoichiometry)'); style(ax); ax.legend(fontsize=6.6, frameon=False, loc='upper left', ncol=1)
# b: contrast profiles
ax = fig.add_subplot(gs[0, 2:4])
for k in ('BEDC', 'STEM_BF100', 'STEM_HAADF'):
    for E, ls in ((15, '-'), (25, '--')):
        r = H.get((E, 'TLP', 'top'))
        if r is None or (k == 'BEDC' and E == 25): continue
        m = r['rc'] < 90; ax.plot(r['rc'][m], 100 * prof(r, k)[m] / r['det'][k]['bg_mean'], color=COL[k], ls=ls, lw=2, label=f'{LAB[k]}, {E} kV')
ax.axhline(0, color=INK2, lw=0.6); ax.axvline(50, color=GRID, lw=0.8); ax.text(51, 2.0, 'spike tips', fontsize=7, color=INK2)
ax.set_xlabel('distance from virus centre (nm)'); ax.set_ylabel('signal change (% of background)')
ax.set_title('b  TLP on the top membrane: contrast'); style(ax); ax.legend(fontsize=6.6, frameon=False, loc='lower right')
# c: dose for detection
ax = fig.add_subplot(gs[0, 4:6])
pos = ['top', 'mid', 'bot']; x = np.arange(3); w = 0.2
for j, (k, E) in enumerate((('BEDC', 15), ('STEM_BF100', 25), ('STEM_HAADF', 25), ('STEM_BF100', 15))):
    v = [25 / snr2(H[(E, 'TLP', p)], k) if (E, 'TLP', p) in H else np.nan for p in pos]
    ax.bar(x + (j - 1.5) * w, v, w * 0.9, color=COL[k], alpha=1.0 if E == 25 or k == 'BEDC' else 0.55, label=f'{LAB[k]}, {E} kV', edgecolor='white', linewidth=1)
ax.set_yscale('log'); ax.set_xticks(x); ax.set_xticklabels(['on top membrane', 'mid-channel', 'on bottom membrane'])
ax.set_ylabel('dose for detection, SNR 5 (e/nm$^2$)'); ax.set_title('c  TLP in 0.5 um water: dose to see one virus'); style(ax); ax.legend(fontsize=6.6, frameon=False, loc='upper left')
# d-f: noise-free images (excess) TLP top / mid / bot, BSE 15 kV and HAADF 25 kV
for i, p in enumerate(pos):
    for j, (k, E) in enumerate((('STEM_BF100', 25), ('STEM_HAADF', 25))):
        ax = fig.add_subplot(gs[1, i * 2 + j]); r = H[(E, 'TLP', p)]; img = 100 * render(r['rc'], prof(r, k, 4.0), PX, HALF) / r['det'][k]['bg_mean']
        v = np.max(np.abs(img)); ax.imshow(img, cmap='RdBu_r', vmin=-v, vmax=v, extent=[-HALF, HALF, -HALF, HALF])
        where = {'top': 'on top membrane', 'mid': 'mid-channel', 'bot': 'on bottom membrane'}[p]
        ax.set_title(f'{"d" if i == 0 else ("e" if i == 1 else "f")}  {p} - {"BF" if k == "STEM_BF100" else "HAADF"}', fontsize=8.2); ax.set_xticks([]); ax.set_yticks([])
        ax.text(-HALF + 6, -HALF + 8, f'{img.min() if k == "STEM_BF100" else img.max():+.1f} %', fontsize=7, color=INK)
# g-l: what the microscope would record
cases = [('g  BSE 15 kV, your 60k detector noise, 1 frame', 'BEDC', 15, 'top', None), ('h  BSE 15 kV, shot-noise limit, 10$^4$ e/nm$^2$', 'BEDC', 15, 'top', 1e4),
         ('i  STEM BF 25 kV, 100 e/nm$^2$', 'STEM_BF100', 25, 'top', 100), ('j  STEM HAADF 25 kV, 100 e/nm$^2$', 'STEM_HAADF', 25, 'top', 100),
         ('k  STEM HAADF 25 kV, 1000 e/nm$^2$', 'STEM_HAADF', 25, 'top', 1000), ('l  STEM BF 25 kV, 1000 e/nm$^2$, mid-channel', 'STEM_BF100', 25, 'mid', 1000)]
for n, (title, k, E, p, dose) in enumerate(cases):
    ax = fig.add_subplot(gs[2 + n // 3, (n % 3) * 2:(n % 3) * 2 + 2]); r = H[(E, 'TLP', p)]
    if dose is None: im, bg = noisy(r, k, 0, detector_sigma=20.6, gain=64.1)
    else: im, bg = noisy(r, k, dose)
    from scipy.ndimage import gaussian_filter
    ims = gaussian_filter(im, 1.0); lo, hi = np.percentile(ims, [1, 99])
    ax.imshow(ims, cmap='gray', vmin=lo, vmax=hi, extent=[-HALF, HALF, -HALF, HALF]); ax.set_xticks([]); ax.set_yticks([])
    ax.set_title(title, fontsize=8.2)
    circ = plt.Circle((0, 0), r['Rout'], fill=False, color='#eda100', lw=0.8, ls=':'); ax.add_patch(circ)
    ax.plot([HALF - 60, HALF - 10], [-HALF + 12] * 2, color='white', lw=2); ax.text(HALF - 35, -HALF + 18, '50 nm', color='white', fontsize=7, ha='center')
fig.suptitle('Rotavirus (triple-layered particle, ~100 nm) in a K-kit with a 0.5 um channel and 30 nm SiN windows - Monte Carlo prediction\n(row 2: STEM bright field and HAADF at 25 kV without noise; top / mid-channel / bottom membrane)', fontsize=10.5, fontweight='bold', color=INK)
fig.savefig(os.path.join(OUT, 'fig_Q3_rotavirus.png'), dpi=150, bbox_inches='tight')
# table
rows = []
for (E, kind, p), r in sorted(H.items()):
    row = dict(E_kV=E, particle=kind, position=p)
    for k in ('BEDC', 'STEM_BF100', 'STEM_ADF', 'STEM_HAADF', 'SE2'):
        pr = prof(r, k); row[f'{k}_centre_%'] = round(100 * float(np.mean(pr[r['rc'] < 8])) / r['det'][k]['bg_mean'], 2)
        row[f'{k}_dose_SNR5'] = round(25 / snr2(r, k), 1); row[f'{k}_mcQ'] = round(mc_quality(r, k), 1)
    rows.append(row)
import pandas as pd
df = pd.DataFrame(rows); df.to_csv(os.path.join(OUT, 'rotavirus_table.csv'), index=False); pd.set_option('display.width', 250); print(df.to_string(index=False))
