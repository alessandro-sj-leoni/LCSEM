# Rotavirus in a K-kit (0.5 um channel, 30 nm SiN windows) - Monte Carlo prediction

Model: group-A rotavirus (SA11 stoichiometry), spherically averaged layers (`lcsem/mc/scenes.py`, sources in the docstring):
core with dsRNA (18,555 bp) + VP1/VP3 (r < 22.5 nm), VP2 shell (to 25.5 nm), VP6 (to 35.25 nm), VP7 (to 38.25 nm), VP4 spike
layer (to 50 nm); protein 0.73 cm3/g, RNA 0.55 cm3/g, rest water. TLP 106.6 MDa (94.7 protein + 11.9 RNA), DLP 61.8 MDa.
Cell: SiN 30 nm | water 500 nm | SiN 30 nm (membrane bulging not included: more water lowers the STEM contrast).

```
python q3_run.py 500                  # all energies (12-30 kV), TLP/DLP, top/mid/bottom (~15 min)
python q3_hi.py 8                     # high statistics for the key cases (~20-40 min)
python q3_analyse.py; python q3_figure.py   # out/fig_Q3_rotavirus.png, out/rotavirus_table.csv
```

Single virus, detection at SNR 5 (matched filter, shot-noise limit), e/nm^2 (1 e/A^2 = 100 e/nm^2):

| particle, position | BSE 15 kV | STEM BF <100 mrad 15 kV | STEM BF 25 kV | STEM HAADF 25 kV |
|---|---|---|---|---|
| TLP on the top membrane | ~2,000 (contrast +2 %) | 240 (-2.9 %) | 120 (-2.2 %) | 220 (+2.2 %) |
| TLP mid-channel | ~10,000 | 320 | 120 | 420 |
| TLP on the bottom membrane | ~70,000 | 410 | 160 | 1,350 |
| DLP on the top membrane | ~3,300 | 400 | 220 | 380 |

The BSE numbers are lower bounds (the BSE contrast of a virus is at the level of the Monte Carlo noise even with 24 M
primaries per case). With the detector-limited noise of the K-kit 1 60k frames, a virus is invisible in one BSE frame.

Reading: unlabelled virions are a transmission (STEM) problem, not a BSE one - bright field at 20-30 kV detects a TLP
anywhere in the channel at ~1.2-1.6 e/A^2; HAADF is sharpest for virions adsorbed on the top membrane and blurs with depth
(a depth cue). 120 e/nm^2 at 25 kV deposits ~20 MGy in the water: expect to see a virion once or a few times, not a long movie.
For dynamics, label with Au (a 40 nm Au label gives ~200x the BSE signal of a whole TLP) or fix the particles.
