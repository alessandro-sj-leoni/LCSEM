import os
import numpy as np, pickle, glob, sys, json
OUT = os.environ.get('LCSEM_EXAMPLE_OUT', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out')); os.makedirs(OUT, exist_ok=True)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lcsem.mc.radial import smooth_profile
from lcsem.mc.detectors import se_yield

SE1 = lambda E: float(se_yield(np.array([E]))[0])
def m2_bg(r, k):
    d = r['det'][k]; m2 = d['bg_var'] + d['bg_mean'] ** 2
    if k in ('SE2', 'SE3'): m2 += d['bg_mean'] + SE1(r['E']) * (1 + SE1(r['E']))
    return m2

def load(T=500):
    R = {}
    for f in glob.glob(OUT + f'/V_T{T}_E*_*.pkl'):
        r = pickle.load(open(f, 'rb')); R[(int(r['E']), r['kind'], r['pos'])] = r
    return R

def prof(r, k, w=3.0):
    d = r['det'][k]; return smooth_profile(r['rc'], d['prof'], np.maximum(d['prof_err'], 1e-9), w)

def snr2_per_dose(r, k, rmax=None, w=3.0):
    """matched-filter detection SNR^2 per unit dose (e/nm^2), shot-noise limit, within rmax (default outer radius + 30 nm)"""
    e = r['edges']; ann = np.pi * (e[1:] ** 2 - e[:-1] ** 2); p = prof(r, k, w); rc = r['rc']; rmax = rmax or r['Rout'] + 30
    m = rc < rmax
    return float((p[m] ** 2 * ann[m]).sum() / m2_bg(r, k))

def prof_snr(r, k, rmax=None, w=3.0):
    """how well the MC itself determined the profile (signal / MC error within rmax)"""
    d = r['det'][k]; rc = r['rc']; rmax = rmax or r['Rout']; m = rc < rmax
    p = prof(r, k, w); e = d['prof_err'][m] / np.sqrt(2 * w / np.diff(r['edges'])[m])
    return float(np.sqrt(((p[m] / np.maximum(e, 1e-12)) ** 2).mean()))

if __name__ == '__main__':
    R = load()
    dets = ['BEDC', 'STEM_BF50', 'STEM_BF100', 'STEM_ADF', 'STEM_HAADF', 'SE2', 'BSE_grazing']
    rows = []
    for (E, kind, pos), r in sorted(R.items()):
        row = dict(E=E, kind=kind, pos=pos)
        for k in dets:
            s2 = snr2_per_dose(r, k); row[f'{k}_dose_SNR5'] = 25 / s2 if s2 > 0 else np.inf
            p = prof(r, k); bg = r['det'][k]['bg_mean']; row[f'{k}_center_contrast_%'] = 100 * float(np.mean(p[r['rc'] < 10])) / bg if bg else np.nan
            row[f'{k}_mcSNR'] = prof_snr(r, k)
        rows.append(row)
    import pandas as pd
    df = pd.DataFrame(rows); pd.set_option('display.width', 250); pd.set_option('display.max_columns', 60)
    print('dose (e/nm^2) for a single-particle detection SNR of 5 (matched filter, shot-noise limit)')
    print(df[['E', 'kind', 'pos'] + [f'{k}_dose_SNR5' for k in dets]].round(1).to_string(index=False))
    print('\ncentre contrast (%) of the virus in each detector')
    print(df[['E', 'kind', 'pos'] + [f'{k}_center_contrast_%' for k in dets]].round(2).to_string(index=False))
    print('\nMC profile SNR (quality of the simulation itself)')
    print(df[['E', 'kind', 'pos'] + [f'{k}_mcSNR' for k in dets]].round(1).to_string(index=False))
    df.to_csv(OUT + '/q3_table.csv', index=False)
