import os
import numpy as np, json, pickle, glob, sys
OUT = os.environ.get('LCSEM_EXAMPLE_OUT', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out')); os.makedirs(OUT, exist_ok=True)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from q1_analyse import smooth, m2_background, core_fraction, SE1

COL = {'BEDC': '#2a78d6', 'STEM_BF100': '#eb6834', 'STEM_ADF': '#1baf7a', 'STEM_HAADF': '#eda100', 'SE2': '#e87ba4', 'BSE_grazing': '#008300'}
LAB = {'BEDC': 'BSE (BED-C)', 'STEM_BF100': 'STEM BF <100 mrad', 'STEM_ADF': 'STEM ADF 100-400', 'STEM_HAADF': 'STEM HAADF >400', 'SE2': 'SE2 (in-lens/E-T)', 'BSE_grazing': 'grazing BSE (E-T, BSE mode)'}
LS = {'BEDC': '-', 'STEM_BF100': '--', 'STEM_ADF': '-.', 'STEM_HAADF': ':', 'SE2': (0, (5, 1, 1, 1)), 'BSE_grazing': (0, (1, 1))}
INK, INK2, GRID = '#0b0b0b', '#52514e', '#e4e3df'
plt.rcParams.update({'font.size': 8.5, 'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'xtick.color': INK2, 'ytick.color': INK2, 'axes.titlesize': 9.5, 'axes.titleweight': 'bold'})

def style(ax):
    ax.grid(True, color=GRID, lw=0.6); ax.set_axisbelow(True)
    for s in ('top', 'right'): ax.spines[s].set_visible(False)

A = json.load(open(OUT + '/A_thickness.json')); D = {(r['E'], r['T']): r for r in A}; Ts = sorted({r['T'] for r in A})
ref = D[(15, 200)]['det']['BEDC']['fisher']
def fisher(E, T, k):
    d = D[(E, T)]['det'][k]
    m2 = d['m2'] + (d['mean'] + SE1[E] * (1 + SE1[E]) if k in ('SE2', 'SE3') else 0.0)
    return d['slope'] ** 2 / m2 / ref

fig, axs = plt.subplots(2, 3, figsize=(13.2, 7.6))
for ax, E in zip(axs[0, :2], (15, 25)):
    for k in ('BEDC', 'STEM_BF100', 'STEM_ADF', 'STEM_HAADF', 'SE2', 'BSE_grazing'):
        y = np.array([fisher(E, T, k) for T in Ts]); y = np.where(y > 1e-3, y, np.nan)
        ax.plot(Ts, y, color=COL[k], ls=LS[k], lw=2, label=LAB[k])
    ax.set_xscale('log'); ax.set_yscale('log'); ax.set_ylim(1e-3, 200); ax.set_xlim(90, 2600)
    ax.axvspan(450, 1100, color='#f0efec', zorder=0); ax.text(700, 180, '0.5 um K-kit\n(+ bulge)', ha='center', va='top', fontsize=7, color=INK2)
    ax.set_xlabel('liquid thickness (nm)'); ax.set_ylabel('thickness information per electron\n(relative to BSE, 15 kV, 200 nm)')
    ax.set_title(f'{"a" if E == 15 else "b"}  Liquid thickness, {E} kV'); style(ax)
axs[0, 0].legend(loc='lower left', fontsize=6.8, frameon=False); axs[0, 1].legend(loc='lower left', fontsize=6.8, frameon=False)

# particle: amplitude and core fraction vs depth (40 nm Au, 500 nm liquid, 15 kV)
B = json.load(open(OUT + '/B_summary.json'))['E15_d40']; z = np.array(B['z'])
ax = axs[0, 2]
for k in ('BEDC', 'STEM_BF100', 'STEM_ADF', 'STEM_HAADF', 'SE2'):
    a = np.abs(np.array(B['A'][k])); ax.plot(z, a / a[0], color=COL[k], ls=LS[k], lw=2, marker='o', ms=4, label=LAB[k])
ax.set_xlabel('particle centre depth below the top membrane (nm)'); ax.set_ylabel('integrated particle signal (top = 1)'); ax.set_ylim(0, 1.45)
ax.set_title('c  40 nm Au in 500 nm liquid, 15 kV: amplitude'); style(ax); ax.legend(fontsize=6.8, frameon=False, loc='lower left')
ax.annotate('BSE / STEM-BF ratio falls 4x\ntop -> bottom: depth from one scan', xy=(420, 0.36), xytext=(230, 1.33), fontsize=7.5, color=INK, arrowprops=dict(arrowstyle='->', color=INK2, lw=0.8))

ax = axs[1, 0]
for k in ('BEDC', 'STEM_ADF', 'STEM_HAADF', 'SE2'):
    ax.plot(z, B['cf'][k], color=COL[k], ls=LS[k], lw=2, marker='o', ms=4, label=LAB[k])
ax.set_xlabel('particle centre depth below the top membrane (nm)'); ax.set_ylabel('core fraction  (signal in R+10 nm / in R+60 nm)')
ax.set_title('d  Same particle: image sharpness (beam broadening)'); style(ax); ax.legend(fontsize=7, frameon=False); ax.set_ylim(0, 1.1)

# gas pocket top vs bottom (profiles re-binned to 10 nm to suppress Monte Carlo noise)
ax = axs[1, 1]
def rebin(rc, p, w=10.0, lo=100, hi=520):
    e = np.arange(lo, hi + w, w); c = 0.5 * (e[1:] + e[:-1]); v = np.array([p[(rc >= a) & (rc < b)].mean() for a, b in zip(e[:-1], e[1:])]); return c, v
for k in ('BEDC', 'BSE_grazing', 'STEM_HAADF'):
    for w, lsw in (('top', '-'), ('bot', '--')):
        r = pickle.load(open(fOUT + '/C_E15_{w}.pkl', 'rb')); c, v = rebin(r['rc'], r['det'][k]['prof']); bg = r['det'][k]['bg_mean']
        ax.plot(c, 100 * v / bg, color=COL[k], ls=lsw, lw=2, label=f'{LAB[k].split(" (")[0]} - gas at {"top" if w == "top" else "bottom"}')
ax.axvline(300, color=INK2, lw=0.8, ls=':'); ax.text(305, 3, 'pocket edge', fontsize=7, color=INK2)
ax.set_xlabel('distance from pocket centre (nm)'); ax.set_ylabel('signal change (% of background)'); ax.set_ylim(-45, 8)
ax.set_title('e  Gas pocket (r 300 nm, 200 nm high), 15 kV'); style(ax); ax.legend(fontsize=6.6, frameon=False, loc='lower right')

# what each signal gives (text panel)
ax = axs[1, 2]; ax.axis('off')
txt = [('STEM (BF/ADF/HAADF)', 'liquid thickness: 10-60x more information per\nelectron than BSE below ~500 nm -> faster/gentler\nframes; BSE/STEM ratio -> particle depth'),
       ('BSE (BED-C)', 'particles (Z contrast) + their depth (amplitude\nand sharpness); thickness backup'),
       ('E-T in BSE mode (grazing)', 'surface-sensitive: gas at the top vs the bottom\nof sub-um pockets (-37 % vs -10 %)'),
       ('in-lens SE', 'charging-mediated contact map of the top\nmembrane (gas touching it); SE2 carries little'),
       ('all four, same scan', 'identical pixel times -> no loss of temporal\nresolution')]
y = 1.0
ax.text(0, y, 'f  What each signal adds', fontsize=9.5, fontweight='bold', color=INK, va='top')
for h, t in txt:
    y -= 0.075; ax.text(0, y, h, fontsize=8.2, fontweight='bold', color=INK, va='top'); y -= 0.04; ax.text(0.02, y, t, fontsize=7.6, color=INK2, va='top'); y -= 0.035 * (t.count('\n') + 1)
plt.tight_layout(); fig.savefig(os.path.join(OUT, 'fig_Q1_four_signals.png'), dpi=170); print('ok')
