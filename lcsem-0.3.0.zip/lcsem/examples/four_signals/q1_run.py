"""Q1: what do BSE, in-lens, E-T and STEM-in-SEM signals each contribute to 3D + time in a liquid cell?
A  thickness information per detector (Fisher information per primary) vs water thickness and beam energy
B  Au spheres (40, 60 nm) at five depths in a 500 nm cell: per-detector images -> depth information
C  gas pocket (R 300 nm, h 200 nm) touching the top vs the bottom membrane: per-detector edge profiles
"""
import os
import numpy as np, sys, json, time, pickle, os
OUT = os.environ.get('LCSEM_EXAMPLE_OUT', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out')); os.makedirs(OUT, exist_ok=True)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
from lcsem.mc.engine import Sim, stack, sphere, cylinder
from lcsem.mc.detectors import signals, DETECTORS
from lcsem.mc import radial, scenes

os.makedirs(OUT + '', exist_ok=True)
S = Sim(['vac', 'SiN', 'H2O', 'Au'])
which = sys.argv[1] if len(sys.argv) > 1 else 'ABC'
t00 = time.time()

if 'A' in which:
    res = []
    for E in (10, 12, 15, 20, 25, 30):
        for T in (100, 200, 300, 500, 800, 1000, 1500):
            D = max(20.0, 0.15 * T); n = 300000; st = {}
            for lab, TT in (('lo', T - D), ('c', T), ('hi', T + D)):
                zb, lm = stack(S, [(TT, 'H2O')]); o = S.go(np.zeros(n), np.zeros(n), np.arange(n) + 91, E, zb, lm)
                st[lab] = {k: (float(v.mean()), float(v.var()), float((v * v).mean())) for k, v in signals(o).items()}
            row = dict(E=E, T=T, D=D, det={})
            for k in st['c']:
                mu, var, m2 = st['c'][k]; sl = (st['hi'][k][0] - st['lo'][k][0]) / (2 * D)
                row['det'][k] = dict(mean=mu, var=var, m2=m2, slope=sl, fisher=sl * sl / max(m2, 1e-30))
            res.append(row); print(f'A E{E} T{T} [{time.time()-t00:.0f}s]', flush=True)
            json.dump(res, open(OUT + '/A_thickness.json', 'w'))

if 'B' in which:
    T = 500.0; zb, lm = stack(S, [(T, 'H2O')])
    for E in (15, 20, 25):
        for d in (40.0, 60.0):
            R = d / 2
            for depth in ('top', 125.0, 'mid', 375.0, 'bot'):
                zc = scenes.z_of(depth, R, T)
                zones = radial.zones_for(R, extra=(40, 150, 400), n=(700000, 300000, 100000), bins=(1.0, 4.0, 10.0))
                r = radial.profiles(S, zb, lm, [sphere(0, 0, zc, R, S.m('Au'))], E, zones, seed=int(1000 + E * 10 + d + zc))
                r.update(E=E, d=d, depth=depth, zc=zc, T=T)
                pickle.dump(r, open(fOUT + '/B_E{E}_d{int(d)}_{depth}.pkl', 'wb'))
                print(f'B E{E} d{d} {depth}: BEDC {r["det"]["BEDC"]["integral"]:.0f}  BF100 {r["det"]["STEM_BF100"]["integral"]:.0f}  ADF {r["det"]["STEM_ADF"]["integral"]:.0f}  HAADF {r["det"]["STEM_HAADF"]["integral"]:.0f} [{r["sec"]:.0f}s, {time.time()-t00:.0f}s]', flush=True)

if 'C' in which:
    T = 500.0; zb, lm = stack(S, [(T, 'H2O')]); Rg = 300.0; h = 200.0
    for E in (15, 20):
        for where in ('top', 'mid', 'bot'):
            obj = scenes.gas_pocket(S, Rg, h, where, T)
            zones = [(0.0, 200.0, 300000, 10.0), (200.0, 400.0, 1500000, 2.0), (400.0, 800.0, 300000, 10.0)]
            r = radial.profiles(S, zb, lm, obj, E, zones, seed=int(5000 + E * 10 + {'top': 0, 'mid': 1, 'bot': 2}[where]))
            r.update(E=E, where=where, Rg=Rg, h=h, T=T)
            pickle.dump(r, open(fOUT + '/C_E{E}_{where}.pkl', 'wb'))
            print(f'C E{E} {where}: BEDC {r["det"]["BEDC"]["integral"]:.0f}  BF100 {r["det"]["STEM_BF100"]["integral"]:.0f} [{r["sec"]:.0f}s, {time.time()-t00:.0f}s]', flush=True)
print('done', flush=True)
