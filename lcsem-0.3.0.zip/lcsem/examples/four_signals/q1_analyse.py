"""Analysis of the Q1 simulations: thickness information per detector, particle-depth information per detector,
top-vs-bottom discrimination of a gas pocket per detector."""
import os
import numpy as np, json, pickle, glob, sys
OUT = os.environ.get('LCSEM_EXAMPLE_OUT', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out')); os.makedirs(OUT, exist_ok=True)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
from scipy.ndimage import gaussian_filter1d
from lcsem.mc.detectors import se_yield

DETS = ['BEDC', 'BSE_axial', 'BSE_grazing', 'SE2', 'STEM_BF50', 'STEM_BF100', 'STEM_ADF', 'STEM_HAADF']
SE1 = {E: float(se_yield(np.array([E]))[0]) for E in (10, 12, 15, 20, 25, 30)}     # SE1 per primary at the entrance surface

def m2_background(r, k):
    d = r['det'][k]; m2 = d['bg_var'] + d['bg_mean'] ** 2
    if k in ('SE2', 'SE3'): m2 = m2 + d['bg_mean'] + SE1[int(r['E'])] * (1 + SE1[int(r['E'])])   # Poisson SE counts + SE1 background
    return m2

def smooth(r, k, w=2.0):
    e = r['edges']; p = r['det'][k]['prof'].copy(); fine = np.diff(e) < 1.5
    p[fine] = gaussian_filter1d(p[fine], w, mode='nearest'); return p

def depth_information(files, k):
    """Fisher information on the particle depth per unit dose (1/nm^2 per e/nm^2) from the full image of detector k,
    at each interior depth (finite differences between neighbouring depths); returns z, I"""
    R = sorted([pickle.load(open(f, 'rb')) for f in files], key=lambda r: r['zc'])
    e = R[0]['edges']; ann = np.pi * (e[1:] ** 2 - e[:-1] ** 2); zs = np.array([r['zc'] - 30 for r in R])
    P = np.array([smooth(r, k) for r in R]); m2 = m2_background(R[0], k)
    out = []
    for i in range(len(R)):
        j0, j1 = max(i - 1, 0), min(i + 1, len(R) - 1)
        dP = (P[j1] - P[j0]) / (zs[j1] - zs[j0])
        out.append(float((dP ** 2 * ann).sum() / m2))
    return zs, np.array(out)

def core_fraction(r, k, R, core=10, flux=60):
    e = r['edges']; ann = np.pi * (e[1:] ** 2 - e[:-1] ** 2); p = smooth(r, k); C = np.concatenate([[0], np.cumsum(p * ann)]); Ci = lambda x: np.interp(x, e, C)
    ra = R + flux; rin, rout = 1.33 * ra, min(2.2 * ra, e[-1]); bg = (Ci(rout) - Ci(rin)) / (np.pi * (rout ** 2 - rin ** 2))
    return (Ci(R + core) - np.pi * (R + core) ** 2 * bg) / (Ci(ra) - np.pi * ra ** 2 * bg), Ci(ra) - np.pi * ra ** 2 * bg

if __name__ == '__main__':
    res = {}
    print('B: Au particle in 500 nm water. Depth information per unit dose; sigma_z (nm) per particle at 1000 e/nm^2, mid depth')
    for E in (15, 20, 25):
        for d in (40, 60):
            files = glob.glob(fOUT + '/B_E{E}_d{d}_*.pkl')
            if len(files) < 5: continue
            line = f'E{E} d{d}: '; Itot = 0; Istem = 0; Ibse = 0; rr = {}
            for k in DETS:
                z, I = depth_information(files, k); Imid = I[len(I) // 2]; rr[k] = dict(z=z.tolist(), I=I.tolist())
                line += f'{k} {1/np.sqrt(1000*Imid) if Imid>0 else np.inf:6.0f} | '
                Itot += Imid
                if k.startswith('STEM'): Istem = max(Istem, Imid) if k != 'STEM_BF50' else Istem
                if k == 'BEDC': Ibse = Imid
            # a realistic STEM detector: BF100 + ADF + HAADF segments (disjoint), and the combination with BED-C
            Iseg = sum(np.array(rr[k]['I'])[len(rr[k]['I']) // 2] for k in ('STEM_BF100', 'STEM_ADF', 'STEM_HAADF'))
            print(line + f' || BED-C {1/np.sqrt(1000*Ibse):.0f}  STEM(3 seg) {1/np.sqrt(1000*Iseg):.0f}  BED-C+STEM {1/np.sqrt(1000*(Ibse+Iseg)):.0f}  all {1/np.sqrt(1000*Itot):.0f}')
            R_ = sorted([pickle.load(open(f, 'rb')) for f in files], key=lambda r: r['zc'])
            cf = {k: [core_fraction(r, k, d / 2) for r in R_] for k in ('BEDC', 'STEM_BF100', 'STEM_ADF', 'STEM_HAADF', 'SE2')}
            for k, v in cf.items():
                print(f'      {k:12s} CF ' + ' '.join(f'{c:5.2f}' for c, a in v) + '   A ' + ' '.join(f'{a:8.0f}' for c, a in v))
            res[f'E{E}_d{d}'] = dict(info=rr, z=[r['zc'] - 30 for r in R_], cf={k: [float(c) for c, a in v] for k, v in cf.items()}, A={k: [float(a) for c, a in v] for k, v in cf.items()})
    json.dump(res, open(OUT + '/B_summary.json', 'w'))
