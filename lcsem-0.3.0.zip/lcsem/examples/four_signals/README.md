# What BSE, in-lens SE, E-T and STEM-in-SEM each contribute to 3-D + time

Monte Carlo (lcsem.mc) for a K-kit cell (SiN 30 / water / SiN 30), detectors from `lcsem/mc/detectors.py`.

```
python q1_run.py ABC      # A thickness information vs T and kV; B Au particles at 5 depths; C gas pocket top vs bottom (~10 min)
python q1_analyse.py      # depth information per detector, core fractions, amplitudes
python q1_figure.py       # out/fig_Q1_four_signals.png
```

Results (per electron, shot-noise limit; relative numbers are what matter):

* **Liquid thickness**: STEM carries 10-60x more information per electron than BSE for T < ~500 nm (15 kV: BF<100 mrad 30x
  at 200 nm, 5x at 500 nm; 25 kV: 30x and 11x). At 0.5-1 um liquid use 20-25 kV and more than one STEM segment (each
  angular range has a thickness where its slope vanishes). SE2 and grazing BSE carry almost none (SE1 dominates the SE noise).
* **Particle depth** (40 nm Au, 500 nm liquid): BSE carries most of it (amplitude falls and the image blurs with depth);
  STEM adds 15-40 %; the BSE / STEM-BF amplitude ratio falls ~4x from top to bottom at 15 kV - a depth gauge from one scan.
* **Gas pockets** (r 300 nm, 200 nm high, 500 nm liquid): top vs bottom placement changes the BSE level inside the pocket
  (-34 % vs -25 %), the grazing BSE much more (-37 % vs -10 %: E-T in BSE mode is surface-sensitive), and the edge width in
  HAADF (28 nm vs 128 nm). For layers wider than ~2-3 um these differences vanish (checked: < 1 % at r = 3 um): the vertical
  position of wide flat layers is invisible to BSE and STEM; only the SE contact map (top) and edges tell.
* All four signals of one scan share the pixel times: no loss of temporal resolution.
