Example configurations for the K-kit 1 data set (JEOL JIB-4700F, 15 kV, 21 Aug 2026):
  kkit1_12k.json   12 000x series 10:19-10:28 (9 frames, fast scans, Si frame in view, SE = LED for the first 3 frames then UED)
  kkit1_60k.json   60 000x series 10:54-11:01 (7 frames, slow scans with mains interference, SE only for the first 4)
Adjust "folder" and "prefix" to where the images are, then:  lcsem run examples/kkit1_12k.json out_12k
Both configurations use the 38 nm Au depth curve (data/), run the PCA + GMM segmentation (SE frames) and write the Amira
volumes (out_12k/amira, README_AMIRA.txt inside). At 12k the 8-bit particle cores are saturated: no particle depths.
se_levels_example.py: SE-level vs thickness test on one frame of a finished run.

v0.2 examples:
  four_signals/    what BSE, in-lens SE, E-T and STEM-in-SEM each add (thickness, particle depth, gas pockets); Monte Carlo
  rotavirus/       a rotavirus (TLP/DLP) in a K-kit with a 0.5 um channel and 30 nm SiN windows; Monte Carlo prediction
  ecoli/           an E. coli cell (1 x 2 um capsule) in a 2 um K-kit, 15-30 kV, all detectors, depth cues, doses vs the lethal dose
  synthetic data:  lcsem simulate syn_out --curve data/curve_15kV_SiN30_H2O_BEDC_STEM100_Au60.json ; lcsem run syn_out_config.json syn_run
  validation:      lcsem validate val_out   (all option sets on synthetic ground truth; see docs/VALIDATION.md)
