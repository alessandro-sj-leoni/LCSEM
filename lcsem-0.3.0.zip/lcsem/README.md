# lcsem - quantitative, time-resolved 3-D liquid-cell SEM

Liquid thickness from BSE and/or STEM-in-SEM, gas contact from SE, gas elsewhere from a gap map, particles in x, y, z with
trajectories, per-pixel acquisition time, 3-D label volumes and 4-D stacks - frame by frame, for membrane liquid cells
(K-kit and similar) imaged in an SEM - from JEOL image series or SE/BSE/STEM movies, with a graphical interface
(`docs/GUI.md`) that shows the time-resolved 3-D volumes and exports them to Amira and 13 other formats
(`docs/EXPORT_FORMATS.md`). Physics, algorithms and references: `METHODS.md`. What to record and what each option gives:
`docs/OPTIONS.md`. Validation on synthetic ground truth: `docs/VALIDATION.md`, `docs/VALIDATION_DENOISING.md`. Publication
plan: `docs/PUBLICATION_PLAN.md`.

![lcsem GUI](docs/img/gui_12k.png)

## Install

```
conda env create -f environment.yml && conda activate lcsem     # everything: GUI, movies, all exports (Windows, macOS, Linux)
pip install -e ".[all]"     # the same with pip; ".[gui]" viewer only; "." core (numpy, scipy, scikit-image, scikit-learn, ...)
python -m pytest tests      # GUI test: needs a display (on a server: xvfb-run python -m pytest tests)
```

## Run

```
lcsem gui                                            # the graphical interface (or: lcsem gui RUN_DIR / PROJECT.json)
lcsem project my_project.json                        # run a project saved from the GUI, without the GUI
lcsem export out_dir --formats all                   # Amira, Fiji, OME-TIFF/Zarr, Imaris, ParaView, Slicer, ChimeraX, meshes, ...
lcsem objects out_dir                                # bubbles / objects: watershed, measurements, tracking
lcsem movie-info SE.tif BSE.tif                      # frames, size, frame rate, bit depth, duplicate frames of movies
lcsem simulate-movie synmovie --curve data/curve_15kV_SiN30_H2O_BEDC_STEM100_Au60.json   # synthetic SE/BSE/STEM movies + truth
lcsem list  /path/to/images --prefix 2026           # scans found: stage position, magnification, kV, channels
lcsem run   my_config.json out_dir                   # full pipeline
lcsem options                                        # what each optional acquisition/reference gives
lcsem mc-curve --E0 20 --detector BEDC stem:0:100 --particle 60 --out curve20.json    # Monte Carlo curves for your cell/detectors
lcsem simulate synthetic_out --curve data/curve_15kV_SiN30_H2O_BEDC_STEM100_Au60.json  # synthetic data set with ground truth
lcsem validate validation_out                        # every option set on synthetic ground truth (about 20 min)
lcsem segment out_dir --frames 3,6,8                # (re)compute the PCA + GMM segmentation of a finished run
lcsem amira   out_dir --bin 4 --dz 10                # Amira volumes (liquid/gas fractions; walls and Au particles = 1)
```

Configuration: one JSON file; everything has a default except `folder` and `pixel_nm`. Examples in `docs/OPTIONS.md` and
`examples/`. Missing Monte Carlo curves are computed on first use (a few minutes) and cached in `~/.lcsem/curves`.

## Outputs

Per frame: `*_liquid_nm.tif` (fused), `*_liquid_sigma_nm.tif`, `*_liquid_BSE_nm.tif` / `*_liquid_STEM_nm.tif` and `*_chi2.tif`
(two thickness channels), `*_gas_top_nm.tif` (SE), `*_gas_other_nm.tif` (gap map), `*_time_s.tif`, `*_labels.tif`
(0 vacuum, 1 membrane, 2 liquid, 3 gas at the top, 4 gas not at the top, 5 film, 7 outside window, 255 not imaged, 10+ particles),
`*_maps.npz`. Per run: `*_4D_liquid_nm.tif`, `*_4D_time_s.tif`, `*_4D_gas_top_nm.tif` (ImageJ hyperstacks), dynamics maps
(`*_dTdt_nm_per_s.tif`, `*_dry_*.tif`, `*_dry_boundary_disp_nm.tif`, `*_boundary_motion.csv`), `particles.csv` (x, y, z with
errors, per-channel photometry, core fractions), `tracks.csv`, `summary.csv`, `calibration_report.json`
(model used + consistency checks), `run_info.json`, `qc_overview.png`. All TIFFs open in Fiji with the nm calibration.
Segmentation (with an SE channel): `*_classes_icl.tif` / `_bic`, `*_class_prob_icl.tif` (probability per class),
`segmentation_classes.csv` (area, SE, thickness, gradient, overlap with the SE contact map, tag, stability of k),
`segmentation_overview.png`. Amira (option `amira`): `amira/` with `*_liquid_fraction.am`, `*_gas_fraction.am` (0-255 =
fraction of the voxel), `*_cell_walls.am` and `*_au_nps.am` (1 = wall / particle), `*_au_nps.surf`, landmarks, README_AMIRA.txt.
New in 0.3.0: dose columns in `summary.csv` (with the probe current), `lcsem_project.json` (the GUI settings of the run),
`objects.csv`, `object_tracks.csv`, `object_events.csv`, `*_objects.tif`, SE-only outputs (`*_se_contact.tif`,
`*_se_denoised.tif`), `export/` folders with one sub-folder per format and `export_manifest.csv`, and in `summary.csv` the
SE contact diagnostics (`se_detection_floor`, `se_contrast`, `se_background`, `se_contact_flag`, `se_signal`) and the gas
volume with its standard deviation (`gas_top_volume_um3`, `gas_top_volume_sd_um3`). Viewing a run writes nothing into its
folder: the binned 4-D model is cached per user (`LCSEM_CACHE_DIR`, default `~/.cache/lcsem` or `%LOCALAPPDATA%\lcsem\cache`).

## Use the pieces

```python
from lcsem.config import load_config
from lcsem.pipeline import run
from lcsem.calib import ChannelCurve, solve
from lcsem.depth import ParticleModel, measure
from lcsem.mc.engine import Sim, stack, sphere, cylinder
from lcsem.mc.radial import profiles          # images of any axisymmetric object for many detectors at once
from lcsem.mc import scenes                   # rotavirus and E. coli models, gas pockets
from lcsem.segment import segment_run         # PCA + GMM segmentation of a finished run
from lcsem.export_amira import export_run     # Amira export
from lcsem.volume4d import Volume4D           # the 4-D model of a run (what the GUI shows and the exports write)
from lcsem.export_formats import export_all   # all export formats
from lcsem import denoise, io_movie, objects  # denoisers, movie input and registration, bubbles/objects
from lcsem.gui.project import load_project, run_project   # GUI projects from scripts
```

## Citing

Cite the methods it is built on (numbered list in `METHODS.md`) and this software (`CITATION.cff`).
